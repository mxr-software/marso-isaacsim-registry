"""Marso Library for Isaac Sim.

Kit imports this package and finds ``MarsoLibraryExtension``. Outside Kit
(the unit tests) only ``marso.library.core`` is importable, so the Kit-side
import is skipped when ``omni`` is missing.
"""

try:
    import omni.ext  # noqa: F401
except ImportError:  # imported by plain Python for the core unit tests
    pass
else:
    from .extension import MarsoLibraryExtension, get_instance  # noqa: F401

"""Sim Studio inside the extension: the objects to test, runs in a separate Isaac Sim, progress, history.

A run never touches the user's stage: the extension writes a job, then starts Isaac Sim's own
standalone launcher (``python.bat``/``python.sh`` beside the app) on ``sim/runner.py`` in the
background and follows its progress lines. The user keeps working while it renders.
"""

from __future__ import annotations

import asyncio
import json
import os
import subprocess
import threading
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable

import carb
import carb.tokens

from . import settings
from .core import sim_job
from .core.controller import EVENT_JOB, JOB_FAILED, STATUS_REMOTE, LibraryController

EVENT_OBJECTS = "objects"
EVENT_PROGRESS = "progress"
EVENT_RUNS = "runs"

PHASE_IDLE = "idle"
PHASE_DOWNLOADING = "downloading"
PHASE_STARTING = "starting"
PHASE_RENDERING = "rendering"
PHASE_DONE = "done"
PHASE_FAILED = "failed"
PHASE_CANCELLED = "cancelled"

EXTENSION_ROOT = Path(__file__).resolve().parents[2]
RUNNER = EXTENSION_ROOT / "marso" / "library" / "sim" / "runner.py"
_NO_WINDOW = 0x08000000  # CREATE_NO_WINDOW: no console pops up on Windows


@dataclass
class RunState:
    phase: str = PHASE_IDLE
    folder: Path | None = None
    tests: list[str] = field(default_factory=list)
    test: str = ""
    frame: int = 0
    frames: int = 0
    done: list[str] = field(default_factory=list)
    message: str = ""

    @property
    def active(self) -> bool:
        return self.phase in (PHASE_DOWNLOADING, PHASE_STARTING, PHASE_RENDERING)

    @property
    def fraction(self) -> float:
        if not self.tests:
            return 0.0
        current = (self.frame / self.frames) if self.frames else 0.0
        return min(1.0, (len(self.done) + (current if self.test not in self.done else 0)) / len(self.tests))


def default_root(ctrl: LibraryController) -> Path:
    return ctrl.config.downloads_dir.parent / "Sim Studio"


class SimStudio:
    def __init__(self, ctrl: LibraryController) -> None:
        self.ctrl = ctrl
        self.objects: list[str] = []
        self.state = RunState()
        self._subscribers: list[Callable[[str, Any], None]] = []
        self._process: subprocess.Popen | None = None
        self._job_path: Path | None = None
        self._launcher: Path | None = None
        self._resumes_left = 0
        self._pending: dict | None = None
        self._loop = asyncio.get_event_loop()
        # A download that fails or is cancelled ends the wait for it.
        self._unsubscribe_ctrl = ctrl.subscribe(self._on_library_event)

    # --- subscribers ---------------------------------------------------------------------------

    def subscribe(self, fn: Callable[[str, Any], None]) -> Callable[[], None]:
        self._subscribers.append(fn)
        return lambda: self._subscribers.remove(fn) if fn in self._subscribers else None

    def _emit(self, topic: str, payload: Any = None) -> None:
        for fn in list(self._subscribers):
            try:
                fn(topic, payload)
            except Exception:  # noqa: BLE001 - a broken view must not break a render
                carb.log_error(f"Marso Sim Studio: subscriber failed on {topic}")

    # --- objects ---------------------------------------------------------------------------------

    def add(self, asset_ids: list[str]) -> None:
        for asset_id in dict.fromkeys(asset_ids):
            known = self.ctrl.library.asset(asset_id) is not None or asset_id in self.ctrl.local
            if known and asset_id not in self.objects:
                self.objects.append(asset_id)
        self._emit(EVENT_OBJECTS)

    def remove(self, asset_id: str) -> None:
        self.objects = [a for a in self.objects if a != asset_id]
        self._emit(EVENT_OBJECTS)

    def clear(self) -> None:
        self.objects = []
        self._emit(EVENT_OBJECTS)

    def name(self, asset_id: str) -> str:
        return self.ctrl.name_of(asset_id)

    # --- where things are ------------------------------------------------------------------------

    @property
    def root(self) -> Path:
        saved = settings.get(settings.KEY_SIM_DIR)
        return Path(os.path.expanduser(saved)) if saved else default_root(self.ctrl)

    @staticmethod
    def launcher() -> Path | None:
        override = os.environ.get("MARSO_ISAACSIM_PYTHON", "")
        if override and Path(override).is_file():
            return Path(override)
        app = carb.tokens.get_tokens_interface().resolve("${app}")
        return sim_job.find_launcher(Path(app)) if app else None

    def runs(self) -> list[sim_job.RunSummary]:
        return sim_job.list_runs(self.root)

    # --- running ---------------------------------------------------------------------------------

    def start(self, tests: list[str], options: dict, quality: str, aspect: str, branding: str, outro: bool) -> str | None:
        """Start a render of the chosen objects; returns a reason when it cannot start."""
        if self.state.active:
            return "A render is already running."
        if not self.objects:
            return "Add objects to test first."
        launcher = self.launcher()
        if launcher is None:
            return "Could not find Isaac Sim's python launcher next to this app."
        try:
            sim_job.build_job(assets=[{"name": "x", "asset_id": "x", "folder": ""}] * len(self.objects), tests=tests,
                              out_dir=self.root, extension_root=EXTENSION_ROOT)
        except ValueError as exc:
            return str(exc)
        self._pending = {"tests": tests, "options": options, "quality": quality, "aspect": aspect,
                         "branding": branding, "outro": outro, "launcher": launcher, "objects": list(self.objects)}
        missing = [a for a in self.objects if a not in self.ctrl.local]
        if missing:
            self.state = RunState(PHASE_DOWNLOADING, tests=list(tests), message=f"Downloading {len(missing)} object(s)...")
            self._emit(EVENT_PROGRESS, self.state)
            self.ctrl.request(missing, on_ready=lambda _local: self._maybe_launch())
            self._maybe_launch()
        else:
            self._launch()
        return None

    def _on_library_event(self, topic: str, _payload: Any) -> None:
        if topic == EVENT_JOB:
            self._maybe_launch()

    def _maybe_launch(self) -> None:
        if self._pending is None or self.state.phase != PHASE_DOWNLOADING:
            return
        objects = self._pending["objects"]
        # Failed, or no longer queued and still not on disk (the download was cancelled).
        failed = [a for a in objects if self.ctrl.status(a) in (JOB_FAILED, STATUS_REMOTE)]
        if failed:
            self.state.phase, self.state.message = PHASE_FAILED, f"Could not download {self.name(failed[0])}."
            self._pending = None
            self._emit(EVENT_PROGRESS, self.state)
        elif all(a in self.ctrl.local for a in objects):
            self._launch()

    def _launch(self) -> None:
        pending, self._pending = self._pending, None
        assets = [{"name": self.name(a), "asset_id": a, "folder": str(self.ctrl.local[a].folder)} for a in pending["objects"]]
        folder = sim_job.run_folder(self.root, [a["name"] for a in assets])
        job = sim_job.build_job(assets=assets, tests=pending["tests"], out_dir=folder, extension_root=EXTENSION_ROOT,
                                quality_key=pending["quality"], aspect=pending["aspect"], branding=pending["branding"],
                                options=pending["options"], outro=pending["outro"])
        self._job_path = sim_job.write_job(job)
        self._launcher = pending["launcher"]
        self._resumes_left = sim_job.RESUME_ATTEMPTS
        self.state = RunState(PHASE_STARTING, folder=folder, tests=list(job["tests"]), message="Starting Isaac Sim...")
        self._emit(EVENT_PROGRESS, self.state)
        self._spawn(append_log=False)

    def _spawn(self, append_log: bool) -> None:
        folder = self.state.folder
        command = (["cmd", "/c"] if os.name == "nt" else []) + [str(self._launcher), str(RUNNER), "--job", str(self._job_path)]
        log = (folder / "runner.log").open("a" if append_log else "w", encoding="utf-8", errors="replace")
        try:
            self._process = subprocess.Popen(
                command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace",
                env=sim_job.runner_env(dict(os.environ)), cwd=str(folder),
                creationflags=_NO_WINDOW if os.name == "nt" else 0, start_new_session=os.name != "nt",
            )
        except OSError as exc:
            log.close()
            self.state.phase, self.state.message = PHASE_FAILED, f"Could not start Isaac Sim: {exc}"
            self._emit(EVENT_PROGRESS, self.state)
            return
        threading.Thread(target=self._read, args=(self._process, log), daemon=True).start()

    def _read(self, process: subprocess.Popen, log) -> None:
        with log:
            for line in process.stdout:
                log.write(line)
                event = sim_job.parse_progress(line)
                if event is not None:
                    self._loop.call_soon_threadsafe(self._on_event, event)
        code = process.wait()
        self._loop.call_soon_threadsafe(self._on_exit, code)

    def _on_event(self, event: dict) -> None:
        state = self.state
        kind = event.get("event")
        if kind == "start":
            state.phase, state.message = PHASE_RENDERING, "Rendering..."
        elif kind == "test_start":
            state.test, state.frame, state.frames = event.get("test", ""), 0, int(event.get("frames") or 0)
            state.message = f"Rendering {sim_job.spec(state.test).title}..."
        elif kind == "frame":
            state.frame, state.frames = int(event.get("frame") or 0), int(event.get("frames") or state.frames)
        elif kind == "test_done":
            state.done.append(event.get("test", ""))
            self._emit(EVENT_RUNS)
        elif kind == "test_failed":
            state.done.append(event.get("test", ""))
            state.message = f"{sim_job.spec(event.get('test', 'scale')).title} failed: {event.get('error', '')}"
        elif kind == "done":
            state.phase = PHASE_DONE if event.get("status") == "done" else PHASE_FAILED
            state.message = "Finished." if state.phase == PHASE_DONE else "Finished with errors; see the report."
        self._emit(EVENT_PROGRESS, state)

    def _on_exit(self, code: int) -> None:
        self._process = None
        if self.state.phase in (PHASE_STARTING, PHASE_RENDERING) and self._resumes_left > 0 and self._job_path:
            # Isaac Sim stopped part way (python.bat reports even a crash as exit 0): go again from the
            # first unfinished test, keeping the videos already made.
            self._resumes_left -= 1
            carb.log_warn(f"Marso Sim Studio: Isaac Sim stopped part way (exit {code}); resuming {self.state.folder}")
            job = json.loads(self._job_path.read_text(encoding="utf-8"))
            job["resume"] = True
            self._job_path.write_text(json.dumps(job, indent=2), encoding="utf-8")
            self.state.phase, self.state.message = PHASE_STARTING, "Isaac Sim stopped; picking up where it left off..."
            self._emit(EVENT_PROGRESS, self.state)
            self._spawn(append_log=True)
            return
        if self.state.phase in (PHASE_STARTING, PHASE_RENDERING):
            self.state.phase = PHASE_FAILED
            self.state.message = f"Isaac Sim stopped unexpectedly (exit {code}). See runner.log in the run folder."
        self._emit(EVENT_PROGRESS, self.state)
        self._emit(EVENT_RUNS)

    def cancel(self) -> None:
        if self.state.phase == PHASE_DOWNLOADING:
            self._pending = None
            self.state.phase, self.state.message = PHASE_CANCELLED, "Cancelled."
            self._emit(EVENT_PROGRESS, self.state)
            return
        process = self._process
        if process is None:
            return
        self.state.phase, self.state.message = PHASE_CANCELLED, "Cancelled."
        try:
            if os.name == "nt":
                subprocess.run(["taskkill", "/F", "/T", "/PID", str(process.pid)], capture_output=True,
                               creationflags=_NO_WINDOW, check=False)
            else:
                os.killpg(process.pid, 15)
        except OSError:
            process.kill()
        self._emit(EVENT_PROGRESS, self.state)

    def shutdown(self) -> None:
        if self._process is not None:
            self.cancel()
        self._unsubscribe_ctrl()
        self._subscribers.clear()


def load_prefs() -> dict:
    try:
        data = json.loads(settings.get(settings.KEY_SIM_PREFS) or "{}")
    except ValueError:
        data = {}
    return data if isinstance(data, dict) else {}


def save_prefs(prefs: dict) -> None:
    settings.set_value(settings.KEY_SIM_PREFS, json.dumps(prefs))

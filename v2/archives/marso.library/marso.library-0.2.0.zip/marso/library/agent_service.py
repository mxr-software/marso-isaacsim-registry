"""The agent connection inside the extension: settings, the outbound link, and running commands on Kit's loop.

Off until the user switches on "Connect to Marso Agents" in the Settings tab. Then the extension connects
out to the Marso MCP with the account's API key (``core/agent_relay.py``), and agents signed in to the same
Marso account can put assets on this stage and film them in Sim Studio. Requests arrive on the link's
worker threads; each is checked against ``core/agent_policy.py`` there, validated against its command's
schema here, then run on Kit's loop, where the stage and the extension's services live.
"""

from __future__ import annotations

import asyncio
import concurrent.futures
import inspect
from pathlib import Path
from typing import Any, Callable

import carb
import omni.kit.app
import omni.usd

from . import agent_handlers, settings
from .core import agent_commands, agent_jobs, agent_relay
from .core.agent_commands import Command, ServiceError
from .core.controller import LibraryController
from .sim_service import SimStudio

COMMAND_TIMEOUT_S = 60.0  # a command on Kit's loop answers within this; slow work runs as a job
WATCH_INTERVAL_S = 1.0


def _error(code: str, message: str) -> dict[str, Any]:
    return {"ok": False, "error": {"code": code, "message": message}}


class AgentService:
    def __init__(self, ctrl: LibraryController, studio: SimStudio, *, addon_version: str) -> None:
        self.ctrl = ctrl
        self.studio = studio
        self.addon_version = addon_version
        self.jobs = agent_jobs.JobRegistry()
        self.registry = agent_commands.Registry()
        self.shared: dict[tuple[str, float], dict[str, Any]] = {}  # videos already sent to the chat
        self._loop = asyncio.get_event_loop()
        self._client: agent_relay.RelayClient | None = None
        self._subscribers: list[Callable[[dict[str, Any]], None]] = []
        self._watch: asyncio.Task | None = None
        self._last: tuple[str, str] | None = None
        self._problem = ""
        agent_handlers.register_all(self.registry, self)

    # --- settings ------------------------------------------------------------------------------

    @property
    def enabled(self) -> bool:
        return bool(settings.get_int(settings.KEY_AGENT_CONNECT, 0))

    @property
    def server(self) -> str:
        return agent_relay.current_endpoint(settings.get(settings.KEY_AGENT_SERVER))

    def apply_settings(self) -> str | None:
        """Connect or disconnect to match the settings; returns why it could not connect, or None."""
        if not self.enabled:
            self.stop()
            return None
        return self.start()

    # --- the link --------------------------------------------------------------------------------

    def start(self) -> str | None:
        self.stop()
        self._problem = ""
        api_key = self.ctrl.config.api_key
        if not api_key:
            self._problem = "Add your Marso API key first."
            self._notify()
            return self._problem
        try:
            client = agent_relay.RelayClient(
                self.server, api_key, addon_version=self.addon_version, app_version=_isaac_version(),
                label=_stage_label(), execute=self.execute,
            )
        except ValueError as exc:
            self._problem = str(exc)
            self._notify()
            return self._problem
        client.start()
        self._client = client
        self._ensure_watch()
        self._notify()
        return None

    def stop(self) -> None:
        client, self._client = self._client, None
        if client is not None:
            client.stop()
        self._notify()

    def shutdown(self) -> None:
        self.stop()
        if self._watch is not None:
            self._watch.cancel()
            self._watch = None
        self._subscribers.clear()

    @property
    def connected(self) -> bool:
        return self._client is not None and self._client.connected

    def upload(self, path: Path, name: str) -> dict[str, Any]:
        client = self._client
        if client is None:
            raise agent_relay.RelayError("Not connected to Marso Agents.")
        return client.upload(path, name)

    def status(self) -> dict[str, Any]:
        if self._client is not None:
            return self._client.status.snapshot()
        if self._problem:
            return {"state": "problem", "message": self._problem}
        return {"state": agent_relay.STATE_OFF, "message": "Off."}

    def subscribe(self, fn: Callable[[dict[str, Any]], None]) -> Callable[[], None]:
        self._subscribers.append(fn)
        return lambda: self._subscribers.remove(fn) if fn in self._subscribers else None

    def call_soon(self, fn: Callable, *args: Any) -> None:
        """Run ``fn`` on Kit's loop, from any thread."""
        self._loop.call_soon_threadsafe(fn, *args)

    # --- running a command -----------------------------------------------------------------------

    def execute(self, body: dict[str, Any]) -> tuple[int, dict[str, Any]]:
        """Run one checked request. Called on a link worker thread; Kit work hops onto Kit's loop."""
        name = body.get("command")
        params = body.get("params") if isinstance(body.get("params"), dict) else {}
        entry = self.registry.get(str(name))
        if entry is None:
            return 404, _error("unknown_command", f"Unknown command: {name}")
        errors = agent_commands.validate(entry.params, params)
        if errors:
            return 400, _error("invalid_params", "; ".join(errors))
        try:
            if entry.main_thread:
                future = asyncio.run_coroutine_threadsafe(self._invoke(entry, params), self._loop)
                result = future.result(timeout=COMMAND_TIMEOUT_S)
            else:
                result = entry.handler(params)
        except ServiceError as exc:
            return (409 if exc.code == "busy" else 422), _error(exc.code, str(exc))
        except concurrent.futures.TimeoutError:
            return 504, _error("timeout", "Isaac Sim did not finish the command in time; it may be busy.")
        except Exception as exc:  # noqa: BLE001 - report it; one bad command must not end the link
            carb.log_error(f"Marso agent command {name} failed: {exc}")
            return 500, _error("internal_error", str(exc) or type(exc).__name__)
        return 200, {"ok": True, "result": result}

    @staticmethod
    async def _invoke(entry: Command, params: dict[str, Any]) -> Any:
        result = entry.handler(params)
        if inspect.isawaitable(result):
            result = await result
        return result

    # --- telling the window ----------------------------------------------------------------------

    def _ensure_watch(self) -> None:
        if self._watch is None or self._watch.done():
            self._watch = self._loop.create_task(self._watch_status())

    async def _watch_status(self) -> None:
        while self._client is not None:
            self._notify()
            await asyncio.sleep(WATCH_INTERVAL_S)

    def _notify(self) -> None:
        status = self.status()
        key = (str(status.get("state")), str(status.get("message")))
        if key == self._last:
            return
        self._last = key
        for fn in list(self._subscribers):
            try:
                fn(status)
            except Exception:  # noqa: BLE001 - a broken view must not break the link
                carb.log_error("Marso agent connection: a status subscriber failed")


def _isaac_version() -> str:
    try:
        return str(omni.kit.app.get_app().get_app_version())
    except Exception:  # noqa: BLE001 - only a label
        return "unknown"


def _stage_label() -> str:
    stage = omni.usd.get_context().get_stage()
    path = stage.GetRootLayer().realPath if stage is not None else ""
    return Path(path).name if path else "Untitled stage"

"""Making new assets from the Create tab: the image, then 3D, PBR, the wait for the USD, the download.

The steps themselves are in ``core/creation.py``. This runs them on worker threads, keeps the image draft
and the runs in settings (so an unfinished run resumes on the next launch instead of being paid for
again) and hands a finished asset to the library: its project is merged into the listing, it downloads
and is prepared like any other asset, then ``on_finished`` adds it to the stage if that was ticked.

Workers own their own copy of a run; every change they make is posted back to the loop as a snapshot,
so the UI only ever reads objects the loop owns.
"""

from __future__ import annotations

import asyncio
import json
import logging
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Any, Callable

from . import settings
from .core import creation, http
from .core.controller import EVENT_JOB, JOB_FAILED, LibraryController
from .core.creation import Draft, Run, Waiter
from .core.storage import LocalAsset
from .core.studio_api import PROJECT_NAME, Prices, Studio, check_prompt

log = logging.getLogger("marso.library")

EVENT_DRAFT = "draft"
EVENT_RUNS = "runs"
EVENT_ACCOUNT = "account"

KEEP_RUNS = 20  # finished runs kept in the list (and in settings)
ACCOUNT_REFRESH_S = 120.0
FOLLOW_UP_SYNC_S = 180.0  # after a new asset arrives, sync once this much later if anything still needs it
_DRAFT = "__draft__"


class Creator:
    def __init__(self, ctrl: LibraryController, loop: asyncio.AbstractEventLoop | None = None) -> None:
        self.ctrl = ctrl
        self._loop = loop or asyncio.get_event_loop()
        self._executor = ThreadPoolExecutor(max_workers=4, thread_name_prefix="marso-create")
        self._subscribers: list[Callable[[str, Any], None]] = []
        self._waiters: dict[str, Waiter] = {}
        self._stopping: set[str] = set()  # runs the user asked to stop (rather than Isaac Sim closing)
        self._draft_token = 0  # bumped when the image is cleared or replaced: older jobs' news is ignored
        self.draft, self.runs = self._load()
        self.timing = creation.TIMING  # poll intervals and timeouts (tests shorten them)
        self.prices = Prices()
        self.credits = -1
        self.account_error = ""
        self._account_at = 0.0
        self._account_busy = False
        self._closed = False
        self.follow_up_s = FOLLOW_UP_SYNC_S
        self._follow_up: asyncio.TimerHandle | None = None
        # Set by the window: called on the loop once a new asset is downloaded (add to stage, show it).
        self.on_finished: Callable[[Run, LocalAsset], None] | None = None
        self._unsubscribe = ctrl.subscribe(self._on_library)

    # --- lifecycle -----------------------------------------------------------------------

    def start(self) -> None:
        """Carry on with whatever was unfinished when Isaac Sim last closed."""
        if self.draft.state == creation.DRAFT_WORKING:
            if self.draft.execution_id and self.draft.source == creation.SOURCE_PROMPT:
                self.generate_image(self.draft.prompt)
            else:  # an upload cannot resume; the user picks the file again
                self.draft.state, self.draft.message = creation.DRAFT_EMPTY, "The upload was interrupted; import the image again."
                self._changed(EVENT_DRAFT)
        for run in self.runs:
            if run.stage in (creation.STAGE_READY, creation.STAGE_DOWNLOADING):
                run.stage = creation.STAGE_LISTING  # list it again, then download
            if run.active:
                self._launch(run)

    def shutdown(self) -> None:
        self._closed = True
        if self._follow_up is not None:
            self._follow_up.cancel()
        self._unsubscribe()
        for waiter in self._waiters.values():
            waiter.stop()  # left at their step, to resume on the next launch
        self._executor.shutdown(wait=False, cancel_futures=True)

    def subscribe(self, fn: Callable[[str, Any], None]) -> Callable[[], None]:
        self._subscribers.append(fn)
        return lambda: self._subscribers.remove(fn) if fn in self._subscribers else None

    # --- state ---------------------------------------------------------------------------

    @property
    def draft_busy(self) -> bool:
        return self.draft.state == creation.DRAFT_WORKING

    @property
    def active_runs(self) -> list[Run]:
        return [run for run in self.runs if run.active]

    def run(self, run_id: str) -> Run | None:
        return next((run for run in self.runs if run.run_id == run_id), None)

    def blocked(self) -> str:
        """Why nothing can be made right now, or ""."""
        if not self.ctrl.config.has_api_key:
            return "Add your Marso API key in Settings first."
        return ""

    def can_afford(self, cost: int) -> bool:
        return self.credits < 0 or cost < 0 or self.credits >= cost

    @property
    def image_dir(self) -> Path:
        return self.ctrl.config.cache_dir / "creation"

    def studio(self) -> Studio:
        cfg = self.ctrl.config
        return Studio(cfg.api_key, cfg.api_endpoint)

    # --- the image -------------------------------------------------------------------------

    def generate_image(self, prompt: str) -> str:
        """Generate the draft's image from a prompt. Returns why it cannot, or ""."""
        problem = self.blocked() or check_prompt(prompt) or ("An image is already on its way." if self._waiters.get(_DRAFT) else "")
        if problem:
            return problem
        draft = Draft.from_dict(self.draft.to_dict())
        draft.state, draft.message = creation.DRAFT_WORKING, "Generating the image..."
        self.draft = Draft.from_dict(draft.to_dict())
        self._changed(EVENT_DRAFT)
        self._spawn_draft(lambda studio, waiter, save: creation.generate_image(studio, draft, prompt, self.image_dir,
                                                                             waiter, save, self.timing), draft)
        return ""

    def import_image(self, path: str) -> str:
        """Use the user's own picture as the draft's image. Returns why it cannot, or ""."""
        problem = self.blocked() or ("An image is already on its way." if self._waiters.get(_DRAFT) else "")
        if problem:
            return problem
        draft = Draft.from_dict(self.draft.to_dict())
        draft.state, draft.message = creation.DRAFT_WORKING, "Uploading the image..."
        self.draft = Draft.from_dict(draft.to_dict())
        self._changed(EVENT_DRAFT)
        self._spawn_draft(lambda studio, _waiter, save: creation.use_image(studio, draft, Path(path), self.image_dir, save),
                          draft)
        return ""

    def clear_image(self) -> None:
        self._draft_token += 1
        waiter = self._waiters.pop(_DRAFT, None)
        if waiter is not None:
            waiter.stop()
        keep = self.draft
        self.draft = Draft(project_id=keep.project_id, graph_id=keep.graph_id)
        self._changed(EVENT_DRAFT)

    def _spawn_draft(self, work: Callable, draft: Draft) -> None:
        self._draft_token += 1
        token = self._draft_token
        waiter = Waiter()
        self._waiters[_DRAFT] = waiter

        def save(item: Draft) -> None:
            self._post(self._draft_saved, token, item.to_dict())

        def job() -> None:
            try:
                work(self.studio(), waiter, save)
            except creation.Stopped:
                return
            except http.MarsoAuthError:
                self._post(self._draft_failed, token, draft.to_dict(), "Marso rejected the API key. Check it in Settings.")
            except creation.CreationError as exc:
                self._post(self._draft_failed, token, draft.to_dict(), str(exc))
            except (http.MarsoApiError, OSError, ValueError) as exc:
                self._post(self._draft_failed, token, draft.to_dict(), f"Could not make the image: {exc}")
            finally:
                self._post(self._draft_job_ended, token)
                self._post(self.refresh_account, True)

        self._executor.submit(job)

    def _draft_job_ended(self, token: int) -> None:
        if token == self._draft_token:
            self._waiters.pop(_DRAFT, None)

    def _draft_saved(self, token: int, raw: dict) -> None:
        if token != self._draft_token:
            return  # cleared or replaced meanwhile
        self.draft = Draft.from_dict(raw)
        self._changed(EVENT_DRAFT)

    def _draft_failed(self, token: int, raw: dict, message: str) -> None:
        if token != self._draft_token:
            return
        draft = Draft.from_dict(raw)
        # Keep a previous image if there was one; the user can try again or use it.
        draft.state = creation.DRAFT_READY if draft.image_asset_id and Path(draft.image_path).is_file() else creation.DRAFT_FAILED
        draft.execution_id, draft.message = "", message
        self.draft = draft
        self._changed(EVENT_DRAFT)

    # --- the asset ---------------------------------------------------------------------------

    def create_asset(self, add_to_stage: bool) -> str:
        """Make a 3D asset from the draft's image. Returns why it cannot, or ""."""
        problem = self.blocked()
        if not problem and (self.draft.state != creation.DRAFT_READY or not self.draft.image_asset_id):
            problem = "Make or import an image first."
        if problem:
            return problem
        run = creation.new_run(self.draft, add_to_stage)
        self.runs.insert(0, run)
        self._changed(EVENT_RUNS)
        self._launch(run)
        return ""

    def stop(self, run_id: str) -> None:
        """Stop waiting for a run. Marso carries on; the asset shows up in IsaacSim_AddOn after a sync."""
        waiter = self._waiters.get(run_id)
        run = self.run(run_id)
        if waiter is not None:
            self._stopping.add(run_id)
            waiter.stop()
        elif run is not None and run.stage == creation.STAGE_DOWNLOADING:
            self.ctrl.cancel(run.pbr_asset_id)
            self._mark(run, creation.STAGE_STOPPED, "Stopped. The asset is in Marso; download it from the Library.")

    def retry(self, run_id: str) -> None:
        run = self.run(run_id)
        if run is None or run.active:
            return
        creation.retry(run)
        self._changed(EVENT_RUNS)
        self._launch(run)

    def dismiss(self, run_id: str) -> None:
        self.runs = [run for run in self.runs if run.run_id != run_id or run.active]
        self._changed(EVENT_RUNS)

    def set_add_to_stage(self, run_id: str, value: bool) -> None:
        run = self.run(run_id)
        if run is not None:
            run.add_to_stage = bool(value)
            self._changed(EVENT_RUNS)

    def _launch(self, run: Run) -> None:
        if self._closed or run.run_id in self._waiters:
            return
        waiter = Waiter()
        self._waiters[run.run_id] = waiter
        work = Run.from_dict(run.to_dict())  # the worker's own copy

        def save(item: Run) -> None:
            self._post(self._run_saved, item.to_dict())

        def job() -> None:
            try:
                listed = creation.make_asset(self.studio(), work, waiter, save, self.timing)
            except creation.Stopped:
                self._post(self._run_stopped, work.to_dict())
                return
            except creation.CreationError:
                self._post(self.refresh_account, True)
                return  # make_asset saved the failure
            finally:
                self._post(self._waiters.pop, work.run_id, None)
            self._post(self._run_listed, work.to_dict(), listed)

        self._executor.submit(job)

    def _run_saved(self, raw: dict) -> None:
        saved = Run.from_dict(raw)
        if saved is None:
            return
        for index, run in enumerate(self.runs):
            if run.run_id == saved.run_id:
                saved.add_to_stage = run.add_to_stage  # the user may have changed it meanwhile
                self.runs[index] = saved
                self._changed(EVENT_RUNS)
                return

    def _run_stopped(self, raw: dict) -> None:
        run_id = raw.get("run_id", "")
        if run_id in self._stopping:  # the user's stop; on shutdown the run stays where it was, to resume
            self._stopping.discard(run_id)
            self._run_saved({**raw, "stage": creation.STAGE_STOPPED, "failed_stage": raw.get("stage", ""),
                             "message": f"Stopped waiting. Marso carries on; the asset will appear in {PROJECT_NAME} "
                                        "after a sync, or retry to wait again."})

    def _run_listed(self, raw: dict, listed) -> None:
        run = self.run(raw.get("run_id", ""))
        if run is None:
            return
        self._run_saved(raw)
        run = self.run(raw["run_id"])
        self.ctrl.merge_project(creation.name_new_asset(listed, run.pbr_asset_id, run.label))
        self._mark(run, creation.STAGE_DOWNLOADING, "Downloading...")
        self.ctrl.request([run.pbr_asset_id], on_ready=lambda local, run_id=run.run_id: self._downloaded(run_id, local))

    def _downloaded(self, run_id: str, local: LocalAsset) -> None:
        run = self.run(run_id)
        if run is None:
            return
        self._mark(run, creation.STAGE_DONE, "In your library" + (", and on the stage." if run.add_to_stage else "."))
        self.refresh_account(True)
        self._schedule_follow_up()
        if self.on_finished is not None:
            try:
                self.on_finished(run, local)
            except Exception:  # noqa: BLE001 - the asset is made; a failed hand-off must not lose the run
                log.exception("Marso: could not hand over the new asset")

    def _schedule_follow_up(self) -> None:
        """Sync once, a few minutes from now (a later new asset moves it on, so still once)."""
        if self._follow_up is not None:
            self._follow_up.cancel()
        self._follow_up = self._loop.call_later(self.follow_up_s, self._follow_up_sync)

    def _needs_follow_up(self) -> bool:
        """A new asset still without its picture, or assets Marso is still finishing."""
        library = self.ctrl.library
        created = [p for p in library.projects if p.name == PROJECT_NAME]
        missing = [a.asset_id for p in created for a in p.assets if self.ctrl.asset_thumbnail(a.asset_id) is None]
        return bool(missing) or library.unfinished > 0

    def _follow_up_sync(self) -> None:
        """Marso makes a new asset's thumbnail, and finishes other assets, a little after; without this they
        would only appear when the user next syncs. One sync, then the made assets' missing thumbnails."""
        self._follow_up = None
        if self._closed or not self.ctrl.config.has_api_key or not self._needs_follow_up():
            return
        task = self.ctrl.sync()
        if task is not None:
            task.add_done_callback(lambda _task: self._fetch_created_thumbnails())

    def _fetch_created_thumbnails(self) -> None:
        if self._closed:
            return
        created = [p for p in self.ctrl.library.projects if p.name == PROJECT_NAME]
        self.ctrl.fetch_thumbnails([a.asset_id for p in created for a in p.assets])

    def _on_library(self, topic: str, payload: Any) -> None:
        """A new asset's download failed: the run fails at listing, so a retry lists and downloads again."""
        if topic != EVENT_JOB:
            return
        job = self.ctrl.jobs.get(payload)
        if job is None or job.status != JOB_FAILED:
            return
        for run in self.runs:
            if run.pbr_asset_id == payload and run.stage == creation.STAGE_DOWNLOADING:
                run.failed_stage = creation.STAGE_LISTING
                self._mark(run, creation.STAGE_FAILED, f"The download failed: {job.error} Retry to try again.")

    def _mark(self, run: Run, stage: str, message: str) -> None:
        run.stage, run.message, run.updated_at = stage, message, time.time()
        if stage == creation.STAGE_FAILED:
            run.error = message
        self._changed(EVENT_RUNS)

    # --- account ---------------------------------------------------------------------------

    def refresh_account(self, force: bool = False) -> None:
        """Fetch prices and the credit balance in the background (at most every two minutes unless forced)."""
        if self._closed or self._account_busy or not self.ctrl.config.has_api_key:
            return
        if not force and time.time() - self._account_at < ACCOUNT_REFRESH_S:
            return
        self._account_busy = True
        studio = self.studio()

        def job() -> None:
            try:
                prices, credits = studio.prices(), studio.credits()
            except (http.MarsoApiError, OSError, ValueError) as exc:
                self._post(self._account_done, None, -1, f"Could not read prices and credits: {exc}")
                return
            self._post(self._account_done, prices, credits, "")

        self._executor.submit(job)

    def _account_done(self, prices: Prices | None, credits: int, error: str) -> None:
        self._account_busy = False
        self._account_at = time.time()
        if prices is not None:
            self.prices, self.credits = prices, credits
        self.account_error = error
        self._emit(EVENT_ACCOUNT, None)

    # --- plumbing ----------------------------------------------------------------------------

    def _post(self, fn: Callable, *args) -> None:
        if not self._closed or fn in (self._run_saved, self._draft_saved):
            try:
                self._loop.call_soon_threadsafe(fn, *args)
            except RuntimeError:  # the loop has closed
                pass

    def _changed(self, topic: str) -> None:
        self._save()
        self._emit(topic, None)

    def _emit(self, topic: str, payload: Any) -> None:
        for fn in list(self._subscribers):
            try:
                fn(topic, payload)
            except Exception:  # noqa: BLE001 - one broken subscriber must not stop the others
                log.exception("Marso creation subscriber failed")

    def _load(self) -> tuple[Draft, list[Run]]:
        try:
            raw = json.loads(settings.get(settings.KEY_CREATION) or "{}")
        except ValueError:
            raw = {}
        raw = raw if isinstance(raw, dict) else {}
        runs = [run for run in (Run.from_dict(item) for item in raw.get("runs") or []) if run is not None]
        return Draft.from_dict(raw.get("draft")), runs

    def _save(self) -> None:
        done = [run for run in self.runs if not run.active]
        keep = [run for run in self.runs if run.active or run in done[:KEEP_RUNS]]
        self.runs = keep
        payload = {"draft": self.draft.to_dict(), "runs": [run.to_dict() for run in keep]}
        settings.set_value(settings.KEY_CREATION, json.dumps(payload))

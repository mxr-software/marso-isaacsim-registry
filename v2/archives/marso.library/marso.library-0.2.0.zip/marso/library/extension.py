"""Extension entry point: wires the controller, the window, the menu item and the USD command."""

from __future__ import annotations

import weakref
from typing import Callable

import omni.ext
import omni.kit.actions.core
import omni.kit.app
import omni.ui as ui
from omni.kit.menu.utils import MenuItemDescription, add_menu_items, refresh_menu_items, remove_menu_items

from . import settings, usd_inspect, usd_ops
from .core import controller as ctl
from .core import http
from .agent_service import AgentService
from .core.controller import LibraryController
from .creation_service import Creator
from .sim_service import SimStudio
from .ui.window import TAB_SETTINGS, WINDOW_TITLE, MarsoWindow

MENU_PARENT = "Window"
MENU_NAME = "Marso Library"
ACTION_ID = "toggle_marso_library"

_instance: "MarsoLibraryExtension | None" = None


def get_instance() -> "MarsoLibraryExtension | None":
    """The running extension (for scripts and tests)."""
    return _instance


def _weak(method: Callable) -> Callable:
    """Wrap a bound method so whoever stores the callback does not keep its object alive."""
    ref = weakref.WeakMethod(method)

    def call(*args, **kwargs):
        target = ref()
        return target(*args, **kwargs) if target is not None else None

    return call


class MarsoLibraryExtension(omni.ext.IExt):
    """Browse your Marso library, download assets and add them to the stage."""

    def on_startup(self, ext_id: str) -> None:
        global _instance
        self._ext_id = ext_id
        manager = omni.kit.app.get_app().get_extension_manager()
        self.version = str(manager.get_extension_dict(ext_id).get("package", {}).get("version", "0.0.0"))
        source = f"marso-isaacsim/{self.version}"
        http.user_agent = source
        usd_ops.register_commands()

        self.controller = LibraryController(settings.resolve, prepare_fn=usd_inspect.prepare, source=source)
        self.controller.start()
        self._synced = False
        # Kit holds these callbacks; weak ones let the extension object go when it is disabled.
        self.studio = SimStudio(self.controller)
        self.creator = Creator(self.controller)
        self.agent = AgentService(self.controller, self.studio, addon_version=self.version)
        self.window = MarsoWindow(self.controller, self.version, on_visibility_changed=_weak(self._visibility_changed),
                                  studio=self.studio, creator=self.creator, agent=self.agent)
        self.creator.start()  # carries on with assets that were being made when Isaac Sim last closed
        if self.agent.enabled:
            self.agent.start()  # the user switched on the agent connection in an earlier session

        ui.Workspace.set_show_window_fn(WINDOW_TITLE, _weak(self.show))
        omni.kit.actions.core.get_action_registry().register_action(
            ext_id, ACTION_ID, _weak(self.toggle), display_name=MENU_NAME, description="Show or hide the Marso Library"
        )
        self._menu = [
            MenuItemDescription(
                name=MENU_NAME,
                ticked=True,
                ticked_fn=_weak(self.is_visible),
                onclick_action=(ext_id, ACTION_ID),
            )
        ]
        add_menu_items(self._menu, MENU_PARENT)
        _instance = self
        if settings.visible_on_startup():
            self.show(True)

    def on_shutdown(self) -> None:
        global _instance
        _instance = None
        remove_menu_items(self._menu, MENU_PARENT)
        omni.kit.actions.core.get_action_registry().deregister_all_actions_for_extension(self._ext_id)
        ui.Workspace.set_show_window_fn(WINDOW_TITLE, None)
        if self.window is not None:
            self.window.destroy()
            self.window = None
        self.agent.shutdown()
        self.studio.shutdown()
        self.creator.shutdown()
        self.controller.shutdown()
        usd_ops.unregister_commands()

    # --- window --------------------------------------------------------------------------

    def show(self, visible: bool = True) -> None:
        if self.window is not None:
            self.window.show(visible)

    def is_visible(self) -> bool:
        return self.window is not None and self.window.visible

    def toggle(self, *_args) -> None:
        self.show(not self.is_visible())

    def _visibility_changed(self, visible: bool) -> None:
        refresh_menu_items(MENU_PARENT)
        if visible and not self._synced and self.controller.config.has_api_key:
            self._synced = True  # one automatic sync per session; the refresh button does the rest
            self.controller.sync()
        elif visible and self.controller.sync_state.status == ctl.SYNC_NO_KEY:
            self.window.show_tab(TAB_SETTINGS)

"""Making a new asset in Marso, one step at a time, so a restart can carry on where it stopped.

The steps, as in the Marso Blender add-on's Create panel:

1. An image: generated from a prompt (one object on a plain background), or the user's own picture.
2. A 3D mesh from that image (Hunyuan 3D 3.1, 500k polygons).
3. PBR materials on the mesh. The PBR result is the asset.
4. Wait until Marso has minted the result's USD: the finished USDZ with Marso's description, real name
   and physics (``enriched_status`` "succeeded"). A basic USDZ (mesh and textures only) exists as soon
   as step 3 finishes; the Blender add-on downloads that one. Here the asset only enters the library
   once the finished one exists, so it arrives sim-ready.
5. Wait until the library listing shows the asset in the IsaacSim_AddOn project, so the library can
   download it like any other.

A ``Draft`` is the image being worked on (steps 1); a ``Run`` is one asset being made from a draft's
image (steps 2-5). Each records every id it is given (nodes, runs, assets) as soon as it has it, and
``save`` is called after every change: the host persists it, and on the next launch an unfinished step
polls the run it already started instead of starting (and paying for) another. A step that fails can be
retried on its own; earlier steps' results are kept.

Kit-free: everything here blocks, so the host calls it from a worker thread, with a ``Waiter`` whose
``sleep`` raises ``Stopped`` when the user stops the run or Isaac Sim shuts down.
"""

from __future__ import annotations

import time
import uuid
from collections.abc import Callable
from dataclasses import asdict, dataclass, field, fields, replace
from pathlib import Path
from typing import Any

from . import api, http
from .studio_api import (
    IMAGE_OUTPUT,
    NODE_GENERATE_3D,
    NODE_GENERATE_PBR,
    NODE_IMAGE,
    NODE_IMAGE_GENERATION,
    PROJECT_NAME,
    TEXTURE_OUTPUT,
    Studio,
    StudioProject,
)

# Run stages, in order.
STAGE_MESH = "mesh"
STAGE_PBR = "pbr"
STAGE_MINTING = "minting"  # waiting for Marso to mint the USD
STAGE_LISTING = "listing"  # waiting for the library listing to show the asset
STAGE_READY = "ready"  # in Marso with its USD: the host downloads it
STAGE_DOWNLOADING = "downloading"
STAGE_DONE = "done"
STAGE_FAILED = "failed"
STAGE_STOPPED = "stopped"  # the user stopped waiting (Marso carries on)
ACTIVE_STAGES = (STAGE_MESH, STAGE_PBR, STAGE_MINTING, STAGE_LISTING, STAGE_READY, STAGE_DOWNLOADING)
STAGE_LABELS = {
    STAGE_MESH: "Generating the 3D mesh",
    STAGE_PBR: "Making PBR materials",
    STAGE_MINTING: "Marso is finishing it: description, name and physics",
    STAGE_LISTING: "Adding it to your library",
    STAGE_READY: "Ready to download",
    STAGE_DOWNLOADING: "Downloading",
    STAGE_DONE: "Done",
    STAGE_FAILED: "Failed",
    STAGE_STOPPED: "Stopped",
}

# Draft states.
DRAFT_EMPTY = "empty"
DRAFT_WORKING = "working"  # generating or uploading its image
DRAFT_READY = "ready"  # has an image
DRAFT_FAILED = "failed"

SOURCE_PROMPT = "prompt"
SOURCE_UPLOAD = "upload"


@dataclass(frozen=True)
class Timing:
    """How often to poll each step and how long to wait before giving up, in seconds."""

    image_poll: float = 5.0
    image_timeout: float = 900.0
    mesh_poll: float = 15.0
    mesh_timeout: float = 1800.0
    pbr_poll: float = 10.0
    pbr_timeout: float = 1800.0
    mint_poll: float = 15.0
    mint_timeout: float = 2700.0
    list_poll: float = 10.0
    list_timeout: float = 600.0
    output_tries: int = 5  # a finished run's result can take a moment to appear on its node
    output_interval: float = 2.0


TIMING = Timing()


class CreationError(Exception):
    """A step failed, with a message for the user."""


class RunFailed(CreationError):
    """Marso ran the step and it failed: a retry needs a fresh node and run."""


class Stopped(Exception):
    """The run was asked to stop waiting (by the user, or because Isaac Sim is closing)."""


@dataclass
class Draft:
    """The image a new asset will be made from."""

    state: str = DRAFT_EMPTY
    prompt: str = ""
    label: str = ""  # a short name for the asset: the prompt's start, or the image file's name
    source: str = ""  # SOURCE_PROMPT or SOURCE_UPLOAD
    project_id: str = ""
    graph_id: str = ""
    node_id: str = ""  # the image (or image-generation) node the 3D step links from
    row: int = -1  # its row in the project graph's layout
    execution_id: str = ""  # an image generation in progress
    image_asset_id: str = ""
    image_path: str = ""  # a local copy, for the preview
    message: str = ""

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, raw: Any) -> Draft:
        return _from_dict(cls, raw) or cls()


@dataclass
class Run:
    """One asset being made from a draft's image."""

    run_id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])
    label: str = ""
    prompt: str = ""
    project_id: str = ""
    graph_id: str = ""
    row: int = 0
    source_node_id: str = ""
    image_asset_id: str = ""
    image_path: str = ""
    add_to_stage: bool = False
    stage: str = STAGE_MESH
    execution_id: str = ""  # the current step's run, once started
    mesh_node_id: str = ""
    mesh_asset_id: str = ""
    pbr_node_id: str = ""
    pbr_asset_id: str = ""  # the new asset
    failed_stage: str = ""  # the step to retry, after a failure
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)
    message: str = ""
    error: str = ""

    @property
    def active(self) -> bool:
        return self.stage in ACTIVE_STAGES

    @property
    def project(self) -> StudioProject:
        return StudioProject(self.project_id, self.graph_id, PROJECT_NAME)

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, raw: Any) -> Run | None:
        return _from_dict(cls, raw)


def _from_dict(cls, raw: Any):
    if not isinstance(raw, dict):
        return None
    names = {f.name for f in fields(cls)}
    try:
        return cls(**{key: value for key, value in raw.items() if key in names})
    except TypeError:
        return None


class Waiter:
    """Sleeps between polls; ``stop()`` (from any thread) makes the next or current sleep raise ``Stopped``."""

    def __init__(self, clock: Callable[[], float] = time.monotonic, sleeper: Callable[[float], None] | None = None) -> None:
        import threading

        self._event = threading.Event()
        self._clock = clock
        self._sleeper = sleeper

    def stop(self) -> None:
        self._event.set()

    @property
    def stopped(self) -> bool:
        return self._event.is_set()

    def now(self) -> float:
        return self._clock()

    def sleep(self, seconds: float) -> None:
        if self._sleeper is not None:
            self._sleeper(seconds)
            if self._event.is_set():
                raise Stopped()
            return
        if self._event.wait(seconds):
            raise Stopped()

    def check(self) -> None:
        if self._event.is_set():
            raise Stopped()


SaveFn = Callable[[Any], None]


def label_for(prompt: str = "", path: str = "") -> str:
    """A short name for a new asset: the prompt's first words, else the image file's name."""
    if prompt.strip():
        words = " ".join(prompt.split())
        return words if len(words) <= 40 else words[:37].rstrip() + "..."  # the UI font has no ellipsis glyph
    return Path(path).stem.replace("_", " ").strip() if path else "New asset"


# --- the image -----------------------------------------------------------------------------


def generate_image(studio: Studio, draft: Draft, prompt: str, image_dir: Path, waiter: Waiter, save: SaveFn,
                   timing: Timing = TIMING) -> Draft:
    """Generate the draft's image from a prompt (or resume a generation already started)."""
    prompt = " ".join(prompt.split())
    if draft.execution_id and draft.prompt != prompt:
        draft.execution_id = ""  # an unfinished run for another prompt: start afresh
    project = _project(studio, draft)
    if not draft.execution_id:
        # Always a new node: running a node that has already run returns its old result.
        draft.row = studio.next_row(project)
        draft.node_id = studio.create_node(project, NODE_IMAGE_GENERATION, 0, draft.row)
        studio.set_generation_mode(project, draft.node_id)
        draft.source, draft.prompt, draft.label = SOURCE_PROMPT, prompt, label_for(prompt)
        draft.image_asset_id, draft.image_path = "", ""
        draft.state, draft.message = DRAFT_WORKING, "Generating the image..."
        save(draft)
        draft.execution_id = _call(studio.start_image, project, draft.node_id, prompt)
        save(draft)
    execution = _wait(studio, draft.execution_id, "Image generation", timing.image_poll, timing.image_timeout, waiter,
                      lambda status: _note(draft, save, f"Generating the image ({status.lower()})..."))
    image_id = _output(studio, project, draft.node_id, IMAGE_OUTPUT, waiter, timing)
    if not image_id:
        raise CreationError("The image finished but Marso did not return it.")
    draft.execution_id, draft.image_asset_id = "", image_id
    draft.image_path = str(_save_image(studio, image_id, image_dir))
    draft.state, draft.message = DRAFT_READY, "Image ready." if execution.status == "SUCCEEDED" else "Image ready (partly)."
    save(draft)
    return draft


def use_image(studio: Studio, draft: Draft, path: Path, image_dir: Path, save: SaveFn) -> Draft:
    """Upload the user's own picture as the draft's image."""
    from .studio_api import check_image

    path = Path(path)
    problem = check_image(path)
    if problem:
        raise CreationError(problem)
    project = _project(studio, draft)
    draft.state, draft.message, draft.execution_id = DRAFT_WORKING, "Uploading the image...", ""
    save(draft)
    image_id = _call(studio.upload_image, path)
    draft.row = studio.next_row(project)
    draft.node_id = studio.create_node(project, NODE_IMAGE, 0, draft.row)
    studio.set_node_image(project, draft.node_id, image_id)
    copy = Path(image_dir) / f"{image_id}{path.suffix.lower()}"
    copy.parent.mkdir(parents=True, exist_ok=True)
    copy.write_bytes(path.read_bytes())
    draft.source, draft.prompt, draft.label = SOURCE_UPLOAD, "", label_for(path=str(path))
    draft.image_asset_id, draft.image_path = image_id, str(copy)
    draft.state, draft.message = DRAFT_READY, "Image ready."
    save(draft)
    return draft


def new_run(draft: Draft, add_to_stage: bool) -> Run:
    """A run for the draft's current image."""
    if draft.state != DRAFT_READY or not draft.image_asset_id:
        raise CreationError("Make or import an image first.")
    return Run(label=draft.label, prompt=draft.prompt, project_id=draft.project_id, graph_id=draft.graph_id,
               row=draft.row, source_node_id=draft.node_id, image_asset_id=draft.image_asset_id,
               image_path=draft.image_path, add_to_stage=add_to_stage, message=STAGE_LABELS[STAGE_MESH] + "...")


# --- the asset ------------------------------------------------------------------------------


def make_asset(studio: Studio, run: Run, waiter: Waiter, save: SaveFn, timing: Timing = TIMING) -> api.Project:
    """Carry a run from wherever it is to STAGE_READY; returns the listing's entry for its project.

    Raises CreationError (the run is marked failed, with the step to retry) or Stopped (left as it is,
    to resume later; the host marks it stopped if the user asked).
    """
    project = run.project
    try:
        if run.stage == STAGE_MESH:
            _mesh(studio, run, project, waiter, save, timing)
        if run.stage == STAGE_PBR:
            _pbr(studio, run, project, waiter, save, timing)
        if run.stage == STAGE_MINTING:
            _minting(studio, run, waiter, save, timing)
        if run.stage in (STAGE_LISTING, STAGE_READY):
            listed = _listing(studio, run, project, waiter, save, timing)
            _advance(run, save, STAGE_READY, "In Marso, with its USD.")
            return listed
    except http.MarsoAuthError as exc:
        _fail(run, save, "Marso rejected the API key. Check it in Settings, then retry.")
        raise CreationError(run.error) from exc
    except (http.MarsoApiError, OSError, ValueError) as exc:  # the network, or Marso, failed us mid-step
        _fail(run, save, f"Lost contact with Marso ({exc}). Retry to carry on from this step.")
        raise CreationError(run.error) from exc
    except CreationError as exc:
        if isinstance(exc, RunFailed):  # a retry starts this step afresh
            run.execution_id = ""
            if run.stage == STAGE_MESH:
                run.mesh_node_id = ""
            elif run.stage == STAGE_PBR:
                run.pbr_node_id = ""
        _fail(run, save, str(exc))
        raise
    raise CreationError(f"Nothing to do for a run that is {run.stage}.")


def _fail(run: Run, save: SaveFn, message: str) -> None:
    """Mark a run failed at its current step, which a retry repeats (keeping a run already started)."""
    run.failed_stage, run.stage, run.error, run.message = run.stage, STAGE_FAILED, message, message
    _touch(run, save)


def retry(run: Run) -> Run:
    """Set a failed or stopped run to repeat its last step.

    A step Marso ran and failed starts afresh (``make_asset`` cleared its node); a step that was still
    running when it timed out or was stopped keeps waiting for that same run.
    """
    stage = run.failed_stage or run.stage
    if stage in (STAGE_FAILED, STAGE_STOPPED, ""):
        stage = STAGE_MINTING if run.pbr_asset_id else STAGE_PBR if run.mesh_asset_id else STAGE_MESH
    if stage in (STAGE_READY, STAGE_DOWNLOADING):
        stage = STAGE_LISTING
    run.stage, run.failed_stage, run.error = stage, "", ""
    run.message = STAGE_LABELS.get(stage, stage) + "..."
    return run


def _mesh(studio: Studio, run: Run, project: StudioProject, waiter: Waiter, save: SaveFn, timing: Timing) -> None:
    if not run.execution_id:
        if not run.mesh_node_id:
            run.mesh_node_id = studio.create_node(project, NODE_GENERATE_3D, 1, run.row)
            studio.link(project, run.source_node_id, run.mesh_node_id)
            studio.set_3d_options(project, run.mesh_node_id)
            _touch(run, save)
        run.execution_id = _call(studio.start_mesh, project, run.mesh_node_id, run.image_asset_id)
        _note(run, save, STAGE_LABELS[STAGE_MESH] + "...")
    _wait(studio, run.execution_id, "Mesh generation", timing.mesh_poll, timing.mesh_timeout, waiter,
          lambda status: _note(run, save, f"{STAGE_LABELS[STAGE_MESH]} ({status.lower()})..."))
    mesh = _output(studio, project, run.mesh_node_id, TEXTURE_OUTPUT, waiter, timing)
    if not mesh:
        raise CreationError("The mesh finished but Marso did not return it.")
    run.mesh_asset_id, run.execution_id = mesh, ""
    _advance(run, save, STAGE_PBR, STAGE_LABELS[STAGE_PBR] + "...")


def _pbr(studio: Studio, run: Run, project: StudioProject, waiter: Waiter, save: SaveFn, timing: Timing) -> None:
    if not run.execution_id:
        if not run.pbr_node_id:
            run.pbr_node_id = studio.create_node(project, NODE_GENERATE_PBR, 2, run.row)
            studio.link(project, run.mesh_node_id, run.pbr_node_id)
            _touch(run, save)
        run.execution_id = _call(studio.start_pbr, project, run.pbr_node_id)
        _note(run, save, STAGE_LABELS[STAGE_PBR] + "...")
    _wait(studio, run.execution_id, "PBR generation", timing.pbr_poll, timing.pbr_timeout, waiter,
          lambda status: _note(run, save, f"{STAGE_LABELS[STAGE_PBR]} ({status.lower()})..."))
    asset = _output(studio, project, run.pbr_node_id, TEXTURE_OUTPUT, waiter, timing)
    if not asset:
        raise CreationError("The PBR materials finished but Marso did not return the asset.")
    run.pbr_asset_id, run.execution_id = asset, ""
    _advance(run, save, STAGE_MINTING, STAGE_LABELS[STAGE_MINTING] + "...")


def _minting(studio: Studio, run: Run, waiter: Waiter, save: SaveFn, timing: Timing) -> None:
    """Wait until Marso has minted the asset's finished USD; nothing enters the library before that."""
    deadline = waiter.now() + timing.mint_timeout
    started = waiter.now()
    while True:
        detail = studio.asset_detail(run.pbr_asset_id)
        if detail is not None and detail.minted:
            _advance(run, save, STAGE_LISTING, STAGE_LABELS[STAGE_LISTING] + "...")
            return
        if detail is not None and detail.mint_failed:
            raise CreationError(f"Marso could not finish this asset's USD (its description and physics). It is in "
                                f"{PROJECT_NAME} without them: download it from the Library, or retry to wait again.")
        if waiter.now() >= deadline:
            raise CreationError(f"Marso has not minted the USD after {timing.mint_timeout / 60:.0f} minutes. "
                                f"The asset will appear in {PROJECT_NAME} once it has; retry to keep waiting.")
        status = ((detail.enriched_status if detail is not None else "") or "pending").lower().replace("_", " ")
        _note(run, save, f"{STAGE_LABELS[STAGE_MINTING]} ({status}, {_elapsed(waiter.now() - started)})...")
        waiter.sleep(timing.mint_poll)


def _listing(studio: Studio, run: Run, project: StudioProject, waiter: Waiter, save: SaveFn,
             timing: Timing) -> api.Project:
    deadline = waiter.now() + timing.list_timeout
    while True:
        listed = studio.listed_project(project, run.pbr_asset_id)
        if listed is not None:
            return listed
        if waiter.now() >= deadline:
            raise CreationError(f"The asset is in Marso but the library has not listed it after "
                                f"{timing.list_timeout / 60:.0f} minutes; retry, or sync the library later.")
        waiter.sleep(timing.list_poll)



def name_new_asset(project: api.Project, asset_id: str, label: str) -> api.Project:
    """Name a new asset after what it was made from while Marso lists it under a placeholder ("generated").

    The name goes into its download's ``marso.json``, the stage prim and the Downloaded tab; once Marso
    gives it a real name (its enrichment's display name), that wins in the Library.
    """
    if not label:
        return project
    assets = tuple(
        replace(asset, name=label)
        if asset.asset_id == asset_id and not asset.display_name
        and (api.is_placeholder_name(asset.name) or asset.name == project.name) else asset
        for asset in project.assets
    )
    return replace(project, assets=assets)


# --- helpers ---------------------------------------------------------------------------------


def _project(studio: Studio, draft: Draft) -> StudioProject:
    if not draft.project_id:
        project = studio.find_or_create_project(PROJECT_NAME)
        draft.project_id, draft.graph_id = project.project_id, project.graph_id
    return StudioProject(draft.project_id, draft.graph_id, PROJECT_NAME)


def _wait(studio: Studio, execution_id: str, what: str, poll: float, timeout: float, waiter: Waiter,
          on_status: Callable[[str], None]):
    deadline = waiter.now() + timeout
    while True:
        execution = _call(studio.execution, execution_id)
        if execution.finished:
            if not execution.succeeded:
                reason = execution.error or f"it ended {execution.status.lower()}"
                raise RunFailed(f"{what} failed: {reason}")
            return execution
        if waiter.now() >= deadline:
            raise CreationError(f"{what} is still running after {timeout / 60:.0f} minutes; retry to keep waiting.")
        on_status(execution.status or "queued")
        waiter.sleep(poll)


def _output(studio: Studio, project: StudioProject, node_id: str, name: str, waiter: Waiter, timing: Timing) -> str:
    for attempt in range(timing.output_tries):
        value = studio.node_output(project, node_id, name)
        if value:
            return value
        if attempt + 1 < timing.output_tries:
            waiter.sleep(timing.output_interval)
    return ""


def _save_image(studio: Studio, image_id: str, image_dir: Path) -> Path:
    """Download the generated image for the preview (a picture link lasts about a minute)."""
    detail = studio.asset_detail(image_id)
    if detail is None or not detail.url:
        raise CreationError("Marso did not give a link to the generated image.")
    data = http.download_bytes(detail.url)
    suffix = ".jpg" if data[:3] == b"\xff\xd8\xff" else ".webp" if data[8:12] == b"WEBP" else ".png"
    path = Path(image_dir) / f"{image_id}{suffix}"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)
    return path


def _call(fn, *args):
    """Make one API call, turning Marso's credit and plan refusals into plain messages."""
    try:
        return fn(*args)
    except http.MarsoAuthError:
        raise
    except http.MarsoApiError as exc:
        if exc.code == "INSUFFICIENT_CREDITS" or exc.status_code == 402:
            raise CreationError("Not enough Marso credits for this step. Top up at marso.app, then retry.") from exc
        if exc.code == "PLAN_FEATURE_REQUIRED":
            raise CreationError("Your Marso plan does not include this step.") from exc
        raise


def _advance(run: Run, save: SaveFn, stage: str, message: str) -> None:
    run.stage, run.message = stage, message
    _touch(run, save)


def _note(item: Any, save: SaveFn, message: str) -> None:
    if item.message != message:
        item.message = message
        if isinstance(item, Run):
            _touch(item, save)
        else:
            save(item)


def _touch(run: Run, save: SaveFn) -> None:
    run.updated_at = time.time()
    save(run)


def _elapsed(seconds: float) -> str:
    minutes = int(seconds // 60)
    return f"{minutes} min" if minutes else f"{int(seconds)} s"

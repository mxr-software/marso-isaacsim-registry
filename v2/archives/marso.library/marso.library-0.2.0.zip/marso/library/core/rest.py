"""Resting poses: does an object stand as modelled, and if not, how does it lie? (numpy only)

Some assets are modelled in a display pose, a pistol standing on its edge for example, and topple
the moment physics starts. Sim Studio lays those down first: an object rests on the face of its
footprint below its centre of mass, and of the poses it can rest in, it settles in the one with the
centre of mass lowest. Poses an object can already rest in are kept as they are.
"""

from __future__ import annotations

import math

import numpy as np

CONTACT = 0.002  # metres: points this close to the lowest plane carry the object
MARGIN = 0.15  # the centre of mass must sit this share of the footprint's size inside its edge
DIRECTIONS = 600  # "down" directions tried for the lying pose
SMALL_TURN = 5.0  # degrees: a turn this small just settles it where it is, so it is left as modelled


def stands(points: np.ndarray, com, down=(0.0, 0.0, -1.0)) -> bool:
    """Whether the object rests with ``down`` (a unit vector, in the points' frame) pointing at the floor."""
    return _rest_height(np.asarray(points, float), np.asarray(com, float), np.asarray(down, float)) is not None


def rest_rotation(points: np.ndarray, com) -> np.ndarray | None:
    """The rotation (3x3, acting on column vectors) that lays the object in its lowest resting pose,
    or None when it already rests as it is (or rests nowhere, like a ball)."""
    pts, centre = np.asarray(points, float), np.asarray(com, float)
    if stands(pts, centre):
        return None
    best, best_height = None, math.inf
    size = float(np.linalg.norm(np.ptp(pts, axis=0)))
    candidates = np.concatenate([np.vstack([np.eye(3), -np.eye(3)]), _sphere(DIRECTIONS)])
    for guess in candidates:
        down = _settle_onto_face(pts, guess, size)
        height = _rest_height(pts, centre, down)
        if height is not None and height < best_height:
            best, best_height = down, height
    if best is None or best @ np.array([0.0, 0.0, -1.0]) > math.cos(math.radians(SMALL_TURN)):
        return None  # nothing better, or just rocking onto the face it nearly rests on: leave it be
    return _turn(best, np.array([0.0, 0.0, -1.0]))


def euler_xyz(rotation: np.ndarray) -> tuple[float, float, float]:
    """Degrees for a USD ``rotateXYZ`` op (X first, then Y, then Z) giving ``rotation`` (column vectors)."""
    r = np.asarray(rotation, float)
    y = math.asin(max(-1.0, min(1.0, -r[2, 0])))
    if abs(r[2, 0]) < 0.999999:
        x, z = math.atan2(r[2, 1], r[2, 2]), math.atan2(r[1, 0], r[0, 0])
    else:  # gimbal lock: put it all in X
        x, z = math.atan2(-r[1, 2], r[1, 1]), 0.0
    return math.degrees(x), math.degrees(y), math.degrees(z)


def _rest_height(points: np.ndarray, com: np.ndarray, down: np.ndarray) -> float | None:
    """The centre of mass's height above the floor when resting with ``down`` downwards, or None if
    it would tip over (its centre of mass outside what it stands on)."""
    depth = points @ down
    floor = depth.max()
    contact = points[depth >= floor - CONTACT]
    u = np.cross(down, [1.0, 0.0, 0.0] if abs(down[0]) < 0.9 else [0.0, 1.0, 0.0])
    u /= np.linalg.norm(u)
    v = np.cross(down, u)
    hull = _hull(np.stack([contact @ u, contact @ v], axis=1))
    if len(hull) < 3:
        return None
    centre = np.array([com @ u, com @ v])
    size = min(np.ptp(hull[:, 0]), np.ptp(hull[:, 1]))
    if _inside_by(hull, centre) < MARGIN * size:
        return None
    return float(floor - com @ down)


def _settle_onto_face(points: np.ndarray, down: np.ndarray, size: float) -> np.ndarray:
    """Turn a rough "down" onto the plane of the points nearest the floor, the way an object tipped
    slightly off a face rocks back onto it (sampled directions never land exactly on a face)."""
    for _ in range(3):
        depth = points @ down
        near = points[depth >= depth.max() - 0.03 * size]
        if len(near) < 3:
            break
        centred = near - near.mean(axis=0)
        normal = np.linalg.svd(centred, full_matrices=False)[2][-1]
        if normal @ down < 0:
            normal = -normal
        if normal @ down < 0.9:  # not a face nearby: keep the sampled direction
            break
        down = normal / np.linalg.norm(normal)
    return down


def _hull(points: np.ndarray) -> np.ndarray:
    """Convex hull of 2D points, anticlockwise (Andrew's monotone chain)."""
    pts = np.unique(np.round(points, 6), axis=0)
    if len(pts) < 3:
        return pts
    pts = pts[np.lexsort((pts[:, 1], pts[:, 0]))]

    def half(seq):
        out = []
        for p in seq:
            while len(out) >= 2 and _cross(out[-1] - out[-2], p - out[-2]) <= 0:
                out.pop()
            out.append(p)
        return out

    lower, upper = half(pts), half(pts[::-1])
    return np.array(lower[:-1] + upper[:-1])


def _inside_by(hull: np.ndarray, point: np.ndarray) -> float:
    """How far ``point`` lies inside an anticlockwise convex polygon (negative outside)."""
    nearest = math.inf
    for a, b in zip(hull, np.roll(hull, -1, axis=0)):
        edge = b - a
        length = float(np.linalg.norm(edge))
        if length < 1e-12:
            continue
        nearest = min(nearest, _cross(edge, point - a) / length)
    return nearest


def _cross(a, b) -> float:
    return float(a[0] * b[1] - a[1] * b[0])


def _sphere(count: int) -> np.ndarray:
    """Evenly spread unit vectors (a Fibonacci sphere)."""
    i = np.arange(count) + 0.5
    polar = np.arccos(1 - 2 * i / count)
    azimuth = math.pi * (1 + 5 ** 0.5) * i
    return np.stack([np.cos(azimuth) * np.sin(polar), np.sin(azimuth) * np.sin(polar), np.cos(polar)], axis=1)


def _turn(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    """The smallest rotation taking unit vector ``a`` onto unit vector ``b``."""
    axis = np.cross(a, b)
    s, c = float(np.linalg.norm(axis)), float(a @ b)
    if s < 1e-9:
        if c > 0:
            return np.eye(3)
        other = np.array([1.0, 0.0, 0.0]) if abs(a[0]) < 0.9 else np.array([0.0, 1.0, 0.0])
        axis = np.cross(a, other)
        axis /= np.linalg.norm(axis)
        return 2 * np.outer(axis, axis) - np.eye(3)
    k = axis / s
    skew = np.array([[0, -k[2], k[1]], [k[2], 0, -k[0]], [-k[1], k[0], 0]])
    return np.eye(3) + s * skew + (1 - c) * skew @ skew

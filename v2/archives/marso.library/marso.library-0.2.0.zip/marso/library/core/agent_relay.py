"""The agent connection: an outbound link from this Isaac Sim to the Marso MCP. (stdlib only)

Chat and coding agents (Codex, ChatGPT, Claude) talk to one server, the Marso MCP. When the user
switches this on, the extension connects *out* to that server and asks it for work, so the same agent
that generates assets can put them on this stage and film them in Sim Studio. Nothing listens on this
computer.

Protocol, version 1 (JSON over HTTPS), shared with the Blender add-on:

  POST {endpoint}/app/connect            Authorization: Bearer <Marso API key>
       {"protocol", "app": "isaacsim", "addon_version", "app_version", "label"}
       -> {"channel_token", "session_id", "poll_wait_s", "account": {"email"}}
  GET  {endpoint}/app/poll?wait=S         Authorization: Bearer <channel token>
       -> {"requests": [{"id", "command", "params", "wait", "timeout"}]}
          401: the token expired, connect again.  409: another Isaac Sim took over.
  POST {endpoint}/app/result             Authorization: Bearer <channel token>
       {"id", "status", "payload"}
  POST {endpoint}/app/render?name=N      Authorization: Bearer <channel token>
       the bytes of one Sim Studio video, for the chat -> {"share_id", "expires_at", "mime", "bytes"}

The API key is sent once, to prove whose Isaac Sim this is, and never stored by the server. Every
request is checked against ``agent_policy`` here, whatever the server sent.
"""

from __future__ import annotations

import json
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable

from . import agent_policy

PROTOCOL_VERSION = 1
APP = "isaacsim"
POLL_WAIT_S = 25
MAX_IN_FLIGHT = 4
MAX_RESULT_BYTES = 8_000_000
CONNECT_TIMEOUT_S = 20
UPLOAD_TIMEOUT_S = 900
_BACKOFF_S = (2, 5, 10, 30, 60)
_LOOPBACK_HOSTS = frozenset({"127.0.0.1", "localhost", "::1"})

# Where the Marso MCP lives.
DEFAULT_ENDPOINT = "https://mcp.api.marso.app"

STATE_OFF = "off"
STATE_CONNECTING = "connecting"
STATE_CONNECTED = "connected"
STATE_RETRYING = "retrying"
STATE_REPLACED = "replaced"
STATE_REFUSED = "refused"

Execute = Callable[[dict[str, Any]], "tuple[int, dict[str, Any]]"]


class RelayError(RuntimeError):
    def __init__(self, message: str, status: int | None = None) -> None:
        super().__init__(message)
        self.status = status


def current_endpoint(endpoint: str) -> str:
    """The address to connect to: the default for an empty setting, else the setting."""
    clean = (endpoint or "").strip().rstrip("/")
    return clean or DEFAULT_ENDPOINT


def validate_endpoint(endpoint: str) -> str:
    """The endpoint as a base URL, or ``ValueError``. HTTPS only, except to this machine for testing."""
    parsed = urllib.parse.urlsplit(endpoint.strip())
    if not parsed.netloc:
        raise ValueError(f"Enter the Marso MCP address, for example {DEFAULT_ENDPOINT}")
    host = (parsed.hostname or "").lower()
    if parsed.scheme == "https" or (parsed.scheme == "http" and host in _LOOPBACK_HOSTS):
        return f"{parsed.scheme}://{parsed.netloc}{parsed.path.rstrip('/')}"
    raise ValueError("The agent connection only uses https (plain http is allowed to this computer, for testing).")


@dataclass
class Status:
    state: str = STATE_OFF
    message: str = ""
    account: str = ""
    endpoint: str = ""
    since: float = field(default_factory=time.time)
    handled: int = 0
    refused: int = 0

    def snapshot(self) -> dict[str, Any]:
        return {
            "state": self.state,
            "message": self.message,
            "account": self.account,
            "endpoint": self.endpoint,
            "since": self.since,
            "handled": self.handled,
            "refused": self.refused,
        }


class RelayClient:
    """One outbound connection. ``execute`` runs a checked command body and returns ``(status, payload)``."""

    def __init__(self, endpoint: str, api_key: str, *, addon_version: str, app_version: str, label: str,
                 execute: Execute) -> None:
        self.endpoint = validate_endpoint(endpoint)
        self._api_key = api_key
        self._hello = {
            "protocol": PROTOCOL_VERSION,
            "app": APP,
            "addon_version": addon_version,
            "app_version": app_version,
            "label": label[:120],
        }
        self._execute = execute
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._pool = ThreadPoolExecutor(max_workers=MAX_IN_FLIGHT, thread_name_prefix="marso-agent-cmd")
        self._in_flight = threading.Semaphore(MAX_IN_FLIGHT)
        self._token = ""
        self._lock = threading.Lock()
        self.status = Status(endpoint=self.endpoint)

    # --- lifecycle --------------------------------------------------------------------------

    def start(self) -> None:
        if self._thread is not None:
            return
        self._set(STATE_CONNECTING, "Connecting...")
        self._thread = threading.Thread(target=self._run, daemon=True, name="marso-agent")
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        thread, self._thread = self._thread, None
        if thread is not None:
            thread.join(timeout=2.0)
        self._pool.shutdown(wait=False, cancel_futures=True)
        if self.status.state not in (STATE_REPLACED, STATE_REFUSED):
            self._set(STATE_OFF, "Disconnected.")

    @property
    def running(self) -> bool:
        return self._thread is not None and not self._stop.is_set()

    @property
    def connected(self) -> bool:
        return self.status.state == STATE_CONNECTED and bool(self._token)

    # --- the loop ---------------------------------------------------------------------------

    def _run(self) -> None:
        attempt = 0
        while not self._stop.is_set():
            try:
                if not self._token:
                    self._connect()
                    attempt = 0
                self._poll_once()
            except RelayError as exc:
                if exc.status == 401 and self._token:
                    self._token = ""  # the channel token expired: connect again at once
                    continue
                if exc.status in (401, 403):
                    self._set(STATE_REFUSED, "Marso refused the API key. Check it in the Settings tab.")
                    return
                if exc.status == 409:
                    self._set(STATE_REPLACED, "Another Isaac Sim connected with this account and took over.")
                    return
                self._retry(attempt, str(exc))
                attempt += 1
            except (urllib.error.URLError, OSError, ValueError) as exc:
                self._retry(attempt, f"Cannot reach Marso: {exc}")
                attempt += 1

    def _retry(self, attempt: int, message: str) -> None:
        delay = _BACKOFF_S[min(attempt, len(_BACKOFF_S) - 1)]
        self._set(STATE_RETRYING, f"{message} Retrying in {delay}s.")
        self._stop.wait(delay)

    def _connect(self) -> None:
        payload = self._request("POST", "/app/connect", self._api_key, self._hello, CONNECT_TIMEOUT_S)
        token = payload.get("channel_token")
        if not isinstance(token, str) or not token:
            raise RelayError("The server did not return a channel token.")
        self._token = token
        account = payload.get("account") if isinstance(payload.get("account"), dict) else {}
        self.status.account = str(account.get("email") or "")
        self._set(STATE_CONNECTED, "Connected. Agents signed in to Marso can use this Isaac Sim.")

    def _poll_once(self) -> None:
        payload = self._request("GET", f"/app/poll?wait={POLL_WAIT_S}", self._token, None, POLL_WAIT_S + 15)
        if self.status.state != STATE_CONNECTED:
            self._set(STATE_CONNECTED, "Connected. Agents signed in to Marso can use this Isaac Sim.")
        requests = payload.get("requests")
        if not isinstance(requests, list):
            return
        for request in requests:
            if isinstance(request, dict) and not self._stop.is_set():
                self._in_flight.acquire()
                self._pool.submit(self._handle, request)

    # --- one request ------------------------------------------------------------------------

    def _handle(self, request: dict[str, Any]) -> None:
        try:
            request_id = str(request.get("id") or "")
            if not request_id:
                return
            status, payload = self.run_request(request)
            self._post_result(request_id, status, payload)
        finally:
            self._in_flight.release()

    def run_request(self, request: dict[str, Any]) -> tuple[int, dict[str, Any]]:
        """Check one request against the policy and run it. Public for tests."""
        command = request.get("command")
        params = request.get("params") if isinstance(request.get("params"), dict) else {}
        if not isinstance(command, str):
            return 400, {"ok": False, "error": {"code": "bad_request", "message": "'command' must be a string."}}
        try:
            agent_policy.check_remote(command, params)
        except agent_policy.PolicyError as exc:
            with self._lock:
                self.status.refused += 1
            return 403, {"ok": False, "error": {"code": exc.code, "message": str(exc)}}
        body = {"command": command, "params": params, "wait": bool(request.get("wait", False))}
        if isinstance(request.get("timeout"), (int, float)) and not isinstance(request.get("timeout"), bool):
            body["timeout"] = max(0.0, float(request["timeout"]))
        try:
            status, payload = self._execute(body)
        except Exception as exc:  # noqa: BLE001 - one bad command must not end the connection
            return 500, {"ok": False, "error": {"code": "internal_error", "message": str(exc) or type(exc).__name__}}
        with self._lock:
            self.status.handled += 1
        return status, payload

    def _post_result(self, request_id: str, status: int, payload: dict[str, Any]) -> None:
        body = {"id": request_id, "status": status, "payload": payload}
        if len(json.dumps(body)) > MAX_RESULT_BYTES:
            body = {"id": request_id, "status": 413,
                    "payload": {"ok": False, "error": {"code": "too_large", "message": "The result was too large to send back."}}}
        try:
            self._request("POST", "/app/result", self._token, body, CONNECT_TIMEOUT_S)
        except (RelayError, urllib.error.URLError, OSError, ValueError):
            pass  # the server times the request out; the loop reconnects if the link is down

    # --- sending a video ----------------------------------------------------------------------

    def upload(self, path: Path, name: str, timeout: float = UPLOAD_TIMEOUT_S) -> dict[str, Any]:
        """Stream one file to the server for the chat; only while connected, with the channel token."""
        token = self._token
        if not token or self.status.state != STATE_CONNECTED:
            raise RelayError("Not connected to Marso Agents.")
        size = path.stat().st_size
        query = urllib.parse.urlencode({"name": name[:120]})
        headers = {"Authorization": f"Bearer {token}", "Accept": "application/json",
                   "Content-Type": "application/octet-stream", "Content-Length": str(size)}
        with path.open("rb") as body:
            request = urllib.request.Request(f"{self.endpoint}/app/render?{query}", data=body, headers=headers, method="POST")
            return self._send(request, timeout)

    # --- plumbing ---------------------------------------------------------------------------

    def _request(self, method: str, path: str, bearer: str, body: dict[str, Any] | None, timeout: float) -> dict[str, Any]:
        data = json.dumps(body).encode("utf-8") if body is not None else None
        headers = {"Authorization": f"Bearer {bearer}", "Accept": "application/json"}
        if data is not None:
            headers["Content-Type"] = "application/json"
        request = urllib.request.Request(f"{self.endpoint}{path}", data=data, headers=headers, method=method)
        return self._send(request, timeout)

    def _send(self, request: urllib.request.Request, timeout: float) -> dict[str, Any]:
        try:
            with urllib.request.urlopen(request, timeout=timeout) as response:  # noqa: S310 - scheme checked in validate_endpoint
                raw = response.read()
        except urllib.error.HTTPError as exc:
            detail = ""
            try:
                detail = json.loads(exc.read().decode("utf-8") or "{}").get("error", "")
            except (ValueError, OSError, AttributeError):
                pass
            finally:
                exc.close()
            raise RelayError(f"Marso answered {exc.code}{f': {detail}' if detail else ''}.", exc.code) from exc
        if not raw:
            return {}
        parsed = json.loads(raw.decode("utf-8"))
        return parsed if isinstance(parsed, dict) else {}

    def _set(self, state: str, message: str) -> None:
        with self._lock:
            if self.status.state != state:
                self.status.since = time.time()
            self.status.state = state
            self.status.message = message

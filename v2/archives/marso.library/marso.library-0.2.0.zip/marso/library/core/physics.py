"""What a downloaded asset carries for simulation, and whether that makes it sim ready.

The USD traversal that fills a ``PhysicsSummary`` needs ``pxr`` and lives in the
Kit layer (``usd_inspect.py``); this module only holds the result and the rules
for reading it, so they can be tested without Kit.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any

LEVEL_SIM_READY = "sim_ready"
LEVEL_COLLIDERS_ONLY = "colliders_only"
LEVEL_VISUAL_ONLY = "visual_only"
LEVEL_UNKNOWN = "unknown"

LEVEL_LABELS = {
    LEVEL_SIM_READY: "Sim ready",
    LEVEL_COLLIDERS_ONLY: "Colliders only",
    LEVEL_VISUAL_ONLY: "Visual only",
    LEVEL_UNKNOWN: "Not checked",
}

# PhysX cannot simulate a triangle mesh on a dynamic body; it falls back to a
# convex hull and logs a warning.
_DYNAMIC_UNSAFE_APPROXIMATIONS = ("none", "meshSimplification")


PREPARE_VERSION = 5  # 2: mass from density; 3: names from the USD; 4: enrichment in the sidecar; 5: checks


@dataclass(frozen=True)
class PhysicsSummary:
    """Counts of the physics and semantics a USD asset authors.

    ``mass_kg`` is the mass PhysX simulates: density x collider volume when the asset has a density
    (the wrapper layer clears any authored mass so PhysX computes it), else the authored mass.
    """

    rigid_bodies: int = 0
    colliders: int = 0
    approximations: tuple[str, ...] = ()
    mass_kg: float | None = None
    physics_materials: int = 0
    semantic_labels: int = 0
    articulations: int = 0
    errors: tuple[str, ...] = field(default=())
    version: int = 0  # PREPARE_VERSION of the analysis and wrapper that produced it
    checks: tuple[str, ...] = ()  # what the file check found (core.checks.file_checks)

    @property
    def level(self) -> str:
        if self.errors and not (self.colliders or self.rigid_bodies):
            return LEVEL_UNKNOWN
        if self.colliders and self.rigid_bodies:
            return LEVEL_SIM_READY
        if self.colliders:
            return LEVEL_COLLIDERS_ONLY
        return LEVEL_VISUAL_ONLY

    @property
    def sim_ready(self) -> bool:
        return self.level == LEVEL_SIM_READY

    @property
    def label(self) -> str:
        return LEVEL_LABELS[self.level]

    def warnings(self) -> list[str]:
        notes = []
        if self.rigid_bodies and any(name in _DYNAMIC_UNSAFE_APPROXIMATIONS for name in self.approximations):
            notes.append("A rigid body uses a triangle-mesh collider; PhysX will substitute a convex hull.")
        if self.rigid_bodies and self.mass_kg is None:
            notes.append("No mass or density is authored; PhysX will use its default density.")
        return notes

    def describe(self) -> list[str]:
        """Human-readable lines for a tooltip."""
        if self.level == LEVEL_UNKNOWN:
            return [f"Could not read physics: {self.errors[0]}"]
        lines = [self.label]
        lines.append(f"Rigid bodies: {self.rigid_bodies}" if self.rigid_bodies else "No rigid body")
        if self.colliders:
            kinds = ", ".join(sorted(set(self.approximations))) or "exact"
            lines.append(f"Colliders: {self.colliders} ({kinds})")
        else:
            lines.append("No colliders")
        if self.mass_kg is not None:
            lines.append(f"Mass: {self.mass_kg:.3g} kg")
        if self.physics_materials:
            lines.append(f"Physics materials: {self.physics_materials}")
        if self.semantic_labels:
            lines.append(f"Semantic labels: {self.semantic_labels}")
        if self.articulations:
            lines.append(f"Articulations: {self.articulations}")
        lines.extend(self.warnings())
        lines.extend(f"Check: {check}" for check in self.checks)
        return lines

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["approximations"] = list(self.approximations)
        data["errors"] = list(self.errors)
        data["checks"] = list(self.checks)
        data["level"] = self.level
        return data

    @classmethod
    def from_dict(cls, raw: Any) -> PhysicsSummary | None:
        if not isinstance(raw, dict):
            return None
        mass = raw.get("mass_kg")
        return cls(
            rigid_bodies=int(raw.get("rigid_bodies") or 0),
            colliders=int(raw.get("colliders") or 0),
            approximations=tuple(str(item) for item in raw.get("approximations") or ()),
            mass_kg=float(mass) if isinstance(mass, (int, float)) else None,
            physics_materials=int(raw.get("physics_materials") or 0),
            semantic_labels=int(raw.get("semantic_labels") or 0),
            articulations=int(raw.get("articulations") or 0),
            errors=tuple(str(item) for item in raw.get("errors") or ()),
            version=int(raw.get("version") or 0),
            checks=tuple(str(item) for item in raw.get("checks") or ()),
        )

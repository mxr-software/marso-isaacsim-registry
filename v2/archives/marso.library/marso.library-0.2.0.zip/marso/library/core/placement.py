"""Where a newly added asset goes and how it is corrected to fit the stage.

Marso packages are authored Z-up at 1 metre per unit, which matches Isaac
Sim's default stage, so the correction is usually the identity. A stage set
up differently (Y-up, or centimetres) gets a rotation and a uniform scale on
the wrapping prim so the asset still lands upright and at real-world size.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

# Space left between assets added side by side, in metres.
ROW_GAP_M = 0.25


@dataclass(frozen=True)
class Correction:
    """Rotation about X (degrees) and uniform scale that map the asset into the stage."""

    rotate_x_deg: float = 0.0
    scale: float = 1.0

    @property
    def is_identity(self) -> bool:
        return self.rotate_x_deg == 0.0 and math.isclose(self.scale, 1.0)


def stage_correction(asset_up: str, asset_mpu: float, stage_up: str, stage_mpu: float) -> Correction:
    """The correction that maps an asset's up axis and units onto the stage's."""
    asset_up = (asset_up or "Y").upper()
    stage_up = (stage_up or "Y").upper()
    if asset_up == stage_up:
        rotate = 0.0
    elif asset_up == "Y" and stage_up == "Z":
        rotate = 90.0  # +Y becomes +Z
    elif asset_up == "Z" and stage_up == "Y":
        rotate = -90.0  # +Z becomes +Y
    else:
        rotate = 0.0
    asset_mpu = asset_mpu if asset_mpu and asset_mpu > 0 else 0.01  # USD's fallback is centimetres
    stage_mpu = stage_mpu if stage_mpu and stage_mpu > 0 else 0.01
    return Correction(rotate_x_deg=rotate, scale=asset_mpu / stage_mpu)


class RowLayout:
    """Lines up assets added in one go along +X, each to the right of the last.

    The first asset stays where it lands (the origin); the rest follow with
    ``gap`` between them. Assets that finish downloading later still join the
    same row, because the layout remembers where the row ends.
    """

    def __init__(self, gap: float) -> None:
        self.gap = gap
        self._end: float | None = None

    def place(self, min_x: float, max_x: float) -> float:
        """The X offset for an item spanning [min_x, max_x] where it currently sits."""
        width = max(0.0, max_x - min_x)
        if self._end is None:
            self._end = max_x
            return 0.0
        offset = self._end + self.gap - min_x
        self._end = self._end + self.gap + width
        return offset

    def place_box(self, lo, hi) -> tuple[float, float, float]:
        """The offset (x, y, z) for an item whose box spans ``lo``..``hi`` (stage axes)."""
        return self.place(lo[0], hi[0]), 0.0, 0.0


# How a batch added in one go is arranged.
ARRANGE_ROW, ARRANGE_GRID, ARRANGE_STACK = "row", "grid", "stack"
ARRANGEMENTS = {ARRANGE_ROW: "In a row", ARRANGE_GRID: "In a grid", ARRANGE_STACK: "Stacked (for drops)"}
GRID_PER_ROW = 5


class GridLayout:
    """Rows of ``per_row`` along +X; each new row steps back (away from the default camera)."""

    def __init__(self, gap: float, up_axis: int = 2, per_row: int = GRID_PER_ROW) -> None:
        self.gap = gap
        self.per_row = max(1, per_row)
        # The horizontal axis that is not X: Y on a Z-up stage (rows go to +Y), Z on a Y-up one (to -Z).
        self._back, self._sign = (1, 1.0) if up_axis == 2 else (2, -1.0)
        self._row = RowLayout(gap)
        self._count = 0
        self._row_origin = 0.0  # where this row's front edge goes, along the back axis
        self._row_depth = 0.0
        self._first_front: float | None = None

    def place_box(self, lo, hi) -> tuple[float, float, float]:
        if self._count and self._count % self.per_row == 0:  # start the next row
            self._row = RowLayout(self.gap)
            self._row_origin += self._row_depth + self.gap
            self._row_depth = 0.0
        self._count += 1
        x = self._row.place(lo[0], hi[0])
        front = lo[self._back] if self._sign > 0 else -hi[self._back]
        if self._first_front is None:
            self._first_front = front
        depth = hi[self._back] - lo[self._back]
        self._row_depth = max(self._row_depth, depth)
        move = (self._first_front + self._row_origin - front) * self._sign
        offset = [x, 0.0, 0.0]
        offset[self._back] = move
        return offset[0], offset[1], offset[2]


class StackLayout:
    """Each asset above the last, centred over the first: drop them and they land on each other."""

    def __init__(self, gap: float, up_axis: int = 2) -> None:
        self.gap = gap
        self._up = up_axis
        self._top: float | None = None
        self._centre: tuple[float, ...] | None = None

    def place_box(self, lo, hi) -> tuple[float, float, float]:
        centre = tuple((lo[i] + hi[i]) / 2 for i in range(3))
        if self._top is None:
            self._top, self._centre = hi[self._up], centre
            return 0.0, 0.0, 0.0
        offset = [self._centre[i] - centre[i] for i in range(3)]
        offset[self._up] = self._top + self.gap - lo[self._up]
        self._top = hi[self._up] + offset[self._up]
        return offset[0], offset[1], offset[2]


def make_layout(kind: str, gap: float, up_axis: int = 2):
    """A layout for ``ARRANGE_*`` (anything unknown is a row)."""
    if kind == ARRANGE_GRID:
        return GridLayout(gap, up_axis)
    if kind == ARRANGE_STACK:
        return StackLayout(gap, up_axis)
    return RowLayout(gap)

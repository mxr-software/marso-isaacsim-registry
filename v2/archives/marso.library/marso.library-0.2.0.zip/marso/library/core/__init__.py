"""Kit-independent logic for the Marso library extension.

Nothing in this package may import ``omni``, ``carb`` or ``pxr``: it is the
part of the extension that runs (and is unit tested) under a plain Python
interpreter. Kit-specific code lives one level up and calls into here.
"""

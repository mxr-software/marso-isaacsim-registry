"""On-disk layout: the cached listing, thumbnails, and downloaded assets.

  <cache_dir>/
    library.json              -- last synced listing (no expiring URLs)
    thumbnails/<key>.png      -- square previews for the grids

  <downloads_dir>/
    Projects/<Project Name>/<asset_id>/
      model.usdz              -- the asset (model + textures in one package)
      thumbnail.png           -- its preview, so the Downloaded tab works offline
      marso.json              -- what the asset is (name, project, physics summary)
      isaacsim/<Name>.usda    -- what Isaac Sim references: a clean root Xform over model.usdz

The downloads layout is the Blender add-on's, so both can share one folder:
an asset downloaded in Blender shows up here as downloaded (it simply has no
``marso.json`` until this extension writes one).
"""

from __future__ import annotations

import json
import os
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .api import Asset, Library, Project
from .enrichment import Enrichment
from .physics import PREPARE_VERSION, PhysicsSummary

MANIFEST_NAME = "library.json"
MANIFEST_VERSION = 1
THUMBNAILS_DIR = "thumbnails"
PROJECTS_DIR = "Projects"
SIDECAR_NAME = "marso.json"
SIDECAR_VERSION = 1
ASSET_THUMBNAIL_NAME = "thumbnail.png"
STAGE_DIR = "isaacsim"  # the Isaac Sim wrapper layer lives here, out of the Blender add-on's sight
USD_FILE_STEM = "model"
STAGING_SUFFIX = ".part"
USD_EXTENSIONS = (".usdz", ".usd", ".usdc", ".usda")


@dataclass(frozen=True)
class LocalAsset:
    """An asset that is on disk under the downloads folder."""

    asset_id: str
    name: str
    project_name: str
    project_id: str
    usd_path: Path
    size_bytes: int
    downloaded_at: float
    thumbnail_path: Path | None = None
    physics: PhysicsSummary | None = None
    has_sidecar: bool = False
    stage_file: str = ""  # relative to the asset folder; written by the Kit side after download
    enrichment: Enrichment | None = None  # from the USD itself (with physics and real-world size)
    model_version: str = ""  # the listing's model_version when it was downloaded

    @property
    def folder(self) -> Path:
        return self.usd_path.parent

    @property
    def stage_path(self) -> Path:
        """The file to reference in a stage: the wrapper layer when it exists, else the package itself."""
        if self.stage_file:
            wrapper = self.folder / self.stage_file
            if wrapper.is_file():
                return wrapper
        return self.usd_path

    @property
    def is_prepared(self) -> bool:
        """Whether the physics has been read and the current wrapper layer written."""
        return (self.physics is not None and self.physics.version >= PREPARE_VERSION
                and self.stage_path != self.usd_path)

    @property
    def search_text(self) -> str:
        """Name, project and Marso's description (type, materials, tags, aliases), lower-cased."""
        extra = self.enrichment.search_text if self.enrichment is not None else ""
        return f"{self.name} {self.project_name} {extra}".lower()


def safe_filename(value: str) -> str:
    """A file or folder name that is safe on every platform (same rule as the Blender add-on)."""
    cleaned = "".join(char if char.isalnum() or char in "-_." else "_" for char in value)
    return cleaned or "_"


# --- cache: listing and thumbnails -------------------------------------------------------


def manifest_path(cache_dir: Path) -> Path:
    return cache_dir / MANIFEST_NAME


def save_library(cache_dir: Path, library: Library, synced_at: float | None = None) -> None:
    """Persist the listing (minus presigned URLs, which expire within a minute)."""
    payload = {
        "version": MANIFEST_VERSION,
        "synced_at": synced_at if synced_at is not None else time.time(),
        "projects": [
            {
                "project_id": project.project_id,
                "name": project.name,
                "unfinished": project.unfinished,
                "assets": [
                    {
                        "asset_id": asset.asset_id,
                        "name": asset.name,
                        "display_name": asset.display_name,
                        "description": asset.description,
                        "category": asset.category,
                        "tags": list(asset.tags),
                        "model_version": asset.model_version,
                        "enrichment": asset.enrichment.to_dict() if asset.enrichment else None,
                    }
                    for asset in project.assets
                ],
            }
            for project in library.projects
        ],
    }
    cache_dir.mkdir(parents=True, exist_ok=True)
    _write_json_atomic(manifest_path(cache_dir), payload)


def load_library(cache_dir: Path) -> tuple[Library, float | None]:
    """The cached listing and when it was synced; an empty library if missing or outdated."""
    data = _read_json(manifest_path(cache_dir))
    if not isinstance(data, dict) or data.get("version") != MANIFEST_VERSION:
        return Library(), None
    projects = []
    for raw in data.get("projects") or []:
        if not isinstance(raw, dict) or not raw.get("project_id"):
            continue
        project_id = str(raw["project_id"])
        assets = tuple(
            Asset(
                asset_id=str(item["asset_id"]),
                name=str(item.get("name") or item["asset_id"]),
                project_id=project_id,
                display_name=str(item.get("display_name") or ""),
                description=str(item.get("description") or ""),
                category=str(item.get("category") or ""),
                tags=tuple(str(tag) for tag in item.get("tags") or ()),
                model_version=str(item.get("model_version") or ""),
                enrichment=Enrichment.from_dict(item.get("enrichment")),
            )
            for item in raw.get("assets") or []
            if isinstance(item, dict) and item.get("asset_id")
        )
        unfinished = raw.get("unfinished") if isinstance(raw.get("unfinished"), int) else 0
        projects.append(Project(project_id, str(raw.get("name") or project_id), "", assets, unfinished))
    synced_at = data.get("synced_at")
    return Library(tuple(projects)), float(synced_at) if isinstance(synced_at, (int, float)) else None


def thumbnails_dir(cache_dir: Path) -> Path:
    return cache_dir / THUMBNAILS_DIR


def thumbnail_path(cache_dir: Path, key: str) -> Path:
    return thumbnails_dir(cache_dir) / f"{safe_filename(key)}.png"


def project_thumbnail_key(project_id: str) -> str:
    return f"project-{project_id}"


def find_thumbnail(cache_dir: Path, key: str) -> Path | None:
    path = thumbnail_path(cache_dir, key)
    return path if path.is_file() else None


# --- downloads ---------------------------------------------------------------------------


def asset_dir(downloads_dir: Path, project_name: str, asset_id: str) -> Path:
    return downloads_dir / PROJECTS_DIR / safe_filename(project_name) / safe_filename(asset_id)


def scan_downloads(downloads_dir: Path) -> dict[str, LocalAsset]:
    """Every downloaded asset, keyed by asset id, whichever project folder it sits in."""
    found: dict[str, LocalAsset] = {}
    projects_root = downloads_dir / PROJECTS_DIR
    if not projects_root.is_dir():
        return found
    for project_folder in _subdirs(projects_root):
        for folder in _subdirs(project_folder):
            if folder.name.endswith(STAGING_SUFFIX):
                continue
            local = read_local_asset(folder)
            if local is None:
                continue
            previous = found.get(local.asset_id)
            if previous is None or local.downloaded_at > previous.downloaded_at:
                found[local.asset_id] = local
    return found


def read_local_asset(folder: Path) -> LocalAsset | None:
    """Describe one asset folder, or None when it holds no USD file."""
    usd_path = find_usd(folder)
    if usd_path is None:
        return None
    sidecar = read_sidecar(folder)
    stat = usd_path.stat()
    thumbnail = folder / ASSET_THUMBNAIL_NAME
    downloaded_at = sidecar.get("downloaded_at")
    return LocalAsset(
        asset_id=str(sidecar.get("asset_id") or folder.name),
        name=str(sidecar.get("name") or folder.name),
        project_name=str(sidecar.get("project_name") or folder.parent.name),
        project_id=str(sidecar.get("project_id") or ""),
        usd_path=usd_path,
        size_bytes=stat.st_size,
        downloaded_at=float(downloaded_at) if isinstance(downloaded_at, (int, float)) else stat.st_mtime,
        thumbnail_path=thumbnail if thumbnail.is_file() else None,
        physics=PhysicsSummary.from_dict(sidecar.get("physics")),
        has_sidecar=bool(sidecar),
        stage_file=str(sidecar.get("stage_file") or ""),
        enrichment=Enrichment.from_dict(sidecar.get("enrichment")),
        model_version=str(sidecar.get("model_version") or ""),
    )


class NotADownload(ValueError):
    """Refused to delete a folder that is not one asset's download inside the downloads folder."""


def delete_download(folder: Path, downloads_dir: Path) -> None:
    """Delete one asset's download folder, after checking it really is one.

    The folder must sit inside the downloads folder (``Projects/<project>/<asset>``) and hold a
    USD package; anything else raises ``NotADownload`` and nothing is touched.
    """
    import shutil

    folder, root = Path(folder).resolve(), Path(downloads_dir).resolve()
    if root == folder or root not in folder.parents or folder.parent.parent.parent != root:
        raise NotADownload(f"{folder} is not an asset folder inside {root}")
    if find_usd(folder) is None:
        raise NotADownload(f"{folder} holds no USD package")
    shutil.rmtree(folder)
    project = folder.parent
    if project != root and not any(project.iterdir()):
        project.rmdir()  # the project folder is empty now


def find_usd(folder: Path) -> Path | None:
    preferred = folder / f"{USD_FILE_STEM}.usdz"
    if preferred.is_file():
        return preferred
    candidates = sorted(
        path for path in _files(folder) if path.suffix.lower() in USD_EXTENSIONS and path.stat().st_size > 0
    )
    return candidates[0] if candidates else None


def read_sidecar(folder: Path) -> dict[str, Any]:
    data = _read_json(folder / SIDECAR_NAME)
    return data if isinstance(data, dict) else {}


def write_sidecar(folder: Path, data: dict[str, Any]) -> None:
    _write_json_atomic(folder / SIDECAR_NAME, {"version": SIDECAR_VERSION, **data})


def update_sidecar(folder: Path, **fields: Any) -> None:
    """Merge fields into an asset's ``marso.json``, creating it if needed."""
    data = read_sidecar(folder)
    data.pop("version", None)
    data.update(fields)
    write_sidecar(folder, data)


def total_size(locals_: dict[str, LocalAsset]) -> int:
    return sum(item.size_bytes for item in locals_.values())


def format_size(size: int) -> str:
    value = float(size)
    for unit in ("B", "KB", "MB", "GB"):
        if value < 1024 or unit == "GB":
            return f"{value:.0f} {unit}" if unit in ("B", "KB") else f"{value:.1f} {unit}"
        value /= 1024
    return f"{value:.1f} GB"


def _subdirs(folder: Path) -> list[Path]:
    try:
        return sorted(path for path in folder.iterdir() if path.is_dir())
    except OSError:
        return []


def _files(folder: Path) -> list[Path]:
    try:
        return [path for path in folder.iterdir() if path.is_file()]
    except OSError:
        return []


def _read_json(path: Path) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None


def _write_json_atomic(path: Path, payload: Any) -> None:
    """Write via a temp file so a crash mid-write never leaves half a JSON file."""
    temp = path.with_name(f"{path.name}.tmp")
    temp.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    os.replace(temp, path)

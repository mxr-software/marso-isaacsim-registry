"""Download one asset's USDZ package into the downloads folder.

Each download is written into a ``<asset_id>.part`` staging folder and only
moved into place once complete, so an interrupted download never looks
finished to a later scan (or to the Blender add-on sharing the folder).
"""

from __future__ import annotations

import shutil
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

from . import api, http, storage
from .api import Asset
from .storage import LocalAsset

_ZIP_MAGIC = b"PK\x03\x04"
_CRATE_MAGIC = b"PXR-USDC"
_USDA_MAGIC = b"#usda"

ProgressFn = Callable[[int, int], None]
CancelledFn = Callable[[], bool]


class DownloadError(RuntimeError):
    """An asset could not be downloaded; the message is fit to show the user."""


@dataclass(frozen=True)
class DownloadRequest:
    asset: Asset
    project_name: str
    api_key: str
    base_url: str
    downloads_dir: Path
    cache_dir: Path
    source: str = "marso-isaacsim"


def download_asset(
    request: DownloadRequest,
    *,
    progress: ProgressFn | None = None,
    cancelled: CancelledFn | None = None,
) -> LocalAsset:
    """Resolve, download, verify and commit one asset; return it as a ``LocalAsset``.

    A presigned URL that has expired by the time the download starts (HTTP 403
    from storage) is resolved once more and retried.
    """
    asset = request.asset
    final_dir = storage.asset_dir(request.downloads_dir, request.project_name, asset.asset_id)
    staging_dir = final_dir.with_name(f"{final_dir.name}{storage.STAGING_SUFFIX}")
    if staging_dir.exists():
        shutil.rmtree(staging_dir, ignore_errors=True)
    staging_dir.mkdir(parents=True, exist_ok=True)

    try:
        usd_name = _download_usdz(request, staging_dir, progress, cancelled)
        thumbnail = storage.find_thumbnail(request.cache_dir, asset.asset_id)
        if thumbnail is not None:
            shutil.copyfile(thumbnail, staging_dir / storage.ASSET_THUMBNAIL_NAME)
        storage.write_sidecar(
            staging_dir,
            {
                "asset_id": asset.asset_id,
                "name": asset.name,
                "project_id": asset.project_id,
                "project_name": request.project_name,
                "model_version": asset.model_version,
                "usd_file": usd_name,
                "downloaded_at": time.time(),
                "source": request.source,
            },
        )
    except BaseException:
        shutil.rmtree(staging_dir, ignore_errors=True)
        raise

    try:
        if final_dir.exists():
            shutil.rmtree(final_dir)
        staging_dir.replace(final_dir)
    except OSError as exc:
        shutil.rmtree(staging_dir, ignore_errors=True)
        raise DownloadError(
            "The existing download could not be replaced; it may be open in the stage. "
            f"Close it and try again. ({exc})"
        ) from exc
    local = storage.read_local_asset(final_dir)
    if local is None:  # pragma: no cover - the file was just verified
        raise DownloadError("The downloaded package went missing.")
    return local


def _download_usdz(request: DownloadRequest, staging_dir: Path, progress, cancelled) -> str:
    target = staging_dir / f"{storage.USD_FILE_STEM}.usdz"
    for attempt in range(2):
        usdz = _resolve_usdz(request)
        try:
            http.download_to_file(
                usdz.download_url, target, progress=progress, cancelled=cancelled, expected_size=usdz.size_bytes
            )
        except http.MarsoApiError as exc:
            if exc.status_code == 403 and attempt == 0:
                continue  # the presigned URL expired before we used it; sign a fresh one
            raise DownloadError(f"Download failed: {exc}") from exc
        break
    _verify_usd(target)
    return target.name


def _resolve_usdz(request: DownloadRequest) -> api.DownloadFile:
    try:
        resolved, errors = api.request_downloads(request.api_key, request.base_url, [request.asset.asset_id])
    except http.MarsoAuthError:
        raise
    except http.NETWORK_ERRORS as exc:
        raise DownloadError(f"Could not get a download link: {exc}") from exc
    download = resolved.get(request.asset.asset_id)
    if download is None:
        raise DownloadError(errors.get(request.asset.asset_id, "No download is available for this asset."))
    if download.usdz is None:
        raise DownloadError("This asset has no USD package to download yet.")
    return download.usdz


def _verify_usd(path: Path) -> None:
    with path.open("rb") as handle:
        head = handle.read(8)
    if not head:
        raise DownloadError("The downloaded package is empty.")
    if not (head.startswith(_ZIP_MAGIC) or head.startswith(_CRATE_MAGIC) or head.startswith(_USDA_MAGIC)):
        raise DownloadError("The download is not a USD package.")

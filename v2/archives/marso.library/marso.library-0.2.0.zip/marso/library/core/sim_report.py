"""A Sim Studio run as a single HTML page: every video, its results card and its notes.

Dark page in Marso's Design Language colours; opens straight from the run folder in a browser.
"""

from __future__ import annotations

import html
from pathlib import Path
from typing import Any

from . import sim_job

_STYLE = """
body{background:#17191b;color:#f8f8fb;font:15px/1.55 "Geist","Segoe UI",system-ui,sans-serif;margin:0;padding:44px 52px}
.eyebrow{font:600 12px "Geist Mono",Consolas,monospace;color:#b48bff;letter-spacing:.08em;text-transform:uppercase}
h1{font-size:30px;margin:4px 0 6px;font-weight:600} .meta{color:#9ea7b8;margin-bottom:28px}
section{margin:44px 0;max-width:1320px} h2{font-size:22px;margin:4px 0 14px;font-weight:600}
video,img{width:100%;border:1px solid #32363f;border-radius:12px;background:#060607;display:block}
.pair{display:grid;grid-template-columns:3fr 2fr;gap:18px;align-items:start}
.links a{color:#b48bff;margin-right:18px;text-decoration:none} .links{margin-top:12px;font-size:14px}
.error{color:#f5746d;white-space:pre-wrap;font:12px Consolas,monospace}
@media (max-width: 900px){.pair{grid-template-columns:1fr}}
"""


def write_report(folder: Path, run: dict[str, Any]) -> Path:
    sections = []
    for test in run.get("tests", []):
        key = test.get("key", "")
        spec = next((s for s in sim_job.TESTS if s.key == key), None)
        video = test.get("video") or test.get("clean")
        media = f"<video src='{html.escape(video)}' controls muted loop playsinline></video>" if video else ""
        card = f"<img src='{html.escape(test['card'])}' alt='Results'>" if test.get("card") else ""
        links = []
        if test.get("video"):
            links.append(f"<a href='{html.escape(test['video'])}'>Branded video</a>")
        if test.get("clean"):
            links.append(f"<a href='{html.escape(test['clean'])}'>Clean video</a>")
        if test.get("scene"):
            links.append(f"<a href='{html.escape(test['scene'])}'>Scene (.usda)</a>")
        sections.append(
            f"<section><div class='eyebrow'>{html.escape(spec.eyebrow if spec else key)}</div>"
            f"<h2>{html.escape(spec.summary if spec else '')}</h2><div class='pair'>{media}{card}</div>"
            f"<div class='links'>{''.join(links)}</div></section>"
        )
    for failure in run.get("errors", []):
        sections.append(f"<section><div class='eyebrow'>{html.escape(failure.get('test', ''))} failed</div>"
                        f"<div class='error'>{html.escape(failure.get('error', ''))}</div></section>")
    settings = run.get("settings", {})
    meta = f"{settings.get('width')}&times;{settings.get('height')} &middot; {settings.get('fps')} fps &middot; {html.escape(run.get('created', ''))}"
    page = (f"<!doctype html><html><head><meta charset='utf-8'><title>Marso Sim Studio</title><style>{_STYLE}</style></head>"
            f"<body><div class='eyebrow'>Marso &middot; Sim Studio</div><h1>{html.escape(run.get('name', ''))}</h1>"
            f"<div class='meta'>{meta}</div>{''.join(sections)}</body></html>")
    path = folder / sim_job.REPORT_FILE
    path.write_text(page, encoding="utf-8")
    return path

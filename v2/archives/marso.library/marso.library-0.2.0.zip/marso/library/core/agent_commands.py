"""The agent connection's command registry: name, description, parameter schema, handler. (stdlib only)

The Kit side registers each command a remote agent may call. A request names a command and passes one
``params`` dict, which is checked against a small JSON Schema before the handler sees it. A handler
that starts slow work returns ``job_id`` (and a ``job`` snapshot) so the caller can wait on it.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable

Handler = Callable[[dict[str, Any]], Any]


class ServiceError(RuntimeError):
    """A request that cannot be carried out; the message is for the person reading the chat."""

    def __init__(self, message: str, *, code: str = "service_error") -> None:
        super().__init__(message)
        self.code = code


class InvalidParams(ValueError):
    """The request's ``params`` do not match the command's schema."""


@dataclass(frozen=True)
class Command:
    name: str
    description: str
    params: dict[str, Any]
    handler: Handler
    main_thread: bool
    returns_job: bool

    def describe(self) -> dict[str, Any]:
        return {"name": self.name, "description": self.description, "params": self.params, "returns_job": self.returns_job}


def object_schema(properties: dict[str, Any], required: tuple[str, ...] = ()) -> dict[str, Any]:
    """A closed JSON Schema object: unknown parameters are rejected."""
    schema: dict[str, Any] = {"type": "object", "properties": properties, "additionalProperties": False}
    if required:
        schema["required"] = list(required)
    return schema


STRING = {"type": "string", "minLength": 1, "maxLength": 200}
BOOL = {"type": "boolean"}
IDS = {"type": "array", "items": STRING}


class Registry:
    """The commands one agent connection serves."""

    def __init__(self) -> None:
        self._commands: dict[str, Command] = {}

    def command(self, name: str, description: str, params: dict[str, Any] | None = None, *,
                main_thread: bool = True, returns_job: bool = False) -> Callable[[Handler], Handler]:
        """Register ``handler`` as command ``name``.

        ``main_thread=False`` is for handlers that only touch thread-safe state (the job registry)
        or that block for a while, like ``wait_job``; everything else runs on Kit's loop.
        """

        def register(handler: Handler) -> Handler:
            if name in self._commands:
                raise ValueError(f"Duplicate agent command: {name}")
            self._commands[name] = Command(name, description, params or object_schema({}), handler, main_thread, returns_job)
            return handler

        return register

    def get(self, name: str) -> Command | None:
        return self._commands.get(name)

    def names(self) -> list[str]:
        return sorted(self._commands)

    def describe(self) -> list[dict[str, Any]]:
        return [self._commands[name].describe() for name in self.names()]


_JSON_TYPES: dict[str, tuple[type, ...]] = {
    "string": (str,),
    "boolean": (bool,),
    "integer": (int,),
    "number": (int, float),
    "array": (list,),
    "object": (dict,),
    "null": (type(None),),
}


def validate(schema: dict[str, Any], value: Any, path: str = "params") -> list[str]:
    """Check ``value`` against the small JSON Schema subset the commands use."""
    errors: list[str] = []
    expected = schema.get("type")
    if expected is not None:
        allowed = expected if isinstance(expected, list) else [expected]
        if not any(_is_type(value, kind) for kind in allowed):
            return [f"{path} must be {' or '.join(allowed)}"]
    if "enum" in schema and value not in schema["enum"]:
        errors.append(f"{path} must be one of {schema['enum']}")
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        if "minimum" in schema and value < schema["minimum"]:
            errors.append(f"{path} must be >= {schema['minimum']}")
        if "maximum" in schema and value > schema["maximum"]:
            errors.append(f"{path} must be <= {schema['maximum']}")
    if isinstance(value, str):
        if "minLength" in schema and len(value) < schema["minLength"]:
            errors.append(f"{path} must be at least {schema['minLength']} characters")
        if "maxLength" in schema and len(value) > schema["maxLength"]:
            errors.append(f"{path} must be at most {schema['maxLength']} characters")
    if isinstance(value, list):
        if "minItems" in schema and len(value) < schema["minItems"]:
            errors.append(f"{path} needs at least {schema['minItems']} item(s)")
        if "maxItems" in schema and len(value) > schema["maxItems"]:
            errors.append(f"{path} takes at most {schema['maxItems']} item(s)")
        if "items" in schema:
            for index, item in enumerate(value):
                errors.extend(validate(schema["items"], item, f"{path}[{index}]"))
    if isinstance(value, dict):
        properties = schema.get("properties")
        if properties is not None:
            for key in schema.get("required", []):
                if key not in value:
                    errors.append(f"{path}.{key} is required")
            for key, item in value.items():
                if key in properties:
                    errors.extend(validate(properties[key], item, f"{path}.{key}"))
                elif schema.get("additionalProperties") is False:
                    errors.append(f"{path}.{key} is not a known parameter")
    return errors


def _is_type(value: Any, kind: str) -> bool:
    if kind in ("integer", "number") and isinstance(value, bool):
        return False
    return isinstance(value, _JSON_TYPES.get(kind, ()))

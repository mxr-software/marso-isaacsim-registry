"""The one HTTP client for the Marso public API and its presigned downloads.

Bearer auth, JSON in and out, linear-backoff retry on 429/5xx, and a streaming
file download that copes with S3 objects stored gzip-compressed without a
``Content-Encoding`` header (Marso's USDZ files arrive that way). Pure
``urllib`` so it imports and tests without Kit.
"""

from __future__ import annotations

import gzip
import json
import time
import urllib.error
import urllib.request
import uuid
import zlib
from pathlib import Path
from typing import Any, Callable

REQUEST_TIMEOUT_S = 60
RETRY_ATTEMPTS = 3
RETRY_BACKOFF_S = 1.5
CHUNK_SIZE = 1 << 20
_RETRYABLE_STATUSES = (429, 500, 502, 503, 504)
_GZIP_MAGIC = b"\x1f\x8b"

# Set by the extension on startup so the API can tell this client apart.
user_agent = "marso-isaacsim"

ProgressFn = Callable[[int, int], None]
CancelledFn = Callable[[], bool]


class MarsoApiError(RuntimeError):
    """A Marso API or download request failed."""

    def __init__(self, message: str, status_code: int | None = None, code: str = "") -> None:
        super().__init__(message)
        self.status_code = status_code
        self.code = code  # the API's error code, e.g. INSUFFICIENT_CREDITS or FORMAT_NOT_AVAILABLE


class MarsoAuthError(MarsoApiError):
    """HTTP 401/403 from the API itself: the API key is missing, invalid or revoked."""


class DownloadCancelled(Exception):
    """The caller asked a download to stop part-way."""


# Every failure a background worker can see from this module. Shared so each
# worker catches the same well-defined set instead of a bare ``except``.
NETWORK_ERRORS: tuple[type[Exception], ...] = (MarsoApiError, urllib.error.URLError, OSError, ValueError)


def json_request(method: str, url: str, api_key: str | None = None, body: dict[str, Any] | None = None) -> dict:
    """Send a JSON request to the API and return the parsed JSON object."""
    headers = {"Content-Type": "application/json", "Accept": "application/json"}
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"
    data = json.dumps(body).encode("utf-8") if body is not None else None
    raw = _send(urllib.request.Request(url, data=data, headers=_with_agent(headers), method=method), auth=True)
    if not raw.strip():
        return {}
    parsed = json.loads(raw)
    if not isinstance(parsed, dict):
        raise MarsoApiError("Unexpected non-object JSON response.")
    return parsed


def multipart_request(url: str, api_key: str, filename: str, data: bytes, content_type: str,
                      field: str = "file") -> dict:
    """POST one file as ``multipart/form-data`` (an image upload) and return the parsed JSON object."""
    boundary = f"marso-{uuid.uuid4().hex}"
    head = (f"--{boundary}\r\n"
            f'Content-Disposition: form-data; name="{field}"; filename="{filename}"\r\n'
            f"Content-Type: {content_type}\r\n\r\n")
    body = head.encode() + data + f"\r\n--{boundary}--\r\n".encode()
    headers = {"Content-Type": f"multipart/form-data; boundary={boundary}", "Accept": "application/json",
               "Authorization": f"Bearer {api_key}"}
    raw = _send(urllib.request.Request(url, data=body, headers=_with_agent(headers), method="POST"), auth=True)
    parsed = json.loads(raw) if raw.strip() else {}
    if not isinstance(parsed, dict):
        raise MarsoApiError("Unexpected non-object JSON response.")
    return parsed


def download_bytes(url: str) -> bytes:
    """Download a small file (a thumbnail) into memory, gunzipping when needed."""
    data = _send(urllib.request.Request(url, headers=_with_agent({}), method="GET"), auth=False)
    return gzip.decompress(data) if data[:2] == _GZIP_MAGIC else data


def download_to_file(
    url: str,
    destination: Path,
    *,
    progress: ProgressFn | None = None,
    cancelled: CancelledFn | None = None,
    expected_size: int = 0,
) -> int:
    """Stream ``url`` into ``destination``, decompressing gzip on the fly.

    ``progress(done, total)`` counts transferred bytes; ``total`` is the
    Content-Length, else ``expected_size``, else 0 when unknown. Returns the
    number of bytes written. Raises ``DownloadCancelled`` when ``cancelled()``
    turns true between chunks; the partial file is left for the caller to
    discard.
    """
    request = urllib.request.Request(url, headers=_with_agent({}), method="GET")
    for attempt in range(RETRY_ATTEMPTS + 1):
        try:
            with urllib.request.urlopen(request, timeout=REQUEST_TIMEOUT_S) as response:
                total = int(response.headers.get("Content-Length") or 0) or expected_size
                return _stream(response, destination, total, progress, cancelled)
        except urllib.error.HTTPError as exc:
            exc.close()
            if exc.code in _RETRYABLE_STATUSES and attempt < RETRY_ATTEMPTS:
                time.sleep(RETRY_BACKOFF_S * (attempt + 1))
                continue
            raise MarsoApiError(f"Download failed: HTTP {exc.code} {exc.reason}", status_code=exc.code) from exc
        except (urllib.error.URLError, TimeoutError, ConnectionError) as exc:
            if attempt < RETRY_ATTEMPTS:
                time.sleep(RETRY_BACKOFF_S * (attempt + 1))
                continue
            raise MarsoApiError(f"Download failed: {exc}") from exc
    raise MarsoApiError("Download failed after retries.")


def _stream(response, destination: Path, total: int, progress, cancelled) -> int:
    inflater: _GzipInflater | None = None
    done = 0
    written = 0
    first = True
    with destination.open("wb") as handle:
        while True:
            if cancelled is not None and cancelled():
                raise DownloadCancelled()
            chunk = response.read(CHUNK_SIZE)
            if not chunk:
                break
            done += len(chunk)
            if first:
                first = False
                encoding = (response.headers.get("Content-Encoding") or "").lower()
                if chunk[:2] == _GZIP_MAGIC or encoding == "gzip":
                    inflater = _GzipInflater()
            if inflater is not None:
                chunk = inflater.feed(chunk)
            handle.write(chunk)
            written += len(chunk)
            if progress is not None:
                progress(done, total)
        if inflater is not None:
            tail = inflater.flush()
            handle.write(tail)
            written += len(tail)
    return written


class _GzipInflater:
    """Incremental gzip decoder that also follows on into any further gzip members."""

    def __init__(self) -> None:
        self._decompressor = zlib.decompressobj(16 + zlib.MAX_WBITS)

    def feed(self, chunk: bytes) -> bytes:
        out = self._decompressor.decompress(chunk)
        while self._decompressor.eof and self._decompressor.unused_data:
            rest = self._decompressor.unused_data
            self._decompressor = zlib.decompressobj(16 + zlib.MAX_WBITS)
            out += self._decompressor.decompress(rest)
        return out

    def flush(self) -> bytes:
        return self._decompressor.flush()


def _with_agent(headers: dict[str, str]) -> dict[str, str]:
    return {**headers, "User-Agent": user_agent}


def _send(request: urllib.request.Request, *, auth: bool) -> bytes:
    for attempt in range(RETRY_ATTEMPTS + 1):
        try:
            with urllib.request.urlopen(request, timeout=REQUEST_TIMEOUT_S) as response:
                return response.read()
        except urllib.error.HTTPError as exc:
            if exc.code in _RETRYABLE_STATUSES and attempt < RETRY_ATTEMPTS:
                exc.close()
                time.sleep(RETRY_BACKOFF_S * (attempt + 1))
                continue
            fallback = f"HTTP {exc.code} {exc.reason}"
            message, code = _error_details(exc, fallback)
            # A 403 for a feature the plan lacks is not a bad key, so it is not reported as one.
            if auth and (exc.code == 401 or (exc.code == 403 and code != "PLAN_FEATURE_REQUIRED")):
                raise MarsoAuthError("The API key was rejected." if message == fallback else message,
                                     status_code=exc.code, code=code) from exc
            raise MarsoApiError(message, status_code=exc.code, code=code) from exc
        except (TimeoutError, ConnectionError) as exc:
            if attempt < RETRY_ATTEMPTS:
                time.sleep(RETRY_BACKOFF_S * (attempt + 1))
                continue
            raise MarsoApiError(f"Could not reach Marso: {exc}") from exc
    raise MarsoApiError("Rate limited; exceeded retry attempts.", status_code=429)


def _error_details(exc: urllib.error.HTTPError, fallback: str) -> tuple[str, str]:
    """The API's own error message and code when the body is its JSON error envelope."""
    try:
        body = json.loads(exc.read().decode("utf-8", errors="replace") or "{}")
    except (ValueError, OSError):
        return fallback, ""
    finally:
        exc.close()
    error = body.get("error") if isinstance(body, dict) else None
    if not isinstance(error, dict):
        return fallback, ""
    code = str(error.get("code") or "")
    if error.get("message"):
        return f"{error['message']} (HTTP {exc.code})", code
    return fallback, code

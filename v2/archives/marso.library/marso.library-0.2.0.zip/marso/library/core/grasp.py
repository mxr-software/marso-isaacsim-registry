"""Top-down grasps for a parallel gripper, planned from an asset's surface (no Isaac Sim needed).

The gripper comes straight down with its fingers open, closes them along a horizontal axis and
lifts. A grasp is a pair of faces, at some height, that the two pads can press on from opposite
sides: each face's outward normal points back at its finger, close to the closing axis (an
antipodal grasp, so squeezing holds the object rather than pushing it out). It must be narrower
than the hand opens; the fingers must come down and close without touching anything else; the
palm must stay clear of the top and the fingertips clear of the table. Among those, the grip
nearest the centre of mass wins (it twists least in the fingers), preferring narrow, deep grips.

Points come with outward unit normals (``oriented_surface`` makes them from triangles). Sizes are
the Franka Hand's (``FRANKA_HAND``), in metres; world Z is up.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np


@dataclass(frozen=True)
class Hand:
    opening: float  # finger gap when fully open
    pad_width: float  # finger pad size across the closing axis
    pad_height: float  # the part of the pad, from the tip up, that grips
    finger_length: float  # how far the fingers reach below the palm
    finger_thickness: float  # each finger, along the closing axis
    palm_half: tuple[float, float]  # palm half-size (along the closing axis, across it)
    payload_kg: float
    clearance: float = 0.004  # kept between open fingers and the object, and above the table


FRANKA_HAND = Hand(opening=0.08, pad_width=0.02, pad_height=0.018, finger_length=0.045, finger_thickness=0.012,
                   palm_half=(0.105, 0.032), payload_kg=3.0)
# Robotiq 2F-140 on a UR10e: 140 mm stroke, long fingers, about 11 kg left of the arm's payload.
# The Inspire hand on a Unitree G1, pinching between its thumb and its index and middle fingers: they
# start 66 mm apart and meet as the hand closes. About 35 N of pinch; the G1's arm carries about 1.5 kg.
INSPIRE_PINCH = Hand(opening=0.06, pad_width=0.018, pad_height=0.02, finger_length=0.045, finger_thickness=0.018,
                     palm_half=(0.09, 0.05), payload_kg=1.5)
ROBOTIQ_2F140 = Hand(opening=0.14, pad_width=0.025, pad_height=0.03, finger_length=0.07, finger_thickness=0.016,
                     palm_half=(0.075, 0.04), payload_kg=11.0, clearance=0.005)


@dataclass(frozen=True)
class Cup:
    """A suction cup coming straight down onto the object."""

    radius: float  # its sealing lip
    hold_n: float  # the pull it holds along its axis before letting go
    shear_n: float  # the sideways load it holds
    payload_kg: float  # what the arm carries
    flatness: float = 0.0025  # how far the surface under the lip may stray from flat
    tilt_deg: float = 25.0  # how far from facing up that surface may lean
    body_radius: float = 0.035  # the tool behind the cup: nothing may stand higher than the cup within it


# The UR10's short suction gripper: a ~50 mm cup at a working vacuum holds about 120 N.
SUCTION_CUP = Cup(radius=0.016, hold_n=120.0, shear_n=80.0, payload_kg=10.0)
SUCTION_SAFETY = 1.6  # weight x this must stay within the cup's hold (the carry's accelerations)

YAW_STEPS = 24  # closing axes tried, over 180 degrees
STRIP_STEP = 0.008  # spacing of the slices tried across the closing axis
LEVELS = 4  # grip heights tried per slice
MIN_CONTACTS = 3  # surface samples a pad must bear on
COVERAGE = 0.6  # share of the pad width the object must fill
CONTACT_BAND = 0.0025  # surface within this of the outermost point is taken as touching the pad
MAX_SLANT = math.tan(math.radians(10))  # a gripped face may turn this far from square
WIDTH_MARGIN = 0.006  # kept spare inside the opening, so a wide grip never just grazes
FACING = 0.9  # |normal . closing axis| for a face a pad can press on: inside a friction cone of about 25 degrees
SURFACE_VOXEL = 0.003
GRIP_N = 70.0  # squeeze per finger, newtons: the real Franka Hand's continuous force
PAD_PATCH = 0.004  # metres: the soft pads' contact patch radius, resisting twist
TWIST_MARGIN = 0.6  # share of the grip the weight may use: rehearsed, the racket at 0.42 holds, a Colt 1911 by its grip at 0.77 swings out


@dataclass(frozen=True)
class Grasp:
    centre: tuple[float, float, float]  # between the finger pads, at the pads' middle
    yaw: float  # the closing axis, radians from +X
    width: float  # the object between the pads
    tip_z: float  # where the fingertips end up
    twist: float = 0.0  # share of the grip the object's weight uses trying to turn out of it (0 when unknown)

    @property
    def axis(self) -> tuple[float, float]:
        return math.cos(self.yaw), math.sin(self.yaw)


def why_not(mass_kg: float | None, hand: Hand = FRANKA_HAND) -> str | None:
    """A reason the hand should not try at all, before any geometry."""
    if mass_kg is not None and mass_kg > hand.payload_kg:
        return f"too heavy to lift ({mass_kg:.3g} kg; the arm carries {hand.payload_kg:g} kg)"
    return None


def why_not_suction(mass_kg: float | None, cup: Cup = SUCTION_CUP) -> str | None:
    """A reason a suction cup should not try at all, before any geometry."""
    if mass_kg is None:
        return None
    if mass_kg > cup.payload_kg:
        return f"too heavy to lift ({mass_kg:.3g} kg; the arm carries {cup.payload_kg:g} kg)"
    if mass_kg * 9.81 * SUCTION_SAFETY > cup.hold_n:
        return f"too heavy for the suction cup ({mass_kg * 9.81:.0f} N; it holds {cup.hold_n:g} N)"
    return None


def plan_suction(points: np.ndarray, normals: np.ndarray, centre_of_mass, table_z: float, cup: Cup = SUCTION_CUP,
                 mass_kg: float | None = None) -> Grasp | None:
    """The best spot for a suction cup coming straight down, or None.

    The lip must seal all round on an upward-facing patch flat to ``cup.flatness``; nothing may stand
    higher than the cup within the tool's footprint; and the object's weight, hanging off the cup by
    its centre of mass's sideways offset, must not peel the cup off (``twist`` is that share of the hold).
    The spot nearest the centre of mass wins.
    """
    pts = np.asarray(points, dtype=np.float64)
    nrm = np.asarray(normals, dtype=np.float64)
    com = np.asarray(centre_of_mass, dtype=np.float64)
    facing_up = nrm[:, 2] >= math.cos(math.radians(cup.tilt_deg))
    candidates = thin_points(pts[facing_up], 0.006)
    if len(candidates) > 1500:
        candidates = candidates[np.linspace(0, len(candidates) - 1, 1500).astype(int)]
    best, best_score = None, math.inf
    for p in candidates:
        d = pts[:, :2] - p[:2]
        r = np.hypot(d[:, 0], d[:, 1])
        # The surface under the lip: upward-facing and near the spot's height (not a thin part's underside).
        disc = (r <= cup.radius) & (np.abs(pts[:, 2] - p[2]) <= 0.008) & (nrm[:, 2] > 0.3)
        if disc.sum() < 8:
            continue
        lip = disc & (r >= 0.55 * cup.radius)
        sectors = np.unique(((np.arctan2(d[lip, 1], d[lip, 0]) + math.pi) // (math.pi / 4)).astype(int))
        if len(sectors) < 8:
            continue  # the lip would hang over an edge or a hole: no seal
        a = np.column_stack([pts[disc, 0], pts[disc, 1], np.ones(disc.sum())])
        coef, *_ = np.linalg.lstsq(a, pts[disc, 2], rcond=None)
        normal = np.array([-coef[0], -coef[1], 1.0])
        normal /= np.linalg.norm(normal)
        if normal[2] < math.cos(math.radians(cup.tilt_deg)) or np.ptp(pts[disc, 2] - a @ coef) > cup.flatness:
            continue
        if np.any((r <= cup.body_radius) & (pts[:, 2] > p[2] + 0.006) & ~disc):
            continue  # something beside the spot stands higher: the tool would hit it
        if p[2] - table_z < 0.004:
            continue
        lever = float(np.hypot(*(com[:2] - p[:2])))
        peel = (mass_kg * 9.81 * lever) / (cup.hold_n * cup.radius) if mass_kg else 0.0
        if peel > 1.0:
            continue
        score = lever + 0.3 * math.acos(min(1.0, normal[2])) + 0.05 * peel
        if score < best_score:
            best_score = score
            best = Grasp((float(p[0]), float(p[1]), float(p[2])), 0.0, 0.0, float(p[2]), float(peel))
    return best


def thin_points(points: np.ndarray, voxel: float) -> np.ndarray:
    """One point per ``voxel`` cube."""
    if len(points) == 0:
        return points
    keys = np.floor(points / voxel).astype(np.int64)
    _, first = np.unique(keys, axis=0, return_index=True)
    return points[np.sort(first)]


def oriented_surface(points: np.ndarray, triangles: np.ndarray, voxel: float = SURFACE_VOXEL) -> tuple[np.ndarray, np.ndarray]:
    """Surface samples (triangle centres) with outward unit normals, thinned to one per voxel and facing.

    Normals follow the winding; a mesh wound inside out (negative volume) is flipped. Both faces of
    a thin wall survive the thinning, since samples facing different ways are kept apart.
    """
    a, b, c = points[triangles[:, 0]], points[triangles[:, 1]], points[triangles[:, 2]]
    cross = np.cross(b - a, c - a)
    if np.einsum("ij,ij->i", a, np.cross(b, c)).sum() < 0:
        cross = -cross
    length = np.linalg.norm(cross, axis=1)
    keep = length > 1e-14
    centres = ((a + b + c) / 3.0)[keep]
    normals = cross[keep] / length[keep, None]
    facing = np.argmax(np.abs(normals), axis=1) * 2 + (normals[np.arange(len(normals)), np.argmax(np.abs(normals), axis=1)] > 0)
    keys = np.concatenate([np.floor(centres / voxel).astype(np.int64), facing[:, None]], axis=1)
    _, first = np.unique(keys, axis=0, return_index=True)
    first = np.sort(first)
    return centres[first], normals[first]


def no_grasp_reason(points: np.ndarray, normals=None, centre_of_mass=None, table_z: float | None = None,
                    hand: Hand = FRANKA_HAND) -> str:
    """Why ``plan`` found nothing, in words for a results card. With the surface's normals, centre of
    mass and table height it can tell "nowhere to hold it" from "it would twist out where it fits"."""
    pts = np.asarray(points, dtype=np.float64)
    if normals is not None and centre_of_mass is not None and table_z is not None             and plan(pts, normals, centre_of_mass, table_z, hand) is not None:
        return "the fingers only fit where it would twist out of the grip (too far from its centre of mass)"
    narrowest = math.inf
    for k in range(YAW_STEPS):
        yaw = math.pi * k / YAW_STEPS
        narrowest = min(narrowest, float(np.ptp(pts[:, :2] @ np.array([math.cos(yaw), math.sin(yaw)]))))
    if narrowest > hand.opening - 2 * hand.clearance:
        return f"too wide for the gripper ({narrowest * 100:.1f} cm; it opens {hand.opening * 100:g} cm) and no rim or handle to hold"
    return "no secure grip: every place the fingers fit would let it slip or turn"


def plan(points: np.ndarray, normals: np.ndarray, centre_of_mass, table_z: float, hand: Hand = FRANKA_HAND,
         mass_kg: float | None = None, friction: float | None = None, grip_n: float = GRIP_N,
         twist_limit: float | None = None, obstacles: np.ndarray | None = None, accept=None,
         gravity=(0.0, 0.0, -1.0), coverage: float = COVERAGE) -> Grasp | None:
    """The best top-down grasp of an object at rest, or None when the hand cannot hold it anywhere.

    With the object's mass (and friction), grips it would twist out of are refused: its weight acting
    off the closing axis must stay well within what the pads' friction resists (``TWIST_MARGIN``, or
    ``twist_limit`` to allow riskier grips; the safest grip still wins).

    ``obstacles`` are other points the gripper must keep clear of (another hand holding the object):
    none may stand where the open fingers or the palm above them would go. ``accept(centre, yaw,
    width)`` can refuse grasps for reasons of the caller's own. "Down" is the frame's -Z: plan a grasp from any
    direction by turning the points so that direction points down, and ``gravity`` (the way the weight
    pulls, in that frame) with them. ``coverage`` is the share of each pad's width the object must
    fill (less for a hand on its side, where the pad's width is the object's thickness).
    """
    pts = np.asarray(points, dtype=np.float64)
    nrm = np.asarray(normals, dtype=np.float64)
    com = np.asarray(centre_of_mass, dtype=np.float64)
    best, best_score = None, math.inf
    reach = hand.opening / 2 - hand.clearance  # how far from the centre the object may come, fingers open
    z = pts[:, 2]
    obs = np.asarray(obstacles, dtype=np.float64) if obstacles is not None and len(obstacles) else None
    pull = np.asarray(gravity, dtype=np.float64) / max(np.linalg.norm(gravity), 1e-9)
    for k in range(YAW_STEPS):
        yaw = math.pi * k / YAW_STEPS
        axis = np.array([math.cos(yaw), math.sin(yaw)])
        across = np.array([-axis[1], axis[0]])
        c = pts[:, :2] @ axis  # along the closing axis
        w = pts[:, :2] @ across
        n_c = nrm[:, :2] @ axis
        n_w = nrm[:, :2] @ across
        if obs is not None:
            oc, ow, oz = obs[:, :2] @ axis, obs[:, :2] @ across, obs[:, 2]
        for w0 in np.arange(w.min() + hand.pad_width * coverage / 2, w.max() - hand.pad_width * coverage / 2 + 1e-9, STRIP_STEP):
            strip = np.abs(w - w0) <= hand.pad_width / 2 + hand.clearance
            if strip.sum() < 2 * MIN_CONTACTS:
                continue
            top = z[strip].max()
            lowest = max(table_z + hand.clearance, top - hand.finger_length + hand.pad_height / 2)
            highest = top - hand.pad_height / 2
            levels = np.linspace(highest, lowest, LEVELS) if highest > lowest else [max(highest, table_z + hand.clearance)]
            for tip in levels:
                pad = strip & (np.abs(w - w0) <= hand.pad_width / 2) & (z >= tip) & (z <= tip + hand.pad_height)
                if pad.sum() < 2 * MIN_CONTACTS:
                    continue
                pieces = _runs(np.sort(c[pad]), gap=2 * hand.clearance)  # what the slice cuts through
                for i in range(len(pieces)):
                    for j in range(i, len(pieces)):
                        # The fingers close on the outermost material between them: pieces i..j.
                        lo, hi = pieces[i][0], pieces[j][1]
                        if hi - lo > 2 * reach - WIDTH_MARGIN:
                            break
                        c0 = (lo + hi) / 2
                        left = pad & (c <= lo + CONTACT_BAND) & (n_c < 0)
                        right = pad & (c >= hi - CONTACT_BAND) & (n_c > 0)
                        if not (_bears(c, w, n_c, n_w, nrm[:, 2], left, -1.0, hand, coverage)
                                and _bears(c, w, n_c, n_w, nrm[:, 2], right, 1.0, hand, coverage)):
                            continue
                        if not _clear(c, w, z, strip, w0, lo, hi, c0, tip, reach, hand):
                            continue
                        if obs is not None and _blocked(oc, ow, oz, c0, w0, tip, reach, hand):
                            continue  # the gripper would run into the other hand
                        centre_xy = axis * c0 + across * w0
                        grip_z = tip + hand.pad_height / 2
                        if accept is not None and not accept((float(centre_xy[0]), float(centre_xy[1]), float(grip_z)), yaw,
                                                             float(hi - lo)):
                            continue
                        twist = _twist(com, np.array([*centre_xy, grip_z]), axis, across, w, z, left, right,
                                       mass_kg, friction, grip_n, pull)
                        if twist > (TWIST_MARGIN if twist_limit is None else twist_limit):
                            continue
                        # The object turns about the closing axis if its weight acts off that line: the
                        # sideways offset matters most; hanging below the grip is steadier than above it.
                        off = com[:2] - centre_xy
                        score = 3.0 * abs(off @ across) + 0.7 * abs(off @ axis)
                        above = float((com - np.array([*centre_xy, grip_z])) @ -pull)
                        score += 0.6 * max(0.0, above) + 0.25 * max(0.0, -above)
                        score += 0.5 * (hi - lo)  # a narrow grip closes fast and squarely
                        facing = min(-_facing(n_c, n_w, nrm[:, 2], left), _facing(n_c, n_w, nrm[:, 2], right))
                        score += 0.05 * (1.0 - facing)  # pads pressing straight on
                        # More pad in contact, top to bottom, holds better and resists turning.
                        score -= 4.0 * min(np.ptp(z[left]), np.ptp(z[right]))
                        score += 0.15 * twist
                        if score < best_score:
                            best_score = score
                            best = Grasp((float(centre_xy[0]), float(centre_xy[1]), float(grip_z)), yaw, float(hi - lo), float(tip),
                                         float(twist))
    return best


def _runs(values: np.ndarray, gap: float) -> list[tuple[float, float]]:
    """Runs of sorted values with no hole wider than ``gap``: the separate pieces a slice cuts through."""
    if len(values) == 0:
        return []
    breaks = np.where(np.diff(values) > gap)[0]
    starts = np.concatenate([[0], breaks + 1])
    ends = np.concatenate([breaks, [len(values) - 1]])
    return [(float(values[s]), float(values[e])) for s, e in zip(starts, ends)]


def _facing(n_c, n_w, n_z, mine) -> float:
    """The closing-axis part of the contact's overall normal (bumps and engraving average out)."""
    mean = np.array([n_c[mine].mean(), n_w[mine].mean(), n_z[mine].mean()])
    return float(mean[0] / max(np.linalg.norm(mean), 1e-9))


def _bears(c, w, n_c, n_w, n_z, mine, sign: float, hand: Hand, coverage: float = COVERAGE) -> bool:
    """One pad's contact is good: it bears across most of the pad's width; the surface there faces the
    finger within the friction cone (a rounded shoulder would squeeze the object out); and it runs
    square to the closing axis (a slanted face, like a box corner, pushes the object sideways)."""
    if mine.sum() < MIN_CONTACTS or np.ptp(w[mine]) < coverage * hand.pad_width:
        return False
    if sign * _facing(n_c, n_w, n_z, mine) < FACING:
        return False
    slope, _offset = np.polyfit(w[mine], c[mine], 1)
    return abs(slope) <= MAX_SLANT


def _blocked(oc, ow, oz, c0: float, w0: float, tip: float, reach: float, hand: Hand) -> bool:
    """Whether any obstacle point stands where the open fingers (from the tips up) or the palm above
    them would go."""
    margin = 0.01
    up = oz >= tip - margin
    fingers = (up & (oz <= tip + hand.finger_length) & (np.abs(ow - w0) <= hand.pad_width / 2 + margin)
               & (np.abs(oc - c0) <= reach + hand.finger_thickness + margin))
    palm = ((oz > tip + hand.finger_length - margin) & (np.abs(ow - w0) <= hand.palm_half[1] + margin)
            & (np.abs(oc - c0) <= hand.palm_half[0] + margin))
    return bool(np.any(fingers | palm))


def _twist(com, centre, axis, across, w, z, left, right, mass_kg, friction, grip_n, pull=(0.0, 0.0, -1.0)) -> float:
    """How much of the grip the object's weight uses up trying to turn it out of the fingers (1 = all).

    Two ways: turning about the closing axis, which friction spread over the pad contact resists; and
    tipping between the pads, which the squeeze resists over the contact's extent (its height for
    tipping about the axis across the pads, its width for tipping about the approach). ``pull`` is the
    way the weight acts in the planning frame. 0 when the mass is unknown.
    """
    if not mass_kg:
        return 0.0
    torque = np.cross(np.asarray(com) - centre, mass_kg * 9.81 * np.asarray(pull))
    a3, b3 = np.array([axis[0], axis[1], 0.0]), np.array([across[0], across[1], 0.0])
    radius = max(PAD_PATCH, min(_patch_radius(w[left], z[left]), _patch_radius(w[right], z[right])))
    turning = abs(torque @ a3) / (2 * (friction or 0.5) * grip_n * radius)
    height = max(PAD_PATCH, min(np.ptp(z[left]), np.ptp(z[right])))
    width = max(PAD_PATCH, min(np.ptp(w[left]), np.ptp(w[right])))
    tipping = max(abs(torque @ b3) / (grip_n * height), abs(torque[2]) / (grip_n * width))
    return max(turning, tipping)


def _patch_radius(w: np.ndarray, z: np.ndarray) -> float:
    """Mean distance of a contact's samples from its middle, across and down the pad."""
    return float(np.hypot(w - w.mean(), z - z.mean()).mean())


def _clear(c, w, z, strip, w0: float, a: float, b: float, c0: float, tip: float, reach: float, hand: Hand) -> bool:
    """The open fingers come down and close onto faces ``a`` and ``b`` without meeting anything else,
    and nothing stands above the palm's underside within its footprint."""
    finger_zone = strip & (z >= tip) & (z <= tip + hand.finger_length)
    outer = reach + hand.finger_thickness + hand.clearance
    # A face that flares a little above the contact just meets the finger higher up; anything further
    # out is in the way.
    give = 2 * CONTACT_BAND
    swept = finger_zone & (((c >= c0 - outer) & (c < a - give)) | ((c > b + give) & (c <= c0 + outer)))
    if np.any(swept):
        return False
    palm_zone = (np.abs(w - w0) <= hand.palm_half[1]) & (np.abs(c - c0) <= hand.palm_half[0])
    return not np.any(palm_zone & (z > tip + hand.finger_length - hand.clearance))


def volume_centroid(points: np.ndarray, triangles: np.ndarray) -> np.ndarray | None:
    """Centre of mass of a closed triangle mesh of even density (None when it encloses no volume)."""
    a, b, c = points[triangles[:, 0]], points[triangles[:, 1]], points[triangles[:, 2]]
    volumes = np.einsum("ij,ij->i", a, np.cross(b, c)) / 6.0
    total = volumes.sum()
    if abs(total) < 1e-12:
        return None
    return ((a + b + c) / 4.0 * volumes[:, None]).sum(axis=0) / total


def min_jerk(t: float) -> float:
    """Smooth 0 -> 1 progress over t in [0, 1], with zero speed and acceleration at both ends."""
    t = min(1.0, max(0.0, t))
    return t * t * t * (10 - 15 * t + 6 * t * t)

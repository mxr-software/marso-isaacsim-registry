"""Client for the Marso calls that make a new asset: the Studio project graph (image, 3D and PBR runs),
an asset's detail (has its USD been minted yet?), prices and the credit balance.

  GET  {base}/mcp/projects?skip&limit                      -- your Studio projects, newest first
  POST {base}/mcp/projects                                 -- create one: {"name"}
  GET  {base}/mcp/projects/{p}/graphs/{g}                  -- a graph: its nodes (with their results) and links
  POST {base}/mcp/projects/{p}/graphs/{g}/nodes            -- add a node: {"type", "position"}
  PUT  {base}/mcp/projects/{p}/graphs/{g}/nodes/{n}/generation-mode       -- {"mode": "object"}
  PUT  {base}/mcp/projects/{p}/graphs/{g}/nodes/{n}/generation-3d-options -- {"model", "polygon_count"}
  PUT  {base}/mcp/projects/{p}/graphs/{g}/nodes/{n}/image  -- {"image_asset_id"}
  POST {base}/mcp/projects/{p}/graphs/{g}/links            -- {"source_id", "target_id"}
  POST {base}/mcp/uploads/image                            -- multipart image upload -> {"asset_id"}
  POST {base}/mcp/executions/image-generation              -- {"project_id", "graph_id", "node_id", "prompt"}
  POST {base}/mcp/executions/generate-3d-mesh-image        -- {..., "image_asset_id"}
  POST {base}/mcp/executions/pbr                           -- {"project_id", "graph_id", "node_id"}
  GET  {base}/mcp/executions/{id}                          -- {"status", "error"}
  GET  {base}/assets/{id}                                  -- detail; a PBR result's "enriched_status" is
                                                              "succeeded" once its USD is minted
  GET  {base}/mcp/pricing, {base}/pricing, {base}/account/credits

The ``/mcp`` routes are plain REST, the same ones the Marso Blender add-on's Create panel uses. A run
returns only an execution id; its result is read off the node's ``properties`` once it has finished.
"""

from __future__ import annotations

import urllib.parse
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from . import api, http

PROJECT_NAME = api.CREATED_PROJECT_NAME  # every asset made from Isaac Sim goes in this Marso project
ROOT_GRAPH_ID = "root"

NODE_IMAGE_GENERATION = "image-generation"
NODE_IMAGE = "image"
NODE_GENERATE_3D = "generate-3d"
NODE_GENERATE_PBR = "generate-pbr-textures"
GENERATION_MODE_OBJECT = "object"  # one object on a plain background, which is what a 3D step wants
MODEL_3D = "hunyuan_3d_3_1"  # the Blender add-on's choice: a good mesh for 40 credits
POLYGON_COUNT = 500_000

IMAGE_OUTPUT = "image_asset_id"  # where an image node keeps its result
TEXTURE_OUTPUT = "texture_asset_id"  # where the 3D and PBR nodes keep theirs (the mesh, then the PBR asset)

SUCCEEDED = frozenset({"SUCCEEDED", "PARTIAL_SUCCEEDED"})
TERMINAL = SUCCEEDED | {"FAILED", "CANCELED"}

PROMPT_MIN, PROMPT_MAX = 3, 16384
MAX_IMAGE_BYTES = 5 * 1024 * 1024
IMAGE_TYPES = {".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".webp": "image/webp"}
NODE_SPACING = 400.0  # graph layout: one row per image, its 3D and PBR nodes to its right
_PROJECT_PAGE = 100


class StudioError(http.MarsoApiError):
    """The API answered, but not with something this client can use."""


@dataclass(frozen=True)
class StudioProject:
    project_id: str
    graph_id: str
    name: str


@dataclass(frozen=True)
class Execution:
    execution_id: str
    status: str
    error: str = ""

    @property
    def finished(self) -> bool:
        return self.status in TERMINAL

    @property
    def succeeded(self) -> bool:
        return self.status in SUCCEEDED


MINTED = "succeeded"  # ``enriched_status`` once Marso has minted the finished USD
MINT_FAILED = frozenset({"failed", "error"})


@dataclass(frozen=True)
class AssetDetail:
    """``GET /assets/{id}``. A PBR result has a USDZ as soon as its PBR run finishes (``basic_usdz``: the
    mesh and textures only). Marso then mints the finished one, ``usdz``, with its description, real name
    and physics (a rigid body and colliders): ``enriched_status`` turns ``succeeded``. That is the one the
    library should download."""

    asset_id: str
    name: str = ""
    available_formats: tuple[str, ...] = ()
    has_usdz: bool = False  # some USDZ exists (the basic one counts)
    enriched_status: str = ""  # "" when the API does not report it
    usdz_id: str = ""
    basic_usdz_id: str = ""
    model_version: str = ""
    url: str = ""  # a presigned download link for the asset itself (an image's picture), about a minute
    thumbnail_url: str = ""

    @property
    def minted(self) -> bool:
        """Marso has minted the finished USD (description, name, physics)."""
        if self.enriched_status:
            return self.enriched_status.lower() == MINTED and self.has_usdz
        return self.has_usdz  # an API that does not report minting: a USDZ is the best sign there is

    @property
    def mint_failed(self) -> bool:
        return self.enriched_status.lower() in MINT_FAILED


@dataclass(frozen=True)
class Prices:
    """Credit costs, -1 where Marso did not say."""

    image: int = -1
    mesh: int = -1
    pbr: int = -1

    @property
    def asset(self) -> int:
        """A 3D asset from an image: the mesh and its PBR materials."""
        return self.mesh + self.pbr if self.mesh >= 0 and self.pbr >= 0 else -1


class Studio:
    """The creation calls for one API key and endpoint. Every method blocks (call it off the UI thread)."""

    def __init__(self, api_key: str, base_url: str) -> None:
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")

    # --- projects and graphs --------------------------------------------------------------

    def find_or_create_project(self, name: str = PROJECT_NAME) -> StudioProject:
        """The Studio project with exactly this name, created (empty) if there is none."""
        for raw in self._project_summaries():
            if raw.get("name") == name and raw.get("id"):
                return StudioProject(str(raw["id"]), str(raw.get("active_graph_id") or ROOT_GRAPH_ID), name)
        raw = self._json("POST", "/mcp/projects", {"name": name})
        if not raw.get("id"):
            raise StudioError("Marso did not return the new project's id.")
        return StudioProject(str(raw["id"]), str(raw.get("active_graph_id") or ROOT_GRAPH_ID), name)

    def _project_summaries(self):
        skip = 0
        while True:
            page = self._json("GET", f"/mcp/projects?{urllib.parse.urlencode({'skip': skip, 'limit': _PROJECT_PAGE})}")
            projects = [p for p in page.get("projects") or [] if isinstance(p, dict)]
            yield from projects
            if len(projects) < _PROJECT_PAGE:
                return
            skip += len(projects)

    def graph(self, project: StudioProject) -> dict:
        return self._json("GET", self._graph_path(project))

    def next_row(self, project: StudioProject) -> int:
        """The first empty row of the graph's layout, so a new image does not land on an old one."""
        rows = [float(((node.get("position") or {}).get("y")) or 0.0) for node in self.graph(project).get("nodes") or []
                if isinstance(node, dict)]
        return int(max(rows) // NODE_SPACING) + 1 if rows else 0

    def node_output(self, project: StudioProject, node_id: str, name: str) -> str:
        """A result a node holds in its properties (an image or texture asset id), or ""."""
        for node in self.graph(project).get("nodes") or []:
            if isinstance(node, dict) and node.get("id") == node_id:
                value = (node.get("properties") or {}).get(name)
                return str(value) if value else ""
        return ""

    def create_node(self, project: StudioProject, node_type: str, column: int, row: int) -> str:
        position = {"x": column * NODE_SPACING, "y": row * NODE_SPACING}
        raw = self._json("POST", f"{self._graph_path(project)}/nodes", {"type": node_type, "position": position})
        if not raw.get("id"):
            raise StudioError(f"Marso did not return the new {node_type} node's id.")
        return str(raw["id"])

    def set_generation_mode(self, project: StudioProject, node_id: str, mode: str = GENERATION_MODE_OBJECT) -> None:
        self._json("PUT", f"{self._graph_path(project)}/nodes/{node_id}/generation-mode", {"mode": mode})

    def set_3d_options(self, project: StudioProject, node_id: str) -> None:
        self._json("PUT", f"{self._graph_path(project)}/nodes/{node_id}/generation-3d-options",
                   {"model": MODEL_3D, "polygon_count": POLYGON_COUNT})

    def set_node_image(self, project: StudioProject, node_id: str, image_asset_id: str) -> None:
        self._json("PUT", f"{self._graph_path(project)}/nodes/{node_id}/image", {"image_asset_id": image_asset_id})

    def link(self, project: StudioProject, source_id: str, target_id: str) -> None:
        self._json("POST", f"{self._graph_path(project)}/links", {"source_id": source_id, "target_id": target_id})

    def upload_image(self, path: Path) -> str:
        """Upload a picture (png, jpg or webp, up to 5 MB) and return its asset id."""
        path = Path(path)
        content_type = IMAGE_TYPES.get(path.suffix.lower())
        if content_type is None:
            raise StudioError("Use a PNG, JPEG or WebP image.")
        data = path.read_bytes()
        if len(data) > MAX_IMAGE_BYTES:
            raise StudioError(f"The image is {len(data) / 1048576:.1f} MB; Marso takes up to 5 MB.")
        raw = http.multipart_request(self._url("/mcp/uploads/image"), self.api_key, path.name, data, content_type)
        if not raw.get("asset_id"):
            raise StudioError("Marso did not return the uploaded image's id.")
        return str(raw["asset_id"])

    # --- runs -----------------------------------------------------------------------------

    def start_image(self, project: StudioProject, node_id: str, prompt: str) -> str:
        return self._start("/mcp/executions/image-generation", project, node_id, prompt=prompt)

    def start_mesh(self, project: StudioProject, node_id: str, image_asset_id: str) -> str:
        return self._start("/mcp/executions/generate-3d-mesh-image", project, node_id, image_asset_id=image_asset_id)

    def start_pbr(self, project: StudioProject, node_id: str) -> str:
        return self._start("/mcp/executions/pbr", project, node_id)

    def execution(self, execution_id: str) -> Execution:
        raw = self._json("GET", f"/mcp/executions/{execution_id}")
        error = raw.get("error") if isinstance(raw.get("error"), dict) else {}
        message = str(error.get("message") or error.get("code") or "")
        return Execution(str(raw.get("id") or execution_id), str(raw.get("status") or ""), message)

    def _start(self, route: str, project: StudioProject, node_id: str, **extra: Any) -> str:
        raw = self._json("POST", route, {"project_id": project.project_id, "graph_id": project.graph_id,
                                         "node_id": node_id, **extra})
        if not raw.get("execution_id"):
            raise StudioError("Marso did not return the run's id.")
        return str(raw["execution_id"])

    # --- assets ---------------------------------------------------------------------------

    def asset_detail(self, asset_id: str) -> AssetDetail | None:
        """The asset's detail, or None while Marso does not list it yet (just made, still settling)."""
        try:
            raw = self._json("GET", f"/assets/{asset_id}")
        except http.MarsoApiError as exc:
            if exc.status_code == 404 and not isinstance(exc, http.MarsoAuthError):
                return None
            raise
        formats = tuple(str(f) for f in raw.get("available_formats") or [] if f)
        usdz = raw.get("usdz") if isinstance(raw.get("usdz"), dict) else {}
        basic = raw.get("basic_usdz") if isinstance(raw.get("basic_usdz"), dict) else {}
        return AssetDetail(
            asset_id=str(raw.get("asset_id") or asset_id),
            name=str(raw.get("name") or ""),
            available_formats=formats,
            has_usdz="usdz" in formats or bool(usdz),
            enriched_status=str(raw.get("enriched_status") or ""),
            usdz_id=str(usdz.get("asset_id") or ""),
            basic_usdz_id=str(basic.get("asset_id") or ""),
            model_version=str(raw.get("model_version") or ""),
            url=str(raw.get("url") or raw.get("download_url") or ""),
            thumbnail_url=str(raw.get("thumbnail_url") or ""),
        )

    def listed_project(self, project: StudioProject, asset_id: str) -> api.Project | None:
        """The library listing's entry for this project, once it lists the asset (None until then).

        The listing groups assets by the same projects; matched by id, else by name.
        """
        for library in api.iter_library(self.api_key, self.base_url):
            for listed in library.projects:
                same = listed.project_id == project.project_id or listed.name == project.name
                if same and any(asset.asset_id == asset_id for asset in listed.assets):
                    return listed
        return None

    # --- prices and credits ---------------------------------------------------------------

    def prices(self) -> Prices:
        studio = self._json("GET", "/mcp/pricing")
        public = self._json("GET", "/pricing")
        image = _int((studio.get("execution_costs") or {}).get("image_generation"))
        mesh = -1
        for entry in studio.get("generation_3d_costs") or []:
            if isinstance(entry, dict) and MODEL_3D in (entry.get("model"), entry.get("id"), entry.get("key")):
                mesh = _int(entry.get("default_credit_cost"))
        # The Studio price list has no PBR entry; the public mesh-to-PBR price is the same step.
        pbr = _int((public.get("execution_costs") or {}).get("mesh_to_pbr"))
        return Prices(image, mesh, pbr)

    def credits(self) -> int:
        return _int(self._json("GET", "/account/credits").get("total_credits"))

    # --- plumbing -------------------------------------------------------------------------

    def _graph_path(self, project: StudioProject) -> str:
        return f"/mcp/projects/{project.project_id}/graphs/{project.graph_id}"

    def _url(self, route: str) -> str:
        return f"{self.base_url}{route}"

    def _json(self, method: str, route: str, body: dict | None = None) -> dict:
        return http.json_request(method, self._url(route), self.api_key, body)


def _int(value: Any) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return -1


def check_prompt(prompt: str) -> str:
    """Why a prompt cannot be sent, or "" when it can."""
    length = len((prompt or "").strip())
    if length < PROMPT_MIN:
        return f"Describe the object in at least {PROMPT_MIN} characters."
    if length > PROMPT_MAX:
        return f"Keep the description under {PROMPT_MAX} characters."
    return ""


def check_image(path: Path) -> str:
    """Why an image file cannot be used, or "" when it can."""
    path = Path(path)
    if not path.is_file():
        return "That image file does not exist."
    if path.suffix.lower() not in IMAGE_TYPES:
        return "Use a PNG, JPEG or WebP image."
    if path.stat().st_size > MAX_IMAGE_BYTES:
        return "The image is over 5 MB."
    return ""

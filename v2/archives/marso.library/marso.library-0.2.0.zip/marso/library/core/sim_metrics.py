"""Sim Studio's numbers: what each test measured, and what it means.

Pure Python (numpy only for the mesh volume), so it is unit tested without Isaac Sim. The Sim
Studio runner (``marso/library/sim``) records trajectories, slip angles, wind speeds and contacts
inside Isaac Sim and calls in here to turn them into results and plain-English notes.
"""

from __future__ import annotations

import math
from dataclasses import asdict, dataclass, field

CONTACT_M = 0.004  # the lowest point within 4 mm of the ground counts as touching it
REST_SPEED = 0.02  # m/s: a jump faster than this while at rest counts as a twitch
REST_DRIFT_M = 0.002  # at rest = staying within 2 mm ...
REST_DRIFT_DEG = 1.0  # ... and 1 degree of the final pose ...
REST_HOLD_S = 0.3  # ... for at least this long
FLUSH_MM = 3.0  # resting this close to the ground (mm) counts as sitting flush
MIN_BOUNCE_M = 0.005  # a rebound lower than this is not counted as a bounce


@dataclass(frozen=True)
class Sample:
    """One physics step of one rigid body."""

    t: float
    bottom_z: float  # lowest point of the visual mesh, metres above the ground
    x: float
    y: float
    z: float  # rigid-body origin
    speed: float  # linear, m/s
    spin: float  # angular, rad/s
    tilt_deg: float  # rotation from the starting orientation


@dataclass
class DropResult:
    name: str
    drop_height_m: float
    impact_time_s: float | None = None
    impact_speed_ms: float | None = None
    bounces: int = 0
    rebound_m: float = 0.0
    restitution_est: float | None = None
    settle_time_s: float | None = None
    rest_gap_mm: float | None = None
    fit: str = ""
    slide_m: float = 0.0
    final_tilt_deg: float = 0.0
    fell_through: bool = False
    still_moving: bool = False
    twitches: int = 0
    static: bool = False
    restitution_authored: float | None = None
    friction_authored: float | None = None  # dynamic
    mass_kg: float | None = None
    touched: list[str] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return asdict(self)


def analyse_drop(
    name: str,
    samples: list[Sample],
    drop_height: float,
    authored: dict | None = None,
    touched: list[str] | None = None,
) -> DropResult:
    """Impact, bounces, rebound, settling, resting gap, slide and tilt from one body's samples.

    ``authored`` carries the asset's own physics values (restitution, dynamic_friction, mass);
    ``touched`` names other bodies it came into contact with, which taints its numbers.
    """
    authored = authored or {}
    result = DropResult(
        name=name,
        drop_height_m=drop_height,
        restitution_authored=authored.get("restitution"),
        friction_authored=authored.get("dynamic_friction"),
        mass_kg=authored.get("mass"),
        touched=list(touched or []),
    )
    # ``touched`` is kept in the result only: assets pass through each other in this test, so an
    # overlap is visual and does not change the numbers.
    round_shape = bool(authored.get("round"))
    if not samples:
        result.static = True
        result.notes.append("No rigid body: it does not fall.")
        return result

    impact = next((i for i, s in enumerate(samples) if s.bottom_z <= CONTACT_M), None)
    if impact is None:
        result.still_moving = True
        result.notes.append("Never reached the ground in the recorded time.")
        return result
    hit = samples[impact]
    result.impact_time_s = round(hit.t, 3)
    result.impact_speed_ms = round(max(s.speed for s in samples[: impact + 1]), 3)

    # Bounces: each time the lowest point leaves the ground and comes back, with its apex.
    apex = 0.0
    airborne = False
    for sample in samples[impact + 1 :]:
        if sample.bottom_z > CONTACT_M:
            airborne = True
            apex = max(apex, sample.bottom_z)
        elif airborne:
            if apex >= MIN_BOUNCE_M:
                result.bounces += 1
                result.rebound_m = max(result.rebound_m, apex)
            airborne, apex = False, 0.0
    if airborne and apex >= MIN_BOUNCE_M:
        result.bounces += 1
        result.rebound_m = max(result.rebound_m, apex)
    result.rebound_m = round(result.rebound_m, 4)
    if drop_height > 0:
        # For a ballistic drop, rebound height / drop height = e^2 (ignores spin and rolling).
        result.restitution_est = round(math.sqrt(min(1.0, result.rebound_m / drop_height)), 3)
        if result.restitution_authored is not None and result.bounces:
            gap = abs(result.restitution_est - result.restitution_authored)
            if gap > 0.15:
                result.notes.append(
                    f"Bounced like e={result.restitution_est:.2f}, not the authored {result.restitution_authored:.2f}: "
                    "the impact turned into spin or hit off-centre."
                )

    settle = _settle_index(samples, impact)
    final = samples[-1]
    if settle is None:
        result.still_moving = True
        result.notes.append(
            "Still rolling at the end of the run: PhysX applies no rolling resistance by default."
            if round_shape else "Still moving at the end of the run (rocking or creeping)."
        )
    else:
        result.settle_time_s = round(samples[settle].t - hit.t, 3)
        result.twitches = _count_twitches(samples[settle:])
        if result.twitches:
            result.notes.append(
                f"Twitches while at rest ({result.twitches} small jump{'s' if result.twitches != 1 else ''}): "
                "contact jitter, often from heavy bodies "
                "on SDF or triangle-mesh colliders."
            )
    result.rest_gap_mm = round(final.bottom_z * 1000.0, 1)
    result.fit = resting_fit(result.rest_gap_mm)
    result.slide_m = round(math.hypot(final.x - hit.x, final.y - hit.y), 3)
    result.final_tilt_deg = round(final.tilt_deg, 1)
    result.fell_through = final.bottom_z < -0.05
    if result.fell_through:
        result.notes.append("Fell through the ground: the collider is missing or broken.")
    elif result.fit == "floats":
        result.notes.append("Rests above the ground: the collider is larger than the visible mesh.")
    elif result.fit == "sinks":
        result.notes.append("Rests in the ground: the collider is smaller than the visible mesh.")
    if result.final_tilt_deg > 30 and not round_shape:
        result.notes.append("Ended on its side: tipped over.")
    return result


def boxes_touch(a: tuple, b: tuple, tolerance: float = 0.003) -> bool:
    """Whether two (min_xyz, max_xyz) boxes overlap, each shrunk by ``tolerance``."""
    (a_min, a_max), (b_min, b_max) = a, b
    return all(a_min[i] + tolerance < b_max[i] and b_min[i] + tolerance < a_max[i] for i in range(3))


def resting_fit(gap_mm: float) -> str:
    if gap_mm > FLUSH_MM:
        return "floats"
    if gap_mm < -FLUSH_MM:
        return "sinks"
    return "flush"


def _settle_index(samples: list[Sample], start: int) -> int | None:
    """First sample after ``start`` from which the body stays within REST_DRIFT of its final pose.

    Judged by pose rather than speed, so a body that twitches in place still counts as at rest
    while one that keeps rolling, however slowly, does not.
    """
    final = samples[-1]
    calm_from = None
    for index in range(len(samples) - 1, start - 1, -1):
        sample = samples[index]
        near = (math.dist((sample.x, sample.y, sample.z), (final.x, final.y, final.z)) <= REST_DRIFT_M
                and abs(sample.tilt_deg - final.tilt_deg) <= REST_DRIFT_DEG)
        if not near:
            break
        calm_from = index
    if calm_from is None or final.t - samples[calm_from].t < REST_HOLD_S:
        return None
    return calm_from


def _count_twitches(samples: list[Sample], calm_s: float = 0.1) -> int:
    """Jumps faster than REST_SPEED that break at least ``calm_s`` of stillness (not the last settling bounces)."""
    twitches, calm_since = 0, None
    for sample in samples:
        if sample.speed > REST_SPEED:
            if calm_since is not None and sample.t - calm_since >= calm_s:
                twitches += 1
            calm_since = None
        elif calm_since is None:
            calm_since = sample.t
    return twitches


def tilt_between(q0: tuple[float, float, float, float], q1: tuple[float, float, float, float]) -> float:
    """Angle in degrees between two orientations given as (w, x, y, z) unit quaternions."""
    dot = abs(sum(a * b for a, b in zip(q0, q1)))
    return math.degrees(2.0 * math.acos(min(1.0, dot)))


@dataclass
class ScaleResult:
    name: str
    size_cm: tuple[float, float, float]  # width (X), depth (Y), height (Z)
    mass_kg: float | None
    density: float | None  # physics material, kg/m^3
    bbox_volume_l: float
    mesh_volume_l: float | None
    mass_from_density_kg: float | None = None
    mass_from_bbox_kg: float | None = None
    implied_density: float | None = None
    notes: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return asdict(self)


def analyse_scale(
    name: str,
    size_m: tuple[float, float, float],
    mass_kg: float | None,
    density: float | None,
    mesh_volume_m3: float | None,
) -> ScaleResult:
    """Size, volumes and what the authored mass implies."""
    bbox_volume = size_m[0] * size_m[1] * size_m[2]
    result = ScaleResult(
        name=name,
        size_cm=tuple(round(v * 100.0, 1) for v in size_m),
        mass_kg=round(mass_kg, 3) if mass_kg is not None else None,
        density=round(density, 1) if density is not None else None,
        bbox_volume_l=round(bbox_volume * 1000.0, 3),
        mesh_volume_l=round(mesh_volume_m3 * 1000.0, 3) if mesh_volume_m3 else None,
    )
    if density:
        result.mass_from_bbox_kg = round(density * bbox_volume, 3)
        if mesh_volume_m3:
            result.mass_from_density_kg = round(density * mesh_volume_m3, 3)
    if mass_kg and mesh_volume_m3:
        result.implied_density = round(mass_kg / mesh_volume_m3, 1)
    if mass_kg and result.mass_from_bbox_kg and abs(mass_kg - result.mass_from_bbox_kg) <= 0.02 * mass_kg:
        result.notes.append(
            "The authored mass equals density x bounding-box volume, so it counts the empty space "
            "around the shape (and inside hollow objects)."
        )
    if mass_kg and result.mass_from_density_kg and result.mass_from_density_kg < 0.5 * mass_kg:
        ratio = mass_kg / result.mass_from_density_kg
        result.notes.append(f"The authored mass is {ratio:.1f}x what the material density gives for the mesh volume.")
    return result


def mesh_volume(points, triangles) -> float:
    """Signed volume of a triangle mesh (m^3, absolute). ``points`` Nx3, ``triangles`` Mx3 vertex indices.

    Exact for a closed mesh; for an open one it is only an estimate.
    """
    import numpy as np

    p = np.asarray(points, dtype=np.float64)
    t = np.asarray(triangles, dtype=np.int64)
    if len(t) == 0:
        return 0.0
    a, b, c = p[t[:, 0]], p[t[:, 1]], p[t[:, 2]]
    return float(abs(np.einsum("ij,ij->i", a, np.cross(b, c)).sum()) / 6.0)


ROUND_TOLERANCE_MM = 1.0  # a round object more out of round than this rolls unevenly


def roundness(points) -> tuple[float, float] | None:
    """How round an object is: (radius in m, out of round in mm).

    Fits a sphere to the outer surface, then takes the outermost point in each of ~2,600
    directions from its centre. "Out of round" is the spread of those radii (99th minus 5th
    percentile), so a few small holes, such as a bowling ball's finger holes, do not count.
    """
    import numpy as np

    p = np.asarray(points, dtype=np.float64)
    if len(p) < 50:
        return None
    centre = (p.min(axis=0) + p.max(axis=0)) / 2
    d = np.linalg.norm(p - centre, axis=1)
    outer = p[d >= np.percentile(d, 40)]
    a = np.c_[2 * outer, np.ones(len(outer))]
    solution, *_ = np.linalg.lstsq(a, (outer ** 2).sum(axis=1), rcond=None)
    c = solution[:3]
    radius = float(np.sqrt(max(solution[3] + c @ c, 0.0)))
    v = p - c
    r = np.linalg.norm(v, axis=1)
    keep = r > 0
    v, r = v[keep], r[keep]
    # equal-area directions: 36 bands of height (cos theta) by 72 sectors
    band = np.minimum(((np.clip(v[:, 2] / r, -1.0, 1.0) + 1.0) / 2.0 * 36).astype(int), 35)
    phi = np.arctan2(v[:, 1], v[:, 0])
    bins = band * 72 + np.minimum(((phi + np.pi) / (2 * np.pi) * 72).astype(int), 71)
    outermost = np.zeros(36 * 72)
    np.maximum.at(outermost, bins, r)
    outermost = outermost[outermost > 0]
    spread = float(np.percentile(outermost, 99) - np.percentile(outermost, 5))
    return radius, round(spread * 1000, 1)


SPHERE_LIKE = 0.05  # out of round by less than this fraction of the radius: meant to be a sphere (a ball, not a melon)


def roundness_note(bump_mm: float | None, radius_m: float | None = None) -> str | None:
    if bump_mm is None or bump_mm <= ROUND_TOLERANCE_MM:
        return None
    if radius_m and bump_mm / 1000.0 > SPHERE_LIKE * radius_m:
        return None  # an oval object (a watermelon) is not a badly made ball

    return (f"Out of round by {bump_mm:g} mm, so its collider (built from the mesh) wobbles, veers and slows as it rolls. "
            "A sphere collider would roll true.")


def fan_triangles(counts, indices):
    """Triangulate USD faces (faceVertexCounts / faceVertexIndices) as fans; returns an Mx3 array."""
    import numpy as np

    counts = np.asarray(counts, dtype=np.int64)
    indices = np.asarray(indices, dtype=np.int64)
    starts = np.concatenate(([0], np.cumsum(counts)[:-1]))
    tris = []
    for n in np.unique(counts):
        if n < 3:
            continue
        face_starts = starts[counts == n]
        for k in range(1, n - 1):
            tris.append(np.stack([indices[face_starts], indices[face_starts + k], indices[face_starts + k + 1]], axis=1))
    return np.concatenate(tris) if tris else np.zeros((0, 3), dtype=np.int64)


# --- friction (tilt table) -----------------------------------------------------------------

BEHAVIOUR_SLIDES = "slides"
BEHAVIOUR_TIPS = "tips"
BEHAVIOUR_ROLLS = "rolls"
BEHAVIOUR_HOLDS = "holds"


@dataclass
class FrictionResult:
    name: str
    behaviour: str  # slides / tips / rolls / holds
    onset_deg: float | None  # table angle when it started to move
    mu_from_angle: float | None  # tan(onset), for a slide
    static_authored: float | None
    dynamic_authored: float | None
    predicted_static_deg: float | None
    predicted_dynamic_deg: float | None
    max_angle_deg: float = 0.0
    notes: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return asdict(self)


def angle_for(mu: float | None) -> float | None:
    """The incline at which a block with friction ``mu`` starts to slide."""
    return round(math.degrees(math.atan(mu)), 1) if mu is not None else None


def analyse_friction(
    name: str, behaviour: str, onset_deg: float | None, authored: dict | None, max_angle_deg: float
) -> FrictionResult:
    authored = authored or {}
    static, dynamic = authored.get("static_friction"), authored.get("dynamic_friction")
    slid = onset_deg is not None and behaviour == BEHAVIOUR_SLIDES
    result = FrictionResult(
        name=name,
        behaviour=behaviour,
        onset_deg=round(onset_deg, 1) if onset_deg is not None else None,
        mu_from_angle=round(math.tan(math.radians(onset_deg)), 2) if slid else None,
        static_authored=static,
        dynamic_authored=dynamic,
        predicted_static_deg=angle_for(static),
        predicted_dynamic_deg=angle_for(dynamic),
        max_angle_deg=max_angle_deg,
    )
    if behaviour == BEHAVIOUR_HOLDS:
        result.notes.append(f"Held on all the way to {max_angle_deg:g} degrees.")
    elif behaviour == BEHAVIOUR_ROLLS:
        result.notes.append("Rolled rather than slid: friction only decides whether it rolls or skids.")
    elif behaviour == BEHAVIOUR_TIPS:
        result.notes.append(
            f"Tipped over at {result.onset_deg:g} degrees before friction gave way: its base is narrow for its height."
        )
    elif slid:
        near_static = result.predicted_static_deg is not None and abs(result.onset_deg - result.predicted_static_deg) <= 2.5
        near_dynamic = result.predicted_dynamic_deg is not None and abs(result.onset_deg - result.predicted_dynamic_deg) <= 2.5
        if near_static:
            result.notes.append("Started to slide where its static friction predicts.")
        elif near_dynamic:
            result.notes.append(
                f"Started to slide at its dynamic-friction angle ({result.predicted_dynamic_deg:g} deg), not the static "
                f"one ({result.predicted_static_deg:g} deg): PhysX lets objects creep at about the dynamic coefficient."
            )
        elif result.predicted_static_deg is not None:
            low = min(result.predicted_dynamic_deg or result.predicted_static_deg, result.predicted_static_deg)
            high = max(result.predicted_dynamic_deg or result.predicted_static_deg, result.predicted_static_deg)
            if low <= result.onset_deg <= high:
                result.notes.append(
                    f"Slid at {result.onset_deg:g} deg, between its dynamic ({low:g} deg) and static ({high:g} deg) "
                    "friction angles, as expected."
                )
            elif result.onset_deg < low:
                result.notes.append(
                    f"Slid at {result.onset_deg:g} deg, earlier than its authored friction predicts ({low:g}-{high:g} deg)."
                )
            else:
                result.notes.append(
                    f"Held on to {result.onset_deg:g} deg, longer than its authored friction predicts ({low:g}-{high:g} deg)."
                )
    return result


# --- wind ------------------------------------------------------------------------------------

AIR_DENSITY = 1.225  # kg/m^3 at sea level
DRAG_COEFFICIENT = 1.05  # a bluff body
FRONTAL_FILL = 0.72  # share of the projected bounding box an irregular object fills
_BEAUFORT_LIMITS = (0.5, 1.5, 3.3, 5.5, 7.9, 10.7, 13.8, 17.1, 20.7, 24.4, 28.4, 32.6)
_BEAUFORT_NAMES = ("Calm", "Light air", "Light breeze", "Gentle breeze", "Moderate breeze", "Fresh breeze",
                   "Strong breeze", "Near gale", "Gale", "Strong gale", "Storm", "Violent storm", "Hurricane")


def beaufort(speed_ms: float) -> tuple[int, str]:
    """Beaufort number and name for a wind speed."""
    force = next((i for i, limit in enumerate(_BEAUFORT_LIMITS) if speed_ms < limit), len(_BEAUFORT_LIMITS))
    return force, _BEAUFORT_NAMES[force]


def drag_force(frontal_area_m2: float, relative_speed_ms: float) -> float:
    """Signed drag force (N) on a body, for the wind speed relative to it."""
    return 0.5 * AIR_DENSITY * DRAG_COEFFICIENT * frontal_area_m2 * relative_speed_ms * abs(relative_speed_ms)


@dataclass
class WindResult:
    name: str
    moves_at_ms: float | None
    tips_at_ms: float | None
    travelled_m: float
    frontal_area_m2: float
    mass_kg: float | None
    max_wind_ms: float
    notes: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return asdict(self)


LIFT_COEFFICIENT = 0.3  # a flat plate lying in a wind
FLAT_RATIO = 0.5  # height / sqrt(footprint area) below this counts as lying flat
GUST_INTENSITY = 0.15  # gusts swing the wind by about this fraction either way


def lift_force(top_area_m2: float, relative_speed_ms: float, flatness: float) -> float:
    """Upward lift (N) on an object lying flat in the wind; nothing for one that stands taller than flat.

    ``flatness`` is height / sqrt(footprint area): 0 for a sheet, about 1 for a cube.
    """
    if flatness >= FLAT_RATIO or relative_speed_ms <= 0:
        return 0.0
    coefficient = LIFT_COEFFICIENT * (1.0 - flatness / FLAT_RATIO)
    return 0.5 * AIR_DENSITY * coefficient * top_area_m2 * relative_speed_ms ** 2


def gust(t: float, x: float) -> float:
    """The gust factor on the mean wind at time t (s) and position x (m downwind): slow waves that roll downwind."""
    phase = t - x / 6.0
    swing = (0.6 * math.sin(2 * math.pi * 0.31 * phase) + 0.3 * math.sin(2 * math.pi * 0.87 * phase + 1.3)
             + 0.1 * math.sin(2 * math.pi * 2.3 * phase + 0.4))
    return 1.0 + GUST_INTENSITY * swing


def analyse_wind(
    name: str,
    moves_at: float | None,
    tips_at: float | None,
    travelled_m: float,
    frontal_area_m2: float,
    mass_kg: float | None,
    max_wind: float,
    rolls: bool = False,
) -> WindResult:
    result = WindResult(
        name=name,
        moves_at_ms=round(moves_at, 1) if moves_at is not None else None,
        tips_at_ms=round(tips_at, 1) if tips_at is not None else None,
        travelled_m=round(travelled_m, 3),
        frontal_area_m2=round(frontal_area_m2, 4),
        mass_kg=mass_kg,
        max_wind_ms=max_wind,
    )
    if moves_at is None:
        result.notes.append(f"Stayed put up to {max_wind:g} m/s ({beaufort(max_wind)[1].lower()}).")
    else:
        force, label = beaufort(moves_at)
        verb = "roll" if rolls else "move"
        result.notes.append(f"Started to {verb} at {result.moves_at_ms:g} m/s, Beaufort {force} ({label.lower()}).")
        if tips_at is not None:
            result.notes.append(f"Blown over at {result.tips_at_ms:g} m/s.")
    return result


# --- collisions --------------------------------------------------------------------------------


@dataclass
class ContactPair:
    a: str
    b: str
    first_contact_s: float
    steps: int = 0
    peak_impulse_ns: float = 0.0
    deepest_mm: float = 0.0  # the most negative separation seen, as a penetration depth

    def to_dict(self) -> dict:
        return asdict(self)


class ContactLog:
    """Accumulates PhysX contact reports, step by step, into per-pair numbers."""

    def __init__(self) -> None:
        self.pairs: dict[tuple[str, str], ContactPair] = {}
        self.last_step: dict[tuple[str, str], int] = {}

    def add(self, step: int, t: float, a: str, b: str, impulse_ns: float, separation_m: float) -> None:
        key = tuple(sorted((a, b)))
        pair = self.pairs.get(key)
        if pair is None:
            pair = self.pairs[key] = ContactPair(key[0], key[1], round(t, 3))
        if self.last_step.get(key) != step:
            pair.steps += 1
        self.last_step[key] = step
        pair.peak_impulse_ns = round(max(pair.peak_impulse_ns, impulse_ns), 4)
        pair.deepest_mm = round(max(pair.deepest_mm, -separation_m * 1000.0), 2)

    def resting_on(self, name: str, final_step: int, ground: str) -> list[str]:
        """What ``name`` was touching in the final step, the ground first."""
        found = [b if a == name else a for (a, b), step in self.last_step.items() if step >= final_step and name in (a, b)]
        return sorted(found, key=lambda other: (other != ground, other))


def collision_notes(pairs: list[ContactPair], ground: str) -> list[str]:
    notes = []
    between = [pair for pair in pairs if ground not in (pair.a, pair.b)]
    if not between:
        notes.append("No two objects touched: they may have missed each other.")
    for pair in between:
        if pair.deepest_mm > 5.0:
            notes.append(f"{pair.a} and {pair.b} sank {pair.deepest_mm:g} mm into each other: the colliders are coarse there.")
    return notes

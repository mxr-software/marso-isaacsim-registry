"""Marso's enrichment: what an asset is, what it is made of, its physics and real-world size.

Two sources carry the same schema (``schema_version`` 1.0.0):

- the API listing, ``asset["enrichment"]`` (no ``physics`` or ``dimensions``);
- the USD itself, the default prim's ``customData["virtuoso"]["enrichment"]``: a JSON string
  whose structured fields are Python-literal strings (``"{'value': 'kitchenware', ...}"``).

Ontology fields are ``{"value": ..., "token": ..., "qcode": <Wikidata id>, "source": "vlm"}``;
``value`` is the human word, ``token`` the stable machine key. Pure Python.
"""

from __future__ import annotations

import ast
import json
from dataclasses import asdict, dataclass, field
from typing import Any

# Facets the browsers can filter by: key -> label.
FACETS = {"category": "Category", "material": "Material", "setting": "Setting"}


@dataclass(frozen=True)
class Enrichment:
    display_name: str = ""
    description_short: str = ""
    description_long: str = ""
    category: str = ""
    subcategory: str = ""
    detail: str = ""
    tags: tuple[str, ...] = ()
    search_aliases: tuple[str, ...] = ()
    materials: tuple[str, ...] = ()  # "metal (powder coated)"
    material_classes: tuple[str, ...] = ()  # "metal"
    density_kg_m3: float | None = None
    static_friction: float | None = None
    dynamic_friction: float | None = None
    restitution: float | None = None
    hollow: bool | None = None
    physics_preset: str = ""
    dimensions_m: tuple[float, float, float] | None = None  # width, depth, height
    placements: tuple[str, ...] = ()
    setting: str = ""
    region: str = ""
    style_period: str = ""
    conditions: tuple[str, ...] = ()
    cleanliness: tuple[str, ...] = ()
    needs_review: bool = False
    review_reasons: tuple[str, ...] = ()
    schema_version: str = ""
    extra: dict[str, str] = field(default_factory=dict)  # anything newer this version does not know

    @property
    def is_empty(self) -> bool:
        return not (self.display_name or self.category or self.description_short or self.tags)

    @property
    def taxonomy(self) -> str:
        """Category > subcategory > detail, without repeats ("kitchenware > bottle > canteen")."""
        parts: list[str] = []
        for part in (self.category, self.subcategory, self.detail):
            if part and part not in parts:
                parts.append(part)
        return " > ".join(parts)

    @property
    def search_text(self) -> str:
        """Every word a search should match, lower-cased."""
        parts = [self.display_name, self.description_short, self.description_long, self.category, self.subcategory,
                 self.detail, *self.tags, *self.search_aliases, *self.materials, self.setting, self.physics_preset,
                 *self.placements, self.region, self.style_period]
        return " ".join(part for part in parts if part).lower()

    def facet(self, key: str) -> tuple[str, ...]:
        """The values this asset has for a filter facet."""
        if key == "category":
            return (self.category,) if self.category else ()
        if key == "material":
            return self.material_classes
        if key == "setting":
            return (self.setting,) if self.setting else ()
        return ()

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["dimensions_m"] = list(self.dimensions_m) if self.dimensions_m else None
        return data

    @classmethod
    def from_dict(cls, raw: Any) -> Enrichment | None:
        """Read back what ``to_dict`` wrote (a sidecar)."""
        if not isinstance(raw, dict):
            return None
        known = {f for f in cls.__dataclass_fields__}
        values = {k: v for k, v in raw.items() if k in known}
        for key in ("tags", "search_aliases", "materials", "material_classes", "placements", "conditions",
                    "cleanliness", "review_reasons"):
            values[key] = tuple(str(v) for v in values.get(key) or ())
        dims = values.get("dimensions_m")
        values["dimensions_m"] = tuple(float(v) for v in dims) if isinstance(dims, (list, tuple)) and len(dims) == 3 else None
        values["extra"] = {str(k): str(v) for k, v in (values.get("extra") or {}).items()}
        return cls(**values)


def parse(raw: Any) -> Enrichment | None:
    """Read Marso's enrichment from the API listing (a dict) or the USD (a JSON string)."""
    data = _load(raw)
    if not isinstance(data, dict) or not data:
        return None
    physics = _load(data.get("physics"))
    physics = physics if isinstance(physics, dict) else {}
    dims = _load(data.get("dimensions"))
    dimensions = None
    if isinstance(dims, dict):
        try:
            dimensions = tuple(float(dims[k]) for k in ("width_meters", "depth_meters", "height_meters"))
        except (KeyError, TypeError, ValueError):
            dimensions = None
    materials, classes = [], []
    for item in _items(data.get("materials")):
        if isinstance(item, dict):
            klass = _word(item.get("material_class")) or _word(item.get("material")) or _word(item)
            finish = _word(item.get("finish"))
            if klass:
                classes.append(klass)
                materials.append(f"{klass} ({finish})" if finish and finish != klass else klass)
        elif _word(item):
            classes.append(_word(item))
            materials.append(_word(item))
    known = {"display_name", "description_short", "description_long", "category", "subcategory", "detail", "tags",
             "search_aliases", "materials", "physics", "dimensions", "placements", "setting", "region", "style_period",
             "conditions", "cleanliness", "needs_review", "review_reasons", "schema_version",
             "model", "prompt_version"}  # the last two are Marso's pipeline internals
    extra = {k: str(_word(v) or v)[:200] for k, v in data.items() if k not in known and not k.endswith("_version")}
    return Enrichment(
        display_name=_text(data.get("display_name")),
        description_short=_text(data.get("description_short")),
        description_long=_text(data.get("description_long")),
        category=_word(data.get("category")),
        subcategory=_word(data.get("subcategory")),
        detail=_word(data.get("detail")),
        tags=_words(data.get("tags")),
        search_aliases=_words(data.get("search_aliases")),
        materials=tuple(dict.fromkeys(materials)),
        material_classes=tuple(dict.fromkeys(classes)),
        density_kg_m3=_number(physics.get("density_kg_per_m3")),
        static_friction=_number(physics.get("static_friction")),
        dynamic_friction=_number(physics.get("dynamic_friction")),
        restitution=_number(physics.get("restitution")),
        hollow=_flag(physics.get("hollow")),
        physics_preset=_word(physics.get("preset")),
        dimensions_m=dimensions,
        placements=_words(data.get("placements")),
        setting=_word(data.get("setting")),
        region=_word(data.get("region")),
        style_period=_word(data.get("style_period")),
        conditions=_words(data.get("conditions")),
        # The values all read "cleanliness"; the token holds the word ("clean"), when it is there at all.
        cleanliness=tuple(w for w in _words(data.get("cleanliness"), prefer_token=True) if w != "cleanliness"),
        needs_review=bool(_flag(data.get("needs_review"))),
        review_reasons=tuple(r.replace("_", " ") for r in _words(data.get("review_reasons"))),
        schema_version=_text(data.get("schema_version")),
        extra=extra,
    )


# --- helpers ---------------------------------------------------------------------------------------

_NOTHING = {"", "none", "null", "unknown", "indeterminate origin", "setting not determinable"}


def _load(value: Any) -> Any:
    """A dict/list from JSON or a Python literal string; other values unchanged."""
    if isinstance(value, str):
        text = value.strip()
        if text[:1] in "{[":
            for loader in (json.loads, ast.literal_eval):
                try:
                    return loader(text)
                except (ValueError, SyntaxError):
                    continue
    return value


def _items(value: Any) -> list:
    value = _load(value)
    return list(value) if isinstance(value, (list, tuple)) else ([value] if value else [])


def _word(value: Any, prefer_token: bool = False) -> str:
    """The human word of an ontology entry ({"value": ...}), or a plain string."""
    value = _load(value)
    if isinstance(value, dict):
        first, second = ("token", "value") if prefer_token else ("value", "token")
        word = value.get(first) or value.get(second) or ""
        word = str(word).replace("_", " ").strip()
    else:
        word = str(value).strip() if value is not None else ""
    return "" if word.lower() in _NOTHING else word


def _words(value: Any, prefer_token: bool = False) -> tuple[str, ...]:
    return tuple(dict.fromkeys(w for w in (_word(item, prefer_token) for item in _items(value)) if w))


def _text(value: Any) -> str:
    text = str(value).strip() if value is not None else ""
    return "" if text.lower() in ("none", "null") else text


def _number(value: Any) -> float | None:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number


def _flag(value: Any) -> bool | None:
    if isinstance(value, bool):
        return value
    if isinstance(value, str) and value.strip().lower() in ("true", "false"):
        return value.strip().lower() == "true"
    return None

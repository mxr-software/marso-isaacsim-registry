"""Sim Studio jobs: which tests exist, how they are configured, and how a run is described on disk.

The extension (or ``internal/sim_test.py``) builds a job here, writes it as ``job.json`` in the
run folder, and launches the runner (``marso/library/sim/runner.py``) in a separate headless
Isaac Sim. The runner reports progress as one JSON object per line, prefixed with
``PROGRESS_PREFIX``, and finally writes ``run.json`` describing everything it produced.
Pure Python, so it is unit tested without Kit.
"""

from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any

PROGRESS_PREFIX = "[marso-sim] "
JOB_FILE = "job.json"
RUN_FILE = "run.json"
REPORT_FILE = "report.html"

BRANDED = "branded"
CLEAN = "clean"
BOTH = "both"
BRANDING_CHOICES = (BOTH, BRANDED, CLEAN)


@dataclass(frozen=True)
class TestSpec:
    key: str
    title: str
    eyebrow: str
    summary: str
    min_objects: int = 1
    options: dict[str, Any] = field(default_factory=dict)


TESTS: tuple[TestSpec, ...] = (
    TestSpec("scale", "Scale", "SCALE TEST", "Real-world size beside a measured floor and a height pole.",
             options={"orbit_s": 9.0}),
    TestSpec("drop", "Drop", "DROP TEST", "Dropped from a height to show bounce and settling.",
             options={"drop_height": 1.0, "slowmo": 2.0, "duration_s": 5.0}),
    TestSpec("friction", "Friction", "FRICTION TEST", "The ground tilts until each object slides, tips or rolls.",
             options={"max_angle": 45.0, "tilt_rate": 4.0}),
    TestSpec("wind", "Wind", "WIND TEST", "A rising wind until each object moves or blows over.",
             options={"max_wind": 30.0, "ramp_s": 10.0}),
    TestSpec("collision", "Collision", "COLLISION TEST", "Objects dropped onto each other, with every contact measured.",
             min_objects=2, options={"slowmo": 2.0, "duration_s": 5.0}),
    TestSpec("robot", "Robot", "ROBOT TEST", "A Franka arm picks up each object it can hold and sets it down on a pad.",
             options={"speed": 1.5, "max_objects": 4, "split_screen": True, "labels": False,
                      "drop_in": False, "risky_grips": False, "max_tries": 3}),
    TestSpec("robot_suction", "Robot: suction", "ROBOT TEST",
             "A UR10 with a suction cup lifts each object by a flat spot: up to 10 kg, any width.",
             options={"speed": 1.5, "max_objects": 4, "split_screen": True, "labels": False,
                      "drop_in": False, "max_tries": 3}),
    TestSpec("robot_wide", "Robot: wide gripper", "ROBOT TEST",
             "A UR10e with a Robotiq 2F-140 grips objects up to 14 cm across and 11 kg.",
             options={"speed": 1.5, "max_objects": 4, "split_screen": True, "labels": False,
                      "drop_in": False, "risky_grips": False, "max_tries": 3}),
    TestSpec("robot_humanoid", "Robot: humanoid", "ROBOT TEST",
             "A Unitree G1 humanoid picks up each light object it can pinch with its five-finger hand and sets it down.",
             options={"speed": 1.5, "max_objects": 3, "split_screen": True, "labels": False,
                      "drop_in": False, "risky_grips": False, "max_tries": 3}),
    TestSpec("robot_handover", "Robot: handover", "ROBOT TEST",
             "Two Frankas pass each object across: one picks it up, the other takes it from the side and sets it down.",
             options={"speed": 1.5, "max_objects": 3, "split_screen": True}),
)
TEST_KEYS = tuple(spec.key for spec in TESTS)


def spec(key: str) -> TestSpec:
    return next(item for item in TESTS if item.key == key)


REALTIME = "RealTimePathTracing"  # RTX Real-Time 2.0
PATH_TRACED = "PathTracing"  # RTX Interactive (Path Tracing): final-quality light, slower
AA_DLSS, AA_RTXAA = 3, 4  # Isaac Sim's anti_aliasing modes: DLSS upscales; RTXAA renders at full size


@dataclass(frozen=True)
class Quality:
    key: str
    label: str
    long_side: int  # pixels along the frame's long edge
    fps: int
    subframes: int  # RTX subframes per frame: more is cleaner (anti-aliasing, denoising) and slower
    bitrate: int  # bits per second for the encoder
    renderer: str = REALTIME
    anti_aliasing: int = AA_DLSS
    spp: int = 0  # path-traced samples per pixel per subframe (path tracing only)

    @property
    def samples(self) -> int:
        """Path-traced samples per pixel in each frame (0 when real-time)."""
        return self.spp * self.subframes if self.renderer == PATH_TRACED else 0


# Every preset is path traced: real-time RTX keeps a history of earlier frames for denoising, which left
# dark trails behind fast-moving objects. Path tracing starts each frame afresh; presets differ in samples.
QUALITIES: tuple[Quality, ...] = (
    Quality("preview", "Preview", 1280, 30, 2, 12_000_000, renderer=PATH_TRACED, spp=8),
    Quality("standard", "Standard", 1920, 30, 4, 24_000_000, renderer=PATH_TRACED, spp=16),
    Quality("marketing", "Marketing", 1920, 30, 4, 45_000_000, renderer=PATH_TRACED, spp=32),
    Quality("marketing_4k", "Marketing 4K", 3840, 30, 4, 90_000_000, renderer=PATH_TRACED, spp=32),
)
DEFAULT_QUALITY = "standard"

ASPECTS: dict[str, tuple[int, int]] = {"16:9": (16, 9), "9:16": (9, 16), "1:1": (1, 1), "4:5": (4, 5)}
DEFAULT_ASPECT = "16:9"


def quality(key: str) -> Quality:
    return next((item for item in QUALITIES if item.key == key), QUALITIES[1])


def resolution(quality_key: str, aspect: str) -> tuple[int, int]:
    """Frame size for a quality and an aspect ratio; both sides even, as H.264 needs."""
    long_side = quality(quality_key).long_side
    w, h = ASPECTS.get(aspect, ASPECTS[DEFAULT_ASPECT])
    if w >= h:
        width, height = long_side, long_side * h / w
    else:
        width, height = long_side * w / h, long_side
    return int(round(width / 2)) * 2, int(round(height / 2)) * 2


def run_name(names: list[str]) -> str:
    """A short, file-safe description of what was tested."""
    if not names:
        return "assets"
    label = names[0] if len(names) == 1 else f"{names[0]} and {len(names) - 1} more"
    return re.sub(r"[^A-Za-z0-9._-]+", "_", label).strip("_")[:60] or "assets"


def run_folder(root: Path, names: list[str], when: datetime | None = None) -> Path:
    stamp = (when or datetime.now()).strftime("%Y-%m-%d_%H%M%S")
    return root / f"{stamp}_{run_name(names)}"


def unique_names(assets: list[dict[str, str]]) -> list[dict[str, str]]:
    """Names label objects on screen and key their results: two assets called "Apple" become "Apple" and "Apple 2"."""
    seen: dict[str, int] = {}
    named = []
    for asset in assets:
        seen[asset["name"]] = seen.get(asset["name"], 0) + 1
        count = seen[asset["name"]]
        named.append({**asset, "name": asset["name"] if count == 1 else f"{asset['name']} {count}"})
    return named


def build_job(
    *,
    assets: list[dict[str, str]],
    tests: list[str],
    out_dir: Path,
    extension_root: Path,
    quality_key: str = DEFAULT_QUALITY,
    aspect: str = DEFAULT_ASPECT,
    branding: str = BOTH,
    options: dict[str, dict[str, Any]] | None = None,
    outro: bool = True,
    ffmpeg: str = "",
) -> dict[str, Any]:
    """The job the runner reads. ``assets`` items carry ``name``, ``asset_id`` and ``folder``."""
    if not assets:
        raise ValueError("Choose at least one object to test.")
    chosen = [key for key in TEST_KEYS if key in tests]
    if not chosen:
        raise ValueError("Choose at least one test.")
    too_few = [spec(key).title for key in chosen if len(assets) < spec(key).min_objects]
    if too_few:
        raise ValueError(f"{', '.join(too_few)} needs at least two objects.")
    assets = unique_names(assets)
    width, height = resolution(quality_key, aspect)
    picked = quality(quality_key)
    merged = {key: {**spec(key).options, **{k: v for k, v in ((options or {}).get(key) or {}).items() if k in spec(key).options}}
              for key in chosen}
    return {
        "version": 1,
        "created": datetime.now().isoformat(timespec="seconds"),
        "extension_root": str(extension_root),
        "out_dir": str(out_dir),
        "assets": assets,
        "tests": chosen,
        "options": merged,
        "quality": picked.key,
        "aspect": aspect,
        "width": width,
        "height": height,
        "fps": picked.fps,
        "subframes": picked.subframes,
        "bitrate": picked.bitrate,
        "renderer": picked.renderer,
        "anti_aliasing": picked.anti_aliasing,
        "spp": picked.spp,
        "branding": branding if branding in BRANDING_CHOICES else BOTH,
        "outro": outro,
        "sim_hz": 240,
        "ffmpeg": ffmpeg,
    }


RESUME_ATTEMPTS = 1  # how many times a run whose Isaac Sim stopped part way is started again


def write_job(job: dict[str, Any]) -> Path:
    folder = Path(job["out_dir"])
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / JOB_FILE
    path.write_text(json.dumps(job, indent=2), encoding="utf-8")
    return path


def progress_line(event: str, **fields: Any) -> str:
    """What the runner prints for the UI: the prefix and one JSON object."""
    return PROGRESS_PREFIX + json.dumps({"event": event, **fields})


def parse_progress(line: str) -> dict[str, Any] | None:
    """The event in a runner output line, or None for ordinary log output."""
    index = line.find(PROGRESS_PREFIX)
    if index < 0:
        return None
    try:
        data = json.loads(line[index + len(PROGRESS_PREFIX):].strip())
    except ValueError:
        return None
    return data if isinstance(data, dict) and "event" in data else None


@dataclass
class RunSummary:
    folder: Path
    name: str
    created: str
    status: str
    tests: list[dict[str, Any]]
    assets: list[str]

    def media(self, test_key: str, kind: str) -> Path | None:
        """A test's file by kind ("video", "clean", "card", "thumb", "scene"), if it exists."""
        for test in self.tests:
            if test.get("key") == test_key and test.get(kind):
                path = self.folder / test[kind]
                return path if path.is_file() else None
        return None

    @property
    def thumbnail(self) -> Path | None:
        for test in self.tests:
            path = self.media(test.get("key", ""), "thumb")
            if path is not None:
                return path
        return None

    @property
    def report(self) -> Path | None:
        path = self.folder / REPORT_FILE
        return path if path.is_file() else None


def read_run(folder: Path) -> RunSummary | None:
    try:
        data = json.loads((folder / RUN_FILE).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    if not isinstance(data, dict):
        return None
    return RunSummary(
        folder=folder,
        name=str(data.get("name") or folder.name),
        created=str(data.get("created") or ""),
        status=str(data.get("status") or "unknown"),
        tests=[t for t in data.get("tests") or [] if isinstance(t, dict)],
        assets=[str(a) for a in data.get("assets") or []],
    )


def list_runs(root: Path, limit: int = 24) -> list[RunSummary]:
    """Finished and failed runs under ``root``, newest first."""
    try:
        folders = sorted((p for p in root.iterdir() if p.is_dir()), reverse=True)
    except OSError:
        return []
    runs = []
    for folder in folders:
        run = read_run(folder)
        if run is not None:
            runs.append(run)
        if len(runs) >= limit:
            break
    return runs


def find_launcher(app_folder: Path) -> Path | None:
    """Isaac Sim's standalone Python launcher, beside the ``apps`` folder of the running app."""
    names = ("python.bat",) if os.name == "nt" else ("python.sh",)
    for root in (app_folder.parent, app_folder, app_folder.parent.parent):
        for name in names:
            candidate = root / name
            if candidate.is_file():
                return candidate
    return None


# Kit sets these for the app that launched us; the runner's own launcher sets them afresh.
_INHERITED_ENV = ("PYTHONPATH", "PYTHONHOME", "CARB_APP_PATH", "ISAAC_PATH", "EXP_PATH", "PYTHONEXE")


def runner_env(base: dict[str, str]) -> dict[str, str]:
    return {key: value for key, value in base.items() if key not in _INHERITED_ENV}

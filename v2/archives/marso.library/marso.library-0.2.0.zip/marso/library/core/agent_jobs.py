"""Jobs the agent connection starts: an id, a status, progress, and a result to wait for. (stdlib only)

A command that starts slow work (downloads, a Sim Studio run, an upload for the chat) returns a job id,
and the Marso MCP waits on it with ``wait_job``. The Kit side drives each job from its own events; this
module only keeps the records, thread-safe, so a connection thread can wait on one while Kit's loop
updates it.
"""

from __future__ import annotations

import itertools
import threading
import time
from typing import Any, Callable

QUEUED = "queued"
RUNNING = "running"
SUCCEEDED = "succeeded"
FAILED = "failed"
CANCELLED = "cancelled"
TERMINAL = frozenset({SUCCEEDED, FAILED, CANCELLED})

_KEEP_FINISHED = 50  # finished jobs remembered for get_job/wait_job; older ones are forgotten


class Job:
    """One piece of work. Update it from any thread; ``wait`` blocks until it ends."""

    def __init__(self, job_id: str, kind: str, params: dict[str, Any] | None = None,
                 cancel_hook: Callable[[], None] | None = None) -> None:
        self.id = job_id
        self.kind = kind
        self.params = dict(params or {})
        self.status = RUNNING
        self.progress = 0.0
        self.message = ""
        self.result: dict[str, Any] | None = None
        self.error: str | None = None
        self.created = time.time()
        self.finished: float | None = None
        self._cancel_hook = cancel_hook
        self._done = threading.Event()
        self._lock = threading.Lock()

    @property
    def is_terminal(self) -> bool:
        return self.status in TERMINAL

    def update(self, progress: float | None = None, message: str | None = None) -> None:
        with self._lock:
            if self.is_terminal:
                return
            if progress is not None:
                self.progress = max(0.0, min(1.0, float(progress)))
            if message is not None:
                self.message = message

    def succeed(self, result: dict[str, Any] | None = None, message: str = "") -> None:
        self._end(SUCCEEDED, result=result, message=message or self.message)

    def fail(self, error: str, result: dict[str, Any] | None = None) -> None:
        self._end(FAILED, result=result, error=error, message=error)

    def cancelled(self, message: str = "Cancelled.") -> None:
        self._end(CANCELLED, message=message, error=message)

    def request_cancel(self) -> None:
        """Ask the work to stop; it reports ``cancelled`` (or its real outcome) when it does."""
        hook = self._cancel_hook
        if hook is not None and not self.is_terminal:
            hook()

    def wait(self, timeout_s: float | None) -> bool:
        return self._done.wait(timeout_s)

    def snapshot(self) -> dict[str, Any]:
        with self._lock:
            return {
                "job_id": self.id,
                "kind": self.kind,
                "status": self.status,
                "progress": round(self.progress, 4),
                "message": self.message,
                "result": self.result,
                "error": self.error,
                "seconds": round((self.finished or time.time()) - self.created, 1),
            }

    def _end(self, status: str, *, result: dict[str, Any] | None = None, error: str | None = None, message: str = "") -> None:
        with self._lock:
            if self.is_terminal:
                return
            self.status = status
            self.result = result
            self.error = error
            self.message = message
            if status == SUCCEEDED:
                self.progress = 1.0
            self.finished = time.time()
        self._done.set()


class JobRegistry:
    """Every job the connection started this session, newest last."""

    def __init__(self) -> None:
        self._jobs: dict[str, Job] = {}
        self._lock = threading.Lock()
        self._ids = itertools.count(1)

    def start(self, kind: str, params: dict[str, Any] | None = None,
              cancel_hook: Callable[[], None] | None = None) -> Job:
        with self._lock:
            job = Job(f"{kind}-{next(self._ids)}-{int(time.time())}", kind, params, cancel_hook)
            self._jobs[job.id] = job
            self._prune()
            return job

    def get(self, job_id: str) -> Job | None:
        with self._lock:
            return self._jobs.get(job_id)

    def list(self, active_only: bool = False) -> list[Job]:
        with self._lock:
            jobs = list(self._jobs.values())
        return [job for job in jobs if not (active_only and job.is_terminal)]

    def _prune(self) -> None:
        finished = [job for job in self._jobs.values() if job.is_terminal]
        for job in finished[:-_KEEP_FINISHED]:
            self._jobs.pop(job.id, None)

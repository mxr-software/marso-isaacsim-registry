"""Things worth flagging on an asset's tile: what Marso flagged for review, and what we find in the file.

Pure Python. ``review_flags`` needs only the listing; ``file_checks`` runs when a download is
prepared (the measurements come from ``usd_inspect``).
"""

from __future__ import annotations

from .enrichment import Enrichment

SIZE_TOLERANCE = 0.35  # the file's largest dimension may differ from Marso's real-world size by this much
SIZE_MIN_DIFF_M = 0.02
HOLLOW_SOLID_FILL = 0.3  # a "hollow" object whose mesh fills more of its box than this is modelled solid
SPHERE_LIKE = 0.05  # out of round by less than this fraction of the radius: meant to be a sphere
ROUND_TOLERANCE_MM = 1.0


def review_flags(info: Enrichment | None) -> list[str]:
    """What Marso itself flagged ("hollow object", "dimension mismatch")."""
    if info is None or not info.needs_review:
        return []
    reasons = ", ".join(info.review_reasons) or "needs review"
    return [f"Marso flagged it for review: {reasons}"]


def file_checks(
    info: Enrichment | None,
    size_m: tuple[float, float, float] | None,
    mesh_volume_m3: float | None,
    roundness: tuple[float, float] | None = None,
) -> list[str]:
    """Checks of a downloaded file against Marso's description.

    ``size_m`` is the file's bounding box (metres); ``roundness`` is (radius m, out of round mm) for
    roughly round objects (``sim_metrics.roundness``).
    """
    found: list[str] = []
    if info is not None and info.dimensions_m and size_m:
        described, measured = max(info.dimensions_m), max(size_m)
        if described > 0 and abs(measured - described) > SIZE_MIN_DIFF_M and not (
                1 - SIZE_TOLERANCE <= measured / described <= 1 + SIZE_TOLERANCE):
            found.append(f"Size: {measured * 100:.3g} cm across in the file, where Marso describes "
                         f"{described * 100:.3g} cm")
    if info is not None and info.hollow and size_m and mesh_volume_m3:
        box = size_m[0] * size_m[1] * size_m[2]
        if box > 0 and mesh_volume_m3 / box > HOLLOW_SOLID_FILL:
            found.append("Hollow but modelled solid: its mass counts the inside, so it is too heavy")
    if roundness is not None:
        radius, bump_mm = roundness
        if bump_mm > ROUND_TOLERANCE_MM and radius > 0 and bump_mm / 1000.0 <= SPHERE_LIKE * radius:
            found.append(f"Out of round by {bump_mm:g} mm: it wobbles as it rolls")
    return found

"""What a remote agent may do through the agent connection. (stdlib only)

The agent connection carries commands from the Marso MCP server, on behalf of whichever chat or coding
agent the user signed in to. So it gets a narrow door:

* Only the commands listed here run. Nothing reconfigures the extension (API key, endpoint, folders),
  creates assets through the Create tab (that spends credits; the Marso MCP generates, quotes and
  journals instead), deletes downloads, opens or reads a local path, or starts a program.
* No command takes a path, a folder, a URL or a key: assets are named by Marso asset id, runs by the
  name Sim Studio gave them. A parameter with such a name is refused before any handler sees it.

The server applies the same allowlist before it sends anything. This copy is the one that holds even
if the server were wrong or compromised.
"""

from __future__ import annotations

from typing import Any

REMOTE_COMMANDS: frozenset[str] = frozenset({
    # Seeing the session
    "get_state",
    "list_stage",
    "viewport_screenshot",
    # Library and stage
    "library_state",
    "sync_library",
    "download_assets",
    "add_to_stage",
    "add_ground",
    # Sim Studio
    "sim_catalog",
    "sim_state",
    "sim_start",
    "sim_cancel",
    "sim_runs",
    "share_render",
    # Jobs
    "list_jobs",
    "get_job",
    "wait_job",
    "cancel_job",
})

# Parameter names that would point at the user's disk, the network or their account.
_FORBIDDEN_KEYS = frozenset({
    "path", "filepath", "file", "folder", "dir", "directory", "usd_path", "url", "endpoint",
    "api_key", "api_endpoint", "cache_dir", "downloads_dir", "sim_dir", "launcher", "ffmpeg",
})


class PolicyError(PermissionError):
    def __init__(self, message: str, *, code: str = "not_allowed_remotely") -> None:
        super().__init__(message)
        self.code = code


def check_remote(command: str, params: dict[str, Any]) -> None:
    """Raise ``PolicyError`` unless a remote agent may run ``command`` with ``params``."""
    if command not in REMOTE_COMMANDS:
        raise PolicyError(f"'{command}' is not available over the agent connection. Use the Marso window for it.")
    key = _forbidden_key(params)
    if key is not None:
        raise PolicyError(f"'{key}' cannot be set over the agent connection; assets and runs are named, never paths.")


def _forbidden_key(value: Any) -> str | None:
    if isinstance(value, dict):
        for key, item in value.items():
            if str(key).lower() in _FORBIDDEN_KEYS:
                return str(key)
            found = _forbidden_key(item)
            if found is not None:
                return found
    elif isinstance(value, list):
        for item in value:
            found = _forbidden_key(item)
            if found is not None:
                return found
    return None

"""Fetch thumbnails and store them as square PNGs that ``omni.ui.Image`` can draw.

Asset thumbnails arrive as WebP and project thumbnails as large JPEGs or PNGs.
Kit's image loader does not read WebP, so every thumbnail is converted with
Pillow (bundled with Isaac Sim through ``omni.kit.pip_archive``), centre-cropped
to a square and shrunk. Without Pillow only PNGs are kept, as they are.
Presigned thumbnail URLs expire after about a minute, so fetch straight after
listing.
"""

from __future__ import annotations

import io
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Callable, Iterable

from . import http, storage

THUMBNAIL_SIZE = 256
WORKERS = 12
_PNG_MAGIC = b"\x89PNG\r\n\x1a\n"

try:  # Pillow ships with Isaac Sim; tolerate a Kit app without it.
    from PIL import Image as _PILImage
except ImportError:  # pragma: no cover - depends on the host app
    _PILImage = None


def pillow_available() -> bool:
    return _PILImage is not None


def fetch_missing(
    items: Iterable[tuple[str, str]],
    cache_dir: Path,
    *,
    on_saved: Callable[[str, Path], None] | None = None,
) -> int:
    """Fetch every (key, url) whose thumbnail is not cached yet; return how many were saved."""
    unique = dict(item for item in items if item[1])  # an asset in two projects is fetched once
    pending = [(key, url) for key, url in unique.items() if storage.find_thumbnail(cache_dir, key) is None]
    if not pending:
        return 0
    storage.thumbnails_dir(cache_dir).mkdir(parents=True, exist_ok=True)
    saved = 0
    with ThreadPoolExecutor(max_workers=min(WORKERS, len(pending))) as pool:
        for key, path in pool.map(lambda item: (item[0], fetch_one(item[0], item[1], cache_dir)), pending):
            if path is None:
                continue
            saved += 1
            if on_saved is not None:
                on_saved(key, path)
    return saved


def fetch_one(key: str, url: str, cache_dir: Path) -> Path | None:
    """Download one thumbnail and store it; None if it could not be fetched or decoded."""
    try:
        data = http.download_bytes(url)
    except http.NETWORK_ERRORS:
        return None
    target = storage.thumbnail_path(cache_dir, key)
    return target if save_square_png(data, target) else None


def save_square_png(data: bytes, target: Path, size: int = THUMBNAIL_SIZE) -> bool:
    """Write ``data`` (any image Pillow reads) to ``target`` as a centre-cropped square PNG."""
    if _PILImage is None:
        if not data.startswith(_PNG_MAGIC):
            return False
        _write_atomic(target, data)
        return True
    try:
        with _PILImage.open(io.BytesIO(data)) as image:
            image = image.convert("RGBA")
            side = min(image.size)
            left = (image.width - side) // 2
            top = (image.height - side) // 2
            image = image.crop((left, top, left + side, top + side))
            if side > size:
                image = image.resize((size, size), _PILImage.LANCZOS)
            buffer = io.BytesIO()
            image.save(buffer, format="PNG")
    except (OSError, ValueError, _PILImage.DecompressionBombError):
        return False
    _write_atomic(target, buffer.getvalue())
    return True


def _write_atomic(target: Path, data: bytes) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    temp = target.with_name(f"{target.name}.tmp")
    temp.write_bytes(data)
    temp.replace(target)

"""Resolve the settings a run uses: saved setting, else environment variable, else default.

The environment variables match the Blender add-on's, so one machine can set
``MARSO_API_KEY`` once for both. The default folders live outside the
extension, which Kit treats as replaceable on update.
"""

from __future__ import annotations

import os
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Mapping

DEFAULT_API_ENDPOINT = "https://virtuoso-api.prod.marso.ai/api/public/v1"

ENV_API_KEY = "MARSO_API_KEY"
ENV_API_ENDPOINT = "MARSO_API_ENDPOINT"
ENV_CACHE_DIR = "MARSO_CACHE_DIR"
ENV_DOWNLOADS_DIR = "MARSO_DOWNLOADS_DIR"

SOURCE_SETTINGS = "settings"
SOURCE_ENVIRONMENT = "environment"
SOURCE_DEFAULT = "default"
SOURCE_NONE = "none"

# Keys of the saved settings mapping (also the persistent carb setting names).
KEY_API_KEY = "api_key"
KEY_API_ENDPOINT = "api_endpoint"
KEY_CACHE_DIR = "cache_dir"
KEY_DOWNLOADS_DIR = "downloads_dir"

_ENV_BY_KEY = {
    KEY_API_KEY: ENV_API_KEY,
    KEY_API_ENDPOINT: ENV_API_ENDPOINT,
    KEY_CACHE_DIR: ENV_CACHE_DIR,
    KEY_DOWNLOADS_DIR: ENV_DOWNLOADS_DIR,
}


@dataclass(frozen=True)
class Config:
    """Everything a sync or download needs, with where each value came from."""

    api_key: str
    api_endpoint: str
    cache_dir: Path
    downloads_dir: Path
    sources: Mapping[str, str]

    @property
    def has_api_key(self) -> bool:
        return bool(self.api_key)


def default_cache_dir(env: Mapping[str, str] | None = None, home: Path | None = None, platform: str = "") -> Path:
    """Thumbnails and the cached listing: a per-user cache folder."""
    env = os.environ if env is None else env
    home = Path.home() if home is None else home
    platform = platform or sys.platform
    if platform.startswith("win"):
        base = env.get("LOCALAPPDATA") or str(home / "AppData" / "Local")
        return Path(base) / "Marso" / "IsaacSim" / "Cache"
    base = env.get("XDG_CACHE_HOME") or str(home / ".cache")
    return Path(base) / "marso" / "isaacsim"


def default_downloads_dir(home: Path | None = None) -> Path:
    """Downloaded assets: somewhere the user can find, and point the Blender add-on at too."""
    home = Path.home() if home is None else home
    return home / "Documents" / "Marso" / "Downloads"


def resolve(
    saved: Mapping[str, str],
    env: Mapping[str, str] | None = None,
    home: Path | None = None,
    platform: str = "",
) -> Config:
    """Merge saved settings, environment and defaults into one ``Config``."""
    env = os.environ if env is None else env
    sources: dict[str, str] = {}

    def pick(key: str) -> str:
        stored = str(saved.get(key) or "").strip()
        if stored:
            sources[key] = SOURCE_SETTINGS
            return stored
        from_env = str(env.get(_ENV_BY_KEY[key]) or "").strip()
        if from_env:
            sources[key] = SOURCE_ENVIRONMENT
            return from_env
        sources[key] = SOURCE_DEFAULT
        return ""

    api_key = pick(KEY_API_KEY)
    if not api_key:
        sources[KEY_API_KEY] = SOURCE_NONE
    endpoint = pick(KEY_API_ENDPOINT) or DEFAULT_API_ENDPOINT
    cache_dir = pick(KEY_CACHE_DIR)
    downloads_dir = pick(KEY_DOWNLOADS_DIR)
    return Config(
        api_key=api_key,
        api_endpoint=endpoint.rstrip("/"),
        cache_dir=Path(os.path.expanduser(cache_dir)) if cache_dir else default_cache_dir(env, home, platform),
        downloads_dir=Path(os.path.expanduser(downloads_dir)) if downloads_dir else default_downloads_dir(home),
        sources=sources,
    )

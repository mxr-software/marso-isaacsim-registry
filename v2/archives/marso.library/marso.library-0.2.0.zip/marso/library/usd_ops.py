"""Adding downloaded assets to the open stage (Kit side; the pxr-only work is in ``usd_inspect``).

Assets are added as references, as dragging a file into the viewport does, so
the downloaded package stays the single copy on disk. The reference points at
the asset's wrapper layer (see ``usd_inspect``), whose root has plain
translate/rotate/scale ops; placement and stage corrections go into those. An
asset without a wrapper is referenced directly, with corrections put in front
of the package's own ops rather than replacing them.
"""

from __future__ import annotations

import carb
import omni.client
import omni.kit.commands
import omni.kit.undo
import omni.usd
from pxr import Gf, Sdf, Usd, UsdGeom, UsdPhysics

from . import settings, usd_inspect
from .core import placement
from .core.storage import LocalAsset

DEFAULT_PARENT = "/World"


class MarsoAddAssetCommand(omni.kit.commands.Command):
    """Add one downloaded asset to the stage as a reference. Undoable."""

    def __init__(
        self,
        usd_path: str,
        prim_name: str,
        asset_id: str = "",
        translate_x: float = 0.0,
        rotate_x_deg: float = 0.0,
        scale: float = 1.0,
        usd_context_name: str = "",
        select: bool = True,
        translate_y: float = 0.0,
        translate_z: float = 0.0,
        payload: bool = False,
    ) -> None:
        self._translate_y = translate_y
        self._translate_z = translate_z
        self._payload = payload  # a payload can be unloaded to lighten a big scene; a reference cannot
        self._usd_path = usd_path
        self._prim_name = prim_name
        self._asset_id = asset_id
        self._translate_x = translate_x
        self._rotate_x = rotate_x_deg
        self._scale = scale
        self._context = omni.usd.get_context(usd_context_name)
        self._select = select
        self._created: str | None = None
        self._previous_selection: list[str] = []

    def do(self) -> str:
        stage = self._context.get_stage()
        parent = _parent_path(stage)
        path = omni.usd.get_stage_next_free_path(stage, f"{parent}/{usd_inspect.prim_name(self._prim_name)}", False)
        prim = UsdGeom.Xform.Define(stage, path).GetPrim()
        layer = stage.GetEditTarget().GetLayer()
        if self._payload:
            prim.GetPayloads().AddPayload(_reference_path(layer, self._usd_path))
        else:
            prim.GetReferences().AddReference(_reference_path(layer, self._usd_path))
        prim.SetCustomDataByKey(usd_inspect.CUSTOM_DATA_KEY, {"assetId": self._asset_id, "source": "Marso"})
        usd_inspect.apply_placement(prim, self._translate_x, self._rotate_x, self._scale, self._translate_y,
                                    self._translate_z)
        self._created = path
        if self._select:
            selection = self._context.get_selection()
            self._previous_selection = list(selection.get_selected_prim_paths())
            selection.set_selected_prim_paths([path], True)
        return path

    def undo(self) -> None:
        if not self._created:
            return
        stage = self._context.get_stage()
        if stage is not None and stage.GetPrimAtPath(self._created):
            stage.RemovePrim(self._created)
        if self._select:
            self._context.get_selection().set_selected_prim_paths(self._previous_selection, True)
        self._created = None


class MarsoAddGroundCommand(omni.kit.commands.Command):
    """Add a physics scene and a ground when the stage has neither, so sim-ready assets have something
    to stand on when Play is pressed. Undoable.

    The ground collider is a 20 m box (not tens of metres: SDF contacts against huge boxes never settle
    on the GPU pipeline) under a visible 20 m floor; both follow the stage's up axis and units.
    """

    def __init__(self, usd_context_name: str = "") -> None:
        self._context = omni.usd.get_context(usd_context_name)
        self._created: list[str] = []

    def do(self) -> list[str]:
        stage = self._context.get_stage()
        self._created = []
        if stage is None:
            return []
        prims = list(stage.Traverse())
        up = UsdGeom.GetStageUpAxis(stage)
        mpu = UsdGeom.GetStageMetersPerUnit(stage) or 0.01
        if not any(prim.IsA(UsdPhysics.Scene) for prim in prims):
            path = omni.usd.get_stage_next_free_path(stage, "/PhysicsScene", False)
            scene = UsdPhysics.Scene.Define(stage, path)
            scene.CreateGravityDirectionAttr(Gf.Vec3f(0, 0, -1) if up == "Z" else Gf.Vec3f(0, -1, 0))
            scene.CreateGravityMagnitudeAttr(9.81 / mpu)
            self._created.append(path)
        static_collider = any(prim.HasAPI(UsdPhysics.CollisionAPI) and not _under_rigid_body(prim) for prim in prims)
        if not static_collider:
            parent = _parent_path(stage)
            path = omni.usd.get_stage_next_free_path(stage, f"{parent}/GroundPlane", False)
            UsdGeom.Xform.Define(stage, path)
            half, thick = 10.0 / mpu, 0.2 / mpu
            floor = UsdGeom.Mesh.Define(stage, f"{path}/Floor")
            corners = [(-half, -half), (half, -half), (half, half), (-half, half)]
            floor.CreatePointsAttr([Gf.Vec3f(a, b, 0) if up == "Z" else Gf.Vec3f(a, 0, -b) for a, b in corners])
            floor.CreateFaceVertexCountsAttr([4])
            floor.CreateFaceVertexIndicesAttr([0, 1, 2, 3])
            floor.CreateDisplayColorAttr([Gf.Vec3f(0.32, 0.33, 0.36)])
            box = UsdGeom.Cube.Define(stage, f"{path}/Collider")
            box.CreateSizeAttr(1.0)
            down = Gf.Vec3d(0, 0, -thick / 2) if up == "Z" else Gf.Vec3d(0, -thick / 2, 0)
            box.AddTranslateOp().Set(down)
            box.AddScaleOp().Set(Gf.Vec3f(2 * half, 2 * half, thick) if up == "Z" else Gf.Vec3f(2 * half, thick, 2 * half))
            box.MakeInvisible()
            UsdPhysics.CollisionAPI.Apply(box.GetPrim())
            self._created.append(path)
        return list(self._created)

    def undo(self) -> None:
        stage = self._context.get_stage()
        for path in reversed(self._created):
            if stage is not None and stage.GetPrimAtPath(path):
                stage.RemovePrim(path)
        self._created = []


def _under_rigid_body(prim: Usd.Prim) -> bool:
    while prim and prim.GetPath() != Sdf.Path.absoluteRootPath:
        if prim.HasAPI(UsdPhysics.RigidBodyAPI):
            return True
        prim = prim.GetParent()
    return False


def register_commands() -> None:
    omni.kit.commands.register(MarsoAddAssetCommand)
    omni.kit.commands.register(MarsoAddGroundCommand)


def unregister_commands() -> None:
    omni.kit.commands.unregister(MarsoAddAssetCommand)
    omni.kit.commands.unregister(MarsoAddGroundCommand)


class StagePlacer:
    """Adds assets to the current stage; assets added through one placer line up in a row."""

    def __init__(self, usd_context_name: str = "", *, arrange: str | None = None, add_ground: bool | None = None) -> None:
        """``arrange`` and ``add_ground`` override the user's settings for this batch (the agent connection uses them)."""
        self._context_name = usd_context_name
        self._row = None  # the batch's layout (core.placement), made with the first asset
        self._arrange = arrange or settings.get(settings.KEY_ARRANGE, placement.ARRANGE_ROW)
        self._payload = bool(settings.get_int(settings.KEY_USE_PAYLOADS, 0))
        self._ground = bool(settings.get_int(settings.KEY_ADD_GROUND, 1)) if add_ground is None else add_ground
        self.added: list[str] = []
        self.errors: list[str] = []
        self.ground: list[str] = []

    def add(self, local: LocalAsset) -> str | None:
        context = omni.usd.get_context(self._context_name)
        stage = context.get_stage()
        if stage is None:
            context.new_stage()
            stage = context.get_stage()
        source = local.stage_path  # the wrapper layer, or the package when there is none
        try:
            asset_stage = Usd.Stage.Open(str(source), Usd.Stage.LoadAll)
        except Exception as exc:  # noqa: BLE001 - pxr raises Tf errors of its own type
            asset_stage = None
            carb.log_error(f"Marso: could not open {source}: {exc}")
        if asset_stage is None or not asset_stage.GetDefaultPrim():
            self.errors.append(f"{local.name}: the package has no default prim to reference.")
            return None

        correction = placement.stage_correction(
            UsdGeom.GetStageUpAxis(asset_stage),
            UsdGeom.GetStageMetersPerUnit(asset_stage),
            UsdGeom.GetStageUpAxis(stage),
            UsdGeom.GetStageMetersPerUnit(stage),
        )
        if self._row is None:
            gap = placement.ROW_GAP_M / (UsdGeom.GetStageMetersPerUnit(stage) or 0.01)
            up_axis = 2 if UsdGeom.GetStageUpAxis(stage) == "Z" else 1
            self._row = placement.make_layout(self._arrange, gap, up_axis)
            if self._ground and local.physics is not None and local.physics.rigid_bodies:
                _ok, self.ground = omni.kit.commands.execute("MarsoAddGroundCommand", usd_context_name=self._context_name)
                self.ground = list(self.ground or [])
        lo, hi = _extent(asset_stage, correction)
        offset = self._row.place_box(lo, hi)

        success, path = omni.kit.commands.execute(
            "MarsoAddAssetCommand",
            usd_path=str(source),
            prim_name=local.name,
            asset_id=local.asset_id,
            translate_x=offset[0],
            translate_y=offset[1],
            translate_z=offset[2],
            payload=self._payload,
            rotate_x_deg=correction.rotate_x_deg,
            scale=correction.scale,
            usd_context_name=self._context_name,
            select=not self.added,
        )
        if not success or not path:
            self.errors.append(f"{local.name}: could not be added to the stage.")
            return None
        self.added.append(path)
        if len(self.added) > 1:
            context.get_selection().set_selected_prim_paths(self.added, True)
        return path


def assets_in_stage(asset_ids: list[str], usd_context_name: str = "") -> list[str]:
    """Which of these assets the open stage uses (prims this extension added carry their asset id)."""
    stage = omni.usd.get_context(usd_context_name).get_stage()
    if stage is None:
        return []
    wanted, found = set(asset_ids), []
    for prim in stage.Traverse():
        data = prim.GetCustomDataByKey(usd_inspect.CUSTOM_DATA_KEY)
        if isinstance(data, dict) and data.get("assetId") in wanted and data["assetId"] not in found:
            found.append(data["assetId"])
    return found


def add_to_stage(assets: list[LocalAsset], usd_context_name: str = "") -> StagePlacer:
    """Add several downloaded assets in one undo step."""
    placer = StagePlacer(usd_context_name)
    with omni.kit.undo.group():
        for local in assets:
            placer.add(local)
    return placer


def open_as_stage(local: LocalAsset) -> None:
    """Open the asset's own package as the stage (asks to save the current one first)."""
    try:
        import omni.kit.window.file as window_file

        window_file.open_stage(local.usd_path.as_posix())
    except ImportError:
        omni.usd.get_context().open_stage(local.usd_path.as_posix())


def _parent_path(stage: Usd.Stage) -> str:
    """Under the default prim (``/World`` in Isaac Sim), creating it if the stage has none."""
    default = stage.GetDefaultPrim()
    if default:
        return default.GetPath().pathString
    world = stage.GetPrimAtPath(DEFAULT_PARENT)
    if not world:
        world = UsdGeom.Xform.Define(stage, DEFAULT_PARENT).GetPrim()
    stage.SetDefaultPrim(world)
    return DEFAULT_PARENT


def _reference_path(layer: Sdf.Layer, usd_path: str) -> str:
    """Relative to the edit layer when that layer is saved somewhere, as Kit's own drop does."""
    url = usd_path.replace("\\", "/")
    if layer is not None and not layer.anonymous:
        return omni.client.make_relative_url_if_possible(layer.identifier, url)
    return url


def _extent(asset_stage: Usd.Stage, correction: placement.Correction) -> tuple[tuple[float, ...], tuple[float, ...]]:
    """The asset's box (min, max) once corrected into the target stage, before any placement."""
    cache = UsdGeom.BBoxCache(Usd.TimeCode.Default(), [UsdGeom.Tokens.default_, UsdGeom.Tokens.render])
    box = cache.ComputeWorldBound(asset_stage.GetDefaultPrim())
    matrix = Gf.Matrix4d().SetScale(correction.scale) * Gf.Matrix4d().SetRotate(
        Gf.Rotation(Gf.Vec3d(1, 0, 0), correction.rotate_x_deg)
    )
    aligned = Gf.BBox3d(box.GetRange(), box.GetMatrix() * matrix).ComputeAlignedRange()
    if aligned.IsEmpty():
        return (0.0, 0.0, 0.0), (0.0, 0.0, 0.0)
    return tuple(aligned.GetMin()), tuple(aligned.GetMax())


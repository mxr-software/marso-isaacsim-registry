"""What a remote agent can ask this Isaac Sim to do: the commands behind the agent connection.

Each handler runs on Kit's loop (unless registered with ``main_thread=False``), takes parameters the
registry has already checked, and returns a JSON-safe dict. A handler that starts slow work (downloads,
a Sim Studio run, an upload for the chat) returns ``job_id`` and a ``job`` snapshot; the Marso MCP then
waits on it with ``wait_job``. Everything here goes through the same services the Marso window uses.

What is deliberately missing: the Create tab (it spends credits; the Marso MCP generates instead),
settings and folders, deleting downloads, and anything that opens or reads a path. See
``core/agent_policy.py``.
"""

from __future__ import annotations

import base64
import io
import tempfile
import threading
import uuid
from pathlib import Path
from typing import TYPE_CHECKING, Any, Callable

import omni.kit.commands
import omni.kit.undo
import omni.usd
from pxr import Usd, UsdGeom, UsdPhysics

from . import settings, usd_inspect, usd_ops
from .core import agent_jobs, placement, sim_job
from .core.agent_commands import BOOL, IDS, STRING, Registry, ServiceError, object_schema
from .core.agent_relay import RelayError
from .core.controller import EVENT_JOB, JOB_FAILED, STATUS_DOWNLOADED, SYNC_IDLE
from .core.storage import LocalAsset
from .sim_service import EVENT_PROGRESS, PHASE_CANCELLED, PHASE_DONE, PHASE_FAILED, RunState

if TYPE_CHECKING:
    from .agent_service import AgentService

# The Marso MCP's host refuses uploads a little over 70 MB, so the MCP takes up to 50 MB.
MAX_SHARE_BYTES = 50 * 1024 * 1024
STAGE_LIMIT = 200


def job_result(job: agent_jobs.Job, **extra: Any) -> dict[str, Any]:
    return {"job_id": job.id, "job": job.snapshot(), **extra}


# --- what the session holds ------------------------------------------------------------------


def stage_summary(limit: int = STAGE_LIMIT) -> dict[str, Any]:
    """The open stage: its name, units, physics, and the Marso assets on it (prims carry their asset id)."""
    context = omni.usd.get_context()
    stage = context.get_stage()
    if stage is None:
        return {"open": False, "marso_assets": []}
    layer = stage.GetRootLayer()
    found: list[dict[str, Any]] = []
    physics = False
    xforms = UsdGeom.XformCache()
    it = iter(Usd.PrimRange(stage.GetPseudoRoot()))
    for prim in it:
        if prim.IsA(UsdPhysics.Scene):
            physics = True
        data = prim.GetCustomDataByKey(usd_inspect.CUSTOM_DATA_KEY)
        if isinstance(data, dict) and data.get("assetId"):
            if len(found) < limit:
                position = xforms.GetLocalToWorldTransform(prim).ExtractTranslation()
                found.append({
                    "prim_path": str(prim.GetPath()),
                    "asset_id": str(data["assetId"]),
                    "name": prim.GetName(),
                    "position": [round(float(v), 4) for v in position],
                })
            it.PruneChildren()  # the asset's own prims are not separate assets
    return {
        "open": True,
        "name": Path(layer.realPath).name if layer.realPath else "Untitled",
        "up_axis": UsdGeom.GetStageUpAxis(stage),
        "meters_per_unit": UsdGeom.GetStageMetersPerUnit(stage),
        "has_physics_scene": physics,
        "selected": list(context.get_selection().get_selected_prim_paths())[:50],
        "marso_assets": found,
    }


def register_all(reg: Registry, svc: "AgentService") -> None:
    ctrl, studio, jobs = svc.ctrl, svc.studio, svc.jobs

    def library_summary() -> dict[str, Any]:
        state = ctrl.sync_state
        assets = ctrl.library.assets
        return {
            "sync": {"status": state.status, "message": state.message, "synced_at": state.synced_at},
            "projects": sum(1 for p in ctrl.library.projects if p.assets),
            "assets": len(assets),
            "downloaded": sum(1 for a in assets if a.asset_id in ctrl.local),
            "downloading": [{"asset_id": j.asset_id, "status": j.status, "progress": round(j.progress, 3)} for j in ctrl.active_jobs],
        }

    def sim_summary() -> dict[str, Any]:
        s = studio.state
        return {
            "phase": s.phase,
            "active": s.active,
            "run": s.folder.name if s.folder else None,
            "tests": list(s.tests),
            "test": s.test,
            "frame": s.frame,
            "frames": s.frames,
            "done": list(s.done),
            "progress": round(s.fraction, 4),
            "message": s.message,
            "objects": list(studio.objects),
        }

    def asset_row(asset_id: str) -> dict[str, Any]:
        asset = ctrl.library.asset(asset_id)
        local = ctrl.local.get(asset_id)
        row: dict[str, Any] = {"asset_id": asset_id, "name": ctrl.name_of(asset_id), "status": ctrl.status(asset_id)}
        if asset is not None and asset.category:
            row["category"] = asset.category
        if local is not None and local.physics is not None:
            row["physics_ready"] = bool(local.physics.rigid_bodies)
        flags = ctrl.flags_of(asset_id)
        if flags:
            row["flags"] = flags[:5]
        if ctrl.has_update(asset_id):
            row["update"] = True
        return row

    def ensure_known(ids: list[str], job: agent_jobs.Job, then: Callable[[], None]) -> None:
        """Run ``then`` once every asset is in the library, syncing first for any that are new."""
        unknown = [a for a in ids if ctrl.library.asset(a) is None and a not in ctrl.local]
        if not unknown:
            then()
            return
        job.update(message="Syncing your Marso library to find the new assets...")
        task = ctrl.sync()

        def after(_task: Any) -> None:
            still = [a for a in unknown if ctrl.library.asset(a) is None and a not in ctrl.local]
            if still:
                job.fail(f"Not in your Marso library: {', '.join(still)}. Finished PBR assets appear there; "
                         "pass a PBR node's texture_asset_id or a library asset's primary_asset_id.")
            else:
                then()

        if task is None:
            after(None)
        else:
            task.add_done_callback(after)

    def follow_downloads(ids: list[str], job: agent_jobs.Job, on_ready: Callable[[LocalAsset], None] | None,
                         finish: Callable[[list[str]], None]) -> None:
        """Request ``ids``, call ``on_ready`` for each that lands, then ``finish(failures)`` once none is pending."""
        pending, failures = set(ids), []
        unsubscribe: list[Callable[[], None]] = []

        def maybe_finish() -> None:
            if pending or job.is_terminal:
                return
            for fn in unsubscribe:
                fn()
            unsubscribe.clear()
            finish(failures)

        def ready(local: LocalAsset) -> None:
            if on_ready is not None:
                on_ready(local)
            pending.discard(local.asset_id)
            job.update(progress=1 - len(pending) / max(1, len(ids)), message=f"{len(ids) - len(pending)} of {len(ids)} ready")
            maybe_finish()

        def on_event(topic: str, asset_id: Any) -> None:
            if topic != EVENT_JOB or asset_id not in pending:
                return
            download = ctrl.jobs.get(asset_id)
            if download is not None and download.status == JOB_FAILED:
                failures.append(f"{ctrl.name_of(asset_id)}: {download.error or 'download failed'}")
                pending.discard(asset_id)
            elif download is None and asset_id not in ctrl.local:
                failures.append(f"{ctrl.name_of(asset_id)}: download cancelled")
                pending.discard(asset_id)
            maybe_finish()

        unsubscribe.append(ctrl.subscribe(on_event))
        with omni.kit.undo.group():
            ctrl.request(ids, on_ready=ready)
        maybe_finish()

    # --- seeing the session --------------------------------------------------------------------

    @reg.command("get_state", "The session at a glance: the stage's Marso assets, the library, Sim Studio and running jobs.")
    def _get_state(params: dict[str, Any]) -> dict[str, Any]:
        stage = stage_summary(limit=50)
        return {
            "stage": stage,
            "library": library_summary(),
            "sim": sim_summary(),
            "jobs": [job.snapshot() for job in jobs.list(active_only=True)],
        }

    @reg.command("list_stage", "Every Marso asset on the open stage: prim path, asset id, name and position.",
                 object_schema({"limit": {"type": "integer", "minimum": 1, "maximum": STAGE_LIMIT}}))
    def _list_stage(params: dict[str, Any]) -> dict[str, Any]:
        return stage_summary(limit=int(params.get("limit", STAGE_LIMIT)))

    @reg.command("viewport_screenshot", "A picture of the active viewport as a PNG data URL.",
                 object_schema({"max_px": {"type": "integer", "minimum": 128, "maximum": 2048}}))
    async def _viewport_screenshot(params: dict[str, Any]) -> dict[str, Any]:
        try:
            from omni.kit.viewport.utility import capture_viewport_to_file, get_active_viewport
        except ImportError as exc:
            raise ServiceError("This Isaac Sim has no viewport to capture.", code="nothing_to_capture") from exc
        viewport = get_active_viewport()
        if viewport is None:
            raise ServiceError("No viewport is open to capture.", code="nothing_to_capture")
        path = Path(tempfile.gettempdir()) / f"marso-viewport-{uuid.uuid4().hex[:12]}.png"
        capture = capture_viewport_to_file(viewport, str(path))
        await capture.wait_for_result()
        try:
            png, width, height = _scaled_image(path, int(params.get("max_px", 768)), "PNG")
        finally:
            path.unlink(missing_ok=True)
        return {"image": "data:image/png;base64," + base64.b64encode(png).decode("ascii"), "width": width, "height": height}

    # --- library and stage ---------------------------------------------------------------------

    @reg.command("library_state", "The synced library: projects (or one project's assets, with download status).",
                 object_schema({"project_id": STRING, "limit": {"type": "integer", "minimum": 1, "maximum": 200}}))
    def _library_state(params: dict[str, Any]) -> dict[str, Any]:
        limit = int(params.get("limit", 100))
        summary = library_summary()
        project_id = params.get("project_id")
        if project_id:
            project = next((p for p in ctrl.library.projects if p.project_id == project_id), None)
            if project is None:
                raise ServiceError(f"No project {project_id} in the synced library. Run sync_library first.", code="not_found")
            return {**summary, "project": {"project_id": project.project_id, "name": project.name,
                                           "assets": [asset_row(a.asset_id) for a in project.assets[:limit]]}}
        projects = [
            {"project_id": p.project_id, "name": p.name, "assets": len(p.assets),
             "downloaded": sum(1 for a in p.assets if a.asset_id in ctrl.local)}
            for p in ctrl.library.projects if p.assets
        ]
        return {**summary, "project_list": projects[:limit]}

    @reg.command("sync_library", "Refresh the library listing from Marso.", returns_job=True)
    def _sync_library(params: dict[str, Any]) -> dict[str, Any]:
        job = jobs.start("sync_library")
        task = ctrl.sync()

        def after(_task: Any) -> None:
            state = ctrl.sync_state
            if state.status == SYNC_IDLE:
                job.succeed(library_summary(), message=state.message)
            else:
                job.fail(state.message or "The sync did not finish.")

        if task is None:
            after(None)
        else:
            task.add_done_callback(after)
        return job_result(job)

    @reg.command("download_assets", "Download library assets as USD without adding them to the stage.",
                 object_schema({"asset_ids": {**IDS, "minItems": 1, "maxItems": 50}}, required=("asset_ids",)),
                 returns_job=True)
    def _download_assets(params: dict[str, Any]) -> dict[str, Any]:
        ids = list(dict.fromkeys(params["asset_ids"]))
        job = jobs.start("download_assets", {"asset_ids": ids}, cancel_hook=lambda: svc.call_soon(_cancel_ids, ids))

        def finish(failures: list[str]) -> None:
            ready = [a for a in ids if ctrl.status(a) == STATUS_DOWNLOADED]
            result = {"downloaded": [asset_row(a) for a in ready], "errors": failures}
            if ready:
                job.succeed(result, message=f"{len(ready)} asset(s) on disk.")
            else:
                job.fail("; ".join(failures) or "Nothing was downloaded.", result)

        ensure_known(ids, job, lambda: follow_downloads(ids, job, None, finish))
        return job_result(job)

    @reg.command("add_to_stage",
                 "Download library assets if needed and add them to the open stage, laid out apart: "
                 "arrange row, grid or stack (default the user's setting); add_ground adds a physics scene and ground.",
                 object_schema({"asset_ids": {**IDS, "minItems": 1, "maxItems": 50},
                                "arrange": {"type": "string", "enum": list(placement.ARRANGEMENTS)},
                                "add_ground": BOOL}, required=("asset_ids",)),
                 returns_job=True)
    def _add_to_stage(params: dict[str, Any]) -> dict[str, Any]:
        ids = list(dict.fromkeys(params["asset_ids"]))
        job = jobs.start("add_to_stage", {"asset_ids": ids}, cancel_hook=lambda: svc.call_soon(_cancel_ids, ids))

        def place() -> None:
            placer = usd_ops.StagePlacer(arrange=params.get("arrange"), add_ground=params.get("add_ground"))
            added: list[dict[str, Any]] = []

            def on_ready(local: LocalAsset) -> None:
                path = placer.add(local)
                if path:
                    added.append({"asset_id": local.asset_id, "name": local.name, "prim_path": path})

            def finish(failures: list[str]) -> None:
                errors = placer.errors + failures
                result = {"added": added, "ground": placer.ground, "errors": errors}
                if added:
                    settings.note_used([a["asset_id"] for a in added])
                    job.succeed(result, message=f"Added {len(added)} asset(s) to the stage.")
                else:
                    job.fail("; ".join(errors) or "Nothing was added to the stage.", result)

            follow_downloads(ids, job, on_ready, finish)

        ensure_known(ids, job, place)
        return job_result(job)

    def _cancel_ids(ids: list[str]) -> None:
        for asset_id in ids:
            ctrl.cancel(asset_id)

    @reg.command("add_ground", "Add a physics scene and a ground plane if the stage has neither.")
    def _add_ground(params: dict[str, Any]) -> dict[str, Any]:
        _ok, created = omni.kit.commands.execute("MarsoAddGroundCommand")
        return {"added": [str(path) for path in (created or [])]}

    # --- Sim Studio ------------------------------------------------------------------------------

    @reg.command("sim_catalog", "Sim Studio's tests with their options and defaults, and the quality, aspect and branding choices.")
    def _sim_catalog(params: dict[str, Any]) -> dict[str, Any]:
        return {
            "tests": [{"key": t.key, "title": t.title, "summary": t.summary, "min_objects": t.min_objects,
                       "options": dict(t.options)} for t in sim_job.TESTS],
            "qualities": [{"key": q.key, "label": q.label, "long_side": q.long_side, "fps": q.fps} for q in sim_job.QUALITIES],
            "aspects": list(sim_job.ASPECTS),
            "branding": list(sim_job.BRANDING_CHOICES),
            "defaults": {"quality": sim_job.DEFAULT_QUALITY, "aspect": sim_job.DEFAULT_ASPECT, "branding": sim_job.BOTH},
        }

    @reg.command("sim_state", "Whether Sim Studio is running, and where it is: phase, test, frame and progress.")
    def _sim_state(params: dict[str, Any]) -> dict[str, Any]:
        return sim_summary()

    @reg.command("sim_start",
                 "Film library assets under physics in Sim Studio, in a separate Isaac Sim: one video per test.",
                 object_schema({
                     "asset_ids": {**IDS, "minItems": 1, "maxItems": 12},
                     "tests": {"type": "array", "minItems": 1, "items": {"type": "string", "enum": list(sim_job.TEST_KEYS)}},
                     "quality": {"type": "string", "enum": [q.key for q in sim_job.QUALITIES]},
                     "aspect": {"type": "string", "enum": list(sim_job.ASPECTS)},
                     "branding": {"type": "string", "enum": list(sim_job.BRANDING_CHOICES)},
                     "outro": BOOL,
                     "options": {"type": "object"},
                 }, required=("asset_ids", "tests")),
                 returns_job=True)
    def _sim_start(params: dict[str, Any]) -> dict[str, Any]:
        if studio.state.active:
            raise ServiceError("Sim Studio is already running. Wait for it, or cancel it with sim_cancel.", code="busy")
        ids = list(dict.fromkeys(params["asset_ids"]))
        tests = list(dict.fromkeys(params["tests"]))
        job = jobs.start("sim_start", {"asset_ids": ids, "tests": tests}, cancel_hook=lambda: svc.call_soon(studio.cancel))

        def begin() -> None:
            studio.clear()
            studio.add(ids)
            missing = [a for a in ids if a not in studio.objects]
            if missing:
                job.fail(f"Not in your Marso library: {', '.join(missing)}.")
                return
            unsubscribe: list[Callable[[], None]] = []

            def on_progress(topic: str, state: Any) -> None:
                if topic != EVENT_PROGRESS or not isinstance(state, RunState):
                    return
                job.update(state.fraction, state.message)
                if state.phase in (PHASE_DONE, PHASE_FAILED, PHASE_CANCELLED):
                    for fn in unsubscribe:
                        fn()
                    unsubscribe.clear()
                    result = run_result(state)
                    if state.phase == PHASE_DONE:
                        job.succeed(result, message=state.message)
                    elif state.phase == PHASE_CANCELLED:
                        job.cancelled(state.message)
                    else:
                        job.fail(state.message or "Sim Studio did not finish.", result)

            unsubscribe.append(studio.subscribe(on_progress))
            problem = studio.start(tests, _clean_options(params.get("options")), params.get("quality", sim_job.DEFAULT_QUALITY),
                                   params.get("aspect", sim_job.DEFAULT_ASPECT), params.get("branding", sim_job.BOTH),
                                   bool(params.get("outro", False)))
            if problem:
                for fn in unsubscribe:
                    fn()
                job.fail(problem)
            else:
                settings.note_used(ids)

        ensure_known(ids, job, begin)
        return job_result(job)

    def run_result(state: RunState) -> dict[str, Any]:
        result: dict[str, Any] = {"run": state.folder.name if state.folder else None, "tests": list(state.tests)}
        summary = sim_job.read_run(state.folder) if state.folder else None
        if summary is not None:
            result["status"] = summary.status
            result["videos"] = run_videos(summary)
        return result

    def run_videos(summary: sim_job.RunSummary) -> list[dict[str, Any]]:
        videos = []
        for test in summary.tests:
            key = str(test.get("key", ""))
            branded, clean = summary.media(key, "video"), summary.media(key, "clean")
            if branded or clean:
                videos.append({"test": key, "branded": branded is not None, "clean": clean is not None,
                               "mb": round(((branded or clean).stat().st_size) / (1024 * 1024), 1)})
        return videos

    @reg.command("sim_cancel", "Stop the running Sim Studio run.")
    def _sim_cancel(params: dict[str, Any]) -> dict[str, Any]:
        studio.cancel()
        return sim_summary()

    @reg.command("sim_runs", "Sim Studio's past runs, newest first: name, status, tests and which videos exist.",
                 object_schema({"limit": {"type": "integer", "minimum": 1, "maximum": 24}}))
    def _sim_runs(params: dict[str, Any]) -> dict[str, Any]:
        runs = studio.runs()[: int(params.get("limit", 10))]
        return {"runs": [{"run": r.folder.name, "name": r.name, "created": r.created, "status": r.status,
                          "assets": list(r.assets), "videos": run_videos(r)} for r in runs]}

    @reg.command("share_render",
                 "Send a Sim Studio video to the chat: the given sim_start job's run, a run by name, or the latest; "
                 "one test (default the first with a video), branded or clean. Only videos Sim Studio made can be sent.",
                 object_schema({"job_id": STRING, "run": STRING, "test": {"type": "string", "enum": list(sim_job.TEST_KEYS)},
                                "clean": BOOL, "upload": BOOL, "preview_px": {"type": "integer", "minimum": 128, "maximum": 1024},
                                "force": BOOL}),
                 returns_job=True)
    def _share_render(params: dict[str, Any]) -> dict[str, Any]:
        summary = _pick_run(params)
        test, path = _pick_video(summary, params.get("test"), bool(params.get("clean", False)))
        size = path.stat().st_size
        title = sim_job.spec(test).title
        info: dict[str, Any] = {
            "name": f"Marso {title} test{' (clean)' if params.get('clean') else ''}.mp4",
            "path": str(path), "kind": "video", "mime": "video/mp4", "bytes": size,
            "run": summary.folder.name, "test": test,
        }
        thumb = summary.media(test, "thumb") or summary.media(test, "card")
        if thumb is not None:
            try:
                jpeg, _w, _h = _scaled_image(thumb, int(params.get("preview_px", 512)), "JPEG")
                info["preview"] = "data:image/jpeg;base64," + base64.b64encode(jpeg).decode("ascii")
            except Exception:  # noqa: BLE001 - a missing preview never stops the share
                pass
        if not params.get("upload", True):
            return {"job_id": None, **info}
        if size > MAX_SHARE_BYTES:
            raise ServiceError(f"That video is {size // (1024 * 1024)} MB; the chat takes up to 50 MB. It is in the Sim "
                               "Studio folder; a preview or standard quality run makes a smaller one.", code="too_large")
        if not svc.connected:
            raise ServiceError("Sending a video to the chat needs Connect to Marso Agents to be on.", code="not_connected")
        key = (str(path), path.stat().st_mtime)
        cached = svc.shared.get(key)
        if cached is not None and not params.get("force"):
            return {"job_id": None, **info, **cached}
        job = jobs.start("share_render", {"run": summary.folder.name, "test": test})

        def upload() -> None:
            try:
                answer = svc.upload(path, info["name"])
            except (RelayError, OSError) as exc:
                job.fail(f"Sending the video failed: {exc}")
                return
            if not isinstance(answer.get("share_id"), str):
                job.fail("The server did not accept the video.")
                return
            share = {"share_id": answer["share_id"], "expires_at": answer.get("expires_at"), "mime": answer.get("mime", "video/mp4")}
            svc.shared[key] = share
            job.succeed({**info, **share}, message="Sent to the chat.")

        threading.Thread(target=upload, daemon=True, name="marso-agent-upload").start()
        return job_result(job, **info)

    def _pick_run(params: dict[str, Any]) -> sim_job.RunSummary:
        runs = studio.runs()
        wanted = params.get("run")
        if params.get("job_id"):
            job = jobs.get(params["job_id"])
            if job is None or job.kind != "sim_start" or not job.result or not job.result.get("run"):
                raise ServiceError("That job is not a finished Sim Studio run.", code="not_a_run")
            wanted = job.result["run"]
        if wanted:
            found = next((r for r in runs if r.folder.name == wanted), None)
            if found is None:
                raise ServiceError(f"No Sim Studio run named {wanted}. sim_runs lists them.", code="not_found")
            return found
        found = next((r for r in runs if run_videos(r)), None)
        if found is None:
            raise ServiceError("Sim Studio has no finished videos yet. Run sim_start first.", code="nothing_rendered")
        return found

    def _pick_video(summary: sim_job.RunSummary, test: str | None, clean: bool) -> tuple[str, Path]:
        kind = "clean" if clean else "video"
        keys = [test] if test else [str(t.get("key", "")) for t in summary.tests]
        for key in keys:
            path = summary.media(key, kind)
            if path is not None:
                root = studio.root.resolve()
                resolved = path.resolve()
                # Only a video inside Sim Studio's own folder, as the run recorded it.
                if resolved.suffix.lower() != ".mp4" or root not in resolved.parents:
                    raise ServiceError("Only videos Sim Studio made can be sent to the chat.", code="not_a_run")
                return key, resolved
        which = f"the {test} test" if test else "this run"
        raise ServiceError(f"No {'clean' if clean else 'branded'} video for {which}.", code="not_found")

    # --- jobs ------------------------------------------------------------------------------------

    @reg.command("list_jobs", "Jobs the connection started this session, newest last.",
                 object_schema({"active_only": BOOL}), main_thread=False)
    def _list_jobs(params: dict[str, Any]) -> dict[str, Any]:
        return {"jobs": [job.snapshot() for job in jobs.list(bool(params.get("active_only", False)))]}

    def _find(job_id: str) -> agent_jobs.Job:
        job = jobs.get(job_id)
        if job is None:
            raise ServiceError(f"No job {job_id}. Finished jobs are forgotten after a while.", code="unknown_job")
        return job

    @reg.command("get_job", "A job's status, progress, message and result.",
                 object_schema({"job_id": STRING}, required=("job_id",)), main_thread=False)
    def _get_job(params: dict[str, Any]) -> dict[str, Any]:
        return _find(params["job_id"]).snapshot()

    @reg.command("wait_job", "Wait until a job ends or timeout seconds pass, then return its snapshot.",
                 object_schema({"job_id": STRING, "timeout": {"type": "number", "minimum": 0, "maximum": 600}},
                               required=("job_id",)), main_thread=False)
    def _wait_job(params: dict[str, Any]) -> dict[str, Any]:
        job = _find(params["job_id"])
        job.wait(float(params.get("timeout", 60.0)))
        return job.snapshot()

    @reg.command("cancel_job", "Ask a running job to stop.",
                 object_schema({"job_id": STRING}, required=("job_id",)), main_thread=False)
    def _cancel_job(params: dict[str, Any]) -> dict[str, Any]:
        job = _find(params["job_id"])
        job.request_cancel()
        return job.snapshot()


def _clean_options(options: Any) -> dict[str, dict[str, Any]]:
    """Per-test options as plain numbers and switches; anything else is dropped (Sim Studio also drops unknown keys)."""
    if not isinstance(options, dict):
        return {}
    clean: dict[str, dict[str, Any]] = {}
    for test, values in options.items():
        if test in sim_job.TEST_KEYS and isinstance(values, dict):
            clean[test] = {k: v for k, v in values.items() if isinstance(v, (int, float, bool)) and isinstance(k, str)}
    return clean


def _scaled_image(path: Path, max_px: int, fmt: str) -> tuple[bytes, int, int]:
    """An image file, scaled so its long edge is at most ``max_px``, encoded as PNG or JPEG (Pillow)."""
    from PIL import Image

    with Image.open(path) as image:
        image.load()
        picture = image.convert("RGB") if fmt == "JPEG" else image.copy()
    picture.thumbnail((max_px, max_px))
    out = io.BytesIO()
    picture.save(out, format=fmt, **({"quality": 82} if fmt == "JPEG" else {}))
    return out.getvalue(), picture.width, picture.height

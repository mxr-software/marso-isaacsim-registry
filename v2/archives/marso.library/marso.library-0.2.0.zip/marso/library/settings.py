"""Persistent settings, stored by Kit in the user's ``user.config.json``.

The API key is kept there in plain text, as Kit stores every persistent
setting; leaving the field empty and setting ``MARSO_API_KEY`` in the
environment avoids writing it to disk at all.
"""

from __future__ import annotations

import json

import carb.settings

from .core import config

EXTENSION_NAME = "marso.library"
_ROOT = f"/persistent/exts/{EXTENSION_NAME}"

# UI preferences, also persistent.
KEY_TILE_SIZE = "tile_size"
KEY_LAST_PROJECT = "last_project"
KEY_LIBRARY_FILTER = "library_filter"
KEY_SHOW_DETAILS = "show_details"  # the details panel beside the Library and Downloaded grids
KEY_SIM_DIR = "sim_dir"  # where Sim Studio runs go; empty = beside the downloads folder
KEY_SIM_PREFS = "sim_prefs"  # the last tests, options and output choices, as JSON
KEY_FAVOURITES = "favourites"  # starred asset ids, as a JSON list
KEY_RECENT = "recent"  # asset ids last added to a stage or tested, newest first, as a JSON list
# Adding to the stage
KEY_ADD_GROUND = "add_ground"  # 1: add a physics scene and a ground when the stage has neither
KEY_ARRANGE = "arrange"  # how a batch is laid out: core.placement.ARRANGE_*
KEY_USE_PAYLOADS = "use_payloads"  # 1: add assets as payloads (they can be unloaded), else references
KEY_CREATION = "creation"  # the Create tab's image draft and asset runs, as JSON (resumed on launch)
KEY_CREATE_TO_STAGE = "create_to_stage"  # 1: "Import onto stage" is ticked for new assets
# Agent connection
KEY_AGENT_CONNECT = "agent_connect"  # 1: connect out to the Marso MCP so the user's agents can use this Isaac Sim
KEY_AGENT_SERVER = "agent_server"  # the Marso MCP's address; empty = the hosted Marso MCP
RECENT_LIMIT = 30

DEFAULT_TILE_SIZE = 128
MIN_TILE_SIZE = 72
MAX_TILE_SIZE = 256

_CONFIG_KEYS = (config.KEY_API_KEY, config.KEY_API_ENDPOINT, config.KEY_CACHE_DIR, config.KEY_DOWNLOADS_DIR)


def _settings() -> carb.settings.ISettings:
    return carb.settings.get_settings()


def get(key: str, default: str = "") -> str:
    value = _settings().get(f"{_ROOT}/{key}")
    return default if value is None else str(value)


def get_int(key: str, default: int) -> int:
    value = _settings().get(f"{_ROOT}/{key}")
    try:
        return int(value) if value is not None else default
    except (TypeError, ValueError):
        return default


def set_value(key: str, value: str | int) -> None:
    _settings().set(f"{_ROOT}/{key}", value)


def saved_config() -> dict[str, str]:
    return {key: get(key) for key in _CONFIG_KEYS}


def resolve() -> config.Config:
    """The settings a run uses right now (saved, else environment, else defaults)."""
    return config.resolve(saved_config())


def visible_on_startup() -> bool:
    return bool(_settings().get(f"/exts/{EXTENSION_NAME}/visible_on_startup"))


def get_list(key: str) -> list[str]:
    try:
        value = json.loads(get(key) or "[]")
    except ValueError:
        return []
    return [str(item) for item in value] if isinstance(value, list) else []


def set_list(key: str, values: list[str]) -> None:
    set_value(key, json.dumps(list(dict.fromkeys(values))))


def favourites() -> list[str]:
    return get_list(KEY_FAVOURITES)


def is_favourite(asset_id: str) -> bool:
    return asset_id in favourites()


def toggle_favourite(asset_ids: list[str], on: bool | None = None) -> bool:
    """Star or unstar assets (``on=None`` flips by the first one). Returns whether they are now starred."""
    current = favourites()
    on = (asset_ids[0] not in current) if on is None and asset_ids else bool(on)
    if on:
        current += [a for a in asset_ids if a not in current]
    else:
        current = [a for a in current if a not in asset_ids]
    set_list(KEY_FAVOURITES, current)
    return on


def recent() -> list[str]:
    return get_list(KEY_RECENT)


def note_used(asset_ids: list[str]) -> None:
    """Assets were added to a stage or tested: they go to the front of Recently used."""
    ids = list(dict.fromkeys(asset_ids))
    set_list(KEY_RECENT, (ids + [a for a in recent() if a not in ids])[:RECENT_LIMIT])


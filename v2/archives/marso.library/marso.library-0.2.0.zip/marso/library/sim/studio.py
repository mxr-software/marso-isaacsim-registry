"""The Sim Studio set: a branded floor, studio lights, cameras, the assets and their physics.

Runs inside the Sim Studio runner's Isaac Sim. Assets are added through their Isaac Sim wrapper
layers (``usd_inspect.prepare``), exactly as the extension's Add to Stage does, so the tests see
the same USD a user would.

The floor's physics material uses PhysX combine modes that pass each asset's own friction
(multiply with 1.0) and restitution (max with 0.0) straight through, so every test measures the
asset's authored physics rather than the floor's.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import omni.physx
import omni.usd
from PIL import Image, ImageDraw
from pxr import Gf, PhysxSchema, Sdf, Usd, UsdGeom, UsdLux, UsdPhysics, UsdShade

from ..core import rest
from ..core import sim_metrics as metrics

FLOOR_NAME = "Floor"
FLOOR_COLLIDER = "/World/Studio/Floor/Collider"
FLOOR_COLLIDER_SIZE = 30.0  # metres; anything that rolls further is long out of shot


@dataclass
class Placed:
    asset: dict
    prim: Usd.Prim
    box: Gf.Range3d

    @property
    def name(self) -> str:
        return self.asset["name"]


class Studio:
    def __init__(self, app, job: dict, usd_inspect, storage) -> None:
        self.app = app
        self.job = job
        self.usd_inspect = usd_inspect
        self.storage = storage
        self.out = Path(job["out_dir"])
        self.W, self.H = int(job["width"]), int(job["height"])
        self.stage: Usd.Stage | None = None
        self._rest_turns: dict[str, np.ndarray | None] = {}  # by asset folder: how to lay it down, if at all

    # --- stage -----------------------------------------------------------------------------------

    def update(self, frames: int = 1) -> None:
        for _ in range(frames):
            self.app.update()

    def new_stage(self, fps: float = 60.0) -> Usd.Stage:
        context = omni.usd.get_context()
        context.new_stage()
        self.update(3)
        stage = context.get_stage()
        for leftover in ("/Environment", "/World"):
            if stage.GetPrimAtPath(leftover):
                stage.RemovePrim(leftover)
        UsdGeom.SetStageUpAxis(stage, UsdGeom.Tokens.z)
        UsdGeom.SetStageMetersPerUnit(stage, 1.0)
        UsdPhysics.SetStageKilogramsPerUnit(stage, 1.0)
        stage.SetTimeCodesPerSecond(fps)
        stage.SetDefaultPrim(UsdGeom.Xform.Define(stage, "/World").GetPrim())
        self.stage = stage
        return stage

    def export(self, name: str, end_seconds: float = 0.0) -> str:
        """Save the set as it stands (before any simulation) for users to open and shoot themselves."""
        if end_seconds:
            self.stage.SetStartTimeCode(0)
            self.stage.SetEndTimeCode(end_seconds * self.stage.GetTimeCodesPerSecond())
        path = self.out / f"{name}_scene.usda"
        self.stage.GetRootLayer().Export(str(path))
        return path.name

    # --- the set ---------------------------------------------------------------------------------

    def floor_texture(self) -> Path:
        """1 m tile on the DL canvas colour: dots every 10 cm, a hairline every metre."""
        path = self.out / "studio_floor.png"
        if path.is_file():
            return path
        size = 1024
        image = Image.new("RGB", (size, size), (29, 31, 35))
        draw = ImageDraw.Draw(image)
        step = size / 10
        for i in range(11):
            for j in range(11):
                r = 4.5 if (i % 5 == 0 and j % 5 == 0) else 3.0
                cx, cy = i * step, j * step
                draw.ellipse((cx - r, cy - r, cx + r, cy + r), fill=(64, 69, 79))
        for edge in (0, size - 1):
            draw.line([(edge, 0), (edge, size)], fill=(74, 80, 92), width=4)
            draw.line([(0, edge), (size, edge)], fill=(74, 80, 92), width=4)
        image.save(path)
        return path

    def studio_hdri(self) -> Path:
        """A lat-long studio environment for reflections: a warm key softbox, a cool fill, a PBR-violet
        rim strip and a top light on a dark room, normalised so it lights the set as the plain dome did.
        """
        path = self.out / "studio_hdri.hdr"
        if path.is_file():
            return path
        w, h = 2048, 1024
        u = (np.arange(w, dtype=np.float32) + 0.5) / w
        v = (np.arange(h, dtype=np.float32) + 0.5) / h
        az = (u[None, :] - 0.5) * 360.0  # degrees around
        el = (0.5 - v[:, None]) * 180.0  # degrees up
        el_full = np.broadcast_to(el, (h, w))
        img = np.zeros((h, w, 3), dtype=np.float32)
        room = np.where(el_full > 0, 0.05 + 0.03 * (1 - el_full / 90.0), 0.025)
        img += room[..., None]

        def softbox(centre_az, centre_el, half_w, half_h, radiance, colour, soft=0.25):
            d_az = (az - centre_az + 180.0) % 360.0 - 180.0
            x = np.abs(d_az) / half_w
            y = np.abs(el - centre_el) / half_h
            edge = np.maximum(x, y)
            mask = np.clip((1.0 + soft - edge) / soft, 0.0, 1.0) ** 2
            img[...] += mask[..., None] * radiance * np.asarray(colour, dtype=np.float32)

        softbox(-40.0, 38.0, 28.0, 17.0, 14.0, (1.0, 0.97, 0.93))  # key
        softbox(118.0, 24.0, 22.0, 13.0, 3.5, (0.9, 0.94, 1.0))  # fill
        softbox(172.0, 18.0, 5.0, 26.0, 7.0, (0.5, 0.26, 1.0), soft=0.4)  # PBR-violet rim strip
        softbox(0.0, 84.0, 180.0, 7.0, 3.0, (1.0, 1.0, 1.0), soft=0.6)  # top light
        # Lighting strength = solid-angle-weighted mean radiance: make it 1 so the dome's intensity holds.
        weight = np.cos(np.radians(el_full))[..., None]
        img /= float((img.mean(axis=2, keepdims=True) * weight).sum() / weight.sum())
        _write_hdr(path, img)
        return path

    def grid_material(self, path: str, tint=(1.0, 1.0, 1.0), roughness: float = 0.42, matte: bool = False) -> UsdShade.Material:
        stage = self.stage
        material = UsdShade.Material.Define(stage, path)
        shader = UsdShade.Shader.Define(stage, f"{path}/Surface")
        shader.CreateIdAttr("UsdPreviewSurface")
        shader.CreateInput("roughness", Sdf.ValueTypeNames.Float).Set(roughness)
        if matte:  # no specular lobe at all: purely diffuse
            shader.CreateInput("useSpecularWorkflow", Sdf.ValueTypeNames.Int).Set(1)
            shader.CreateInput("specularColor", Sdf.ValueTypeNames.Color3f).Set(Gf.Vec3f(0.0))
        reader = UsdShade.Shader.Define(stage, f"{path}/St")
        reader.CreateIdAttr("UsdPrimvarReader_float2")
        reader.CreateInput("varname", Sdf.ValueTypeNames.Token).Set("st")
        texture = UsdShade.Shader.Define(stage, f"{path}/Grid")
        texture.CreateIdAttr("UsdUVTexture")
        texture.CreateInput("file", Sdf.ValueTypeNames.Asset).Set(self.floor_texture().as_posix())
        texture.CreateInput("wrapS", Sdf.ValueTypeNames.Token).Set("repeat")
        texture.CreateInput("wrapT", Sdf.ValueTypeNames.Token).Set("repeat")
        texture.CreateInput("sourceColorSpace", Sdf.ValueTypeNames.Token).Set("sRGB")
        texture.CreateInput("scale", Sdf.ValueTypeNames.Float4).Set(Gf.Vec4f(*tint, 1.0))
        texture.CreateInput("st", Sdf.ValueTypeNames.Float2).ConnectToSource(reader.ConnectableAPI(), "result")
        shader.CreateInput("diffuseColor", Sdf.ValueTypeNames.Color3f).ConnectToSource(texture.ConnectableAPI(), "rgb")
        material.CreateSurfaceOutput().ConnectToSource(shader.ConnectableAPI(), "surface")
        return material

    def quad(self, path: str, half_x: float, half_y: float, z: float = 0.0) -> UsdGeom.Mesh:
        mesh = UsdGeom.Mesh.Define(self.stage, path)
        mesh.CreatePointsAttr([Gf.Vec3f(-half_x, -half_y, z), Gf.Vec3f(half_x, -half_y, z),
                               Gf.Vec3f(half_x, half_y, z), Gf.Vec3f(-half_x, half_y, z)])
        mesh.CreateFaceVertexCountsAttr([4])
        mesh.CreateFaceVertexIndicesAttr([0, 1, 2, 3])
        mesh.CreateNormalsAttr([Gf.Vec3f(0, 0, 1)] * 4)
        mesh.SetNormalsInterpolation(UsdGeom.Tokens.vertex)
        st = UsdGeom.PrimvarsAPI(mesh).CreatePrimvar("st", Sdf.ValueTypeNames.TexCoord2fArray, UsdGeom.Tokens.vertex)
        st.Set([Gf.Vec2f(-half_x, -half_y), Gf.Vec2f(half_x, -half_y), Gf.Vec2f(half_x, half_y), Gf.Vec2f(-half_x, half_y)])
        return mesh

    def pass_through_material(self, path: str) -> UsdShade.Material:
        """A physics material that lets the other body's friction and restitution decide."""
        material = UsdShade.Material.Define(self.stage, path)
        api = UsdPhysics.MaterialAPI.Apply(material.GetPrim())
        api.CreateStaticFrictionAttr(1.0)
        api.CreateDynamicFrictionAttr(1.0)
        api.CreateRestitutionAttr(0.0)
        physx = PhysxSchema.PhysxMaterialAPI.Apply(material.GetPrim())
        physx.CreateFrictionCombineModeAttr("multiply")
        physx.CreateRestitutionCombineModeAttr("max")
        return material

    def build_set(self, half: float = 25.0) -> None:
        stage = self.stage
        UsdGeom.Xform.Define(stage, "/World/Studio")
        floor = self.quad("/World/Studio/Floor/Surface", half, half)
        # A matte floor: with any specular, views facing the rim light washed the frame with its glossy highlight.
        UsdShade.MaterialBindingAPI.Apply(floor.GetPrim()).Bind(self.grid_material("/World/Studio/Looks/Floor", roughness=0.8, matte=True))
        # The collider is smaller than the floor you see: a box tens of metres across gives SDF
        # contacts that never settle (a resting anvil jittered at ~2 cm/s on a 50 m box).
        collider = UsdGeom.Cube.Define(stage, FLOOR_COLLIDER)
        collider.CreateSizeAttr(1.0)
        collider.AddTranslateOp().Set(Gf.Vec3d(0, 0, -0.1))
        collider.AddScaleOp().Set(Gf.Vec3f(FLOOR_COLLIDER_SIZE, FLOOR_COLLIDER_SIZE, 0.2))
        collider.MakeInvisible()
        UsdPhysics.CollisionAPI.Apply(collider.GetPrim())
        UsdShade.MaterialBindingAPI.Apply(collider.GetPrim()).Bind(
            self.pass_through_material("/World/Studio/Looks/FloorPhysics"), UsdShade.Tokens.weakerThanDescendants, "physics")

        dome = UsdLux.DomeLight.Define(stage, "/World/Studio/Lights/Dome")
        dome.CreateIntensityAttr(230.0)
        dome.CreateColorAttr(Gf.Vec3f(0.88, 0.89, 0.95))
        # A studio environment, so metal and gloss have softboxes to reflect; unseen as background.
        dome.CreateTextureFileAttr(self.studio_hdri().as_posix())
        dome.CreateTextureFormatAttr(UsdLux.Tokens.latlong)
        dome.GetPrim().CreateAttribute("visibleInPrimaryRay", Sdf.ValueTypeNames.Bool).Set(False)
        for name, intensity, colour, angle, rotation in (
            ("Key", 2700.0, (1.0, 0.98, 0.96), 2.5, (52.0, 0.0, -28.0)),
            ("Rim", 1500.0, (0.80, 0.68, 1.0), 3.0, (-58.0, 0.0, 168.0)),  # a faint PBR-violet edge
            ("Fill", 380.0, (0.92, 0.94, 1.0), 6.0, (68.0, 0.0, -125.0)),
        ):
            light = UsdLux.DistantLight.Define(stage, f"/World/Studio/Lights/{name}")
            light.CreateIntensityAttr(intensity)
            # Light only, no highlights: their glossy sheen washed the floor out whenever the camera faced
            # them. Reflections come from the studio HDRI on the dome instead.
            light.CreateSpecularAttr(0.0)
            light.CreateColorAttr(Gf.Vec3f(*colour))
            light.CreateAngleAttr(angle)
            light.AddRotateXYZOp().Set(Gf.Vec3f(*rotation))

    def physics_scene(self, hz: int | None = None) -> None:
        scene = UsdPhysics.Scene.Define(self.stage, "/World/Studio/PhysicsScene")
        scene.CreateGravityDirectionAttr(Gf.Vec3f(0, 0, -1))
        scene.CreateGravityMagnitudeAttr(9.81)
        physx = PhysxSchema.PhysxSceneAPI.Apply(scene.GetPrim())
        physx.CreateTimeStepsPerSecondAttr(int(hz or self.job["sim_hz"]))
        physx.CreateEnableCCDAttr(True)
        # CPU PhysX: with a handful of SDF-collider assets it is as fast as the GPU pipeline here and
        # its resting contacts are steady (the GPU pipeline left heavy assets twitching).
        physx.CreateEnableGPUDynamicsAttr(False)
        physx.CreateBroadphaseTypeAttr("MBP")

    def pole(self, x: float, height: float) -> tuple[float, float]:
        """A banded height pole (5 cm bands up to 1 m, 10 cm above). Returns (band, radius)."""
        band = 0.05 if height <= 1.0 else 0.1
        radius = max(0.008, height * 0.016)
        for i in range(int(round(height / band))):
            seg = UsdGeom.Cylinder.Define(self.stage, f"/World/Studio/Pole/Band{i:02d}")
            seg.CreateRadiusAttr(radius)
            seg.CreateHeightAttr(band)
            seg.CreateAxisAttr("Z")
            seg.AddTranslateOp().Set(Gf.Vec3d(x, 0, band * (i + 0.5)))
            seg.CreateDisplayColorAttr([Gf.Vec3f(0.93, 0.93, 0.96) if i % 2 == 0 else Gf.Vec3f(0.44, 0.33, 0.72)])
        return band, radius

    # --- assets ----------------------------------------------------------------------------------

    def add_asset(self, asset: dict) -> Usd.Prim:
        local = self.storage.read_local_asset(Path(asset["folder"]))
        prepared = self.usd_inspect.prepare(local)
        wrapper = (local.folder / prepared.stage_file).as_posix()
        base = self.usd_inspect.prim_name(asset["name"])
        path, n = Sdf.Path("/World/Assets").AppendChild(base), 1
        while self.stage.GetPrimAtPath(path):  # never stack two assets on one prim
            n += 1
            path = Sdf.Path("/World/Assets").AppendChild(f"{base}_{n}")
        prim = UsdGeom.Xform.Define(self.stage, path).GetPrim()
        prim.GetReferences().AddReference(wrapper)
        self.usd_inspect.apply_placement(prim, 0.0, 0.0, 1.0)
        self._lay_down(prim, asset["folder"])
        return prim

    def _lay_down(self, prim: Usd.Prim, key: str) -> None:
        """Assets modelled in a pose they cannot rest in (a pistol on its edge) are laid in their
        lowest resting pose first, so no test starts with them toppling; the rest keep their pose."""
        if key not in self._rest_turns:
            from .robot import oriented_surface_of

            points, _normals, com = oriented_surface_of(prim)
            self._rest_turns[key] = rest.rest_rotation(points, com if com is not None else points.mean(axis=0))                 if len(points) else None
        turn = self._rest_turns[key]
        attr = prim.GetAttribute("xformOp:rotateXYZ")
        if turn is None or not attr:
            return
        before = attr.Get() or Gf.Vec3d(0.0)
        rx, ry, rz = (math.radians(float(a)) for a in before)
        old = (np.array([[math.cos(rz), -math.sin(rz), 0], [math.sin(rz), math.cos(rz), 0], [0, 0, 1]])
               @ np.array([[math.cos(ry), 0, math.sin(ry)], [0, 1, 0], [-math.sin(ry), 0, math.cos(ry)]])
               @ np.array([[1, 0, 0], [0, math.cos(rx), -math.sin(rx)], [0, math.sin(rx), math.cos(rx)]]))
        attr.Set(Gf.Vec3d(*rest.euler_xyz(turn @ old)))

    def move(self, prim: Usd.Prim, x: float, y: float, z: float) -> None:
        prim.GetAttribute("xformOp:translate").Set(Gf.Vec3d(x, y, z))

    def row(self, assets: list[dict], axis: int = 0, spacing: float = 0.35, arrange=None) -> list[Placed]:
        """Add the assets and line them up along X (axis 0) or Y (axis 1), resting on the floor, centred.

        ``arrange`` may reorder the measured assets before they are spaced out.
        """
        placed = [Placed(asset, prim, world_box(prim)) for asset in assets for prim in [self.add_asset(asset)]]
        if arrange is not None:
            placed = arrange(placed)
        return self._line_up(placed, axis, spacing)

    def rows(self, assets: list[dict], spacing: float = 0.35, arrange=None, per_row: int = 5) -> list[Placed]:
        """Like ``row`` along X, but a big group goes into several rows, front (-Y) to back.

        Objects are dealt into the rows in turn, so each row keeps the arranged order left to right.
        """
        placed = [Placed(asset, prim, world_box(prim)) for asset in assets for prim in [self.add_asset(asset)]]
        if arrange is not None:
            placed = arrange(placed)
        count = max(1, math.ceil(len(placed) / per_row))
        pitch = max(p.box.GetSize()[1] for p in placed) * 1.6 + 0.35
        result = []
        for index in range(count):
            result += self._line_up(placed[index::count], 0, spacing, cross=(index - (count - 1) / 2) * pitch)
        return result

    def _line_up(self, placed: list[Placed], axis: int, spacing: float, cross: float = 0.0) -> list[Placed]:
        sizes = [p.box.GetSize()[axis] for p in placed]
        gap = max(0.15, spacing * (sum(sizes) / max(1, len(sizes))))
        cursor = -(sum(sizes) + gap * (len(sizes) - 1)) / 2.0
        result = []
        for p, size in zip(placed, sizes):
            mid = p.box.GetMidpoint()
            offset = [-mid[0], -mid[1]]
            offset[axis] = cursor - p.box.GetMin()[axis]
            offset[1 - axis] += cross
            self.move(p.prim, offset[0], offset[1], -p.box.GetMin()[2])
            cursor += size + gap
            result.append(Placed(p.asset, p.prim, world_box(p.prim)))
        return result

    # --- cameras ---------------------------------------------------------------------------------

    def camera(self, path: str, focal: float = 50.0, size: tuple[int, int] | None = None) -> UsdGeom.Camera:
        """A camera for the whole frame, or for a split-screen panel of ``size`` (its aspect)."""
        width, height = size or (self.W, self.H)
        cam = UsdGeom.Camera.Define(self.stage, path)
        cam.CreateFocalLengthAttr(focal)
        cam.CreateHorizontalApertureAttr(36.0)
        cam.CreateVerticalApertureAttr(36.0 * height / width)
        cam.CreateClippingRangeAttr(Gf.Vec2f(0.01, 3000.0))
        cam.AddTransformOp()
        return cam

    @staticmethod
    def look_at(cam: UsdGeom.Camera, eye, target, up=(0, 0, 1)) -> None:
        view = Gf.Matrix4d().SetLookAt(Gf.Vec3d(*map(float, eye)), Gf.Vec3d(*map(float, target)), Gf.Vec3d(*map(float, up)))
        UsdGeom.Xformable(cam).GetOrderedXformOps()[0].Set(view.GetInverse())

    def fit_distance(self, width: float, height: float, focal: float = 50.0, margin: float = 1.25) -> float:
        hfov = 2 * math.atan(18.0 / focal)
        vfov = 2 * math.atan(18.0 * self.H / self.W / focal)
        return margin * max((width / 2) / math.tan(hfov / 2), (height / 2) / math.tan(vfov / 2))

    def aim(self, cam: UsdGeom.Camera, centre, yaw: float, elevation: float, distance: float) -> None:
        """Look at ``centre`` from ``distance`` away; ``yaw`` turns the view from +Y towards +X (radians)."""
        eye = (centre[0] - distance * math.sin(yaw) * math.cos(elevation),
               centre[1] - distance * math.cos(yaw) * math.cos(elevation),
               centre[2] + distance * math.sin(elevation))
        self.look_at(cam, eye, centre)

    def fit_aim(self, cam: UsdGeom.Camera, centre, yaw: float, elevation: float, points,
                side: float = 0.05, top: float = 0.17, bottom: float = 0.06, size: tuple[int, int] | None = None) -> float:
        """Aim as ``aim`` does, at the nearest distance that keeps every point inside the frame's margins
        (fractions of the frame; ``top`` leaves room for the title). Returns the distance."""
        width, height = size or (self.W, self.H)

        def fits(distance: float) -> bool:
            self.aim(cam, centre, yaw, elevation, distance)
            for point in points:
                spot = self.project(cam, point, size)
                if spot is None or not (side * width <= spot[0] <= (1 - side) * width
                                        and top * height <= spot[1] <= (1 - bottom) * height):
                    return False
            return True

        low, high = 0.3, 60.0
        for _ in range(40):
            mid = (low + high) / 2
            low, high = (low, mid) if fits(mid) else (mid, high)
        self.aim(cam, centre, yaw, elevation, high)
        return high

    def project(self, cam: UsdGeom.Camera, point, size: tuple[int, int] | None = None) -> tuple[float, float] | None:
        frustum = cam.GetCamera(Usd.TimeCode.Default()).frustum
        matrix = frustum.ComputeViewMatrix() * frustum.ComputeProjectionMatrix()
        clip = Gf.Vec4d(point[0], point[1], point[2], 1.0) * matrix
        if clip[3] <= 1e-6:
            return None
        width, height = size or (self.W, self.H)
        return ((clip[0] / clip[3] + 1) * 0.5 * width, (1 - clip[1] / clip[3]) * 0.5 * height)


def _write_hdr(path: Path, rgb: np.ndarray) -> None:
    """Write float RGB as a Radiance .hdr (flat RGBE scanlines)."""
    h, w, _ = rgb.shape
    peak = rgb.max(axis=2)
    mantissa, exponent = np.frexp(peak)
    scale = np.where(peak > 1e-32, mantissa * 256.0 / np.maximum(peak, 1e-32), 0.0)
    rgbe = np.zeros((h, w, 4), dtype=np.uint8)
    rgbe[..., :3] = np.clip(rgb * scale[..., None], 0, 255).astype(np.uint8)
    rgbe[..., 3] = np.where(peak > 1e-32, exponent + 128, 0).astype(np.uint8)
    with open(path, "wb") as handle:
        handle.write(f"#?RADIANCE\nFORMAT=32-bit_rle_rgbe\n\n-Y {h} +X {w}\n".encode("ascii"))
        handle.write(rgbe.tobytes())


def world_box(prim: Usd.Prim) -> Gf.Range3d:
    cache = UsdGeom.BBoxCache(Usd.TimeCode.Default(), [UsdGeom.Tokens.default_, UsdGeom.Tokens.render])
    return cache.ComputeWorldBound(prim).ComputeAlignedRange()


def is_round(box: Gf.Range3d) -> bool:
    size = sorted(box.GetSize())
    return size[0] > 0 and size[2] / size[0] < 1.12


def physics_of(root: Usd.Prim) -> tuple[list[Usd.Prim], dict]:
    """Rigid bodies under ``root`` and the authored values: mass (kg), density, restitution, friction."""
    bodies = []
    info = {"mass": None, "density": None, "restitution": None, "static_friction": None, "dynamic_friction": None}
    for prim in Usd.PrimRange(root, Usd.TraverseInstanceProxies(Usd.PrimDefaultPredicate)):
        schemas = prim.GetAppliedSchemas()
        if "PhysicsRigidBodyAPI" in schemas:
            bodies.append(prim)
        if "PhysicsMassAPI" in schemas:
            value = prim.GetAttribute("physics:mass").Get()
            if value:
                info["mass"] = round((info["mass"] or 0.0) + float(value), 4)
        if "PhysicsMaterialAPI" in schemas and info["density"] is None:
            for key, attr in (("density", "physics:density"), ("restitution", "physics:restitution"),
                              ("static_friction", "physics:staticFriction"), ("dynamic_friction", "physics:dynamicFriction")):
                value = prim.GetAttribute(attr).Get()
                info[key] = round(float(value), 4) if value is not None else None
    return bodies, info


def mesh_points(root: Usd.Prim, limit: int = 30000) -> np.ndarray:
    """World-space mesh points under ``root``, thinned to ``limit`` but keeping the extremes."""
    cache = UsdGeom.XformCache()
    chunks = []
    for prim in Usd.PrimRange(root, Usd.TraverseInstanceProxies(Usd.PrimDefaultPredicate)):
        if not prim.IsA(UsdGeom.Mesh) or UsdGeom.Imageable(prim).ComputePurpose() in ("guide", "proxy"):
            continue
        points = UsdGeom.Mesh(prim).GetPointsAttr().Get()
        if not points:
            continue
        matrix = np.array(cache.GetLocalToWorldTransform(prim), dtype=np.float64)
        chunks.append(np.asarray(points, dtype=np.float64) @ matrix[:3, :3] + matrix[3, :3])
    if not chunks:
        return np.zeros((1, 3))
    points = np.concatenate(chunks)
    if len(points) <= limit:
        return points
    directions = np.array([[a, b, c] for a in (-1, 0, 1) for b in (-1, 0, 1) for c in (-1, 0, 1) if (a, b, c) != (0, 0, 0)], float)
    extremes = np.unique(np.argmax(points @ directions.T, axis=0))
    return np.concatenate([points[:: max(1, len(points) // limit)], points[extremes]])


def mesh_volume(root: Usd.Prim) -> float | None:
    cache = UsdGeom.XformCache()
    total, found = 0.0, False
    for prim in Usd.PrimRange(root, Usd.TraverseInstanceProxies(Usd.PrimDefaultPredicate)):
        if not prim.IsA(UsdGeom.Mesh):
            continue
        mesh = UsdGeom.Mesh(prim)
        points, counts, indices = (mesh.GetPointsAttr().Get(), mesh.GetFaceVertexCountsAttr().Get(),
                                   mesh.GetFaceVertexIndicesAttr().Get())
        if not points or not counts or not indices:
            continue
        matrix = np.array(cache.GetLocalToWorldTransform(prim), dtype=np.float64)
        world = np.asarray(points, dtype=np.float64) @ matrix[:3, :3] + matrix[3, :3]
        total += metrics.mesh_volume(world, metrics.fan_triangles(counts, indices))
        found = True
    return total if found else None


def quat_to_matrix(w: float, x: float, y: float, z: float) -> np.ndarray:
    return np.array([
        [1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
        [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
        [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)],
    ])


def quat_multiply(a, b):
    aw, ax, ay, az = a
    bw, bx, by, bz = b
    return (aw * bw - ax * bx - ay * by - az * bz, aw * bx + ax * bw + ay * bz - az * by,
            aw * by - ax * bz + ay * bw + az * bx, aw * bz + ax * by - ay * bx + az * bw)


class Body:
    """One rigid body read back from PhysX each step: its pose, speed, tilt and visual mesh bounds."""

    def __init__(self, placed: Placed, prim: Usd.Prim) -> None:
        self.placed = placed
        self.name = placed.name
        self.path = prim.GetPath().pathString
        world = UsdGeom.XformCache().GetLocalToWorldTransform(prim)
        expected = Gf.Transform(world).GetRotation().GetQuat()
        self.expected = (expected.GetReal(), *expected.GetImaginary())
        self.xyzw = True
        self.samples: list[metrics.Sample] = []
        self.boxes: list[tuple[np.ndarray, np.ndarray]] = []
        self._world0 = mesh_points(placed.prim)
        self._local = None
        self.world = self._world0

    def _read(self):
        state = omni.physx.get_physx_interface().get_rigidbody_transformation(self.path)
        p = np.array(state["position"], dtype=np.float64)
        r = tuple(state["rotation"])
        return p, ((r[3], r[0], r[1], r[2]) if self.xyzw else (r[0], r[1], r[2], r[3]))

    def start(self) -> None:
        r = tuple(omni.physx.get_physx_interface().get_rigidbody_transformation(self.path)["rotation"])
        self.xyzw = metrics.tilt_between((r[3], r[0], r[1], r[2]), self.expected) <= metrics.tilt_between(r, self.expected)
        p, q = self._read()
        self.p0, self.q0 = p, q
        self._local = (self._world0 - p) @ quat_to_matrix(*q)
        self._last = (0.0, p, q)
        self.record(0.0)

    def record(self, t: float) -> metrics.Sample:
        p, q = self._read()
        t_prev, p_prev, q_prev = self._last
        dt = max(1e-6, t - t_prev)
        speed = float(np.linalg.norm(p - p_prev) / dt) if t > 0 else 0.0
        self.velocity = (p - p_prev) / dt if t > 0 else np.zeros(3)
        spin = math.radians(metrics.tilt_between(q, q_prev)) / dt if t > 0 else 0.0
        self.world = (self._local @ quat_to_matrix(*q).T) + p
        self.boxes.append((self.world.min(axis=0), self.world.max(axis=0)))
        sample = metrics.Sample(t, float(self.world[:, 2].min()), *map(float, p), speed, spin, metrics.tilt_between(self.q0, q))
        self.samples.append(sample)
        self._last = (t, p, q)
        self.p, self.q = p, q
        return sample

    def top(self) -> tuple[float, float, float]:
        """Where to pin a label: above the highest point, at the last recorded pose."""
        return float(self.world[:, 0].mean()), float(self.world[:, 1].mean()), float(self.world[:, 2].max())

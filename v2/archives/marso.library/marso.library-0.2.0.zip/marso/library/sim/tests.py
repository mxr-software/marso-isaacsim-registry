"""The Sim Studio tests: scale, drop, friction, wind, collision and robot.

Each builds its set, saves it as an editable scene, records the shot (branded and/or clean),
measures what happened, and ends on a results card and the Marso outro. Runs inside the Sim
Studio runner's Isaac Sim.
"""

from __future__ import annotations

import math
import time
from pathlib import Path
from typing import Callable

import carb
import numpy as np
import omni.physx
import omni.usd
from isaacsim.core.simulation_manager import SimulationManager
from omni.physx.bindings._physx import ContactEventType
from PIL import Image
from pxr import Gf, PhysicsSchemaTools, PhysxSchema, Sdf, UsdGeom, UsdPhysics, UsdShade

from .. import usd_inspect
from ..core import sim_job
from ..core import sim_metrics as metrics
from . import film
from .windsock import WindSock
from .film import INK, INK2, PBR, SUCCESS, WARNING, appear
from .studio import (FLOOR_COLLIDER, FLOOR_NAME, Body, Placed, Studio, is_round, mesh_points, mesh_volume, physics_of,
                     quat_multiply, quat_to_matrix, world_box)

CARD_S = 4.0
OUTRO_S = 2.5
LABEL = (15, 600, False)
MONO = (13, 500, True)
DEGREE = "°"


def state_line(text_and_colour: tuple[str, tuple]) -> tuple:
    """A label's second line from a (text, colour) status."""
    text, colour = text_and_colour
    return (text, colour, *MONO)


class Context:
    def __init__(self, app, job: dict, usd_inspect, storage, emit: Callable[..., None]) -> None:
        self.job = job
        self.emit = emit
        self.out = Path(job["out_dir"])
        self.fps = int(job["fps"])
        self.sim_hz = int(job["sim_hz"])
        self.brand = film.Brand(Path(job["extension_root"]), int(job["width"]), int(job["height"]))
        self.studio = Studio(app, job, usd_inspect, storage)

    def options(self, key: str) -> dict:
        return self.job["options"].get(key, {})


class Shoot:
    """One test's recording: frames, results card, outro, thumbnail, and its entry for run.json."""

    def __init__(self, ctx: Context, key: str, camera_path: str, frames: int, views=None, open_ended: bool = False) -> None:
        """``frames`` is the shot's length; ``open_ended`` takes it as an estimate (for progress) and lets
        the shot run as long as it needs (its frames are kept and encoded at the end)."""
        self.ctx, self.key = ctx, key
        branding = ctx.job["branding"]
        self.branded = ctx.out / f"{key}.mp4" if branding in (sim_job.BOTH, sim_job.BRANDED) else None
        self.clean = ctx.out / f"{key}_clean.mp4" if branding in (sim_job.BOTH, sim_job.CLEAN) else None
        extra = (int(CARD_S * ctx.fps) + (int(OUTRO_S * ctx.fps) if ctx.job.get("outro") else 0)) if self.branded else 0
        self.planned = frames + extra
        self.recorder = film.Recorder(camera_path, ctx.job, self.branded, self.clean, branded_frames=self.planned,
                                      clean_frames=frames, backdrop=ctx.brand.backdrop, views=views, open_ended=open_ended)
        self.frame = 0
        ctx.brand._label_slots.clear()  # labels find fresh spots in each test
        self.thumb: Image.Image | None = None
        self.last_raw: Image.Image | None = None
        # Where the time goes (seconds): rendering, overlays, encoding; the rest is physics and setup.
        self.timing = {"render": 0.0, "brand": 0.0, "encode": 0.0}
        self.started = time.time()
        ctx.emit("test_start", test=key, frames=self.planned)

    def shot(self, dress: Callable[[Image.Image], Image.Image]) -> Image.Image:
        t0 = time.time()
        raw = self.recorder.grab()
        t1 = time.time()
        branded = dress(raw) if self.branded else None
        t2 = time.time()
        self.recorder.write(branded, raw if self.clean else None)
        t3 = time.time()
        self.timing["render"] += t1 - t0
        self.timing["brand"] += t2 - t1
        self.timing["encode"] += t3 - t2
        self.last_raw = raw
        self._tick()
        return raw

    def _tick(self) -> None:
        self.frame += 1
        if self.frame % 10 == 0 or self.frame == self.planned:
            self.ctx.emit("frame", test=self.key, frame=self.frame, frames=self.planned)

    def keep_thumb(self, raw: Image.Image) -> None:
        self.thumb = raw.copy()

    def finish(self, eyebrow: str, title: str, columns: list[str], rows: list, notes: list[str]) -> dict:
        brand, fps = self.ctx.brand, self.ctx.fps
        card_path = self.ctx.out / f"{self.key}_card.png"
        final = brand.card(self.last_raw, eyebrow, title, columns, rows, notes)
        final.convert("RGB").save(card_path)
        if self.branded:
            for i in range(int(CARD_S * fps)):
                alpha = appear(i / fps, 0.0, 0.45)
                self.recorder.write(final if alpha >= 1 else brand.card(self.last_raw, eyebrow, title, columns, rows, notes, alpha))
                self._tick()
            if self.ctx.job.get("outro"):
                for i in range(int(OUTRO_S * fps)):
                    self.recorder.write(brand.outro(i / fps))
                    self._tick()
        self.recorder.close()
        thumb_path = self.ctx.out / f"{self.key}_thumb.png"
        thumb = (self.thumb or self.last_raw).copy()
        thumb.thumbnail((640, 640))
        thumb.save(thumb_path)
        entry = {"key": self.key, "title": sim_job.spec(self.key).title, "card": card_path.name, "thumb": thumb_path.name}
        total = time.time() - self.started
        entry["timing_s"] = {**{k: round(v, 1) for k, v in self.timing.items()},
                             "physics_and_other": round(total - sum(self.timing.values()), 1), "total": round(total, 1)}
        if self.branded:
            entry["video"] = self.branded.name
        if self.clean:
            entry["clean"] = self.clean.name
        return entry


# --- helpers -------------------------------------------------------------------------------------


def start_physics(ctx: Context, hz: int | None = None) -> None:
    SimulationManager.invalidate_physics()
    SimulationManager.set_physics_dt(1.0 / (hz or ctx.sim_hz))
    started = time.time()
    SimulationManager.initialize_physics()
    carb.log_info(f"Marso Sim Studio: physics ready in {time.time() - started:.1f}s")


def step_physics() -> None:
    SimulationManager.step(update_fabric=SimulationManager.is_fabric_enabled())


def bodies_for(placed: list[Placed]) -> tuple[list[Body], list[Placed], dict[str, dict]]:
    """Rigid bodies to follow, the objects without one, and each object's physics.

    ``info["mass"]`` is the mass PhysX simulates: the wrapper layer clears an authored mass when the
    asset has a density, so it is density x collider volume (else the authored mass).
    """
    bodies, statics, authored = [], [], {}
    for item in placed:
        rigid, info = physics_of(item.prim)
        for prim in rigid:
            # Fast, thin objects must not tunnel through each other or the floor between steps (the
            # assets author CCD off); more position iterations resolve deep overlaps.
            settings = PhysxSchema.PhysxRigidBodyAPI.Apply(prim)
            settings.CreateEnableCCDAttr(True)
            settings.CreateEnableSpeculativeCCDAttr(True)
            settings.CreateSolverPositionIterationCountAttr(16)
        info["mass"] = mass_of(item, info)
        info["round"] = is_round(item.box)
        fit = metrics.roundness(mesh_points(item.prim)) if info["round"] else None
        info["bump_mm"], info["radius_m"] = (fit[1], fit[0]) if fit else (None, None)
        authored[item.name] = info
        if rigid:
            bodies.append(Body(item, rigid[0]))
        else:
            statics.append(item)
    return bodies, statics, authored


def num(value, unit: str = "", digits: int = 3) -> str:
    if value is None:
        return "-"
    text = f"{value:.{digits}g}" if abs(value) < 1000 else f"{value:.0f}"
    return f"{text}{unit}" if unit in (DEGREE, "%") else f"{text} {unit}".strip()


def mass_of(item: Placed, info: dict) -> float | None:
    """The mass PhysX simulates for an asset placed through its wrapper (see ``usd_inspect.physics_mass``)."""
    mass, _clear = usd_inspect.physics_mass_under(item.prim)
    return mass if mass is not None else info["mass"]


def screen_box(st: Studio, cam, lo, hi):
    """The on-screen rectangle (left, top, right, bottom) of a world box, or None when behind the camera."""
    spots = [st.project(cam, (x, y, z)) for x in (lo[0], hi[0]) for y in (lo[1], hi[1]) for z in (lo[2], hi[2])]
    spots = [s for s in spots if s is not None]
    if not spots:
        return None
    xs, ys = [s[0] for s in spots], [s[1] for s in spots]
    return min(xs), min(ys), max(xs), max(ys)


def obstacles_of(st: Studio, cam, bodies: list[Body], statics: list[Placed] = ()) -> list:
    """Screen rectangles of the objects in shot, for labels to keep off."""
    boxes = [b.boxes[-1] if b.boxes else (b.world.min(axis=0), b.world.max(axis=0)) for b in bodies]
    boxes += [(p.box.GetMin(), p.box.GetMax()) for p in statics]
    return [r for r in (screen_box(st, cam, lo, hi) for lo, hi in boxes) if r is not None]


def shape_notes(authored: dict[str, dict]) -> list[tuple[str, str]]:
    """Round objects that are not quite round, which is why they roll unevenly."""
    return [(name, note) for name, info in authored.items()
            if (note := metrics.roundness_note(info.get("bump_mm"), info.get("radius_m")))]


def grouped(notes: list[tuple[str, str]], total: int) -> list[str]:
    by_note: dict[str, list[str]] = {}
    for name, note in notes:
        by_note.setdefault(note, []).append(name)
    return [f"{f'All {total} objects' if len(names) == total and total > 1 else ', '.join(names)}: {note}"
            for note, names in by_note.items()]


def ends_for_round(placed_order: list[Placed]) -> list[Placed]:
    """Round (likely to roll) assets at the two ends of a row, so they roll into open floor."""
    round_ones = [p for p in placed_order if is_round(p.box)]
    others = [p for p in placed_order if p not in round_ones]
    left, right = round_ones[::2], round_ones[1::2]
    return right[::-1] + others + left


# --- scale ---------------------------------------------------------------------------------------


def scale_test(ctx: Context) -> dict:
    st, brand, fps = ctx.studio, ctx.brand, ctx.fps
    st.new_stage(fps)
    st.build_set()
    placed = st.row(sorted(ctx.job["assets"], key=lambda a: a["name"]), spacing=0.35)
    max_h = max(p.box.GetSize()[2] for p in placed)
    x_min = min(p.box.GetMin()[0] for p in placed)
    x_max = max(p.box.GetMax()[0] for p in placed)
    pole_h = max(0.3, math.ceil(max_h * 1.3 / 0.1) * 0.1)
    pole_x = x_max + max(0.12, (x_max - x_min) * 0.12)
    band, radius = st.pole(pole_x, pole_h)
    results = []
    for p in placed:
        _rigid, info = physics_of(p.prim)
        results.append((p, metrics.analyse_scale(p.name, tuple(p.box.GetSize()), mass_of(p, info), info["density"],
                                                 mesh_volume(p.prim))))
    scene = st.export("scale")

    cam = st.camera("/World/Studio/Camera", focal=50.0)
    centre = Gf.Vec3d((pole_x + x_min) / 2, 0, max_h * 0.42)
    distance = st.fit_distance(pole_x + radius - x_min, max(max_h, pole_h), 50.0, margin=1.45)
    elevation = math.radians(15)

    def eye(angle: float):
        return (centre[0] + distance * math.sin(angle) * math.cos(elevation),
                centre[1] - distance * math.cos(angle) * math.cos(elevation),
                centre[2] + distance * math.sin(elevation))

    st.look_at(cam, eye(0.0), centre)
    hold, orbit = int(2.5 * fps), int(float(ctx.options("scale").get("orbit_s", 9.0)) * fps)
    shoot = Shoot(ctx, "scale", "/World/Studio/Camera", hold + orbit)
    shoot.recorder.warm_up()
    step = 0.1 if pole_h <= 1.0 else 0.5
    marks = [round(step * k, 2) for k in range(1, int(pole_h / step + 1e-6) + 1)]
    for frame in range(hold + orbit):
        t = frame / fps
        u = max(0.0, (frame - hold) / orbit)
        st.look_at(cam, eye(2 * math.pi * (u - math.sin(2 * math.pi * u) / (2 * math.pi))), centre)

        def dress(raw: Image.Image) -> Image.Image:
            items = []
            for p, result in results:
                w, d, h = result.size_cm
                lines = [(p.name, INK, *LABEL), (f"{w:g} x {d:g} x {h:g} cm", INK2, *MONO)]
                if result.mass_kg is not None:
                    lines.append((f"{result.mass_kg:.3g} kg", PBR, *MONO))
                items.append((st.project(cam, (p.box.GetMidpoint()[0], p.box.GetMidpoint()[1], p.box.GetMax()[2])), lines))
            canvas = brand.canvas(raw)
            brand.labels(canvas, items, appear(t, 0.7, 0.5), obstacles_of(st, cam, [], [p for p, _ in results]))
            brand.ticks(canvas, [(st.project(cam, (pole_x + radius * 1.6, 0, m)), f"{int(round(m * 100))} cm") for m in marks],
                                appear(t, 0.9, 0.5))
            return brand.dress(canvas, "SCALE TEST", "Real-world size", t,
                               right=f"floor dots 10 cm  ·  pole bands {int(band * 100)} cm")

        raw = shoot.shot(dress)
        if frame == hold // 2:
            shoot.keep_thumb(raw)

    rows, notes = [], []
    for p, r in results:
        w, d, h = r.size_cm
        rows.append([(p.name, INK), (f"{w:g} x {d:g} x {h:g}", INK), (num(r.mass_kg, "kg"), PBR), (num(r.density, "kg/m³"), INK2),
                     (num(r.mesh_volume_l, "L"), INK2)])
        notes.extend((p.name, n) for n in r.notes)
    entry = shoot.finish("SCALE TEST", "Size and mass", ["Object", "Size cm (W x D x H)", "Mass", "Density", "Volume"],
                         rows, grouped(notes, len(results)))
    entry.update(scene=scene, results=[r.to_dict() for _, r in results])
    return entry


# --- drop ----------------------------------------------------------------------------------------


def drop_test(ctx: Context) -> dict:
    st, brand, fps = ctx.studio, ctx.brand, ctx.fps
    opts = ctx.options("drop")
    drop_h = float(opts.get("drop_height", 1.0))
    slowmo, duration = float(opts.get("slowmo", 2.0)), float(opts.get("duration_s", 5.0))
    st.new_stage(fps)
    st.build_set()
    st.physics_scene()
    placed = st.rows(sorted(ctx.job["assets"], key=lambda a: a["name"]), spacing=0.8, arrange=ends_for_round)
    for p in placed:
        t = p.prim.GetAttribute("xformOp:translate").Get()
        st.move(p.prim, t[0], t[1], t[2] + drop_h)
    placed = [Placed(p.asset, p.prim, world_box(p.prim)) for p in placed]
    bodies, statics, authored = bodies_for(placed)
    scene = st.export("drop", end_seconds=duration + 1)

    # The camera frames the objects, not the whole fall: it starts on them hanging at the drop height
    # and eases down with them as they fall, so small things (a pistol, a grenade) fill the frame
    # as well as big ones do. It is framed for their spread and size, with room above for labels.
    span = max(p.box.GetMax()[0] for p in placed) - min(p.box.GetMin()[0] for p in placed)
    depth = max(p.box.GetMax()[1] for p in placed) - min(p.box.GetMin()[1] for p in placed)
    tallest = max(p.box.GetSize()[2] for p in placed)
    distance = st.fit_distance(span + 0.25, max(3.2 * tallest, 0.45) + 0.3 * depth, 50.0, margin=1.3)
    floor_aim = 0.55 * tallest + 0.08 * depth
    yaw, elevation = math.radians(16), math.radians(13)
    cam = st.camera("/World/Studio/Camera", focal=50.0)
    aim = {"z": None}

    def place_camera(push: float) -> None:
        middle = float(np.mean([(b.boxes[-1][0][2] + b.boxes[-1][1][2]) / 2 if b.boxes else b.world[:, 2].mean()
                                for b in bodies])) if bodies else floor_aim
        wanted = max(floor_aim, middle)
        aim["z"] = wanted if aim["z"] is None else aim["z"] + (wanted - aim["z"]) * 0.22  # follow, smoothly
        d = distance * (1.0 - 0.06 * push)
        st.look_at(cam, (d * math.sin(yaw), -d * math.cos(yaw), aim["z"] + d * math.sin(elevation)), (0.0, 0.0, aim["z"]))

    place_camera(0.0)
    start_physics(ctx)
    for body in bodies:
        body.start()
    capture_hz = fps * slowmo
    steps = max(1, int(round(ctx.sim_hz / capture_hz)))
    hold, frames = int(1.0 * fps), int(duration * capture_hz)
    shoot = Shoot(ctx, "drop", "/World/Studio/Camera", hold + frames)
    shoot.recorder.warm_up()
    speed_note = f"{1 / slowmo:g}x speed" if slowmo != 1 else "real time"
    subtitle = ""
    title = f"Dropped from {drop_h:g} m"
    clock = {"t": 0.0, "video": 0.0}

    def dress(raw: Image.Image) -> Image.Image:
        items = []
        for body in bodies:
            s = body.samples[-1]
            items.append((st.project(cam, body.top()), [(body.name, INK, *LABEL),
                          (f"h {max(0.0, s.bottom_z):.2f} m  v {s.speed:.2f} m/s", INK2, *MONO)]))
        for item in statics:
            items.append((st.project(cam, (item.box.GetMidpoint()[0], item.box.GetMidpoint()[1], item.box.GetMax()[2])),
                          [(item.name, INK, *LABEL), ("no rigid body", WARNING, *MONO)]))
        canvas = brand.canvas(raw)
        brand.labels(canvas, items, appear(clock["video"], 0.5, 0.5), obstacles_of(st, cam, bodies, statics))
        return brand.dress(canvas, "DROP TEST", title, clock["video"], right=f"t {clock['t']:4.2f} s  ·  {speed_note}", subtitle=subtitle)

    for frame in range(hold):
        clock["video"] = frame / fps
        shoot.shot(dress)
    for frame in range(frames):
        for _ in range(steps):
            step_physics()
            clock["t"] += 1.0 / ctx.sim_hz
            for body in bodies:
                body.record(clock["t"])
        clock["video"] = (hold + frame) / fps
        place_camera(frame / frames)
        raw = shoot.shot(dress)
        if frame == int(frames * 0.12):
            shoot.keep_thumb(raw)

    touched = {b.name: [] for b in bodies}
    for i, a in enumerate(bodies):
        for b in bodies[i + 1:]:
            if any(metrics.boxes_touch(x, y) for x, y in zip(a.boxes, b.boxes)):
                touched[a.name].append(b.name)
                touched[b.name].append(a.name)
    results = [metrics.analyse_drop(b.name, b.samples, drop_h, authored[b.name], touched[b.name]) for b in bodies]
    results += [metrics.analyse_drop(p.name, [], drop_h, authored[p.name]) for p in statics]
    rows, notes = [], []
    for r in results:
        settle = ("still moving" if r.still_moving else num(r.settle_time_s, "s")) + (f" ({r.twitches} twitches)" if r.twitches else "")
        rows.append([
            (r.name, INK), (num(r.impact_speed_ms, "m/s"), INK2), ("-" if r.static else str(r.bounces), INK2),
            (num(r.rebound_m * 100 if r.rebound_m else 0.0, "cm"), INK2), (num(r.restitution_authored), INK2),
            (num(r.restitution_est), PBR), (settle, WARNING if r.still_moving or r.twitches else INK2),
            (f"{r.rest_gap_mm:+.1f} mm {r.fit}" if r.rest_gap_mm is not None else "-", SUCCESS if r.fit == "flush" else WARNING),
            (num(r.slide_m * 100, "cm"), INK2), (num(r.final_tilt_deg, "°"), INK2),
        ])
        notes.extend((r.name, n) for n in r.notes)
    notes += shape_notes(authored)
    entry = shoot.finish("DROP TEST", title, ["Object", "Impact", "Bounces", "Rebound", "e authored", "e measured", "Settles in",
                         "Resting gap", "Slide", "Tilt"], rows, grouped(notes, len(results)))
    entry.update(scene=scene, results=[r.to_dict() for r in results])
    return entry


# --- friction ------------------------------------------------------------------------------------


def friction_test(ctx: Context) -> dict:
    st, brand, fps = ctx.studio, ctx.brand, ctx.fps
    opts = ctx.options("friction")
    max_angle, rate = float(opts.get("max_angle", 45.0)), float(opts.get("tilt_rate", 4.0))
    stage = st.new_stage(fps)
    st.build_set()
    st.physics_scene()
    placed = st.row(sorted(ctx.job["assets"], key=lambda a: a["name"]), spacing=0.6)
    x_min = min(p.box.GetMin()[0] for p in placed)
    x_max = max(p.box.GetMax()[0] for p in placed)
    # A table sized to what is on it, so small objects (knives, pistols) are not lost on a big one.
    biggest = max(max(p.box.GetSize()[0], p.box.GetSize()[1]) for p in placed)
    depth = min(1.1, max(0.55, 3.0 * biggest + 0.3))
    width, thick, top_z = (x_max - x_min) + max(0.3, 1.5 * biggest), 0.04, 0.04
    front = -0.6
    pivot = np.array([0.0, front, top_z])
    for p in placed:
        mid = p.box.GetMidpoint()
        t = p.prim.GetAttribute("xformOp:translate").Get()
        st.move(p.prim, t[0], t[1] - mid[1] + front + 0.7 * depth, t[2] + top_z + 0.001)
    placed = [Placed(p.asset, p.prim, world_box(p.prim)) for p in placed]

    table = UsdGeom.Xform.Define(stage, "/World/Studio/Table")
    table.AddTranslateOp().Set(Gf.Vec3d(*pivot))
    tilt = table.AddRotateXOp(UsdGeom.XformOp.PrecisionDouble)
    tilt.Set(0.0)
    slab = UsdGeom.Mesh.Define(stage, "/World/Studio/Table/Top")
    _box_mesh(slab, width, depth, thick, (0.0, depth / 2, -thick / 2))
    UsdShade.MaterialBindingAPI.Apply(slab.GetPrim()).Bind(st.grid_material("/World/Studio/Looks/Table", tint=(1.35, 1.35, 1.45), roughness=0.5))
    UsdPhysics.CollisionAPI.Apply(slab.GetPrim())
    UsdPhysics.MeshCollisionAPI.Apply(slab.GetPrim()).CreateApproximationAttr("boundingCube")
    UsdShade.MaterialBindingAPI(slab.GetPrim()).Bind(st.pass_through_material("/World/Studio/Looks/TablePhysics"),
                                                      UsdShade.Tokens.weakerThanDescendants, "physics")
    lip = UsdGeom.Mesh.Define(stage, "/World/Studio/Table/Lip")
    _box_mesh(lip, width, 0.012, 0.006, (0.0, 0.006, 0.003))
    glow = UsdShade.Material.Define(stage, "/World/Studio/Looks/Lip")
    shader = UsdShade.Shader.Define(stage, "/World/Studio/Looks/Lip/Surface")
    shader.CreateIdAttr("UsdPreviewSurface")
    shader.CreateInput("diffuseColor", Sdf.ValueTypeNames.Color3f).Set(Gf.Vec3f(0.42, 0.3, 0.75))
    shader.CreateInput("emissiveColor", Sdf.ValueTypeNames.Color3f).Set(Gf.Vec3f(0.55, 0.36, 1.0))
    glow.CreateSurfaceOutput().ConnectToSource(shader.ConnectableAPI(), "surface")
    UsdShade.MaterialBindingAPI.Apply(lip.GetPrim()).Bind(glow)
    # The table is a heavy body on a hinge along its front edge, turned by a velocity motor. Moving a
    # kinematic table by per-frame targets jerks it (a frame's rotation in one step, then still),
    # which throws objects off; per-step targets are smooth but slow to push through USD.
    UsdPhysics.RigidBodyAPI.Apply(table.GetPrim())
    UsdPhysics.MassAPI.Apply(table.GetPrim()).CreateMassAttr(400.0)
    table_physx = PhysxSchema.PhysxRigidBodyAPI.Apply(table.GetPrim())
    table_physx.CreateDisableGravityAttr(True)
    table_physx.CreateSleepThresholdAttr(0.0)
    hinge = UsdPhysics.RevoluteJoint.Define(stage, "/World/Studio/TableHinge")
    hinge.CreateAxisAttr(UsdPhysics.Tokens.x)
    hinge.CreateBody1Rel().SetTargets([table.GetPath()])  # body0 empty: hinged to the world
    hinge.CreateLocalPos0Attr(Gf.Vec3f(*map(float, pivot)))
    hinge.CreateLocalRot0Attr(Gf.Quatf(1.0))
    hinge.CreateLocalPos1Attr(Gf.Vec3f(0.0))
    hinge.CreateLocalRot1Attr(Gf.Quatf(1.0))
    hinge.CreateLowerLimitAttr(-1.0)
    hinge.CreateUpperLimitAttr(max_angle)
    motor = UsdPhysics.DriveAPI.Apply(hinge.GetPrim(), "angular")
    motor.CreateTypeAttr("force")
    motor.CreateStiffnessAttr(0.0)
    motor.CreateDampingAttr(1e9)
    speed = motor.CreateTargetVelocityAttr(rate)  # degrees per second

    hold_s, ramp_s, end_s = 1.0, max_angle / rate, 2.5
    bodies, statics, authored = bodies_for(placed)
    # The saved scene tilts by itself on Play; here the motor waits for the objects to settle first.
    scene = st.export("friction", end_seconds=hold_s + ramp_s + end_s)
    speed.Set(0.0)

    cam = st.camera("/World/Studio/Camera", focal=45.0)
    max_h = max(p.box.GetSize()[2] for p in placed)
    rise = depth * math.sin(math.radians(max_angle))
    centre = Gf.Vec3d(0, front + depth * 0.42, (rise + max_h) * 0.38)
    distance = st.fit_distance(width + 0.12, rise + max_h + 0.2, 45.0, margin=1.12)
    yaw, elevation = math.radians(-28), math.radians(22)
    st.look_at(cam, (centre[0] + distance * math.sin(yaw) * math.cos(elevation), centre[1] - distance * math.cos(yaw) * math.cos(elevation),
                     centre[2] + distance * math.sin(elevation)), centre)
    start_physics(ctx)
    for body in bodies:
        body.start()

    state = {b.name: {"onset": None, "onset_t": None, "behaviour": None} for b in bodies}
    steps = max(1, int(round(ctx.sim_hz / fps)))
    frames = int((hold_s + ramp_s + end_s) * fps)
    shoot = Shoot(ctx, "friction", "/World/Studio/Camera", frames)
    shoot.recorder.warm_up()
    clock = {"t": 0.0, "angle": 0.0, "motor": "waiting"}
    xyzw = bodies[0].xyzw if bodies else True

    def table_angle() -> float:
        r = omni.physx.get_physx_interface().get_rigidbody_transformation(table.GetPath().pathString)["rotation"]
        qx, qw = (r[0], r[3]) if xyzw else (r[1], r[0])
        return max(0.0, math.degrees(2.0 * math.atan2(qx, qw)))

    def ride(body: Body, angle: float):
        r = math.radians(angle)
        rot = np.array([[1, 0, 0], [0, math.cos(r), -math.sin(r)], [0, math.sin(r), math.cos(r)]])
        q_table = (math.cos(r / 2), math.sin(r / 2), 0.0, 0.0)
        return pivot + rot @ (body.p0 - pivot), quat_multiply(q_table, body.q0)

    def status(body: Body) -> tuple[str, tuple]:
        s = state[body.name]
        if s["onset"] is None:
            return "holding", INK2
        verb = s["behaviour"] or "moving"
        colour = {"slides": PBR, "tips": WARNING, "rolls": INK}.get(verb, INK)
        return f"{verb} at {s['onset']:.1f}°", colour

    def dress(raw: Image.Image) -> Image.Image:
        t, angle = clock["t"], clock["angle"]
        items = [(st.project(cam, b.top()), [(b.name, INK, *LABEL), state_line(status(b))]) for b in bodies]
        canvas = brand.canvas(raw)
        brand.labels(canvas, items, appear(t, 0.5, 0.5), obstacles_of(st, cam, bodies, statics))
        brand.gauge(canvas, "TABLE ANGLE", f"{angle:.1f}°", angle / max_angle, f"slope {math.tan(math.radians(angle)):.2f}",
                            appear(t, 0.4, 0.5))
        return brand.dress(canvas, "FRICTION TEST", "Tilt until it slips", t, subtitle="Friction = the slope (tan of the angle) where an object starts to slide")

    for frame in range(frames):
        if clock["motor"] == "waiting" and clock["t"] >= hold_s:
            speed.Set(rate)
            clock["motor"] = "tilting"
            # Measure from where each object has settled, not where it was put: a shape that rocks
            # or rolls a little onto its resting face is not "letting go" at 0 degrees.
            for body in bodies:
                body.p0, body.q0 = body.p.copy(), body.q
                state[body.name] = {"onset": None, "onset_t": None, "behaviour": None}
        elif clock["motor"] == "tilting" and clock["angle"] >= max_angle - 0.05:
            speed.Set(0.0)
            clock["motor"] = "stopped"
        for _ in range(steps):
            clock["t"] += 1.0 / ctx.sim_hz
            step_physics()
            angle = clock["angle"] = table_angle()
            for body in bodies:
                body.record(clock["t"])
                s = state[body.name]
                ride_p, ride_q = ride(body, angle)
                if clock["motor"] != "waiting" and s["onset"] is None and np.linalg.norm(body.p - ride_p) > 0.01:
                    s["onset"], s["onset_t"] = angle, clock["t"]
                if s["onset"] is not None and s["behaviour"] is None and clock["t"] - s["onset_t"] >= 0.3:
                    turned = metrics.tilt_between(body.q, ride_q)
                    s["behaviour"] = (metrics.BEHAVIOUR_ROLLS if authored[body.name]["round"]
                                      else metrics.BEHAVIOUR_TIPS if turned > 12.0 else metrics.BEHAVIOUR_SLIDES)
        raw = shoot.shot(dress)
        if frame == int(frames * 0.62):
            shoot.keep_thumb(raw)

    results = []
    for body in bodies:
        s = state[body.name]
        behaviour = s["behaviour"] or (metrics.BEHAVIOUR_SLIDES if s["onset"] is not None else metrics.BEHAVIOUR_HOLDS)
        results.append(metrics.analyse_friction(body.name, behaviour, s["onset"], authored[body.name], max_angle))
    rows, notes = [], []
    for r in results:
        predicted = num(r.predicted_dynamic_deg) + "-" + num(r.predicted_static_deg, DEGREE)
        rows.append([(r.name, INK), (r.behaviour, PBR if r.behaviour == "slides" else WARNING if r.behaviour == "tips" else INK2),
                     (num(r.onset_deg, "°"), INK), (num(r.mu_from_angle), PBR), (num(r.static_authored), INK2),
                     (num(r.dynamic_authored), INK2), (predicted, INK2)])
        notes.extend((r.name, n) for n in r.notes)
    notes += [(p.name, "No rigid body: it does not move.") for p in statics]
    notes += shape_notes(authored)
    entry = shoot.finish("FRICTION TEST", "Where each object lets go", ["Object", "Behaviour", "Lets go at", "Friction there",
                         "Static", "Dynamic", "Predicted"], rows, grouped(notes, len(results) + len(statics)))
    entry.update(scene=scene, results=[r.to_dict() for r in results])
    return entry


def _box_mesh(mesh: UsdGeom.Mesh, sx: float, sy: float, sz: float, centre) -> None:
    cx, cy, cz = centre
    xs, ys, zs = (cx - sx / 2, cx + sx / 2), (cy - sy / 2, cy + sy / 2), (cz - sz / 2, cz + sz / 2)
    points = [Gf.Vec3f(x, y, z) for x in xs for y in ys for z in zs]
    mesh.CreatePointsAttr(points)
    mesh.CreateFaceVertexCountsAttr([4] * 6)
    mesh.CreateFaceVertexIndicesAttr([0, 1, 3, 2, 4, 6, 7, 5, 0, 4, 5, 1, 2, 3, 7, 6, 0, 2, 6, 4, 1, 5, 7, 3])
    st = UsdGeom.PrimvarsAPI(mesh).CreatePrimvar("st", Sdf.ValueTypeNames.TexCoord2fArray, UsdGeom.Tokens.vertex)
    st.Set([Gf.Vec2f(p[0], p[1]) for p in points])


# --- wind ----------------------------------------------------------------------------------------


def wind_test(ctx: Context) -> dict:
    st, brand, fps = ctx.studio, ctx.brand, ctx.fps
    opts = ctx.options("wind")
    max_wind, ramp_s = float(opts.get("max_wind", 30.0)), float(opts.get("ramp_s", 10.0))
    st.new_stage(fps)
    st.build_set()
    st.physics_scene()
    # One row across the frame; the wind blows along +Y, away from the camera, so each object blows
    # straight off into the distance and none can blow into another.
    placed = st.row(ctx.job["assets"], axis=0, spacing=1.2,
                    arrange=lambda ps: sorted(ps, key=lambda p: p.box.GetSize()[2]))
    bodies, statics, authored = bodies_for(placed)

    x_min = min(p.box.GetMin()[0] for p in placed)
    x_max = max(p.box.GetMax()[0] for p in placed)
    max_h = max(p.box.GetSize()[2] for p in placed)
    # The wind sock stands in the foreground at the near end of the row, big enough to read at a glance.
    sock_h = max(0.6, 2.0 * max_h, 0.16 * (x_max - x_min))
    sock_x, sock_y = x_min - 0.3 - 0.3 * sock_h, -0.45 - 0.3 * sock_h
    sock = WindSock(st.stage, "/World/Studio/WindSock", (sock_x, sock_y, 0.0), sock_h, heading_deg=90.0)
    scene = st.export("wind")
    left, right, top = sock_x - 0.12, x_max + 0.3, max(max_h, sock_h)
    # A three-quarter view down the wind: from in front and to the left, looking a little to the right,
    # framed on the objects, the sock at full stretch and a metre of floor beyond for things to blow into.
    yaw, elevation = math.radians(42), math.radians(18)  # side-on enough that the sock is not foreshortened
    centre = Gf.Vec3d((left + right) / 2, 0.45, top * 0.35)
    cam = st.camera("/World/Studio/Camera", focal=40.0)
    keep = [(x, y, z) for p in placed for x in (p.box.GetMin()[0], p.box.GetMax()[0])
            for y in (p.box.GetMin()[1], p.box.GetMax()[1]) for z in (p.box.GetMin()[2], p.box.GetMax()[2])]
    keep += [(sock_x, sock_y, 0.0), (sock_x, sock_y, sock_h * 1.1), (sock_x, sock_y + 0.85 * sock_h, sock_h),
             (left, 1.2, 0.0), (right, 1.2, 0.0)]
    st.fit_aim(cam, centre, yaw, elevation, keep)
    rng = np.random.default_rng(11)
    lines = [(rng.uniform(left - 0.5, right + 0.5), rng.uniform(0.03, top * 1.15), rng.uniform(0, 1), rng.uniform(0.7, 1.3))
             for _ in range(90)]
    start_physics(ctx)
    for body in bodies:
        body.start()
    stage_id = omni.usd.get_context().get_stage_id()
    simulation = omni.physx.get_physx_simulation_interface()
    ids = {b.name: PhysicsSchemaTools.sdfPathToInt(b.path) for b in bodies}
    hold_s, end_s = 1.0, 2.5

    def wind_at(t: float) -> float:
        return max_wind * min(1.0, max(0.0, (t - hold_s) / ramp_s)) ** 1.15

    state = {b.name: {"moves": None, "tips": None, "area": 0.0} for b in bodies}
    steps = max(1, int(round(ctx.sim_hz / fps)))
    frames = int((hold_s + ramp_s + end_s) * fps)
    shoot = Shoot(ctx, "wind", "/World/Studio/Camera", frames)
    shoot.recorder.warm_up()
    clock = {"t": 0.0}

    def status(body: Body) -> tuple[str, tuple]:
        s = state[body.name]
        if s["tips"] is not None:
            return f"blown over at {s['tips']:.1f} m/s", WARNING
        if s["moves"] is not None:
            verb = "rolling" if authored[body.name]["round"] else "moving"
            return f"{verb} since {s['moves']:.1f} m/s", PBR
        return "holding", INK2

    def dress(raw: Image.Image) -> Image.Image:
        t, wind = clock["t"], wind_at(clock["t"])
        force, label = metrics.beaufort(wind)
        canvas = brand.canvas(raw)
        strength = wind / max_wind if max_wind else 0.0
        segments = []
        for x, z, phase, pace in lines[:int(len(lines) * min(1.0, 0.25 + strength))]:
            travel = (phase + t * pace * (0.12 + 0.5 * strength)) % 1.0
            y = -1.5 + travel * 9.0
            a, b = st.project(cam, (x, y, z)), st.project(cam, (x, y + 0.25 + 0.9 * strength, z))
            if a is not None and b is not None:
                segments.append((a, b, math.sin(math.pi * travel)))
        brand.wind_lines(canvas, segments, strength)
        items = [(st.project(cam, b.top()), [(b.name, INK, *LABEL), state_line(status(b))]) for b in bodies]
        brand.labels(canvas, items, appear(t, 0.5, 0.5), obstacles_of(st, cam, bodies, statics))
        brand.gauge(canvas, "WIND", f"{wind:.1f} m/s", wind / max_wind if max_wind else 0, f"Beaufort {force}  ·  {label}",
                            appear(t, 0.4, 0.5))
        return brand.dress(canvas, "WIND TEST", "Rising wind", t, subtitle="Drag, lift on flat objects, and gusts")

    for frame in range(frames):
        for _ in range(steps):
            wind = wind_at(clock["t"])
            for body in bodies:  # the wind blows along +Y
                pts = body.world
                x0, x1 = pts[:, 0].min(), pts[:, 0].max()
                y0, y1 = pts[:, 1].min(), pts[:, 1].max()
                z0, z1 = pts[:, 2].min(), pts[:, 2].max()
                area = (x1 - x0) * (z1 - z0) * metrics.FRONTAL_FILL
                state[body.name]["area"] = state[body.name]["area"] or area
                relative = wind * metrics.gust(clock["t"], float((y0 + y1) / 2)) - float(body.velocity[1])
                force = metrics.drag_force(area, relative)
                if abs(force) > 1e-6:
                    centre_p = carb.Float3(float((x0 + x1) / 2), float(pts[:, 1].mean()), float((z0 + z1) / 2))
                    simulation.apply_force_at_pos(stage_id, ids[body.name], carb.Float3(0.0, float(force), 0.0), centre_p, "Force")
                footprint = max((x1 - x0) * (y1 - y0), 1e-6)
                lift = metrics.lift_force(footprint * metrics.FRONTAL_FILL, relative, (z1 - z0) / math.sqrt(footprint))
                if lift > 1e-6:  # flat things lift at the upwind edge first, which flips them downwind
                    edge = carb.Float3(float((x0 + x1) / 2), float(y0 + 0.25 * (y1 - y0)), float(z1))
                    simulation.apply_force_at_pos(stage_id, ids[body.name], carb.Float3(0.0, 0.0, float(lift)), edge, "Force")
            step_physics()
            clock["t"] += 1.0 / ctx.sim_hz
            for body in bodies:
                body.record(clock["t"])
                s = state[body.name]
                if s["moves"] is None and np.linalg.norm(body.p - body.p0) > 0.01:
                    s["moves"] = wind
                if s["tips"] is None and not authored[body.name]["round"] and body.samples[-1].tilt_deg > 45.0:
                    s["tips"] = wind
        sock.pose(wind_at(clock["t"]), clock["t"])
        raw = shoot.shot(dress)
        if frame == int(frames * 0.75):
            shoot.keep_thumb(raw)

    results = []
    for body in bodies:
        s = state[body.name]
        travelled = float(np.hypot(*(body.p - body.p0)[:2]))
        results.append(metrics.analyse_wind(body.name, s["moves"], s["tips"], travelled, s["area"], authored[body.name]["mass"], max_wind,
                                            rolls=authored[body.name]["round"]))
    rows, notes = [], []
    for r in results:
        rows.append([(r.name, INK), (num(r.moves_at_ms, "m/s"), PBR), (num(r.tips_at_ms, "m/s"), WARNING if r.tips_at_ms else INK2),
                     (num(r.travelled_m * 100, "cm"), INK2), (num(r.frontal_area_m2 * 1e4, "cm²"), INK2), (num(r.mass_kg, "kg"), INK2)])
        notes.extend((r.name, n) for n in r.notes)
    notes = grouped(notes + shape_notes(authored), len(results))
    notes.append(f"Wind is drag on each object's frontal area (Cd {metrics.DRAG_COEFFICIENT:g}, air {metrics.AIR_DENSITY:g} kg/m³), "
                 f"lift on flat ones and gusts of about ±{metrics.GUST_INTENSITY * 100:.0f}%, not an airflow simulation.")

    entry = shoot.finish("WIND TEST", f"Rising wind to {max_wind:g} m/s", ["Object", "Moves at", "Blown over at", "Travelled",
                         "Frontal area", "Mass"], rows, notes)
    entry.update(scene=scene, results=[r.to_dict() for r in results])
    return entry


# --- collision -----------------------------------------------------------------------------------


def collision_test(ctx: Context) -> dict:
    st, brand, fps = ctx.studio, ctx.brand, ctx.fps
    opts = ctx.options("collision")
    slowmo, duration = float(opts.get("slowmo", 2.0)), float(opts.get("duration_s", 5.0))
    st.new_stage(fps)
    st.build_set()
    hz = ctx.sim_hz * 2  # objects hitting each other fast: half-size steps so nothing passes through
    st.physics_scene(hz)
    placed = st.row(ctx.job["assets"], spacing=0.5)
    placed.sort(key=lambda p: p.box.GetSize()[0] * p.box.GetSize()[1], reverse=True)
    base = placed[0]
    bmid, bsize = base.box.GetMidpoint(), base.box.GetSize()
    t = base.prim.GetAttribute("xformOp:translate").Get()
    st.move(base.prim, t[0] - bmid[0], t[1] - bmid[1], t[2])
    base_top = bsize[2]
    offsets = [(0.12, 0.05), (-0.18, -0.08), (0.04, 0.16), (-0.06, -0.18), (0.2, -0.12), (-0.22, 0.14)]
    height = base_top + 0.25
    for index, p in enumerate(placed[1:]):
        mid, size = p.box.GetMidpoint(), p.box.GetSize()
        ox, oy = offsets[index % len(offsets)]
        t = p.prim.GetAttribute("xformOp:translate").Get()
        st.move(p.prim, t[0] - mid[0] + ox * bsize[0], t[1] - mid[1] + oy * bsize[1], t[2] + height)
        height += size[2] + 0.3
    placed = [Placed(p.asset, p.prim, world_box(p.prim)) for p in placed]
    bodies, statics, authored = bodies_for(placed)
    for body in bodies:
        PhysxSchema.PhysxContactReportAPI.Apply(omni.usd.get_context().get_stage().GetPrimAtPath(body.path)).CreateThresholdAttr(0.0)
    scene = st.export("collision", end_seconds=duration + 1)

    names = {body.path: body.name for body in bodies}
    names[FLOOR_COLLIDER] = FLOOR_NAME
    top = max(p.box.GetMax()[2] for p in placed)
    centre = Gf.Vec3d(0, 0, top * 0.46)
    distance = st.fit_distance(max(1.0, bsize[0] * 2.4), top + 0.3, 50.0, margin=1.25)
    yaw, elevation = math.radians(24), math.radians(16)
    cam = st.camera("/World/Studio/Camera", focal=50.0)
    st.look_at(cam, (distance * math.sin(yaw), -distance * math.cos(yaw), centre[2] + distance * math.sin(elevation)), centre)
    start_physics(ctx, hz)
    for body in bodies:
        body.start()
    simulation = omni.physx.get_physx_simulation_interface()
    log = metrics.ContactLog()
    sparks: list[tuple[float, tuple[float, float, float]]] = []
    touching: dict[str, set[str]] = {b.name: set() for b in bodies}
    capture_hz = fps * slowmo
    steps = max(1, int(round(hz / capture_hz)))
    hold, frames = int(0.8 * fps), int(duration * capture_hz)
    shoot = Shoot(ctx, "collision", "/World/Studio/Camera", hold + frames)
    shoot.recorder.warm_up()
    clock = {"t": 0.0, "video": 0.0, "step": 0}

    by_name = {b.name: b for b in bodies}

    def centre_z(body: Body) -> float:
        lo, hi = body.boxes[-1] if body.boxes else (body.world.min(axis=0), body.world.max(axis=0))
        return float(lo[2] + hi[2]) / 2

    def supports(body: Body) -> list[str]:
        """What it rests on: the floor, or touching objects whose middle is lower than its own."""
        below = [o for o in touching[body.name] if o == FLOOR_NAME or (o in by_name and centre_z(by_name[o]) < centre_z(body))]
        return sorted(below, key=lambda o: (o != FLOOR_NAME, o))

    def status(body: Body) -> tuple[str, tuple]:
        under = supports(body)
        others = [o for o in under if o != FLOOR_NAME]
        if others:
            return f"on {', '.join(others)}", PBR
        if under:
            return "on the floor", INK2
        return ("touching " + ", ".join(sorted(touching[body.name])), INK2) if touching[body.name] else ("falling", INK2)

    def dress(raw: Image.Image) -> Image.Image:
        items = [(st.project(cam, b.top()), [(b.name, INK, *LABEL), state_line(status(b))]) for b in bodies]
        canvas = brand.canvas(raw)
        recent = []
        for when, point in sparks:
            age = (clock["t"] - when) / 0.35
            spot = st.project(cam, point)
            if age <= 1.0 and spot is not None:
                recent.append((spot[0], spot[1], age))
        brand.dots(canvas, recent)  # under the labels, so they never hide a word
        brand.labels(canvas, items, appear(clock["video"], 0.5, 0.5), obstacles_of(st, cam, bodies, statics))
        return brand.dress(canvas, "COLLISION TEST", "Every contact measured", clock["video"],
                           right=f"t {clock['t']:4.2f} s  ·  {1 / slowmo:g}x speed", subtitle="Violet dots mark object-to-object contacts")

    for frame in range(hold):
        clock["video"] = frame / fps
        shoot.shot(dress)
    for frame in range(frames):
        for _ in range(steps):
            step_physics()
            clock["t"] += 1.0 / hz
            clock["step"] += 1
            headers, data = simulation.get_contact_report()[:2]
            for header in headers:
                a = names.get(str(PhysicsSchemaTools.intToSdfPath(header.actor0)), str(PhysicsSchemaTools.intToSdfPath(header.actor0)))
                b = names.get(str(PhysicsSchemaTools.intToSdfPath(header.actor1)), str(PhysicsSchemaTools.intToSdfPath(header.actor1)))
                if header.type == ContactEventType.CONTACT_LOST:
                    for x, y in ((a, b), (b, a)):
                        if x in touching:
                            touching[x].discard(y)
                    continue
                chunk = [data[i] for i in range(header.contact_data_offset, header.contact_data_offset + header.num_contact_data)]
                if not chunk:
                    continue
                impulse = sum(math.sqrt(c.impulse[0] ** 2 + c.impulse[1] ** 2 + c.impulse[2] ** 2) for c in chunk)
                log.add(clock["step"], clock["t"], a, b, impulse, min(c.separation for c in chunk))
                for x, y in ((a, b), (b, a)):
                    if x in touching:
                        touching[x].add(y)
                if FLOOR_NAME not in (a, b) and impulse > 1e-4:
                    sparks.append((clock["t"], tuple(chunk[0].position)))
            for body in bodies:
                body.record(clock["t"])
        sparks[:] = [s for s in sparks if clock["t"] - s[0] <= 0.35]
        clock["video"] = (hold + frame) / fps
        raw = shoot.shot(dress)
        if frame == int(frames * 0.35):
            shoot.keep_thumb(raw)

    pairs = sorted(log.pairs.values(), key=lambda p: p.first_contact_s)
    rows = [[(f"{p.a} + {p.b}", INK), (num(p.first_contact_s, "s"), INK2), (num(p.peak_impulse_ns, "N s"), PBR),
             (f"{p.deepest_mm:.1f} mm", SUCCESS if p.deepest_mm <= 5 else WARNING)]
            for p in pairs if FLOOR_NAME not in (p.a, p.b)]
    # What each touches at the end (contacts held while bodies sleep), the floor first.
    rests = {b.name: supports(b) for b in bodies}
    notes = [f"{name} came to rest on {', '.join('the floor' if o == FLOOR_NAME else o for o in on) or 'nothing (still moving)'}."
             for name, on in rests.items()]
    notes += metrics.collision_notes(pairs, FLOOR_NAME)
    entry = shoot.finish("COLLISION TEST", "Every contact measured", ["Contact", "First touch", "Peak impulse", "Deepest overlap"],
                         rows or [[("No object-to-object contacts", WARNING), ("", INK2), ("", INK2), ("", INK2)]], notes)
    entry.update(scene=scene, pairs=[p.to_dict() for p in pairs], rests_on=rests)
    return entry


# --- robot ---------------------------------------------------------------------------------------



def robot_test(ctx: Context, key: str = "robot", rig_key: str = "franka") -> dict:
    """A robot arm picks each object it can hold off one side of a table and sets it down on the other.

    ``rig_key`` picks the arm (``robot.RIGS``): a Franka with its two-finger hand, a UR10 with a
    suction cup, or a UR10e with a wide Robotiq gripper; ``key`` names the test's files.

    Grasps are planned from each asset's own surface (``core.grasp``); the objects are held by friction
    alone (the asset's own friction, against rubber pads) and carried with real accelerations, so
    what slips, swings or drops does so for the asset's mass, friction and shape.
    """
    from . import robot
    from .robot import ROBOT_BASE, ROBOT_YAW, TABLE_TOP

    st, brand, fps = ctx.studio, ctx.brand, ctx.fps
    rig = robot.RIGS[rig_key]
    opts = ctx.options(key)
    speed = float(opts.get("speed", 1.5))
    drop_in = bool(opts.get("drop_in", False))  # objects fall onto the table at the start and rest as they land
    risky = bool(opts.get("risky_grips", False))  # also try grips the object might twist out of
    stage = st.new_stage(fps)
    st.build_set()
    st.physics_scene()
    # A humanoid stands on the floor behind a smaller, lower table; the arms sit on a big one.
    standing = bool(rig.pin_link)
    top = robot.HUMANOID_TABLE_TOP if standing else TABLE_TOP
    size = robot.HUMANOID_TABLE if standing else (1.6, 1.0)
    robot.add_table(stage, "/World/Studio/Table", size[0], size[1], top,
                    st.grid_material("/World/Studio/Looks/Table", tint=(1.3, 1.3, 1.38), roughness=0.55, matte=True),
                    st.grid_material("/World/Studio/Looks/TableLegs", tint=(0.45, 0.45, 0.5), roughness=0.4))
    if standing:
        robot.add_robot(stage, "/World/Robot", (0.0, robot.HUMANOID_STAND_Y, rig.stand_height), ROBOT_YAW, rig)
        shoulder = robot.link_position(stage, "/World/Robot", robot.HUMANOID_SHOULDER)
        base = np.array([shoulder[0], shoulder[1], top])  # what the arm swings about
        robot_top = (0.0, robot.HUMANOID_STAND_Y, rig.height)
    else:
        base = np.array([ROBOT_BASE[0], ROBOT_BASE[1], TABLE_TOP])
        robot.add_robot(stage, "/World/Robot", base, ROBOT_YAW, rig)
        robot_top = (base[0], base[1], TABLE_TOP + rig.height)
    if rig.pad_prims:
        robot.pad_fingers(stage, "/World/Robot", rig.pad_prims, rig.pad_friction)
    partner = robot.RIGS.get(rig.partner) if rig.partner else None  # a humanoid's other arm
    if partner is not None and partner.pad_prims:
        robot.pad_fingers(stage, "/World/Robot", partner.pad_prims, partner.pad_friction)

    # Which objects the hand can take, judged on each asset at rest; the rest are listed on the card.
    candidates, skipped = [], []
    for asset in sorted(ctx.job["assets"], key=lambda a: a["name"]):
        prim = st.add_asset(asset)
        item = Placed(asset, prim, world_box(prim))
        rigid, info = physics_of(prim)
        mass = mass_of(item, info)
        refusal = None if rigid else "it has no rigid body, so it cannot be moved"
        refusal = refusal or robot.refusal(rig, mass)
        if refusal is None and not risky:
            points, normals, com = robot.oriented_surface_of(prim)
            centre = com if com is not None else points.mean(axis=0)
            if robot.plan_at_rest(rig, points, normals, centre, item.box.GetMin()[2], mass, info.get("static_friction")) is None:
                refusal = robot.no_grip_reason(rig, points, normals, centre, item.box.GetMin()[2])
        if refusal:
            skipped.append((item.name, refusal))
            stage.RemovePrim(prim.GetPath())
        else:
            candidates.append(item)
    skipped += [(c.name, "only the first few objects fit on the table") for c in candidates[int(opts.get("max_objects", 4)):]]
    for extra in candidates[int(opts.get("max_objects", 4)):]:
        stage.RemovePrim(extra.prim.GetPath())
    candidates = candidates[:int(opts.get("max_objects", 4))]

    # Spots on an arc to the robot's left; marked rings on its right. The front spot goes first. A
    # humanoid's one arm takes each object along its own arc round the shoulder, right to left.
    radii = [0.5 * math.hypot(*list(c.box.GetSize())[:2]) for c in candidates]
    arm_of = [0] * len(candidates)  # which arm takes each object (a humanoid uses both hands)
    shoulders = [base[:2]]
    if standing:
        candidates, picks, targets, arm_of, shoulders, gone = humanoid_layout(stage, rig, candidates, base[:2], size)
        skipped += gone
        radii = [_footprint_radius(c.prim) for c in candidates]
    else:
        picks, targets = robot.arc_spots(radii)
    placed = []
    for item, spot in zip(candidates, picks):
        mid = item.box.GetMidpoint()
        tr = item.prim.GetAttribute("xformOp:translate").Get()
        st.move(item.prim, tr[0] + spot[0] - mid[0], tr[1] + spot[1] - mid[1], tr[2] + top + 0.001 - item.box.GetMin()[2])
        if drop_in:
            # Held a little above its spot, slightly tilted, to fall and land however it lands.
            tr = item.prim.GetAttribute("xformOp:translate").Get()
            st.move(item.prim, tr[0], tr[1], tr[2] + 0.14 + 0.04 * (len(placed) % 2))
            tilt = item.prim.GetAttribute("xformOp:rotateXYZ")
            if tilt:
                tilt.Set(tilt.Get() + Gf.Vec3d(0.0, 12.0 if len(placed) % 2 else -9.0, 0.0))
        placed.append(Placed(item.asset, item.prim, world_box(item.prim)))
    for i, (target, radius) in enumerate(zip(targets, radii)):
        _target_pad(stage, f"/World/Studio/Pads/Pad{i}", target, radius, top)
    surfaces = [robot.oriented_surface_of(p.prim) for p in placed]
    bodies, statics, authored = bodies_for(placed)
    tallest = max((p.box.GetSize()[2] for p in placed), default=0.1)
    scene = st.export("robot")

    split = bool(opts.get("split_screen", True))
    labels_on = bool(opts.get("labels", not split))
    panels = film.split_layout(st.W, st.H) if split else [(0, 0, st.W, st.H)]
    main_size = (panels[0][2], panels[0][3])
    work = []  # the spots, pads and the arm: what the cameras must keep in view
    for p, target, radius in zip(placed, targets, radii):
        mid = p.box.GetMidpoint()
        for cx, cy in ((mid[0], mid[1]), (target[0], target[1])):
            work += [(cx + dx, cy + dy, top) for dx in (-radius, radius) for dy in (-radius, radius)]
        work.append((mid[0], mid[1], p.box.GetMax()[2]))
    cam = st.camera("/World/Studio/Camera", focal=40.0, size=main_size)
    centre = Gf.Vec3d(0.0, 0.12, top + 0.32) if standing else Gf.Vec3d(0.0, -0.08, TABLE_TOP + 0.2)
    if split:
        # Close in, on a slow arc round the arm (a marketing shot); the side views show the rest.
        arc = (math.radians(-30), math.radians(-6))
        close = [robot_top] + work
        distance = max(st.fit_aim(cam, centre, yaw, math.radians(20), close, side=0.03, top=0.16, bottom=0.03, size=main_size)
                       for yaw in arc)
        distance *= float(opts.get("closeness", 0.7))  # tighter still: the table's ends may leave the frame
    else:
        view = [(robot_top[0], robot_top[1], robot_top[2] + 0.1), (base[0] - 0.25, base[1], top),
                (base[0] + 0.25, base[1], top)] + work
        st.fit_aim(cam, centre, math.radians(-14), math.radians(26), view, side=0.07, top=0.2, bottom=0.08, size=main_size)
    _studio_lights(st, stage, base)
    texture = st.out / "robot_logo.png"
    aspect = robot.logo_texture(texture, brand.mark, brand.font(160 / brand.s, 620))
    # On the front of the base, between its two light strips: the way the robot faces (-90 degrees).
    if not standing and not robot.add_logo(stage, "/World/Robot", texture.as_posix(), aspect, math.radians(ROBOT_YAW),
                                           base_link=rig.base_link):
        carb.log_warn("Marso Sim Studio: could not place the logo on the robot's base")
    views = None
    if split:
        wrist = st.camera("/World/Studio/WristCamera", focal=11.0, size=(panels[1][2], panels[1][3]))
        top_cam = st.camera("/World/Studio/TopCamera", focal=70.0, size=(panels[2][2], panels[2][3]))  # high up: the arm never fills it
        st.fit_aim(top_cam, Gf.Vec3d(0.0, 0.1 if standing else -0.02, top), 0.0, math.radians(78), work + [(base[0], base[1], top)],
                   side=0.05, top=0.05, bottom=0.05, size=(panels[2][2], panels[2][3]))
        views = [("/World/Studio/Camera", panels[0]), ("/World/Studio/WristCamera", panels[1]), ("/World/Studio/TopCamera", panels[2])]

    if rig.gripper == "suction":
        robot.reset_suction(st.update)  # else a test run before this one leaves the cup unfound
    start_physics(ctx)
    arm = robot.Arm("/World/Robot", ctx.sim_hz, rig)
    arms = [arm] + ([robot.Arm("/World/Robot", ctx.sim_hz, partner, share=arm)] if partner is not None else [])
    for each in arms:
        each.home()
        each.strengthen_grip()
    step_physics()  # the links' poses follow the joints only once the world steps (the pick planning reads them)
    arm.check_suction()
    active = {"arm": arm}  # the arm at work; the other holds still
    for body in bodies:
        body.start()
    hz = ctx.sim_hz
    open_gap = arm.open_gap
    by_name = {b.name: b for b in bodies}
    steps = max(1, int(round(hz * speed / fps)))
    # The shot runs as long as the work takes (a slipped grip is tried again); this guess drives the
    # progress bar and the camera's arc.
    settle_s = 2.4 if drop_in else 0.8  # long enough to watch them land and settle
    estimate = int((settle_s + 10.0 * len(placed) + 2.5) * fps / speed)
    state = {b.name: ("waiting", INK2) for b in bodies}
    tones = {"ink": INK, "accent": PBR, "good": SUCCESS, "warn": WARNING}
    results: dict[str, dict] = {}
    clock = {"t": 0.0, "video": 0.0, "gap": open_gap, "shown": open_gap, "frames": 0, "step": 0}

    def dress(raw: Image.Image) -> Image.Image:
        canvas = brand.canvas(raw)
        fade = appear(clock["video"], 0.4, 0.5)
        if labels_on:
            items = [(st.project(cam, b.top(), main_size), [(b.name, INK, *LABEL), state_line(state[b.name])]) for b in bodies]
            brand.labels(canvas, items, appear(clock["video"], 0.5, 0.5), obstacles_of(st, cam, bodies, statics))
        if rig.cup is not None:
            tool_state = "SUCTION ON" if clock["gap"] < 0.5 * open_gap else "SUCTION OFF"
        else:
            tool_state = f"GRIP {clock['shown'] * 1000:.0f} MM"
        if split:
            brand.caption(canvas, panels[1], f"WRIST CAMERA  ·  {tool_state}", fade)
            brand.caption(canvas, panels[2], "TOP VIEW", fade)
        else:
            brand.gauge(canvas, "GRIP", tool_state.split("  ")[-1].title(), clock["gap"] / open_gap,
                        f"{rig.cup.hold_n:g} N hold" if rig.cup is not None else f"{rig.grip_n:g} N per finger", fade)
        return brand.dress(canvas, "ROBOT TEST", f"Pick and place  ·  {rig.name}", clock["video"],
                           right="" if split else f"{speed:g}x speed",
                           subtitle="" if split else f"A {rig.name} picks up each object it can hold")

    def move_cameras() -> None:
        """The main camera's slow arc, and the wrist camera riding on the hand."""
        if not split:
            return
        s = robot.grasp_plan.min_jerk(min(1.0, clock["frames"] / max(1, estimate - 1)))
        st.aim(cam, centre, arc[0] + (arc[1] - arc[0]) * s, math.radians(20), distance)
        hand = active["arm"]
        hand_p, hand_q = hand.hand_pose()
        turn = quat_to_matrix(*hand_q)
        # Out beside the tool, looking down past its tip; the arm is "up" in the picture.
        side = np.cross(hand.closing_axis, hand.tool_axis)
        eye = hand_p + turn @ (0.11 * side + (hand.tip - 0.05) * hand.tool_axis)
        look = hand_p + turn @ ((hand.tip + 0.1) * hand.tool_axis)
        st.look_at(wrist, eye, look, turn @ -hand.tool_axis)

    shoot = Shoot(ctx, key, "/World/Studio/Camera", estimate, views=views, open_ended=True)
    move_cameras()
    shoot.recorder.warm_up()

    rest: dict = {}  # where each arm waits while the other works

    def step(pose, gap: float) -> None:
        for each in arms:
            if each is active["arm"]:
                if pose is not None:
                    each.track(*pose)
                each.grip(gap)
            else:
                each.track(*rest[each])
                each.grip(each.open_gap)
        step_physics()
        hand = active["arm"]
        clock["t"] += 1.0 / hz
        clock["step"] += 1
        clock["gap"] = hand.finger_gap()
        # Closed on an object, the grip's own width (the simulated Robotiq's fingers lean in as they hold).
        clock["shown"] = hand.planned_width if gap == 0.0 and hand.planned_width else clock["gap"]
        for body in bodies:
            body.record(clock["t"])
        if clock["step"] % steps == 0:
            clock["video"] = clock["frames"] / fps
            move_cameras()
            raw = shoot.shot(dress)
            clock["frames"] += 1
            if clock["frames"] == int(fps * 7 / speed):
                shoot.keep_thumb(raw)

    # A humanoid carries low, each object along its own arc (nothing to clear): its hand pointing down
    # cannot rise far above the table.
    carry = robot.HUMANOID_CARRY if standing else max(0.22, tallest + 0.08)
    pickers = [robot.PickPlace(each, hz, step, carry_clear=carry, risky=risky, tries=int(opts.get("max_tries", robot.MAX_TRIES)),
                               base=shoulders[min(i, len(shoulders) - 1)], table_top=top) for i, each in enumerate(arms)]
    rest.update({each: (pk.home_p, pk.home_q) for each, pk in zip(arms, pickers)})
    picker = pickers[0]
    picker.hold((picker.home_p, picker.home_q), open_gap, settle_s)
    for k, (item, surface, target, which) in enumerate(zip(placed, surfaces, targets, arm_of)):
        body = by_name.get(item.name)
        if body is None:
            continue
        info = authored[item.name]
        if arms[which] is not active["arm"]:
            picker.go_home()  # the other hand's turn
            active["arm"], picker = arms[which], pickers[which]

        def say(text: str, tone: str, name=item.name) -> None:
            state[name] = (text, tones.get(tone, INK))

        results[item.name] = picker.pick_and_place(body, surface, target, info.get("mass"), info.get("static_friction"), say)
    picker.go_home()
    shoot.planned = clock["frames"] + (shoot.planned - estimate)  # the card and outro follow the last frame shot

    rows = []
    for name, r in results.items():
        verdict = SUCCESS if r["result"] == "placed" else WARNING
        outcome = r["result"] + (f", {r['tries']} tries" if r.get("tries", 0) > 1 else "")
        grip = "cup" if rig.cup is not None and r.get("tries") else _mm(r.get("grip_mm"))
        rows.append([(name, INK), (num(r.get("mass_kg"), "kg"), INK2), (grip, INK2),
                     (_mm(r.get("lifted_mm")), INK2), (_mm(r.get("slip_mm")), PBR), (_mm(r.get("off_mm")), INK),
                     (_mm(r.get("tilt_deg"), DEGREE), INK2), (outcome, verdict)])
    notes = [f"Not attempted: {name}: {why}." for name, why in skipped]
    if rig.cup is not None:
        notes.append(f"{rig.name}: it lifts by a flat spot near the centre of mass and lets go past {rig.cup.hold_n:g} N. "
                     f"Anything that drops is picked up again, up to {picker.tries} tries.")
    elif rig.gripper == "hand":
        notes.append(f"{rig.name}: {'each hand' if partner is not None else 'it'} pinches between its thumb and two fingers. "
                     f"The grip is assisted: once the fingers close "
                     f"on an object it moves with the hand while its weight, swing and twist stay within what the pinch "
                     f"({rig.grip_n:g} N on rubber pads) holds; PhysX cannot hold a five-finger pinch by friction alone. "
                     f"Anything that slips or drops is picked up again, up to {picker.tries} tries.")
    else:
        notes.append(f"{rig.name}, {rig.grip_n:g} N per finger on rubber pads; the grip's friction is each asset's own. "
                     f"Anything that slips or drops is picked up again, up to {picker.tries} tries.")
    if risky:
        notes.append("Risky grips allowed: the arm also tried grips an object could twist out of.")
    if drop_in:
        notes.append("The objects were dropped onto the table and picked up from wherever they landed.")
    entry = shoot.finish("ROBOT TEST", f"Pick and place  ·  {rig.name}",
                         ["Object", "Mass", "Grip", "Lifted", "Slip in grip", "From its pad", "Tilted", "Result"],
                         rows or [[("Nothing the hand could hold", WARNING)] + [("", INK2)] * 7], notes)
    entry.update(scene=scene, results=results, skipped=dict(skipped))
    return entry


# --- handover --------------------------------------------------------------------------------------


def handover_set(st: Studio, stage, assets: list[dict], max_objects: int = 3):
    """The handover's set: a long table, two Frankas behind it, the objects the hands can take in front
    of the left arm and a ring for each in front of the right one. Returns (placed, targets, radii,
    skipped); shared with ``internal/probes/handover_probe.py``."""
    from . import robot

    top = robot.TABLE_TOP
    robot.add_table(stage, "/World/Studio/Table", 1.9, 1.0, top,
                    st.grid_material("/World/Studio/Looks/Table", tint=(1.3, 1.3, 1.38), roughness=0.55, matte=True),
                    st.grid_material("/World/Studio/Looks/TableLegs", tint=(0.45, 0.45, 0.5), roughness=0.4))
    rig = robot.RIGS["franka"]
    for path, base in (("/World/LeftRobot", robot.LEFT_BASE), ("/World/RightRobot", robot.RIGHT_BASE)):
        robot.add_robot(stage, path, (base[0], base[1], top), robot.ROBOT_YAW, rig)
        robot.pad_fingers(stage, path, rig.pad_prims, rig.pad_friction)
    candidates, skipped = [], []
    for asset in sorted(assets, key=lambda a: a["name"]):
        prim = st.add_asset(asset)
        item = Placed(asset, prim, world_box(prim))
        rigid, info = physics_of(prim)
        mass = mass_of(item, info)
        refusal = None if rigid else "it has no rigid body, so it cannot be moved"
        refusal = refusal or robot.refusal(rig, mass)
        if refusal is None:
            points, normals, com = robot.oriented_surface_of(prim)
            centre = com if com is not None else points.mean(axis=0)
            if robot.plan_at_rest(rig, points, normals, centre, item.box.GetMin()[2], mass, info.get("static_friction")) is None:
                refusal = robot.no_grip_reason(rig, points, normals, centre, item.box.GetMin()[2])
        if refusal:
            skipped.append((item.name, refusal))
            stage.RemovePrim(prim.GetPath())
        else:
            candidates.append(item)
    skipped += [(c.name, "only the first few objects fit on the table") for c in candidates[max_objects:]]
    for extra in candidates[max_objects:]:
        stage.RemovePrim(extra.prim.GetPath())
    candidates = candidates[:max_objects]
    radii = [0.5 * math.hypot(*list(c.box.GetSize())[:2]) for c in candidates]
    def around(base, deg):
        return np.array(base) + 0.46 * np.array([math.cos(math.radians(deg)), math.sin(math.radians(deg))])
    picks = [around(robot.LEFT_BASE, d) for d in robot.spread_on_arc(radii, 250.0, 0.46)]
    # In front of the right arm, a little to its left: it sets objects down held from their right side,
    # its hand pointing left, which out to its right meant an awkward reach back towards its own base.
    targets = [around(robot.RIGHT_BASE, d) for d in robot.spread_on_arc(radii, 250.0, 0.46)]
    placed = []
    for item, spot in zip(candidates, picks):
        mid = item.box.GetMidpoint()
        tr = item.prim.GetAttribute("xformOp:translate").Get()
        st.move(item.prim, tr[0] + spot[0] - mid[0], tr[1] + spot[1] - mid[1], tr[2] + top + 0.001 - item.box.GetMin()[2])
        placed.append(Placed(item.asset, item.prim, world_box(item.prim)))
    return placed, targets, radii, skipped


def handover_test(ctx: Context) -> dict:
    """Two Frankas pass each object across the table: the left picks it up and holds it out, the right
    takes it from the side, and sets it down on its ring. Filmed split screen: a close shot and each
    hand's wrist camera."""
    from . import robot

    st, brand, fps = ctx.studio, ctx.brand, ctx.fps
    opts = ctx.options("robot_handover")
    speed = float(opts.get("speed", 1.5))
    top = robot.TABLE_TOP
    stage = st.new_stage(fps)
    st.build_set()
    st.physics_scene()
    placed, targets, radii, skipped = handover_set(st, stage, ctx.job["assets"], int(opts.get("max_objects", 3)))
    for i, (target, radius) in enumerate(zip(targets, radii)):
        _target_pad(stage, f"/World/Studio/Pads/Pad{i}", target, radius, top)
    surfaces = [robot.oriented_surface_of(p.prim) for p in placed]
    bodies, statics, authored = bodies_for(placed)
    tallest = max((p.box.GetSize()[2] for p in placed), default=0.1)
    scene = st.export("robot_handover")

    split = bool(opts.get("split_screen", True))
    panels = film.split_layout(st.W, st.H) if split else [(0, 0, st.W, st.H)]
    main_size = (panels[0][2], panels[0][3])
    work = [(robot.MEET[0], robot.MEET[1], robot.MEET[2] + 0.1)]
    for p, target, radius in zip(placed, targets, radii):
        mid = p.box.GetMidpoint()
        for cx, cy in ((mid[0], mid[1]), (target[0], target[1])):
            work += [(cx + dx, cy + dy, top) for dx in (-radius, radius) for dy in (-radius, radius)]
    for base in (robot.LEFT_BASE, robot.RIGHT_BASE):
        work.append((base[0], base[1], top + 0.85))
    cam = st.camera("/World/Studio/Camera", focal=40.0, size=main_size)
    centre = Gf.Vec3d(0.0, -0.06, top + 0.25)
    arc = (math.radians(-12), math.radians(12))
    distance = max(st.fit_aim(cam, centre, yaw, math.radians(18), work, side=0.03, top=0.16, bottom=0.03, size=main_size)
                   for yaw in arc) * float(opts.get("closeness", 0.85))
    _studio_lights(st, stage, None)
    texture = st.out / "robot_logo.png"
    aspect = robot.logo_texture(texture, brand.mark, brand.font(160 / brand.s, 620))
    for path in ("/World/LeftRobot", "/World/RightRobot"):
        robot.add_logo(stage, path, texture.as_posix(), aspect, math.radians(robot.ROBOT_YAW), base_link="panda_link0")
        mesh = stage.GetPrimAtPath("/World/Studio/RobotLogo")
        if mesh:  # one decal per robot
            Sdf.CopySpec(stage.GetRootLayer(), mesh.GetPath(), stage.GetRootLayer(), Sdf.Path(f"/World/Studio/Logo{path[7:]}"))
            stage.RemovePrim(mesh.GetPath())
    views = None
    if split:
        cams = {"left": st.camera("/World/Studio/LeftWrist", focal=11.0, size=(panels[1][2], panels[1][3])),
                "right": st.camera("/World/Studio/RightWrist", focal=11.0, size=(panels[2][2], panels[2][3]))}
        views = [("/World/Studio/Camera", panels[0]), ("/World/Studio/LeftWrist", panels[1]), ("/World/Studio/RightWrist", panels[2])]

    start_physics(ctx)
    rig = robot.RIGS["franka"]
    left, right = robot.Arm("/World/LeftRobot", ctx.sim_hz, rig), robot.Arm("/World/RightRobot", ctx.sim_hz, rig)
    for arm in (left, right):
        arm.home()
        arm.strengthen_grip()
    for body in bodies:
        body.start()
    hz = ctx.sim_hz
    steps = max(1, int(round(hz * speed / fps)))
    estimate = int((1.0 + 22.0 * len(placed) + 2.0) * fps / speed)
    state = {b.name: ("waiting", INK2) for b in bodies}
    tones = {"ink": INK, "accent": PBR, "good": SUCCESS, "warn": WARNING}
    results: dict[str, dict] = {}
    clock = {"t": 0.0, "video": 0.0, "frames": 0, "step": 0}
    by_name = {b.name: b for b in bodies}

    def dress(raw: Image.Image) -> Image.Image:
        canvas = brand.canvas(raw)
        fade = appear(clock["video"], 0.4, 0.5)
        if split:
            brand.caption(canvas, panels[1], f"LEFT HAND  ·  GRIP {left.finger_gap() * 1000:.0f} MM", fade)
            brand.caption(canvas, panels[2], f"RIGHT HAND  ·  GRIP {right.finger_gap() * 1000:.0f} MM", fade)
        return brand.dress(canvas, "ROBOT TEST", "Handover  ·  two Franka Pandas", clock["video"],
                           right="" if split else f"{speed:g}x speed")

    def move_cameras() -> None:
        if not split:
            return
        s = robot.grasp_plan.min_jerk(min(1.0, clock["frames"] / max(1, estimate - 1)))
        st.aim(cam, centre, arc[0] + (arc[1] - arc[0]) * s, math.radians(18), distance)
        for arm, key in ((left, "left"), (right, "right")):
            hand_p, hand_q = arm.hand_pose()
            turn = quat_to_matrix(*hand_q)
            side = np.cross(arm.closing_axis, arm.tool_axis)
            eye = hand_p + turn @ (0.11 * side + (arm.tip - 0.05) * arm.tool_axis)
            look = hand_p + turn @ ((arm.tip + 0.1) * arm.tool_axis)
            st.look_at(cams[key], eye, look, turn @ -arm.tool_axis)

    shoot = Shoot(ctx, "robot_handover", "/World/Studio/Camera", estimate, views=views, open_ended=True)
    move_cameras()
    shoot.recorder.warm_up()

    def step(lp, lg, rp, rg) -> None:
        left.track(*lp)
        left.grip(lg)
        right.track(*rp)
        right.grip(rg)
        step_physics()
        clock["t"] += 1.0 / hz
        clock["step"] += 1
        for body in bodies:
            body.record(clock["t"])
        if clock["step"] % steps == 0:
            clock["video"] = clock["frames"] / fps
            move_cameras()
            raw = shoot.shot(dress)
            clock["frames"] += 1
            if clock["frames"] == int(fps * 9 / speed):
                shoot.keep_thumb(raw)

    hands = robot.Handover(left, right, hz, step, carry_clear=max(0.22, tallest + 0.08))
    hands.hold(1.0)
    for item, surface, target in zip(placed, surfaces, targets):
        body = by_name.get(item.name)
        if body is None:
            continue
        info = authored[item.name]

        def say(text: str, tone: str, name=item.name) -> None:
            state[name] = (text, tones.get(tone, INK))

        results[item.name] = hands.pass_over(body, surface, target, info.get("mass"), info.get("static_friction"), say)
    hands.hold(1.5)
    shoot.planned = clock["frames"] + (shoot.planned - estimate)

    rows = []
    for name, r in results.items():
        verdict = SUCCESS if r["result"] == "placed" else WARNING
        rows.append([(name, INK), (num(r.get("mass_kg"), "kg"), INK2), (_mm(r.get("left_grip_mm")), INK2),
                     (_mm(r.get("right_grip_mm")), INK2), (_mm(r.get("handover_slip_mm")), PBR), (_mm(r.get("off_mm")), INK),
                     (_mm(r.get("tilt_deg"), DEGREE), INK2), (r["result"], verdict)])
    notes = [f"Not attempted: {name}: {why}." for name, why in skipped]
    notes.append("Two Franka Pandas, 70 N per finger on rubber pads. The left hand turns each object to offer it; the "
                 "right takes it from the side, around the left hand, its fingers beside the object so it can set it down.")
    entry = shoot.finish("ROBOT TEST", "Handover  ·  two Franka Pandas",
                         ["Object", "Mass", "Left grip", "Right grip", "Slip in handover", "From its spot", "Tilted", "Result"],
                         rows or [[("Nothing both hands could hold", WARNING)] + [("", INK2)] * 7], notes)
    entry.update(scene=scene, results=results, skipped=dict(skipped))
    return entry


def humanoid_layout(stage, rig, candidates: list, base_xy, size: tuple):
    """Where a standing humanoid's objects start and finish: each arm takes its own (both hands when it
    has a ``partner`` arm), on an arc round its shoulder, each object turned to lie across the way that
    hand closes there so the fingers take it the short way. Smallest first, so as many as possible fit.

    Returns (objects, starts, finishes, which arm for each, the shoulders, [(name, why not)] left out).
    Shared with ``internal/probes/robot_probe.py``.
    """
    from . import robot

    sized = sorted(zip((_footprint_radius(c.prim) for c in candidates), range(len(candidates))))
    candidates = [candidates[i] for _r, i in sized]
    radii = [r for r, _i in sized]
    edge = size[1] / 2 - 0.01
    shoulders = [np.asarray(base_xy, float)[:2]]
    if rig.partner:
        shoulders.append(robot.link_position(stage, "/World/Robot", robot.HUMANOID_SHOULDER.replace("right_", "left_"))[:2])
        plan = robot.share_out(radii, shoulders, edge)
    else:
        starts, ends, kept = robot.reach_spots(shoulders[0], radii, back_edge=edge)
        plan = [(list(range(kept)), starts, ends)]
    objects, picks, targets, arms, used = [], [], [], [], set()
    for arm, (mine, starts, ends) in enumerate(plan):
        for i, start, end in zip(mine, starts, ends):
            heading = math.degrees(math.atan2(start[1] - shoulders[arm][1], start[0] - shoulders[arm][0]))
            # The left hand closes as turned the other way from its heading as the right one does.
            _turn_lengthwise(candidates[i].prim, heading + (robot.GRIP_TURN if arm == 0 else -robot.GRIP_TURN) + 90.0)
            objects.append(Placed(candidates[i].asset, candidates[i].prim, world_box(candidates[i].prim)))
            picks.append(start)
            targets.append(end)
            arms.append(arm)
            used.add(i)
    left_out = [(c.name, "no room within the arms' reach") for i, c in enumerate(candidates) if i not in used]
    for i, c in enumerate(candidates):
        if i not in used:
            stage.RemovePrim(c.prim.GetPath())
    return objects, picks, targets, arms, shoulders, left_out


def _footprint_radius(prim) -> float:
    """How far the object reaches from its middle, across the table, whichever way it is turned."""
    from . import robot

    points = robot.oriented_surface_of(prim)[0]
    xy = points[:, :2]
    return float(np.linalg.norm(xy - (xy.min(axis=0) + xy.max(axis=0)) / 2, axis=1).max())


def _turn_lengthwise(prim, along_deg: float) -> None:
    """Turn an object about the vertical so its longest way across lies along ``along_deg`` (world)."""
    from . import robot

    points = robot.oriented_surface_of(prim)[0]
    xy = points[:, :2] - points[:, :2].mean(axis=0)
    long_way = np.linalg.eigh(xy.T @ xy)[1][:, -1]
    turn = math.remainder(along_deg - math.degrees(math.atan2(long_way[1], long_way[0])), 180.0)
    rotate = prim.GetAttribute("xformOp:rotateXYZ")
    if rotate and rotate.Get() is not None:
        rotate.Set(rotate.Get() + Gf.Vec3d(0.0, 0.0, turn))


def _studio_lights(st: Studio, stage, base=None) -> None:
    """Studio lighting for the robot set: a big key softbox front-left, a soft overhead, a violet rim
    behind the arm, and the set's own lights and dome turned down so the softboxes shape everything."""
    from . import robot

    table = np.array([0.0, -0.1, robot.TABLE_TOP])
    robot.softbox(stage, "/World/Studio/Lights/KeySoftbox", table + (-1.5, -1.6, 1.7), table + (0, 0, 0.25), 1.6, 1.1, 2600.0,
                  (1.0, 0.97, 0.94))
    robot.softbox(stage, "/World/Studio/Lights/TopSoftbox", table + (0.0, 0.1, 1.9), table, 2.2, 1.4, 2100.0, (0.97, 0.98, 1.0))
    robot.softbox(stage, "/World/Studio/Lights/RimSoftbox", table + (1.3, 1.9, 1.3), table + (0, 0.25, 0.35), 1.2, 0.6, 2400.0,
                  (0.78, 0.66, 1.0))
    robot.softbox(stage, "/World/Studio/Lights/FillCard", table + (1.9, -1.2, 0.8), table + (0, 0, 0.3), 1.2, 1.2, 600.0,
                  (0.94, 0.96, 1.0))
    for name, scale in (("Key", 0.25), ("Rim", 0.0), ("Fill", 0.4), ("Dome", 0.55)):
        light = stage.GetPrimAtPath(f"/World/Studio/Lights/{name}")
        if light:
            attr = light.GetAttribute("inputs:intensity")
            attr.Set(float(attr.Get() or 0.0) * scale)


def _mm(value, unit: str = "mm") -> str:
    """Millimetres (or degrees) for the robot card: whole numbers from 10 up, one decimal below."""
    if value is None:
        return "-"
    text = f"{value:.0f}" if abs(value) >= 10 else f"{value:.1f}"
    return f"{text}{unit}" if unit == DEGREE else f"{text} {unit}"


def _target_pad(stage, path: str, centre, radius: float, top: float) -> None:
    """A thin glowing violet ring on the table where an object should be set down (seen only)."""
    outer, inner, segments, z = radius + 0.015, radius + 0.006, 96, top + 0.0006
    points, counts, indices = [], [], []
    for i in range(segments):
        a = 2 * math.pi * i / segments
        for r in (inner, outer):
            points.append(Gf.Vec3f(float(centre[0] + r * math.cos(a)), float(centre[1] + r * math.sin(a)), z))
    for i in range(segments):
        j = (i + 1) % segments
        counts.append(4)
        indices += [2 * i, 2 * j, 2 * j + 1, 2 * i + 1]
    pad = UsdGeom.Mesh.Define(stage, path)
    pad.CreatePointsAttr(points)
    pad.CreateFaceVertexCountsAttr(counts)
    pad.CreateFaceVertexIndicesAttr(indices)
    pad.CreateDoubleSidedAttr(True)
    look = UsdShade.Material.Define(stage, path + "_Look")
    shader = UsdShade.Shader.Define(stage, path + "_Look/Surface")
    shader.CreateIdAttr("UsdPreviewSurface")
    shader.CreateInput("diffuseColor", Sdf.ValueTypeNames.Color3f).Set(Gf.Vec3f(0.42, 0.3, 0.75))
    shader.CreateInput("emissiveColor", Sdf.ValueTypeNames.Color3f).Set(Gf.Vec3f(0.55, 0.36, 1.0))
    look.CreateSurfaceOutput().ConnectToSource(shader.ConnectableAPI(), "surface")
    UsdShade.MaterialBindingAPI.Apply(pad.GetPrim()).Bind(look)


TESTS = {"scale": scale_test, "drop": drop_test, "friction": friction_test, "wind": wind_test, "collision": collision_test,
         "robot": robot_test,
         "robot_suction": lambda ctx: robot_test(ctx, "robot_suction", "ur10_suction"),
         "robot_wide": lambda ctx: robot_test(ctx, "robot_wide", "ur10e_wide"),
         "robot_handover": handover_test,
         "robot_humanoid": lambda ctx: robot_test(ctx, "robot_humanoid", "g1_inspire")}

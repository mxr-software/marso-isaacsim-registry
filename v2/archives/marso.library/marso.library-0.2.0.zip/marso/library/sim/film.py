"""Frames to film: Replicator capture, Marso branding drawn with Pillow, and MP4 encoding.

Runs inside the Sim Studio runner's Isaac Sim. Branding follows Marso's Design Language
(marso-motion ``studio/src/ui/dl``): Geist and Geist Mono, ink on the canvas colour, PBR violet as
the one accent and the only glow, DL panels for labels, the Marso mark in a corner.

Encoding uses ffmpeg when the job names one, otherwise Kit's own ``omni.videoencoding`` (NVENC),
so nothing extra has to be installed. Kit's encoder can only write one file at a time, so a clean
copy is spooled to PNGs and encoded after the branded one.
"""

from __future__ import annotations

import math
import shutil
import subprocess
import tempfile
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFont

INK = (248, 248, 251)
INK2 = (158, 167, 184)
INK3 = (122, 130, 144)
PBR = (180, 139, 255)
GLOW = (154, 92, 255)
PBR_FILL = (54, 26, 128)
SUCCESS = (63, 217, 138)
WARNING = (244, 195, 82)
DANGER = (245, 116, 109)
CANVAS = (23, 25, 27)
SURFACE = (20, 25, 34)
HAIRLINE = (50, 54, 63)
NODE = (6, 6, 7)

Line = tuple  # (text, colour, size, weight, mono)


def ease(u: float) -> float:
    """Ease in-out, clamped to [0, 1]."""
    u = min(1.0, max(0.0, u))
    return u * u * (3 - 2 * u)


def appear(t: float, start: float, duration: float = 0.5) -> float:
    return ease((t - start) / duration) if duration > 0 else float(t >= start)


class Brand:
    """Fonts, the mark and every overlay, sized for one frame size."""

    def __init__(self, extension_root: Path, width: int, height: int) -> None:
        self.W, self.H = width, height
        self.s = min(width, height) / 720.0
        fonts = extension_root / "data" / "fonts"
        self._sans = fonts / "Geist-Variable.ttf"
        self._mono = fonts / "GeistMono-Variable.ttf"
        self._fonts: dict[tuple, ImageFont.FreeTypeFont] = {}
        mark = Image.open(extension_root / "data" / "brand" / "marso_mark.png").convert("RGBA")
        self.mark = mark
        self._static = self._make_static()
        self._label_slots: dict[str, int] = {}  # each label's spot last frame, by its first line
        self.backdrop = self._make_backdrop()
        self._corner_mark = self.mark_of(20, 0.9)

    # --- type and marks ----------------------------------------------------------------------

    def font(self, size: float, weight: int = 400, mono: bool = False) -> ImageFont.FreeTypeFont:
        key = (max(6, round(size * self.s)), weight, mono)
        font = self._fonts.get(key)
        if font is None:
            try:
                font = ImageFont.truetype(str(self._mono if mono else self._sans), key[0])
                font.set_variation_by_axes([weight])
            except (OSError, AttributeError):
                font = ImageFont.load_default()
            self._fonts[key] = font
        return font

    def mark_of(self, height: float, alpha: float = 1.0) -> Image.Image:
        h = max(4, round(height * self.s))
        mark = self.mark.resize((round(self.mark.width * h / self.mark.height), h), Image.LANCZOS)
        if alpha < 1.0:
            a = mark.getchannel("A").point(lambda v: int(v * alpha))
            mark.putalpha(a)
        return mark

    # --- frame dressing ----------------------------------------------------------------------
    #
    # Overlays draw onto one transparent layer per frame (a ``Canvas``); ``dress`` then composites
    # the frame, the static vignette and scrims, and that layer, once. Far cheaper than compositing
    # every element separately at 1080p and 4K.

    def _make_static(self) -> Image.Image:
        """Vignette plus the canvas-coloured scrims behind the header and footer, as one overlay."""
        y = np.arange(self.H, dtype=np.float32)[:, None]
        x = np.arange(self.W, dtype=np.float32)[None, :]
        d = np.sqrt(((x - self.W / 2) / (self.W / 2)) ** 2 + ((y - self.H / 2) / (self.H / 2)) ** 2)
        vignette = np.clip((d - 0.75) / 0.75, 0, 1) ** 2 * 0.55
        top, bottom = int(self.H * 0.24), int(self.H * 0.16)
        scrim = np.zeros((self.H, 1), dtype=np.float32)
        scrim[:top, 0] = np.linspace(0.82, 0.0, top) ** 1.5
        scrim[self.H - bottom:, 0] = np.linspace(0.0, 0.72, bottom) ** 1.5
        scrim = np.repeat(scrim, self.W, axis=1)
        alpha = 1 - (1 - vignette) * (1 - scrim)
        share = scrim / np.maximum(alpha, 1e-6)  # how much of the darkening is the canvas colour
        rgba = np.zeros((self.H, self.W, 4), dtype=np.uint8)
        for c in range(3):
            rgba[:, :, c] = np.clip(share * CANVAS[c], 0, 255).astype(np.uint8)
        rgba[:, :, 3] = (alpha * 255).astype(np.uint8)
        return Image.fromarray(rgba, "RGBA")

    def _make_backdrop(self) -> Image.Image:
        """What shows beyond the floor: the canvas colour with a soft PBR-violet glow above the horizon."""
        y = np.arange(self.H, dtype=np.float32)[:, None] / self.H
        x = np.arange(self.W, dtype=np.float32)[None, :] / self.W
        glow = np.clip(1.0 - np.sqrt(((x - 0.5) / 0.7) ** 2 + ((y - 0.38) / 0.5) ** 2), 0, 1) ** 2.2
        shade = 1.0 - 0.25 * y
        rgb = np.empty((self.H, self.W, 3), dtype=np.float32)
        for c in range(3):
            rgb[:, :, c] = CANVAS[c] * shade + (PBR_FILL[c] - CANVAS[c]) * glow * 0.55
        return Image.fromarray(np.clip(rgb, 0, 255).astype(np.uint8), "RGB")

    def canvas(self, frame: Image.Image) -> "Canvas":
        return Canvas(frame)

    def dress(self, canvas: "Canvas", eyebrow: str, title: str, t: float, right: str = "", subtitle: str = "") -> Image.Image:
        """The title block (fading in from t=0.2 s), the corner mark, then everything composited once."""
        draw = canvas.draw
        pad = 34 * self.s
        a = appear(t, 0.2, 0.6)
        lift = (1 - a) * 10 * self.s
        draw.text((pad, pad + lift), eyebrow, font=self.font(14, 600, mono=True), fill=PBR + (int(255 * a),))
        draw.text((pad, pad + 22 * self.s + lift), title, font=self.font(34, 600), fill=INK + (int(255 * a),))
        if subtitle:
            b = appear(t, 0.45, 0.6)
            draw.text((pad, pad + 66 * self.s), subtitle, font=self.font(15, 400), fill=INK2 + (int(255 * b),))
        if right:
            font = self.font(14, 500, mono=True)
            draw.text((self.W - pad - draw.textlength(right, font=font), pad + 4 * self.s), right, font=font,
                      fill=INK2 + (int(255 * a),))
        mark = self._corner_mark
        canvas.layer.alpha_composite(mark, (int(pad), int(self.H - pad - mark.height)))
        draw.text((pad + mark.width + 10 * self.s, self.H - pad - mark.height / 2 - 8 * self.s), "marso.app",
                  font=self.font(14, 500, mono=True), fill=INK2 + (230,))
        image = Image.alpha_composite(canvas.frame.convert("RGBA"), self._static)
        return Image.alpha_composite(image, canvas.layer)

    # --- labels ------------------------------------------------------------------------------

    def labels(self, canvas: "Canvas", items: list, alpha: float = 1.0, obstacles: list | None = None) -> None:
        """DL panels raised above their points on leader lines, overlapping neither each other nor any object.

        ``obstacles`` are screen rectangles (left, top, right, bottom) of the objects in shot. Each panel
        tries heights above its point (centred, then nudged right or left) and keeps the spot it had last
        frame while that still fits, so labels do not hop about as objects move.
        """
        if alpha <= 0:
            return
        draw = canvas.draw
        pad, gap = 9 * self.s, 6 * self.s
        placed: list[tuple[float, float, float, float]] = [(0, 0, self.W * 0.42, self.H * 0.13),
                                                            (self.W * 0.6, 0, self.W, self.H * 0.17)]
        a = int(255 * alpha)
        # An object that has left the shot, or gone up behind the title, loses its label.
        visible = [item for item in items if item[0] is not None and -40 * self.s <= item[0][0] <= self.W + 40 * self.s
                   and self.H * 0.16 <= item[0][1] <= self.H + 40 * self.s]

        blocked = [tuple(o) for o in (obstacles or [])]

        def clear(x: float, y: float, w: float, h: float) -> bool:
            return all(not (x < r + gap and x + w > l - gap and y < b + gap and y + h > t - gap)
                       for l, t, r, b in placed + blocked)

        for anchor, lines in sorted(visible, key=lambda item: item[0][0]):
            fonts = [self.font(size, weight, mono) for _, _, size, weight, mono in lines]
            widths = [draw.textlength(text, font=font) for (text, *_), font in zip(lines, fonts)]
            heights = [font.size + 4 * self.s for font in fonts]
            box_w, box_h = max(widths) + 2 * pad, sum(heights) + 2 * pad - 4 * self.s
            ax, ay = anchor
            above = ay - box_h - 40 * self.s  # raised clear of the object, on a leader line
            slots = []
            for level in range(6):
                y = above - level * (box_h * 0.7 + gap)
                slots += [(ax - box_w / 2, y), (ax - box_w * 0.15, y), (ax - box_w * 0.85, y)]
            fitted = [(min(max(x, 8), self.W - box_w - 8), min(max(y, 8), self.H - box_h - 8)) for x, y in slots]
            key = lines[0][0]
            order = list(range(len(fitted)))
            previous = self._label_slots.get(key)
            if previous is not None:
                order.remove(previous)
                order.insert(0, previous)
            choice = next((i for i in order if clear(*fitted[i], box_w, box_h)), None)
            if choice is None:  # crowded out: the spot that covers least (the title and gauge count heavily)
                def cover(i: int) -> float:
                    x0, y0 = fitted[i]
                    total = 0.0
                    for n, (l, t_, r, b) in enumerate(placed + blocked):
                        w = min(x0 + box_w, r) - max(x0, l)
                        h = min(y0 + box_h, b) - max(y0, t_)
                        if w > 0 and h > 0:
                            total += w * h * (10.0 if n < 2 else 1.0)
                    return total

                choice = min(order, key=cover)
            self._label_slots[key] = choice
            x, y = fitted[choice]
            # leader line from the point to the nearest edge of its panel
            nx, ny = min(max(ax, x), x + box_w), min(max(ay, y), y + box_h)
            if math.hypot(nx - ax, ny - ay) > 10 * self.s:
                draw.line([(ax, ay - 4 * self.s), (nx, ny)], fill=INK3 + (int(a * 0.8),), width=max(1, round(self.s)))
            draw.rounded_rectangle((x, y, x + box_w, y + box_h), radius=8 * self.s, fill=SURFACE + (int(a * 0.86),),
                                   outline=HAIRLINE + (a,), width=max(1, round(self.s)))
            cursor = y + pad - 2 * self.s
            for (text, colour, *_), font, height in zip(lines, fonts, heights):
                draw.text((x + pad, cursor), text, font=font, fill=colour + (a,))
                cursor += height
            placed.append((x, y, x + box_w, y + box_h))

    def ticks(self, canvas: "Canvas", items: list, alpha: float = 1.0) -> None:
        """Small mono labels beside projected points (the height pole's marks)."""
        font = self.font(12, 500, mono=True)
        for spot, text in items:
            if spot is not None:
                canvas.draw.text((spot[0] + 7 * self.s, spot[1] - font.size / 2), text, font=font,
                                 fill=INK2 + (int(230 * alpha),))

    # --- gauges and effects ----------------------------------------------------------------------

    def gauge(self, canvas: "Canvas", eyebrow: str, value: str, fraction: float, caption: str, alpha: float = 1.0) -> None:
        """A readout panel under the top-right corner: label, a big value, a bar and a caption."""
        draw = canvas.draw
        a = int(255 * alpha)
        width, height = 250 * self.s, 104 * self.s
        x, y = self.W - 34 * self.s - width, 70 * self.s
        draw.rounded_rectangle((x, y, x + width, y + height), radius=10 * self.s, fill=SURFACE + (int(a * 0.86),),
                               outline=HAIRLINE + (a,), width=max(1, round(self.s)))
        draw.text((x + 14 * self.s, y + 11 * self.s), eyebrow, font=self.font(12, 600, mono=True), fill=INK3 + (a,))
        draw.text((x + 14 * self.s, y + 26 * self.s), value, font=self.font(34, 600), fill=INK + (a,))
        bar_y = y + 72 * self.s
        draw.rounded_rectangle((x + 14 * self.s, bar_y, x + width - 14 * self.s, bar_y + 5 * self.s), radius=3 * self.s,
                               fill=HAIRLINE + (a,))
        fill_to = x + 14 * self.s + (width - 28 * self.s) * min(1.0, max(0.0, fraction))
        if fill_to > x + 16 * self.s:
            draw.rounded_rectangle((x + 14 * self.s, bar_y, fill_to, bar_y + 5 * self.s), radius=3 * self.s, fill=PBR + (a,))
        draw.text((x + 14 * self.s, bar_y + 9 * self.s), caption, font=self.font(12, 500, mono=True), fill=INK2 + (a,))

    def caption(self, canvas: "Canvas", box: tuple[int, int, int, int], text: str, alpha: float = 1.0) -> None:
        """A small tag in a split-screen panel's lower-left corner naming the view."""
        draw = canvas.draw
        a = int(255 * alpha)
        font = self.font(12, 600, mono=True)
        pad, inset = 8 * self.s, 14 * self.s
        width = draw.textlength(text, font=font) + 2 * pad
        x, y = box[0] + inset, box[1] + box[3] - inset - 26 * self.s
        draw.rounded_rectangle((x, y, x + width, y + 26 * self.s), radius=6 * self.s, fill=SURFACE + (int(a * 0.86),),
                               outline=HAIRLINE + (a,), width=max(1, round(self.s)))
        draw.text((x + pad, y + 6 * self.s), text, font=font, fill=INK2 + (a,))

    def streaks(self, canvas: "Canvas", strength: float, t: float, count: int = 70) -> None:
        """Wind: thin lavender streaks flowing left to right, denser and faster as the wind rises."""
        if strength <= 0.01:
            return
        rng = np.random.default_rng(7)
        ys = rng.uniform(0.18, 0.92, count) * self.H
        phases = rng.uniform(0, 1, count)
        lengths = rng.uniform(60, 220, count) * self.s
        speeds = rng.uniform(0.6, 1.4, count)
        for i in range(int(count * min(1.0, 0.25 + strength))):
            travel = (phases[i] + t * speeds[i] * (0.25 + 1.6 * strength)) % 1.0
            x = -lengths[i] + travel * (self.W + 2 * lengths[i])
            wobble = math.sin(t * 3 + i) * 4 * self.s
            alpha = int(150 * min(1.0, strength * 1.3) * math.sin(math.pi * travel))
            canvas.draw.line([(x, ys[i] + wobble), (x + lengths[i] * (0.4 + strength), ys[i] + wobble)],
                             fill=(217, 204, 255, alpha), width=max(1, round(1.4 * self.s)))

    def wind_lines(self, canvas: "Canvas", segments: list, strength: float) -> None:
        """Wind: lavender lines already projected from the scene, ``((x0, y0), (x1, y1), fade)``."""
        if strength <= 0.01:
            return
        width = max(1, round(1.4 * self.s))
        for start, end, fade in segments:
            alpha = int(150 * min(1.0, strength * 1.3) * fade)
            if alpha > 2:
                canvas.draw.line([start, end], fill=(217, 204, 255, alpha), width=width)

    def dots(self, canvas: "Canvas", points: list) -> None:
        """Contact points: PBR-violet dots with a soft halo, fading with age (third value, 0..1)."""
        for x, y, age in points:
            fade = max(0.0, 1.0 - age)
            r = (4 + 6 * (1 - fade)) * self.s
            canvas.draw.ellipse((x - 2.4 * r, y - 2.4 * r, x + 2.4 * r, y + 2.4 * r), fill=GLOW + (int(60 * fade),))
            canvas.draw.ellipse((x - r, y - r, x + r, y + r), fill=PBR + (int(235 * fade),))

    # --- end card and outro ----------------------------------------------------------------------

    def card(self, frame: Image.Image, eyebrow: str, title: str, columns: list[str],
             rows: list[list[tuple[str, tuple]]], notes: list[str], alpha: float = 1.0) -> Image.Image:
        """The results over the last frame, dimmed to the canvas colour."""
        base = frame.convert("RGBA")
        layer = Image.new("RGBA", base.size, CANVAS + (int(236 * alpha),))
        draw = ImageDraw.Draw(layer)
        a = int(255 * alpha)
        pad = 56 * self.s
        draw.text((pad, pad), eyebrow, font=self.font(14, 600, mono=True), fill=PBR + (a,))
        draw.text((pad, pad + 24 * self.s), title, font=self.font(34, 600), fill=INK + (a,))
        head_font, body_font = self.font(11.5, 600, mono=True), self.font(15, 400)
        widths = [max([draw.textlength(columns[i].upper(), font=head_font)] +
                      [draw.textlength(row[i][0], font=body_font) for row in rows]) for i in range(len(columns))]
        gap = 26 * self.s
        total = sum(widths) + gap * (len(widths) - 1)
        if total > self.W - 2 * pad:  # too wide (portrait frames): tighten
            body_font = self.font(15 * (self.W - 2 * pad) / total, 400)
            head_font = self.font(11.5 * (self.W - 2 * pad) / total, 600, mono=True)
            widths = [w * (self.W - 2 * pad) / total for w in widths]
            gap *= (self.W - 2 * pad) / total
        xs, x = [], pad
        for width in widths:
            xs.append(x)
            x += width + gap
        top = pad + 88 * self.s
        for x, text in zip(xs, columns):
            draw.text((x, top), text.upper(), font=head_font, fill=INK3 + (a,))
        y = top + 26 * self.s
        draw.line([(pad, y - 7 * self.s), (xs[-1] + widths[-1], y - 7 * self.s)], fill=HAIRLINE + (a,), width=max(1, round(self.s)))
        for row in rows:
            for x, (text, colour) in zip(xs, row):
                draw.text((x, y), text, font=body_font, fill=colour + (a,))
            y += body_font.size * 2
        y += 16 * self.s
        note_font = self.font(14, 400)
        for note in notes[:8]:
            for line in _wrap(draw, note, note_font, self.W - 2 * pad):
                if y > self.H - 90 * self.s:
                    break
                draw.text((pad, y), line, font=note_font, fill=INK2 + (a,))
                y += note_font.size * 1.55
        mark = self.mark_of(20, 0.9 * alpha)
        layer.alpha_composite(mark, (int(pad), int(self.H - 34 * self.s - mark.height)))
        draw.text((pad + mark.width + 10 * self.s, self.H - 34 * self.s - mark.height / 2 - 8 * self.s), "marso.app",
                  font=self.font(14, 500, mono=True), fill=INK2 + (a,))
        return Image.alpha_composite(base, layer)

    def outro(self, t: float, line: str = "Sim-ready 3D assets") -> Image.Image:
        """The Marso lockup on the DL glow background, fading up over its first half second."""
        y, x = np.mgrid[0:self.H, 0:self.W].astype(np.float32)
        d = np.sqrt(((x - self.W / 2) / (0.62 * self.W)) ** 2 + ((y - self.H * 0.46) / (0.62 * self.H)) ** 2)
        glow = np.clip(1.0 - d, 0, 1) ** 1.8
        breath = 0.85 + 0.15 * math.sin(t * 2 * math.pi / 2.6)
        rgb = np.empty((self.H, self.W, 3), dtype=np.float32)
        for c in range(3):
            rgb[:, :, c] = CANVAS[c] + (PBR_FILL[c] - CANVAS[c]) * glow * breath + (GLOW[c] - PBR_FILL[c]) * glow ** 3 * 0.35
        image = Image.fromarray(np.clip(rgb, 0, 255).astype(np.uint8), "RGB").convert("RGBA")
        a = appear(t, 0.0, 0.6)
        mark = self.mark_of(min(self.W, self.H) * 0.22 / self.s, a)
        image.alpha_composite(mark, (int((self.W - mark.width) / 2), int(self.H * 0.42 - mark.height / 2)))
        draw = ImageDraw.Draw(image)
        b = appear(t, 0.35, 0.6)
        for text, font, colour, dy in ((line, self.font(30, 500), INK, 0.62), ("marso.app", self.font(16, 600, mono=True), PBR, 0.70)):
            width = draw.textlength(text, font=font)
            draw.text(((self.W - width) / 2, self.H * dy), text, font=font, fill=colour + (int(255 * b),))
        return image


class Canvas:
    """One frame's overlay layer: the elements draw here; ``Brand.dress`` composites it once."""

    def __init__(self, frame: Image.Image) -> None:
        self.frame = frame
        self.layer = Image.new("RGBA", frame.size, (0, 0, 0, 0))
        self.draw = ImageDraw.Draw(self.layer)


def _wrap(draw: ImageDraw.ImageDraw, text: str, font, width: float) -> list[str]:
    words, lines, current = text.split(), [], ""
    for word in words:
        trial = f"{current} {word}".strip()
        if draw.textlength(trial, font=font) <= width or not current:
            current = trial
        else:
            lines.append(current)
            current = word
    if current:
        lines.append(current)
    return lines


# --- encoding -------------------------------------------------------------------------------------


class FfmpegEncoder:
    def __init__(self, ffmpeg: str, path: Path, width: int, height: int, fps: int, bitrate: int) -> None:
        self.path = path
        self.process = subprocess.Popen(
            [ffmpeg, "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{width}x{height}",
             "-r", str(fps), "-i", "-", "-c:v", "libx264", "-pix_fmt", "yuv420p", "-preset", "slow",
             "-b:v", str(bitrate), "-maxrate", str(int(bitrate * 1.5)), "-bufsize", str(bitrate * 2),
             "-movflags", "+faststart", str(path)],
            stdin=subprocess.PIPE,
        )

    def write(self, image: Image.Image) -> None:
        self.process.stdin.write(image.convert("RGB").tobytes())

    def close(self) -> None:
        self.process.stdin.close()
        self.process.wait()


class KitEncoder:
    """Kit's NVENC encoder (``omni.videoencoding``). Only one can be open at a time."""

    def __init__(self, path: Path, fps: int, bitrate: int, frames: int = 0) -> None:
        import carb.settings
        from video_encoding import get_video_encoding_interface

        # Only the bitrate: the encoder's own preset (default, high-quality tuning, H.264 High) is
        # already its best, and forcing PRESET_P7 makes NVENC throw on some GPUs.
        carb.settings.get_settings().set("/exts/omni.videoencoding/bitrate", int(bitrate))
        self.path = path
        self._encoder = get_video_encoding_interface()
        if not self._encoder.start_encoding(str(path), float(fps), int(frames), True):
            raise RuntimeError(f"Could not start encoding {path.name}")

    def write(self, image: Image.Image) -> None:
        self._encoder.encode_next_frame_from_buffer(np.ascontiguousarray(np.asarray(image.convert("RGBA"))))

    def write_file(self, path: Path) -> None:
        self._encoder.encode_next_frame_from_file(str(path))

    def close(self) -> None:
        self._encoder.finalize_encoding()


def split_layout(width: int, height: int) -> list[tuple[int, int, int, int]]:
    """Three panels (x, y, w, h) for a split-screen frame: a big main view and two smaller ones.

    Landscape frames put the small views in a column on the right; portrait frames put them side
    by side under the main view. Thin gaps between panels show the canvas colour.
    """
    gap = max(4, round(min(width, height) * 0.008))
    if width >= height:
        main_w = round(width * 2 / 3 - gap / 2)
        side_x, side_w = main_w + gap, width - main_w - gap
        top_h = round(height / 2 - gap / 2)
        return [(0, 0, main_w, height), (side_x, 0, side_w, top_h), (side_x, top_h + gap, side_w, height - top_h - gap)]
    main_h = round(height * 0.62 - gap / 2)
    side_y, side_h = main_h + gap, height - main_h - gap
    left_w = round(width / 2 - gap / 2)
    return [(0, 0, width, main_h), (0, side_y, left_w, side_h), (left_w + gap, side_y, width - left_w - gap, side_h)]


class Recorder:
    """Renders a camera through a Replicator ``rgb`` annotator into a branded and/or a clean MP4.

    With ``views`` (camera path, panel box) it renders each camera at its panel's size in the same
    step and lays them out as one split-screen frame.
    """

    def __init__(self, camera_path: str, job: dict, branded: Path | None, clean: Path | None,
                 branded_frames: int = 0, clean_frames: int = 0, backdrop: Image.Image | None = None,
                 views: list[tuple[str, tuple[int, int, int, int]]] | None = None, open_ended: bool = False) -> None:
        import omni.replicator.core as rep

        self.backdrop = backdrop

        self._rep = rep
        self.W, self.H = int(job["width"]), int(job["height"])
        self.fps, self.subframes = int(job["fps"]), int(job["subframes"])
        self.path_traced = job.get("renderer") == "PathTracing"
        self.coverage, self.tone = 0.0, 0.0
        self._frame_counter = 0
        if self.path_traced:
            import carb.settings

            # Path tracing keeps accumulating while nothing moves, so a still shot froze on whatever it had
            # (the warm-up's 1-sample image). Restart the samples for every captured frame instead.
            settings = carb.settings.get_settings()
            settings.set_bool("/rtx-transient/resetPtAccumOnlyWhenExternalFrameCounterChanges", True)
            self._frame_counter = int(settings.get("/rtx/externalFrameCounter") or 0)
        self.views = views or [(camera_path, (0, 0, self.W, self.H))]
        self._panels = []  # (render product, annotator, box)
        for path, box in self.views:
            product = rep.create.render_product(path, (box[2], box[3]))
            annotator = rep.AnnotatorRegistry.get_annotator("rgb")
            annotator.attach(product)
            self._panels.append((product, annotator, box))
        self.render_product, self.annotator = self._panels[0][0], self._panels[0][1]
        self.frames = 0
        ffmpeg, bitrate = job.get("ffmpeg") or "", int(job["bitrate"])
        self.branded = self.clean = None
        self._spool: Path | None = None
        self._branded_spool: Path | None = None
        self._branded_path = branded
        self._branded_frames = 0
        self._clean_path = clean
        if open_ended and not ffmpeg:
            # The length is not known yet and Kit's encoder needs it: keep the frames, encode at the end.
            spool_root = Path(job["out_dir"])
            self._branded_spool = Path(tempfile.mkdtemp(prefix=".frames-branded-", dir=spool_root)) if branded else None
            self._spool = Path(tempfile.mkdtemp(prefix=".frames-clean-", dir=spool_root)) if clean else None
        elif ffmpeg:
            self.branded = FfmpegEncoder(ffmpeg, branded, self.W, self.H, self.fps, bitrate) if branded else None
            self.clean = FfmpegEncoder(ffmpeg, clean, self.W, self.H, self.fps, bitrate) if clean else None
        elif branded:
            self.branded = KitEncoder(branded, self.fps, bitrate, branded_frames)
            if clean:
                self._spool = Path(tempfile.mkdtemp(prefix="marso-clean-"))
        elif clean:
            self.clean = KitEncoder(clean, self.fps, bitrate, clean_frames)
        self._bitrate = bitrate
        self._clean_frames = 0
        self._clean_planned = clean_frames

    def grab(self, subframes: int | None = None) -> Image.Image:
        if self.path_traced:
            import carb.settings

            self._frame_counter += 1
            carb.settings.get_settings().set_int("/rtx/externalFrameCounter", self._frame_counter)
        self._rep.orchestrator.step(rt_subframes=subframes or self.subframes, delta_time=0.0, pause_timeline=False)
        if len(self._panels) == 1:
            return self._panel(self._panels[0][1], self._panels[0][2])
        frame = Image.new("RGB", (self.W, self.H), CANVAS)
        coverage = tone = 0.0
        for _product, annotator, box in self._panels:
            frame.paste(self._panel(annotator, box), (box[0], box[1]))
            coverage, tone = coverage + self.coverage / len(self._panels), tone + self.tone / len(self._panels)
        self.coverage, self.tone = coverage, tone
        return frame

    def _panel(self, annotator, box: tuple[int, int, int, int]) -> Image.Image:
        x, y, w, h = box
        backdrop = self.backdrop.crop((x, y, x + w, y + h)) if self.backdrop is not None else None
        data = annotator.get_data()
        if data is None or getattr(data, "size", 0) == 0:
            self.coverage = self.tone = 0.0
            return backdrop.copy() if backdrop is not None else Image.new("RGB", (w, h), CANVAS)
        pixels = np.asarray(data).astype(np.uint8)
        if pixels.shape[2] >= 4:  # how much of the frame holds rendered scene, and its average colour
            solid = pixels[:, :, 3] > 0
            self.coverage = float(solid.mean())
            self.tone = float(pixels[:, :, :3][solid].mean()) if solid.any() else 0.0
        if backdrop is None or pixels.shape[2] < 4:
            return Image.fromarray(pixels[:, :, :3], "RGB")
        # The background renders transparent (backgroundZeroAlpha); show the branded backdrop there.
        frame = Image.fromarray(pixels, "RGBA")
        return Image.alpha_composite(backdrop.convert("RGBA"), frame).convert("RGB")

    def warm_up(self, frames: int = 50) -> None:
        """Render until the scene is really there: geometry loaded (the frame is no longer empty) and
        textures in (its colour has stopped changing). Path tracing does this at 1 sample per pixel."""
        import carb.settings

        settings = carb.settings.get_settings()
        saved = {key: settings.get(key) for key in ("/rtx/pathtracing/spp", "/rtx/pathtracing/totalSpp")}
        if self.path_traced:
            for key in saved:
                settings.set(key, 1)
        history: list[tuple[float, float]] = []
        try:
            for index in range(400):
                self.coverage, self.tone = 0.0, 0.0
                self.grab(1 if self.path_traced else 4)
                history.append((self.coverage, self.tone))
                recent = history[-12:]
                if (index >= max(20, frames // 2) and len(recent) == 12 and recent[-1][0] > 0
                        and max(c for c, _ in recent) - min(c for c, _ in recent) < 0.002
                        and max(v for _, v in recent) - min(v for _, v in recent) < 0.6):
                    break
        finally:
            if self.path_traced:
                for key, value in saved.items():
                    if value is not None:
                        settings.set(key, value)
        self.grab()  # one full-quality frame so the accumulation starts from the finished scene

    def write(self, branded: Image.Image | None = None, clean: Image.Image | None = None) -> None:
        if branded is not None and self.branded is not None:
            self.branded.write(branded)
        elif branded is not None and self._branded_spool is not None:
            branded.convert("RGBA").save(self._branded_spool / f"{self._branded_frames:06d}.png", compress_level=1)
            self._branded_frames += 1
        if clean is not None:
            if self.clean is not None:
                self.clean.write(clean)
            elif self._spool is not None:
                clean.convert("RGBA").save(self._spool / f"{self._clean_frames:06d}.png", compress_level=1)
            self._clean_frames += 1
        self.frames += 1

    def close(self) -> None:
        for encoder in (self.branded, self.clean):
            if encoder is not None:
                encoder.close()
        if self._branded_spool is not None:
            encoder = KitEncoder(self._branded_path, self.fps, self._bitrate, self._branded_frames)
            for frame in sorted(self._branded_spool.glob("*.png")):
                encoder.write_file(frame)
            encoder.close()
            shutil.rmtree(self._branded_spool, ignore_errors=True)
        if self._spool is not None:
            encoder = KitEncoder(self._clean_path, self.fps, self._bitrate, self._clean_frames)
            for frame in sorted(self._spool.glob("*.png")):
                encoder.write_file(frame)
            encoder.close()
            shutil.rmtree(self._spool, ignore_errors=True)
        for product, annotator, _box in self._panels:
            annotator.detach()
            product.destroy()

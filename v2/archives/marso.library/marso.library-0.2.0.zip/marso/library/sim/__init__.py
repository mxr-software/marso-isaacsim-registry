"""Sim Studio's renderer: runs in its own headless Isaac Sim, started by the extension (``sim_service``).

Nothing here is imported by the extension itself: ``runner.py`` is launched with Isaac Sim's
standalone Python launcher and imports ``studio``, ``film`` and ``tests`` inside that process.
"""

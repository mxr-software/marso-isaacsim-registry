"""Robot arms for Sim Studio's robot tests: the robots, a table, and a tool that follows smooth paths.

The arms are NVIDIA's models from the Isaac Sim assets server (``RIGS``): a Franka Panda with its own
two-finger hand, a UR10 with a suction cup, and a UR10e with a Robotiq 2F-140 two-finger gripper.
Each tool follows minimum-jerk paths in space: every physics step, damped least-squares inverse
kinematics turns the planned motion into joint targets for the arm's own drives. Two-finger grips
hold objects by friction alone; the suction cup by its own hold, which lets go past its force limits.
Arms are driven through PhysX's articulation view directly (the higher-level wrappers rewrite the
stage, which breaks the Robotiq's mimic joints).
"""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np
from pxr import Gf, Sdf, Usd, UsdGeom, UsdLux, UsdPhysics, UsdShade

from ..core import grasp as grasp_plan
from ..core import sim_metrics as metrics

FRANKA_USD = "/Isaac/Robots/FrankaRobotics/FrankaPanda/franka.usd"
DEFAULT_ASSETS_ROOT = "https://omniverse-content-production.s3-us-west-2.amazonaws.com/Assets/Isaac/6.0"
HOME = [0.012, -0.568, 0.0, -2.811, 0.0, 3.037, 0.741, 0.04, 0.04]  # arm ready, hand down, fingers open
DOWN = np.array([0.0, 1.0, 0.0, 0.0])  # hand pointing straight down (w, x, y, z)
HAND = grasp_plan.FRANKA_HAND
WINDUP = 0.2  # radians the joint targets may lead the joints
CORRECTION = 0.04  # share of the gap to the planned pose closed each step
POSTURE_PULL = 0.01  # share of the way back to the home posture, per step, for a seven-joint arm
GRIP_N = grasp_plan.GRIP_N
ROBOTIQ_SHUT = 0.771  # radians of the Robotiq's finger joint at which its empty fingers meet (measured)
PAD_RADIUS = 0.012  # metres: the rubber fingertip's contact patch, resisting twist


def assets_root() -> str:
    """Where Isaac Sim's own assets live (the configured server, else NVIDIA's public one)."""
    import carb

    try:
        from isaacsim.storage.native import get_assets_root_path

        root = get_assets_root_path()
    except Exception:  # noqa: BLE001 - offline, or the extension is not loaded
        root = None
    return root or carb.settings.get_settings().get("/persistent/isaac/asset_root/default") or DEFAULT_ASSETS_ROOT


@dataclass(frozen=True)
class Rig:
    """One robot arm and its tool, as the robot tests need to know it."""

    key: str
    name: str  # for results cards
    usd: str  # under the assets root
    variants: tuple  # (variant set, choice) pairs
    tool_link: str  # the articulation link the inverse kinematics drives
    tool_prim: str  # that link's prim, under the robot
    tool_axis: tuple  # in the tool link's frame: from the flange out towards the tip
    tip_prims: tuple  # prims whose far end along the tool axis is the tool's tip
    arm_dofs: int
    home: tuple  # arm joint positions: the tool pointing down above the table's front
    gripper: str  # "franka", "robotiq" or "suction"
    payload_kg: float
    base_link: str  # the prim the logo goes on
    height: float  # how far the arm reaches up above its base, for framing
    hand: grasp_plan.Hand | None = None  # two-finger grippers
    cup: grasp_plan.Cup | None = None  # suction
    finger_links: tuple = ()  # two-finger grippers: the links on either side (their gap gives the closing axis)
    finger_dofs: tuple = ()  # the joints driven to open and close
    pad_prims: tuple = ()  # prims that get rubber pads
    grip_n: float = GRIP_N
    suction_prim: str = ""
    finger_closed: float = 0.0  # the Robotiq's finger joint, closed (radians)
    # A humanoid: its arm is some of its joints, the rest hold a pose, it stands on the floor pinned
    # at ``pin_link`` (no balancing), and its many-jointed hand opens and shuts to set joint angles.
    arm_joints: tuple = ()  # the arm's joints by name, shoulder to wrist (else the first ``arm_dofs``)
    body_pose: tuple = ()  # (joint, angle) the other joints hold
    hand_open: tuple = ()  # (joint, angle) for the open hand
    hand_shut: tuple = ()  # (joint, angle) the hand closes towards
    hand_force: float = 0.0  # torque cap on each hand joint (N m)
    mimic: tuple = ()  # (natural frequency, damping ratio) for the hand's mimic joints, when the model's are too loose
    arm_gains: tuple = ()  # (stiffness, damping) for the arm's drives, when the model's do not suit
    pin_link: str = ""  # the link pinned to the world, for a robot standing on the floor
    stand_height: float = 0.0  # how high that link stands above the floor
    closing: tuple = ()  # the closing axis in the tool frame, when finger links cannot give it
    tip_length: float = 0.0  # how far the grip reaches along the tool axis, when tip prims cannot give it
    grip_point: tuple = ()  # in the tool frame: between the fingertips, when not straight out along the tool axis
    curl: float = 0.0  # metres the fingertips rise as they close (a hand's fingers curl): it starts that much lower
    pad_friction: float = 1.0  # the finger pads' friction, as a multiple of each asset's own
    # The grip is assisted: once the fingers have closed on an object it moves with the hand, for as long
    # as its weight and swing stay within what the pinch's friction holds (``Arm.take_hold``).
    assisted_grip: bool = False
    partner: str = ""  # the robot's other arm (a rig key), for a humanoid using both hands
    wrist_roll: bool = True  # whether the arm's last joint turns the tool about its axis
    yaw_band: float = 0.0  # degrees either side of its usual closing direction the hand can grip at (0: any)


# The Unitree G1: its right arm reaches, the rest of it stands still; its Inspire hand pinches with the
# thumb (turned to face the fingers) against its index and middle fingers, ring and little finger tucked in.
G1_RIGHT_ARM = ("right_shoulder_pitch_joint", "right_shoulder_roll_joint", "right_shoulder_yaw_joint", "right_elbow_joint",
                "right_wrist_roll_joint", "right_wrist_pitch_joint", "right_wrist_yaw_joint")
G1_READY = (-0.213, -0.239, 0.235, -0.567, -1.184, -0.032, 1.36)  # the hand pointing down above the table, closing 60 deg right of its left
G1_BODY = (("left_shoulder_pitch_joint", 0.25), ("left_shoulder_roll_joint", 0.18), ("left_elbow_joint", 0.9),
           ("left_wrist_roll_joint", 0.0))  # the left arm lowered, elbow bent, out of the way
# Only the knuckles and the thumb's swing and bend are driven: each finger's middle joint (and the
# thumb's outer two) follow on a mimic joint, as the real hand's linkage does.
_G1_TUCKED = (("R_ring_proximal_joint", 1.7), ("R_pinky_proximal_joint", 1.7), ("R_thumb_proximal_yaw_joint", 1.3))
G1_PINCH_OPEN = _G1_TUCKED + (("R_thumb_proximal_pitch_joint", 0.05), ("R_index_proximal_joint", 0.5), ("R_middle_proximal_joint", 0.5))
G1_PINCH_SHUT = _G1_TUCKED + (("R_thumb_proximal_pitch_joint", 0.5), ("R_index_proximal_joint", 1.4), ("R_middle_proximal_joint", 1.4))

# The left arm mirrors the right across the robot's middle: its roll and yaw joints turn the other way,
# and in its hand's frame the palm-normal axis (y) is flipped (measured: the mirrored pose puts the left
# hand within a millimetre of the right one's mirror image).
G1_LEFT_ARM = tuple(n.replace("right_", "left_") for n in G1_RIGHT_ARM)
G1_LEFT_READY = tuple(-v if ("roll" in n or "yaw" in n) else v for n, v in zip(G1_RIGHT_ARM, G1_READY))


def _left_hand(joints: tuple) -> tuple:
    return tuple((n.replace("R_", "L_", 1), v) for n, v in joints)


RIGS = {
    "franka": Rig("franka", "Franka Panda", FRANKA_USD, (("Gripper", "AlternateFinger"), ("Mesh", "Quality")),
                  "panda_hand", "panda_hand", (0.0, 0.0, 1.0), ("panda_leftfinger",), 7, tuple(HOME[:7]), "franka",
                  3.0, "panda_link0", 0.85, hand=grasp_plan.FRANKA_HAND,
                  finger_links=("panda_leftfinger", "panda_rightfinger"), finger_dofs=("panda_finger_joint1", "panda_finger_joint2"),
                  pad_prims=("panda_leftfinger", "panda_rightfinger")),
    "ur10_suction": Rig("ur10_suction", "UR10 with a suction cup", "/Isaac/Robots/UniversalRobots/ur10/ur10.usd",
                        (("Gripper", "Short_Suction"),), "ee_link", "ee_link", (1.0, 0.0, 0.0), ("ee_link",), 6,
                        (0.0, -math.pi / 2, math.pi / 2, -math.pi / 2, -math.pi / 2, 0.0), "suction", 10.0, "base_link", 1.0,
                        cup=grasp_plan.SUCTION_CUP, suction_prim="ee_link/SurfaceGripper"),
    "ur10e_wide": Rig("ur10e_wide", "UR10e with a Robotiq 2F-140", "/Isaac/Robots/UniversalRobots/ur10e/ur10e.usd",
                      (("Gripper", "Robotiq_2f_140"),), "robotiq_base_link", "ee_link/robotiq_base_link", (0.0, 0.0, 1.0),
                      ("ee_link/left_inner_finger", "ee_link/right_inner_finger"), 6,
                      (0.0, -math.pi / 2, math.pi / 2, -math.pi / 2, -math.pi / 2, 0.0), "robotiq", 11.0, "base_link", 1.0,
                      hand=grasp_plan.ROBOTIQ_2F140, finger_links=("left_inner_finger", "right_inner_finger"),
                      finger_dofs=("finger_joint",), pad_prims=("ee_link/left_inner_finger", "ee_link/right_inner_finger"),
                      grip_n=100.0, finger_closed=0.785),
    "g1_inspire": Rig("g1_inspire", "Unitree G1 humanoid with Inspire hands", "/Isaac/Robots/Unitree/G1/g1.usd",
                      (("right_hand", "Inspire"), ("left_hand", "Inspire"), ("Physics", "PhysX"), ("Thor", "None")),
                      "R_hand_base_link", "right_hand/R_hand_base_link", (0.633, 0.774, 0.0), (), 7,
                      G1_READY, "hand", 1.5, "torso_link", 1.32, hand=grasp_plan.INSPIRE_PINCH,
                      arm_joints=G1_RIGHT_ARM, body_pose=G1_BODY, hand_open=G1_PINCH_OPEN, hand_shut=G1_PINCH_SHUT,
                      hand_force=3.0, mimic=(120.0, 0.8), curl=0.012, pad_friction=2.0, assisted_grip=True, arm_gains=(400.0, 40.0), pin_link="pelvis", stand_height=0.793,
                      closing=(0.774, -0.633, 0.0), tip_length=0.155, grip_point=(0.1535, 0.075, 0.0245), wrist_roll=False,
                      grip_n=35.0, yaw_band=40.0,
                      pad_prims=("right_hand/R_thumb_distal", "right_hand/R_index_intermediate", "right_hand/R_middle_intermediate"),
                      partner="g1_inspire_left"),
    "g1_inspire_left": Rig("g1_inspire_left", "Unitree G1 humanoid with Inspire hands", "/Isaac/Robots/Unitree/G1/g1.usd", (),
                           "L_hand_base_link", "left_hand/L_hand_base_link", (0.633, -0.774, 0.0), (), 7,
                           G1_LEFT_READY, "hand", 1.5, "torso_link", 1.32, hand=grasp_plan.INSPIRE_PINCH,
                           arm_joints=G1_LEFT_ARM, hand_open=_left_hand(G1_PINCH_OPEN), hand_shut=_left_hand(G1_PINCH_SHUT),
                           hand_force=3.0, curl=0.012, pad_friction=2.0, assisted_grip=True, arm_gains=(400.0, 40.0),
                           closing=(0.774, 0.633, 0.0), tip_length=0.155, grip_point=(0.1535, -0.075, 0.0245), wrist_roll=False,
                           grip_n=35.0, yaw_band=40.0,
                           pad_prims=("left_hand/L_thumb_distal", "left_hand/L_index_intermediate", "left_hand/L_middle_intermediate")),
}


def add_robot(stage: Usd.Stage, path: str, position, yaw_deg: float, rig: Rig) -> Usd.Prim:
    """Reference ``rig``'s robot at ``position`` (its base on the table), turned ``yaw_deg`` about Z.

    The model comes from Isaac Sim's asset server, downloaded the first time it is used: raises a
    RuntimeError that says so when it cannot be loaded (offline, say)."""
    if rig.gripper == "suction":
        enable_suction()  # before the simulation starts, so the cup is set up with it
    url = assets_root() + rig.usd
    prim = UsdGeom.Xform.Define(stage, path).GetPrim()
    prim.GetReferences().AddReference(url)
    if not prim.GetChildren():
        raise RuntimeError(f"Could not load the {rig.name} robot from {url}. The robot tests download NVIDIA's "
                           "robot models the first time they run: check this computer's internet connection, "
                           "or point Isaac Sim's asset root at a local copy of its assets.")
    for name, choice in rig.variants:
        variants = prim.GetVariantSets()
        if variants.HasVariantSet(name):
            names = variants.GetVariantSet(name).GetVariantNames()
            pick = next((n for n in names if n.lower() == choice.lower()), None)
            if pick:
                variants.GetVariantSet(name).SetVariantSelection(pick)
    lights_off(stage, prim)
    if rig.mimic:
        # The model's finger linkages are loose springs (25 Hz, almost undamped): the fingers flopped
        # instead of curling. Stiff and damped, they move as one piece with their knuckle.
        frequency, ratio = rig.mimic
        for joint in Usd.PrimRange(prim, Usd.TraverseInstanceProxies()):
            for schema in joint.GetAppliedSchemas():
                if schema.startswith("PhysxMimicJointAPI:") and not joint.IsInstanceProxy():
                    axis = schema.split(":", 1)[1]
                    joint.GetAttribute(f"physxMimicJoint:{axis}:naturalFrequency").Set(float(frequency))
                    joint.GetAttribute(f"physxMimicJoint:{axis}:dampingRatio").Set(float(ratio))
    if rig.cup is not None and rig.suction_prim:
        cup = stage.GetPrimAtPath(f"{path}/{rig.suction_prim}")
        if not cup:
            raise RuntimeError(f"The {rig.name} model has no suction gripper at {rig.suction_prim}.")

        def limit(name: str, value: float) -> None:
            attr = cup.GetAttribute(name)
            if not attr:
                attr = cup.CreateAttribute(name, Sdf.ValueTypeNames.Float)
            attr.Set(float(value))

        # A real cup lets go past its limits (the model ships with none set).
        limit("isaac:coaxialForceLimit", rig.cup.hold_n)
        limit("isaac:shearForceLimit", rig.cup.shear_n)
        # Keep trying to seal for a moment after switching on, as a real cup's vacuum builds.
        limit("isaac:retryInterval", 1.0)
    xform = UsdGeom.Xformable(prim)
    xform.ClearXformOpOrder()
    xform.AddTranslateOp().Set(Gf.Vec3d(*map(float, position)))
    xform.AddRotateZOp().Set(float(yaw_deg))
    if rig.pin_link:
        # Standing on the floor without balancing: the pinned link is held where it stands.
        link = next((p for p in Usd.PrimRange(prim) if p.GetName() == rig.pin_link), None)
        if link is None:
            raise RuntimeError(f"The {rig.name} model has no {rig.pin_link} to stand it by.")
        pin = UsdPhysics.FixedJoint.Define(stage, f"{path}Pin")
        pin.CreateBody1Rel().SetTargets([link.GetPath()])
        pin.CreateLocalPos0Attr(Gf.Vec3f(*map(float, position)))
        half = math.radians(yaw_deg) / 2
        pin.CreateLocalRot0Attr(Gf.Quatf(math.cos(half), 0.0, 0.0, math.sin(half)))
        pin.CreateLocalPos1Attr(Gf.Vec3f(0.0, 0.0, 0.0))
        pin.CreateLocalRot1Attr(Gf.Quatf(1.0, 0.0, 0.0, 0.0))
    return prim


def lights_off(stage: Usd.Stage, root: Usd.Prim) -> int:
    """Switch off lights that come with a model (the UR10 carries a very bright one on its tool): the
    studio lights the set. Returns how many."""
    paths = [p.GetPath() for p in Usd.PrimRange(root, Usd.TraverseInstanceProxies())
             if p.HasAPI(UsdLux.LightAPI) or p.GetTypeName().endswith("Light")]
    for path in paths:
        light = stage.GetPrimAtPath(path)
        while light.IsInstanceProxy():  # open up the instance it sits in, to edit it
            holder = light.GetParent()
            while not holder.IsInstance():
                holder = holder.GetParent()
            holder.SetInstanceable(False)
            light = stage.GetPrimAtPath(path)
        light.SetActive(False)
    return len(paths)


def enable_suction() -> None:
    """Load Isaac Sim's surface gripper (suction cup) extension if it is not loaded yet."""
    import omni.kit.app

    manager = omni.kit.app.get_app().get_extension_manager()
    if not manager.is_extension_enabled("isaacsim.robot.surface_gripper"):
        manager.set_extension_enabled_immediate("isaacsim.robot.surface_gripper", True)


def reset_suction(update) -> None:
    """Have Isaac Sim's surface gripper find this stage's suction cup when physics starts.

    It looks for cups on the first physics step after the timeline stops. Sim Studio steps physics
    itself and never plays the timeline, so after any earlier test in the same run the new stage's
    cup was never found ("Gripper not found") and the suction test could not take hold. Playing and
    stopping the timeline, a frame apart and before physics starts, resets it. ``update`` runs one
    app frame.
    """
    import omni.timeline

    timeline = omni.timeline.get_timeline_interface()
    timeline.play()
    timeline.commit()
    update()  # in the same frame, the play and stop cancel out and the gripper never sees a stop
    timeline.stop()
    timeline.commit()
    update()


def add_franka(stage: Usd.Stage, path: str, position, yaw_deg: float) -> Usd.Prim:
    """Reference the Franka at ``position`` (its base on the table), turned ``yaw_deg`` about Z."""
    return add_robot(stage, path, position, yaw_deg, RIGS["franka"])


def pad_fingers(stage: Usd.Stage, path: str, fingers: tuple = ("panda_leftfinger", "panda_rightfinger"),
                friction: float = 1.0) -> int:
    """Rubber fingertips, like the real hand's: the grip's friction is the asset's own (the pads
    multiply it by 1.0, as the studio floor does), or ``friction`` times it for softer, grippier pads,
    and the soft pads resist twisting.

    Returns how many finger colliders got the twist resistance (none when they sit inside instances).
    """
    from pxr import PhysxSchema  # Isaac Sim's own schema, not in plain USD

    looks = f"{path}_Looks/FingerPads"
    material = UsdShade.Material.Define(stage, looks)
    physics = UsdPhysics.MaterialAPI.Apply(material.GetPrim())
    physics.CreateStaticFrictionAttr(float(friction))
    physics.CreateDynamicFrictionAttr(float(friction))
    physics.CreateRestitutionAttr(0.0)
    physx = PhysxSchema.PhysxMaterialAPI.Apply(material.GetPrim())
    physx.CreateFrictionCombineModeAttr("multiply")
    physx.CreateRestitutionCombineModeAttr("min")
    padded = 0
    for finger in fingers:
        link = stage.GetPrimAtPath(f"{path}/{finger}")
        if not link:
            continue
        UsdShade.MaterialBindingAPI.Apply(link).Bind(material, UsdShade.Tokens.strongerThanDescendants, "physics")
        # The model shares its finger meshes between instances; give these fingers their own copy so
        # their colliders can take the pad settings.
        for prim in Usd.PrimRange(link):
            if prim.IsInstance():
                prim.SetInstanceable(False)
        for prim in Usd.PrimRange(link):
            if prim.HasAPI(UsdPhysics.CollisionAPI) and not prim.IsInstanceProxy():
                collision = PhysxSchema.PhysxCollisionAPI.Apply(prim)
                # The pad is about 2 cm across and soft: it presses flat over most of that.
                collision.CreateTorsionalPatchRadiusAttr(PAD_RADIUS)
                collision.CreateMinTorsionalPatchRadiusAttr(PAD_RADIUS / 2)
                padded += 1
    return padded


def add_table(stage: Usd.Stage, path: str, size_x: float, size_y: float, top_z: float, material: UsdShade.Material,
              leg_material: UsdShade.Material) -> None:
    """A table: a slab you can see and collide with, on four legs (seen only)."""
    UsdGeom.Xform.Define(stage, path)
    slab = UsdGeom.Cube.Define(stage, f"{path}/Top")
    slab.CreateSizeAttr(1.0)
    thick = 0.04
    slab.AddTranslateOp().Set(Gf.Vec3d(0, 0, top_z - thick / 2))
    slab.AddScaleOp().Set(Gf.Vec3f(size_x, size_y, thick))
    UsdPhysics.CollisionAPI.Apply(slab.GetPrim())
    UsdShade.MaterialBindingAPI.Apply(slab.GetPrim()).Bind(material)
    inset, leg = 0.08, 0.05
    for i, (sx, sy) in enumerate(((-1, -1), (1, -1), (-1, 1), (1, 1))):
        post = UsdGeom.Cube.Define(stage, f"{path}/Leg{i}")
        post.CreateSizeAttr(1.0)
        post.AddTranslateOp().Set(Gf.Vec3d(sx * (size_x / 2 - inset), sy * (size_y / 2 - inset), (top_z - thick) / 2))
        post.AddScaleOp().Set(Gf.Vec3f(leg, leg, top_z - thick))
        UsdShade.MaterialBindingAPI.Apply(post.GetPrim()).Bind(leg_material)


def oriented_surface_of(root: Usd.Prim) -> tuple[np.ndarray, np.ndarray, np.ndarray | None]:
    """The asset's surface samples with outward normals, and its centre of mass, all in world space."""
    cache = UsdGeom.XformCache()
    centres, normals, all_points, all_tris, offset = [], [], [], [], 0
    for prim in Usd.PrimRange(root, Usd.TraverseInstanceProxies(Usd.PrimDefaultPredicate)):
        if not prim.IsA(UsdGeom.Mesh) or UsdGeom.Imageable(prim).ComputePurpose() in ("guide", "proxy"):
            continue
        mesh = UsdGeom.Mesh(prim)
        points, counts, indices = (mesh.GetPointsAttr().Get(), mesh.GetFaceVertexCountsAttr().Get(),
                                   mesh.GetFaceVertexIndicesAttr().Get())
        if not points or not counts or not indices:
            continue
        matrix = np.array(cache.GetLocalToWorldTransform(prim), dtype=np.float64)
        world = np.asarray(points, dtype=np.float64) @ matrix[:3, :3] + matrix[3, :3]
        tris = metrics.fan_triangles(counts, indices)
        if mesh.GetOrientationAttr().Get() == UsdGeom.Tokens.leftHanded:
            tris = tris[:, [0, 2, 1]]
        c, n = grasp_plan.oriented_surface(world, tris)
        centres.append(c)
        normals.append(n)
        all_points.append(world)
        all_tris.append(tris + offset)
        offset += len(world)
    if not centres:
        return np.zeros((0, 3)), np.zeros((0, 3)), None
    com = grasp_plan.volume_centroid(np.concatenate(all_points), np.concatenate(all_tris))
    return np.concatenate(centres), np.concatenate(normals), com


def quat_mul(a, b) -> np.ndarray:
    aw, ax, ay, az = a
    bw, bx, by, bz = b
    return np.array([aw * bw - ax * bx - ay * by - az * bz, aw * bx + ax * bw + ay * bz - az * by,
                     aw * by - ax * bz + ay * bw + az * bx, aw * bz + ax * by - ay * bx + az * bw])


def quat_conj(q) -> np.ndarray:
    return np.array([q[0], -q[1], -q[2], -q[3]])


def yaw_quat(yaw: float) -> np.ndarray:
    return np.array([math.cos(yaw / 2), 0.0, 0.0, math.sin(yaw / 2)])


def slerp(a, b, t: float) -> np.ndarray:
    a, b = np.asarray(a, float), np.asarray(b, float)
    dot = float(a @ b)
    if dot < 0:
        b, dot = -b, -dot
    if dot > 0.9995:
        q = a + t * (b - a)
        return q / np.linalg.norm(q)
    theta = math.acos(dot)
    return (math.sin((1 - t) * theta) * a + math.sin(t * theta) * b) / math.sin(theta)


def hand_down(yaw: float) -> np.ndarray:
    """The hand pointing down, turned so its fingers close along the horizontal direction ``yaw``.

    Pointing down, the fingers close along world -Y; turning by ``psi`` about Z makes that
    (sin psi, -cos psi), which is the closing direction (cos yaw, sin yaw) when psi = yaw + 90 deg.
    """
    return quat_mul(yaw_quat(yaw + math.pi / 2), DOWN)


def tool_down(tool_axis, closing_axis, yaw: float) -> np.ndarray:
    """The tool pointing straight down, its closing axis along the horizontal direction ``yaw`` (w, x, y, z)."""
    t = np.asarray(tool_axis, float)
    c = np.asarray(closing_axis, float)
    c = c - (c @ t) * t
    c /= np.linalg.norm(c)
    world = np.column_stack([[0.0, 0.0, -1.0], [math.cos(yaw), math.sin(yaw), 0.0],
                             np.cross([0.0, 0.0, -1.0], [math.cos(yaw), math.sin(yaw), 0.0])])
    local = np.column_stack([t, c, np.cross(t, c)])
    return _quat_from_matrix(world @ local.T)


def _quat_from_matrix(m: np.ndarray) -> np.ndarray:
    """(w, x, y, z) for a rotation matrix acting on column vectors."""
    trace = m[0, 0] + m[1, 1] + m[2, 2]
    if trace > 0:
        s = 2.0 * math.sqrt(trace + 1.0)
        q = [0.25 * s, (m[2, 1] - m[1, 2]) / s, (m[0, 2] - m[2, 0]) / s, (m[1, 0] - m[0, 1]) / s]
    elif m[0, 0] > m[1, 1] and m[0, 0] > m[2, 2]:
        s = 2.0 * math.sqrt(1.0 + m[0, 0] - m[1, 1] - m[2, 2])
        q = [(m[2, 1] - m[1, 2]) / s, 0.25 * s, (m[0, 1] + m[1, 0]) / s, (m[0, 2] + m[2, 0]) / s]
    elif m[1, 1] > m[2, 2]:
        s = 2.0 * math.sqrt(1.0 + m[1, 1] - m[0, 0] - m[2, 2])
        q = [(m[0, 2] - m[2, 0]) / s, (m[0, 1] + m[1, 0]) / s, 0.25 * s, (m[1, 2] + m[2, 1]) / s]
    else:
        s = 2.0 * math.sqrt(1.0 + m[2, 2] - m[0, 0] - m[1, 1])
        q = [(m[1, 0] - m[0, 1]) / s, (m[0, 2] + m[2, 0]) / s, (m[1, 2] + m[2, 1]) / s, 0.25 * s]
    q = np.array(q)
    return q / np.linalg.norm(q)


class Arm:
    """A robot arm and its tool, driven through its joint drives. Create after physics has started.

    It works through PhysX's articulation view (``SimulationManager``'s simulation view): the tool
    pose is its link's transform, the inverse kinematics uses that link's Jacobian, and the gripper is
    the rig's own (finger joints, or a surface gripper for suction).
    """

    def __init__(self, path: str, hz: float, rig: Rig | None = None, share: "Arm | None" = None) -> None:
        import omni.usd
        from isaacsim.core.simulation_manager import SimulationManager

        self.rig = rig or RIGS["franka"]
        self.path = path
        stage = omni.usd.get_context().get_stage()
        robot = stage.GetPrimAtPath(path)
        root = next((p for p in Usd.PrimRange(robot) if p.HasAPI(UsdPhysics.ArticulationRootAPI)), robot)
        self.view = SimulationManager.get_physics_sim_view().create_articulation_view(root.GetPath().pathString)
        meta = self.view.shared_metatype
        self.dof_names, self.link_names = list(meta.dof_names), list(meta.link_names)
        self._ids = np.array([0], dtype=np.int32)
        self.n = self.rig.arm_dofs
        self.tool_index = self.link_names.index(self.rig.tool_link)
        # The arm's joints among all the robot's; a floating base (a pinned humanoid) adds six base
        # columns to the Jacobian and a row for its root link.
        self.arm_ids = ([self.dof_names.index(n) for n in self.rig.arm_joints] if self.rig.arm_joints
                        else list(range(self.n)))
        shape = np.asarray(self.view.get_jacobians()).shape
        floating = shape[-1] == len(self.dof_names) + 6
        self._jac_row = self.tool_index if floating else self.tool_index - 1
        self._jac_cols = [i + (6 if floating else 0) for i in self.arm_ids]
        self.hz = float(hz)
        self._command: np.ndarray | None = None
        self._last: tuple[np.ndarray, np.ndarray] | None = None
        # Two arms of one robot (a humanoid's) keep one copy of the robot's joint targets between them:
        # each writes them all, so separate copies would undo each other's.
        self._share = share
        self._targets = None
        self.tool_axis = np.asarray(self.rig.tool_axis, float)
        self.closing_axis = self._closing_axis()
        self.tip = self._tip(stage)
        # Between the fingertips, in the tool frame: straight out along the tool axis for a gripper; off
        # to one side for a hand pinching between its thumb and fingers.
        self.grip_point = np.asarray(self.rig.grip_point, float) if self.rig.grip_point else self.tip * self.tool_axis
        self.finger_ids = [self.dof_names.index(n) for n in self.rig.finger_dofs if n in self.dof_names]
        if self.rig.gripper == "franka" and len(self.finger_ids) != 2:
            self.finger_ids = [self.n, self.n + 1]  # the two finger joints follow the arm's seven
        if self.rig.gripper == "hand":
            self._hand_open = {self.dof_names.index(n): v for n, v in self.rig.hand_open}
            self._hand_shut = {self.dof_names.index(n): v for n, v in self.rig.hand_shut}
            self.finger_ids = sorted(set(self._hand_open) | set(self._hand_shut))
        if self.rig.arm_gains:
            stiffness, damping = self.rig.arm_gains
            self._set_all(self.view.get_dof_stiffnesses, self.view.set_dof_stiffnesses, {i: stiffness for i in self.arm_ids})
            self._set_all(self.view.get_dof_dampings, self.view.set_dof_dampings, {i: damping for i in self.arm_ids})
        self.open_gap = self.rig.hand.opening if self.rig.hand is not None else 1.0
        self._suction = None
        self._sucking = False
        self.planned_width = None  # the width of the grip the hand is taking (for captions)
        self._held = None  # an assisted grip's object, while it holds
        self.posture = POSTURE_PULL  # how hard a seven-joint arm leans back to its home posture (0: not at all)
        if self.rig.gripper == "suction":
            enable_suction()
            from isaacsim.robot.surface_gripper import _surface_gripper

            self._suction = _surface_gripper.acquire_surface_gripper_interface()
            self._suction_path = f"{path}/{self.rig.suction_prim}"

    # --- reading ------------------------------------------------------------------------------

    @property
    def _targets(self) -> np.ndarray | None:
        owner = self.__dict__.get("_share")
        return owner._targets if owner is not None else self.__dict__.get("_own_targets")

    @_targets.setter
    def _targets(self, value) -> None:
        owner = self.__dict__.get("_share")
        if owner is not None:
            owner._targets = value
        else:
            self.__dict__["_own_targets"] = value

    def _links(self) -> np.ndarray:
        return np.asarray(self.view.get_link_transforms())[0]

    def hand_pose(self) -> tuple[np.ndarray, np.ndarray]:
        """The tool link's position and orientation (w, x, y, z)."""
        t = self._links()[self.tool_index]
        return np.asarray(t[:3], np.float64), np.array([t[6], t[3], t[4], t[5]], np.float64)

    def _closing_axis(self) -> np.ndarray:
        """In the tool frame: from one finger to the other (any axis square to the tool, for a cup)."""
        t = self.tool_axis
        spare = np.array([0.0, 1.0, 0.0]) if abs(t[1]) < 0.9 else np.array([1.0, 0.0, 0.0])
        if self.rig.closing:
            spare = np.asarray(self.rig.closing, float)
        elif len(self.rig.finger_links) == 2 and all(n in self.link_names for n in self.rig.finger_links):
            links = self._links()
            p = [np.asarray(links[self.link_names.index(n)][:3], float) for n in self.rig.finger_links]
            _p, q = self.hand_pose()
            spare = _matrix(q).T @ (p[0] - p[1])
        spare = spare - (spare @ t) * t
        return spare / np.linalg.norm(spare)

    def _tip(self, stage) -> float:
        """How far the tool's tip reaches beyond the tool link's origin, along the tool axis."""
        if self.rig.tip_length:
            return float(self.rig.tip_length)
        tool = stage.GetPrimAtPath(f"{self.path}/{self.rig.tool_prim}")
        cache = UsdGeom.BBoxCache(Usd.TimeCode.Default(), [UsdGeom.Tokens.default_, UsdGeom.Tokens.render])
        reach = 0.0
        for rel in self.rig.tip_prims:
            prim = stage.GetPrimAtPath(f"{self.path}/{rel}")
            if not prim or not tool:
                continue
            box = cache.ComputeRelativeBound(prim, tool).ComputeAlignedRange()
            if box.IsEmpty():
                continue
            corners = np.array([[x, y, z] for x in (box.GetMin()[0], box.GetMax()[0])
                                for y in (box.GetMin()[1], box.GetMax()[1]) for z in (box.GetMin()[2], box.GetMax()[2])])
            reach = max(reach, float((corners @ self.tool_axis).max()))
        return reach or 0.1034 + 0.005

    def check_suction(self) -> None:
        """Raise if Isaac Sim has not set up the suction cup: it would never take hold, and every object
        would look as if it slipped. (Opening a cup Isaac Sim does not know about returns False.)"""
        if self._suction is not None and not self._suction.open_gripper(self._suction_path):
            raise RuntimeError(f"Isaac Sim did not set up the {self.rig.name}'s suction gripper. Run the test again.")

    def suction_report(self) -> dict:
        """The suction gripper's state and what it holds."""
        if self._suction is None:
            return {}
        try:
            return {"status": str(self._suction.get_gripper_status_batch([self._suction_path])[0]),
                    "holding": list(self._suction.get_gripped_objects_batch([self._suction_path])[0])}
        except Exception as exc:  # noqa: BLE001 - report it rather than stop the run
            return {"error": str(exc)[:120]}

    def cloud(self, links: tuple = ()) -> np.ndarray:
        """World points over the tool and its fingers (or ``links``) as they are now (for another arm
        to keep clear of)."""
        import omni.usd

        names = links or (self.rig.tool_link, *self.rig.finger_links)
        if getattr(self, "_local_clouds", None) is None:
            self._local_clouds = {}
        missing = [name for name in names if name not in self._local_clouds]
        if missing:
            stage = omni.usd.get_context().get_stage()
            cache = UsdGeom.XformCache()
            for name in missing:
                prim = stage.GetPrimAtPath(f"{self.path}/{name}")
                world = _sample_mesh_points(prim, cache) if prim else np.zeros((0, 3))
                if len(world):
                    # Into the link's own frame (USD rows: p_world = p_local @ M).
                    inv = np.linalg.inv(np.array(cache.GetLocalToWorldTransform(prim), dtype=np.float64))
                    world = (np.c_[world, np.ones(len(world))] @ inv)[:, :3]
                self._local_clouds[name] = world
        links_now = self._links()
        out = []
        for name in names:
            local = self._local_clouds[name]
            if not len(local) or name not in self.link_names:
                continue
            out.append(self._mesh_now(links_now, self.link_names.index(name), local))
        return np.concatenate(out) if out else np.zeros((0, 3))

    def cloud_at(self, p, q, gap: float) -> np.ndarray:
        """Where the tool's and fingers' points would be with the tool at pose ``(p, q)`` and the
        fingers ``gap`` apart (for planning around a hand before it gets there)."""
        p_now, q_now = self.hand_pose()
        back = _matrix(q_now)  # world -> tool frame, as rows: rel = (world - p_now) @ back
        parts = [(self.cloud((self.rig.tool_link,)) - p_now) @ back]
        closing = self.finger_gap() - gap
        for side, name in zip((1.0, -1.0), self.rig.finger_links):  # the first finger sits on the closing axis's + side
            parts.append((self.cloud((name,)) - p_now) @ back - side * self.closing_axis * closing / 2)
        return np.concatenate(parts) @ _matrix(q).T + np.asarray(p)

    def joint_report(self) -> list[str]:
        """The arm's joints near their limits, for diagnosing a pose it cannot reach."""
        q = np.asarray(self.view.get_dof_positions())[0]
        limits = np.asarray(self.view.get_dof_limits())[0]
        out = []
        for i in self.arm_ids:
            lo, hi = float(limits[i][0]), float(limits[i][1])
            margin = min(q[i] - lo, hi - q[i])
            if margin < 0.15:
                out.append(f"{self.dof_names[i]} {q[i]:.2f} (limits {lo:.2f}..{hi:.2f})")
        return out or [f"joints {np.round(q[self.arm_ids], 2).tolist()}"]

    def wrist_after(self, turns: list[float]) -> list[float]:
        """Where the wrist's roll joint will be after the tool turns about the vertical by each of
        ``turns`` in sequence (radians), from how that joint turns the tool now."""
        q = np.asarray(self.view.get_dof_positions())[0]
        jacobian = np.asarray(self.view.get_jacobians())[0, self._jac_row]
        rate = float(jacobian[5, self._jac_cols[-1]]) or -1.0  # tool yaw per radian of the wrist's roll
        wrist, out = float(q[self.arm_ids[-1]]), []
        for turn in turns:
            wrist += turn / rate
            out.append(wrist)
        return out

    def wrist_limits(self) -> tuple[float, float]:
        if not self.rig.wrist_roll:
            return -math.inf, math.inf  # no one joint turns the tool about its axis: no limit to plan round
        limits = np.asarray(self.view.get_dof_limits())[0][self.arm_ids[-1]]
        return float(limits[0]), float(limits[1])

    def closing_yaw(self, q) -> float:
        """The horizontal direction the tool closes along, for a tool pose (w, x, y, z)."""
        c = _matrix(q) @ self.closing_axis
        return math.atan2(c[1], c[0])

    def down(self, yaw: float) -> np.ndarray:
        return tool_down(self.tool_axis, self.closing_axis, yaw)

    def finger_gap(self) -> float:
        if self.rig.gripper == "suction":
            return 0.0 if self._sucking else self.open_gap
        q = np.asarray(self.view.get_dof_positions())[0]
        if self.rig.gripper == "hand":
            # How far the hand has closed from open to shut, on average over the joints that move.
            moving = [(i, self._hand_open.get(i, 0.0), v) for i, v in self._hand_shut.items() if abs(v - self._hand_open.get(i, 0.0)) > 1e-6]
            shut = np.mean([(q[i] - a) / (b - a) for i, a, b in moving]) if moving else 0.0
            return float(self.open_gap * (1.0 - max(0.0, min(1.0, float(shut)))))
        if self.rig.gripper == "robotiq":
            # Measured with the gripper empty, its opening falls in step with the finger joint, from
            # fully open to shut at ROBOTIQ_SHUT. (Closed on an object, the simulated fingers lean
            # in a little, so this reads somewhat under the object's width.)
            return float(self.open_gap * max(0.0, 1.0 - float(q[self.finger_ids[0]]) / ROBOTIQ_SHUT))
        return float(sum(q[i] for i in self.finger_ids))

    @staticmethod
    def _mesh_now(links, index: int, local: np.ndarray) -> np.ndarray:
        t = links[index]
        return local @ _matrix([t[6], t[3], t[4], t[5]]).T + np.asarray(t[:3])

    # --- driving ------------------------------------------------------------------------------

    def _set_all(self, getter, setter, values: dict[int, float]) -> None:
        data = np.array(getter(), dtype=np.float32)
        for i, v in values.items():
            data[0, i] = v
        setter(data, self._ids)

    def home(self) -> None:
        values = {self.dof_names.index(n): v for n, v in self.rig.body_pose}
        values.update({i: v for i, v in zip(self.arm_ids, self.rig.home)})
        if self.rig.gripper == "hand":
            values.update(self._hand_open)
        if self.rig.gripper == "franka":
            values.update({i: self.open_gap / 2 for i in self.finger_ids})
        elif self.rig.gripper == "robotiq":
            values.update({i: 0.0 for i in self.finger_ids})
        self._set_all(self.view.get_dof_positions, self.view.set_dof_positions, values)
        # The arm keeps its own copy of every joint target and always writes the lot: reading targets
        # back from the view between two writes in one step returns the old ones, so a gripper write
        # would undo the arm's (the arm drifted off its path, ending up 17 cm from a grasp).
        if self._targets is None or self._share is None:
            self._targets = np.array(self.view.get_dof_positions(), dtype=np.float32)
        for i, v in values.items():
            self._targets[0, i] = v
        self.view.set_dof_position_targets(self._targets, self._ids)
        self._command = self._last = None

    def _write_targets(self, values: dict[int, float]) -> None:
        if getattr(self, "_targets", None) is None:
            self._targets = np.array(self.view.get_dof_positions(), dtype=np.float32)
        for i, v in values.items():
            self._targets[0, i] = v
        self.view.set_dof_position_targets(self._targets, self._ids)

    def strengthen_grip(self, force_n: float | None = None, stiffness: float = 2.0e4, damping: float = 1.0e3) -> None:
        """Squeeze like the real gripper's force mode: stiff finger drives capped at a set force, so a
        closed grip presses with that force whatever the object's width (the models' own drives are weak)."""
        if not self.finger_ids:
            return
        if self.rig.gripper == "hand":
            stiffness, damping, cap = 30.0, 1.0, self.rig.hand_force
        elif self.rig.gripper == "robotiq":
            # One driven knuckle: about 100 N at the pads for a capped torque on it.
            stiffness, damping, cap = 300.0, 8.0, 12.0
        else:
            cap = force_n or self.rig.grip_n
        self._set_all(self.view.get_dof_stiffnesses, self.view.set_dof_stiffnesses, {i: stiffness for i in self.finger_ids})
        self._set_all(self.view.get_dof_dampings, self.view.set_dof_dampings, {i: damping for i in self.finger_ids})
        self._set_all(self.view.get_dof_max_forces, self.view.set_dof_max_forces, {i: cap for i in self.finger_ids})

    def take_hold(self, body, mass: float | None, friction: float | None, twist: float = 0.0) -> bool:
        """Start an assisted grip on ``body`` if the closed fingers are really on it: the grip point
        within 2 cm of its surface and the fingers stopped short of shutting. ``twist`` is the planned
        grip's share of the pads' friction its weight would use turning it out (``grasp.Grasp.twist``,
        for the asset's own friction): past the grippier pads' whole hold, it twists out once lifted.
        Returns whether it holds."""
        from isaacsim.core.simulation_manager import SimulationManager

        hand_p, hand_q = self.hand_pose()
        point = hand_p + _matrix(hand_q) @ self.grip_point
        near = float(np.linalg.norm(body.world - point, axis=1).min())
        if near > 0.02 or self.finger_gap() < 0.15 * self.open_gap:
            return False
        view = SimulationManager.get_physics_sim_view().create_rigid_body_view(body.path)
        pose = np.asarray(view.get_transforms())[0]
        obj_p, obj_q = pose[:3].astype(np.float64), np.array([pose[6], pose[3], pose[4], pose[5]], np.float64)
        # What the pinch's friction can carry: both pads, the pads' friction on the asset's own.
        grip = 2.0 * min(1.5, self.rig.pad_friction * (friction or 0.5)) * self.rig.grip_n
        self._held = {"view": view, "at": _matrix(hand_q).T @ (obj_p - hand_p), "turn": quat_mul(quat_conj(hand_q), obj_q),
                      "mass": float(mass or 0.1), "grip": grip, "v": np.zeros(3), "over": 0, "z0": float(obj_p[2]),
                      "twists": twist / self.rig.pad_friction > 1.0, "up": 0}
        return True

    def _follow(self) -> None:
        """Carry an assisted grip's object with the hand, or let it slip when the pinch could not hold it."""
        held = self._held
        hand_p, hand_q = self.hand_pose()
        want_p = hand_p + _matrix(hand_q) @ held["at"]
        want_q = quat_mul(hand_q, held["turn"])
        pose = np.asarray(held["view"].get_transforms())[0]
        obj_p, obj_q = pose[:3].astype(np.float64), np.array([pose[6], pose[3], pose[4], pose[5]], np.float64)
        v = (want_p - obj_p) * self.hz
        w = rotation_between(obj_q, want_q) * self.hz
        # The force the pinch must give: the object's weight and its acceleration with the hand.
        need = held["mass"] * float(np.linalg.norm((v - held["v"]) * self.hz + np.array([0.0, 0.0, 9.81])))
        held["over"] = held["over"] + 1 if need > held["grip"] else 0
        held["up"] = held["up"] + 1 if obj_p[2] > held["z0"] + 0.01 else 0
        if held["over"] > self.hz * 0.05 or (held["twists"] and held["up"] > self.hz * 0.25):
            self._held = None  # more than the pinch can hold, or its weight turns it out: it slips
            return
        held["v"] = v
        held["view"].set_velocities(np.array([[*v, *w]], dtype=np.float32), self._ids)

    def grip_force(self) -> float:
        if self.rig.gripper == "suction":
            return self.rig.cup.hold_n
        return float(np.asarray(self.view.get_dof_max_forces())[0, self.finger_ids[0]]) if self.finger_ids else 0.0

    def track(self, position, orientation) -> None:
        """One physics step along a planned tool path.

        The joint targets carry the plan forward: each step they move by the inverse kinematics of
        how far the planned pose moved, plus a gentle pull (``CORRECTION`` per step, about a tenth of
        a second to close a gap) towards the plan from where the tool really is, which also undoes
        the drives' sag under gravity. Commanding the joints from their measured positions with a
        strong correction instead fed every tremor back into the next command, and the arm shook
        (2-3 mm of wobble, against 0.03-0.2 mm now, measured by ``internal/probes/robot_probe.py``).
        """
        position, orientation = np.asarray(position, float), np.asarray(orientation, float)
        p, q = self.hand_pose()
        jacobian = np.asarray(self.view.get_jacobians())[0, self._jac_row][:, self._jac_cols].astype(np.float64)
        dofs = np.asarray(self.view.get_dof_positions())[0]
        current = dofs[self.arm_ids].astype(np.float64)
        if self._command is None or self._last is None:
            self._command, self._last = current.copy(), (position, orientation)
        last_p, last_q = self._last
        ahead = _dls(jacobian, np.concatenate([position - last_p, rotation_between(last_q, orientation)]))
        pull = _dls(jacobian, CORRECTION * np.concatenate([position - p, rotation_between(q, orientation)]))
        step = ahead + pull
        if self.n > 6 and self.posture > 0.0:
            # A seven-joint arm has a spare way to hold any tool pose: lean it back towards the home
            # posture, without moving the tool, or the joints drift a little every move until they hit
            # their limits (it stopped 17 cm short of a grasp, three joints at their ends).
            pinv = jacobian.T @ np.linalg.inv(jacobian @ jacobian.T + np.eye(6) * 0.03 ** 2)
            posture = self.posture * (np.asarray(self.rig.home[:self.n]) - current)
            posture[self.n - 1] = 0.0  # the wrist's roll follows the grasp; it is chosen by the planner
            step = step + (np.eye(self.n) - pinv @ jacobian) @ posture
        self._command = np.clip(self._command + step, current - WINDUP, current + WINDUP)
        # The drives' damping brakes towards their target velocity: give them the plan's, or the arm
        # trails its path by the damping's time constant (a fifth of a second) times its speed.
        self._set_all(lambda: np.zeros((1, len(self.dof_names)), np.float32), self.view.set_dof_velocity_targets,
                      {i: float(v) for i, v in zip(self.arm_ids, ahead * self.hz)})
        self._last = (position, orientation)
        self._write_targets({i: float(v) for i, v in zip(self.arm_ids, self._command)})

    def grip(self, gap: float) -> None:
        """Close (``gap`` 0) or open (``gap`` the opening) the tool."""
        closing = gap < 0.5 * self.open_gap
        if self.rig.gripper == "suction":
            if closing != self._sucking:
                (self._suction.close_gripper if closing else self._suction.open_gripper)(self._suction_path)
                self._sucking = closing
            return
        if self.rig.gripper == "robotiq":
            self._write_targets({self.finger_ids[0]: self.rig.finger_closed if closing else 0.0})
            return
        if self.rig.gripper == "hand":
            self._write_targets(self._hand_shut if closing else self._hand_open)
            if self._held is not None:
                if closing:
                    self._follow()
                else:
                    self._held = None  # the hand opens: let go
            return
        half = max(0.0, min(self.open_gap, gap)) / 2
        self._write_targets({i: half for i in self.finger_ids})


def _dls(jacobian: np.ndarray, error: np.ndarray, damping: float = 0.03) -> np.ndarray:
    """Damped least-squares inverse kinematics: joint changes for a small hand motion ``error``."""
    return jacobian.T @ np.linalg.solve(jacobian @ jacobian.T + np.eye(6) * damping ** 2, error)


def rotation_between(a, b) -> np.ndarray:
    """The rotation vector (radians, world frame) that turns orientation ``a`` into ``b`` (w, x, y, z)."""
    d = quat_mul(b, quat_conj(a))
    if d[0] < 0:
        d = -d
    v = d[1:]
    s = float(np.linalg.norm(v))
    if s < 1e-12:
        return np.zeros(3)
    return v / s * 2.0 * math.atan2(s, d[0])


class Move:
    """A minimum-jerk move of the hand from one pose to another over ``seconds``."""

    def __init__(self, start_p, start_q, end_p, end_q, seconds: float) -> None:
        self.p0, self.p1 = np.asarray(start_p, float), np.asarray(end_p, float)
        self.q0, self.q1 = np.asarray(start_q, float), np.asarray(end_q, float)
        self.seconds = max(1e-3, seconds)

    def at(self, t: float) -> tuple[np.ndarray, np.ndarray]:
        s = grasp_plan.min_jerk(t / self.seconds)
        return self.p0 + (self.p1 - self.p0) * s, slerp(self.q0, self.q1, s)


def move_time(a, b, speed: float = 0.35, least: float = 0.6) -> float:
    """Seconds for a calm move between two points (a min-jerk move peaks at 1.9x its average speed)."""
    return max(least, float(np.linalg.norm(np.asarray(b) - np.asarray(a))) / speed)


class ArcMove:
    """Swing the hand around the robot's base, easing angle, reach and height together (as an arm
    turning at its base does), and turning the hand with the swing."""

    def __init__(self, base_xy, start_p, start_q, end_p, seconds: float) -> None:
        self.base = np.asarray(base_xy, float)
        self.p0, self.p1 = np.asarray(start_p, float), np.asarray(end_p, float)
        d0, d1 = self.p0[:2] - self.base, self.p1[:2] - self.base
        self.a0 = math.atan2(d0[1], d0[0])
        self.turn = math.remainder(math.atan2(d1[1], d1[0]) - self.a0, 2 * math.pi)
        self.r0, self.r1 = float(np.linalg.norm(d0)), float(np.linalg.norm(d1))
        self.q0 = np.asarray(start_q, float)
        self.q1 = quat_mul(yaw_quat(self.turn), self.q0)
        self.seconds = max(1e-3, seconds)

    def at(self, t: float) -> tuple[np.ndarray, np.ndarray]:
        s = grasp_plan.min_jerk(t / self.seconds)
        angle, reach = self.a0 + self.turn * s, self.r0 + (self.r1 - self.r0) * s
        z = self.p0[2] + (self.p1[2] - self.p0[2]) * s
        return (np.array([self.base[0] + reach * math.cos(angle), self.base[1] + reach * math.sin(angle), z]),
                slerp(self.q0, self.q1, s))


def spread_on_arc(radii: list[float], centre_deg: float, distance: float, gap: float = 0.06) -> list[float]:
    """Angles (degrees) for objects of these footprint radii side by side on an arc around the base."""
    if not radii:
        return []
    steps = [math.degrees((a + b + gap) / distance) for a, b in zip(radii, radii[1:])]
    total = sum(steps)
    angles, angle = [], centre_deg - total / 2
    for i in range(len(radii)):
        angles.append(angle)
        if i < len(steps):
            angle += steps[i]
    return angles


def closing_yaw(q) -> float:
    """The horizontal direction the Franka's fingers close along, for a hand pose (w, x, y, z)."""
    c = _matrix(q) @ np.array([0.0, 1.0, 0.0])
    return math.atan2(c[1], c[0])


def choose_hand_yaw(grasp_yaw: float, preferred: float) -> float:
    """Of the two ways round a parallel gripper can take a grasp, the one nearer ``preferred``."""
    options = (grasp_yaw, grasp_yaw + math.pi)
    return min(options, key=lambda y: abs(math.remainder(y - preferred, 2 * math.pi)))


# --- studio lighting and the Marso logo on the robot's base ----------------------------------------


def softbox(stage: Usd.Stage, path: str, eye, target, width: float, height: float, intensity: float,
            colour=(1.0, 1.0, 1.0), focus: float = 0.0) -> None:
    """A rectangular studio softbox at ``eye`` facing ``target``: soft shadows and broad, soft highlights."""
    light = UsdLux.RectLight.Define(stage, path)
    light.CreateWidthAttr(float(width))
    light.CreateHeightAttr(float(height))
    light.CreateIntensityAttr(float(intensity))
    light.CreateColorAttr(Gf.Vec3f(*map(float, colour)))
    if focus:
        UsdLux.ShapingAPI.Apply(light.GetPrim()).CreateShapingFocusAttr(float(focus))
    # A rect light shines down its -Z axis, like a camera looks.
    up = (0.0, 0.0, 1.0) if abs(float(np.asarray(target)[2]) - float(np.asarray(eye)[2])) < 0.95 * float(
        np.linalg.norm(np.asarray(target, float) - np.asarray(eye, float))) else (0.0, 1.0, 0.0)
    view = Gf.Matrix4d().SetLookAt(Gf.Vec3d(*map(float, eye)), Gf.Vec3d(*map(float, target)), Gf.Vec3d(*up))
    xform = UsdGeom.Xformable(light)
    xform.ClearXformOpOrder()
    xform.AddTransformOp().Set(view.GetInverse())


def logo_texture(path, mark, font, colour=(16, 16, 18)):
    """The Marso mark with the wordmark centred beneath it, in black on a transparent texture (a decal).

    Returns the texture's width over its height.
    """
    from PIL import Image, ImageDraw

    width = 512
    mark = mark.convert("RGBA").resize((width, round(mark.height * width / mark.width)), Image.LANCZOS)
    ink = Image.new("RGBA", mark.size, colour + (255,))
    ink.putalpha(mark.getchannel("A"))
    probe = ImageDraw.Draw(Image.new("RGBA", (1, 1)))
    left, top, right, bottom = probe.textbbox((0, 0), "marso", font=font)
    # The wordmark a little narrower than the mark, a fifth of the mark's height below it.
    scale = 0.92 * width / (right - left)
    text_w, text_h = round((right - left) * scale), round((bottom - top) * scale)
    words = Image.new("RGBA", (right - left, bottom - top), (0, 0, 0, 0))
    ImageDraw.Draw(words).text((-left, -top), "marso", font=font, fill=colour + (255,))
    words = words.resize((text_w, text_h), Image.LANCZOS)
    gap = round(mark.height * 0.2)
    margin = 8
    image = Image.new("RGBA", (width + 2 * margin, mark.height + gap + text_h + 2 * margin), (0, 0, 0, 0))
    image.alpha_composite(ink, (margin, margin))
    image.alpha_composite(words, (margin + (width - text_w) // 2, margin + mark.height + gap))
    image.save(path)
    return image.width / image.height


def add_logo(stage: Usd.Stage, robot_path: str, texture: str, aspect: float, facing: float,
             height: float = 0.1, offset: float = 0.0012, base_link: str = "panda_link0") -> bool:
    """Lay the logo texture on the robot's base, shaped to its surface, centred on the direction ``facing``.

    The base stays put (the arm is fixed to the table), so the decal is a separate thin mesh hugging
    the base's visual surface, found by sampling the base mesh's radius around its axis. It is as tall
    as ``height``, but never more than 60% of the base, and sits in the base's middle.
    """
    base = stage.GetPrimAtPath(f"{robot_path}/{base_link}")
    if not base:
        return False
    cache = UsdGeom.XformCache()
    points = []
    for prim in Usd.PrimRange(base, Usd.TraverseInstanceProxies(Usd.PrimDefaultPredicate)):
        if prim.IsA(UsdGeom.Mesh) and UsdGeom.Imageable(prim).ComputePurpose() not in ("guide", "proxy"):
            pts = UsdGeom.Mesh(prim).GetPointsAttr().Get()
            if pts:
                matrix = np.array(cache.GetLocalToWorldTransform(prim), dtype=np.float64)
                points.append(np.asarray(pts, dtype=np.float64) @ matrix[:3, :3] + matrix[3, :3])
    if not points:
        return False
    pts = np.concatenate(points)
    origin = np.array(cache.GetLocalToWorldTransform(base).ExtractTranslation())
    rel = pts - origin
    radius = np.hypot(rel[:, 0], rel[:, 1])
    # Only the base itself: above its mounting face and close to its axis (the model's cable runs off
    # across the table and down to the floor, which would put the "middle" of the base under the table).
    body = (rel[:, 2] > -0.002) & (radius < 0.16)
    if body.sum() < 100:
        return False
    rel, radius = rel[body], radius[body]
    angle = np.arctan2(rel[:, 1], rel[:, 0])
    low, high = float(np.percentile(rel[:, 2], 1)), float(np.percentile(rel[:, 2], 99))
    height = min(height, 0.6 * (high - low))
    width = height * aspect
    centre_height = low + 0.5 * (high - low)
    z0 = origin[2] + centre_height
    # The decal's angular span, from the base's radius where it goes.
    band = np.abs(rel[:, 2] - centre_height) < height
    near = band & (np.abs(np.remainder(angle - facing + math.pi, 2 * math.pi) - math.pi) < 0.6)
    if not near.any():
        return False
    span = width / float(np.percentile(radius[near], 90))
    columns, rows = 24, 24
    fallback = float(np.percentile(radius[near], 90))
    surface = np.full((rows + 1, columns + 1), np.nan)
    for j in range(rows + 1):
        z = centre_height - height / 2 + height * j / rows
        for i in range(columns + 1):
            theta = facing - span / 2 + span * i / columns
            around = (np.abs(np.remainder(angle - theta + math.pi, 2 * math.pi) - math.pi) < 0.1) & (np.abs(rel[:, 2] - z) < 0.012)
            if around.any():
                surface[j, i] = float(radius[around].max())
    surface = np.where(np.isnan(surface), fallback, surface)
    # Each point stands clear of its neighbours' surface too, so no part of the decal sinks into the base
    # where the base mesh has few vertices.
    padded = np.pad(surface, 1, mode="edge")
    surface = np.max([padded[a:a + rows + 1, b:b + columns + 1] for a in range(3) for b in range(3)], axis=0)
    verts, uvs = [], []
    for j in range(rows + 1):
        z = z0 - height / 2 + height * j / rows
        for i in range(columns + 1):
            theta = facing - span / 2 + span * i / columns
            r = surface[j, i] + offset
            verts.append(Gf.Vec3f(float(origin[0] + r * math.cos(theta)), float(origin[1] + r * math.sin(theta)), float(z)))
            uvs.append(Gf.Vec2f(i / columns, j / rows))
    counts, indices = [], []
    for j in range(rows):
        for i in range(columns):
            a = j * (columns + 1) + i
            counts.append(4)
            indices += [a, a + 1, a + columns + 2, a + columns + 1]
    mesh = UsdGeom.Mesh.Define(stage, "/World/Studio/RobotLogo")
    mesh.CreatePointsAttr(verts)
    mesh.CreateFaceVertexCountsAttr(counts)
    mesh.CreateFaceVertexIndicesAttr(indices)
    mesh.CreateSubdivisionSchemeAttr("none")
    st = UsdGeom.PrimvarsAPI(mesh).CreatePrimvar("st", Sdf.ValueTypeNames.TexCoord2fArray, UsdGeom.Tokens.vertex)
    st.Set(uvs)
    look = UsdShade.Material.Define(stage, "/World/Studio/Looks/RobotLogo")
    surface = UsdShade.Shader.Define(stage, "/World/Studio/Looks/RobotLogo/Surface")
    surface.CreateIdAttr("UsdPreviewSurface")
    surface.CreateInput("roughness", Sdf.ValueTypeNames.Float).Set(0.35)
    surface.CreateInput("opacityThreshold", Sdf.ValueTypeNames.Float).Set(0.5)
    reader = UsdShade.Shader.Define(stage, "/World/Studio/Looks/RobotLogo/St")
    reader.CreateIdAttr("UsdPrimvarReader_float2")
    reader.CreateInput("varname", Sdf.ValueTypeNames.Token).Set("st")
    image = UsdShade.Shader.Define(stage, "/World/Studio/Looks/RobotLogo/Image")
    image.CreateIdAttr("UsdUVTexture")
    image.CreateInput("file", Sdf.ValueTypeNames.Asset).Set(texture)
    image.CreateInput("sourceColorSpace", Sdf.ValueTypeNames.Token).Set("sRGB")
    image.CreateInput("wrapS", Sdf.ValueTypeNames.Token).Set("clamp")
    image.CreateInput("wrapT", Sdf.ValueTypeNames.Token).Set("clamp")
    image.CreateInput("st", Sdf.ValueTypeNames.Float2).ConnectToSource(reader.ConnectableAPI(), "result")
    rgb = image.CreateOutput("rgb", Sdf.ValueTypeNames.Float3)
    alpha = image.CreateOutput("a", Sdf.ValueTypeNames.Float)
    surface.CreateInput("diffuseColor", Sdf.ValueTypeNames.Color3f).ConnectToSource(rgb)
    surface.CreateInput("opacity", Sdf.ValueTypeNames.Float).ConnectToSource(alpha)
    look.CreateSurfaceOutput().ConnectToSource(surface.ConnectableAPI(), "surface")
    UsdShade.MaterialBindingAPI.Apply(mesh.GetPrim()).Bind(look)
    return True


# --- the robot test's set and its pick-and-place, shared with internal/probes/robot_probe.py --------------

TABLE_TOP = 0.75
ROBOT_BASE = (0.0, 0.32)
ROBOT_YAW = -90.0  # degrees: the arm faces the front of the table (-Y)
ARC = 0.52  # metres from the robot's base to the objects' spots
PICK_SIDE, PLACE_SIDE = 228.0, 312.0  # degrees round the base: objects start on its left, go to its right
PLACE_TOLERANCE = 0.05  # metres from its spot that still counts as placed
MAX_TRIES = 3  # a slipped grip is tried again from wherever the object ends up
DROPPED_MM = 60.0  # moved this far in the fingers during the carry: it fell out
RISKY_TWIST = 3.0  # twist allowed when risky grips are asked for (TWIST_MARGIN is the safe limit)


def refusal(rig: Rig, mass_kg: float | None) -> str | None:
    """Why ``rig`` should not try an object at all, before any geometry."""
    if rig.cup is not None:
        return grasp_plan.why_not_suction(mass_kg, rig.cup)
    return grasp_plan.why_not(mass_kg, rig.hand)


def no_grip_reason(rig: Rig, points, normals, centre, table_z: float) -> str:
    if rig.cup is not None:
        return "no flat spot for the suction cup to seal on"
    return grasp_plan.no_grasp_reason(points, normals, centre, table_z, rig.hand)


def plan_at_rest(rig: Rig, points, normals, centre, table_z: float, mass_kg, friction, risky: bool = False):
    """A grasp on an object as it stands, as the rig would plan it (for choosing what to try)."""
    if rig.cup is not None:
        return grasp_plan.plan_suction(points, normals, centre, table_z, rig.cup, mass_kg=mass_kg)
    return grasp_plan.plan(points, normals, centre, table_z, rig.hand, mass_kg=mass_kg, friction=friction,
                           grip_n=rig.grip_n, twist_limit=twist_limit(rig, risky))


def twist_limit(rig: Rig, risky: bool = False) -> float | None:
    """The most twist (``grasp.Grasp.twist``, for the asset's own friction) a rig's grips may have: the
    planner's margin for a friction grip; an assisted grip holds up to its pads' whole friction (and
    lets anything past that twist out), so it plans up to that; risky grips try more."""
    if risky:
        return RISKY_TWIST
    return rig.pad_friction if rig.assisted_grip else None


HUMANOID_TABLE = (1.2, 0.65)  # metres: the humanoid's table, centred on the origin
HUMANOID_TABLE_TOP = 0.66  # lower than the arms' table: its hand, pointing down, reaches only so high
HUMANOID_STAND_Y = 0.45  # where its pelvis stands, behind the table's back edge, facing -Y
HUMANOID_SHOULDER = "right_shoulder_pitch_link"  # the arm swings round this
HUMANOID_CARRY = 0.07  # metres a carried object's bottom rides above the table
REACH = 0.36  # metres from the shoulder (across the table) the hand picks and places at
REACH_SIDES = ((-95.0, -160.0), (-85.0, -20.0))  # degrees round the shoulder, inner to outer: picks to its right, places to its left
GRIP_TURN = 30.0  # degrees the G1's hand closes turned from its heading out of the shoulder (its ready pose)


def reach_spots(shoulder, radii: list[float], back_edge: float = math.inf, sides: tuple = REACH_SIDES,
                reach: tuple = (REACH, REACH)) -> tuple[list[np.ndarray], list[np.ndarray], int]:
    """Start and finish spots for a standing humanoid's one arm, on an arc round its shoulder: objects
    start to its right and go to its left, the innermost first and to the outermost spot, so a carried
    object only ever passes over empty spots. Nothing hangs over the table's ``back_edge`` (y).
    Returns the spots and how many fit."""
    def side(inner: float, outer: float, arc: float) -> list[float]:
        angles, at, step = [], math.radians(inner), math.copysign(1.0, outer - inner)
        for radius in radii:
            centre = at + step * radius / arc
            if step * (centre + step * radius / arc - math.radians(outer)) > 0:
                break
            if shoulder[1] + arc * math.sin(centre) + radius > back_edge:
                break
            angles.append(centre)
            at = centre + step * (radius + 0.02) / arc
        return angles

    picks, places = side(*sides[0], reach[0]), side(*sides[1], reach[1])
    kept = min(len(picks), len(places))
    # The first object (innermost on the right) goes to the outermost spot on the left, and so on.
    order = places[:kept][::-1]

    def spot(a: float, arc: float) -> np.ndarray:
        return np.asarray(shoulder[:2], float) + arc * np.array([math.cos(a), math.sin(a)])

    return [spot(a, reach[0]) for a in picks[:kept]], [spot(a, reach[1]) for a in order], kept


PAIR_SIDES = ((-104.0, -170.0), (-84.0, -132.0))  # the right arm's, with both arms working: places stay on its half
PAIR_REACH = (0.34, 0.33)  # picked out at the side, set down a little nearer, in front of its shoulder


def mirrored(sides: tuple) -> tuple:
    """The same spots for the other arm: angles round its shoulder mirrored across the robot's middle."""
    return tuple(tuple(-180.0 - a for a in side) for side in sides)


def share_out(radii: list[float], shoulders: list, back_edge: float) -> list[tuple[list[int], list, list]]:
    """Objects for each of a humanoid's arms, in turn, smallest first: for each arm, which objects (by
    index) with their start and finish spots round its shoulder. Objects left over fit nowhere."""
    sides = [PAIR_SIDES, mirrored(PAIR_SIDES)]
    picks: list[list[int]] = [[] for _ in shoulders]
    for i in range(len(radii)):
        picks[i % len(shoulders)].append(i)
    out = []
    for arm, (shoulder, side) in enumerate(zip(shoulders, sides)):
        mine = picks[arm]
        starts, ends, kept = reach_spots(shoulder, [radii[i] for i in mine], back_edge, side, PAIR_REACH)
        out.append((mine[:kept], starts, ends))
    return out


def link_position(stage: Usd.Stage, robot_path: str, link: str) -> np.ndarray:
    """Where one of a robot's links stands in the world, as set up (before the simulation runs)."""
    prim = next((p for p in Usd.PrimRange(stage.GetPrimAtPath(robot_path)) if p.GetName() == link), None)
    if prim is None:
        raise RuntimeError(f"The robot has no link called {link}.")
    return np.array(UsdGeom.Xformable(prim).ComputeLocalToWorldTransform(Usd.TimeCode.Default()).ExtractTranslation())


def arc_spots(radii: list[float]) -> tuple[list[np.ndarray], list[np.ndarray]]:
    """Start and finish spots (x, y) for objects of these footprint radii: the front spot goes first."""
    def spot(deg: float) -> np.ndarray:
        return np.array(ROBOT_BASE) + ARC * np.array([math.cos(math.radians(deg)), math.sin(math.radians(deg))])

    picks = spread_on_arc(radii, PICK_SIDE, ARC)[::-1]
    places = spread_on_arc(radii[::-1], PLACE_SIDE, ARC)[::-1]
    return [spot(d) for d in picks], [spot(d) for d in places]


def _ordinal(n: int) -> str:
    return {1: "1st", 2: "2nd", 3: "3rd"}.get(n, f"{n}th")


def _matrix(q) -> np.ndarray:
    w, x, y, z = q
    return np.array([[1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
                     [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
                     [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)]])


class PickPlace:
    """Moves objects one at a time: plans a grip on it as it lies, picks it up, swings it round the base
    and sets it down on its spot; if it slips out, the hand opens over it and tries again (up to
    ``MAX_TRIES``), planning afresh from wherever it ended up.

    ``step(pose, gap)`` advances the world one physics step with the hand heading for ``pose`` and the
    fingers for ``gap``: the robot test films there, the probe only measures. Objects are ``Body``s
    (``sim.studio``) and their surfaces come from ``oriented_surface_of`` at the start pose.
    """

    def __init__(self, arm: "Arm", hz: float, step, carry_clear: float, risky: bool = False,
                 tries: int = MAX_TRIES, base=None, table_top: float = TABLE_TOP) -> None:
        self.arm, self.hz, self.step = arm, float(hz), step
        # Risky: also try grips the object might twist out of (the safest grip on offer still wins).
        self.twist_limit = twist_limit(arm.rig, risky)
        self.tries = max(1, int(tries))
        # What the arm swings about: its base on the table, or a standing humanoid's shoulder.
        base = ROBOT_BASE if base is None else base
        self.table_top = float(table_top)  # a humanoid works at a lower table than the arms
        self.base = np.array([base[0], base[1], self.table_top])
        self.carry_clear = carry_clear  # how high a carried object's bottom rides above the table
        self.home_p, self.home_q = arm.hand_pose()
        heading = math.atan2(self.home_p[1] - self.base[1], self.home_p[0] - self.base[0])
        # How the tool sits relative to the arm's heading at rest: grasps are taken the same way round.
        self.offset = math.remainder(arm.closing_yaw(self.home_q) - heading, math.pi)

    def plan(self, points, normals, centre, mass, friction):
        """A grasp on the object as it lies: a two-finger grip, or a spot for the suction cup."""
        rig = self.arm.rig
        if rig.cup is not None:
            return grasp_plan.plan_suction(points, normals, centre, self.table_top, rig.cup, mass_kg=mass)
        accept = None
        if rig.yaw_band:
            # Only grips the arm can turn the hand to: near the way it closes at rest, for its heading.
            band = math.radians(rig.yaw_band)

            def accept(c, yaw, _width):
                usual = math.atan2(c[1] - self.base[1], c[0] - self.base[0]) + self.offset
                return abs(math.remainder(yaw - usual, math.pi)) <= band
        return grasp_plan.plan(points, normals, centre, self.table_top, rig.hand, mass_kg=mass, friction=friction,
                               grip_n=rig.grip_n, twist_limit=self.twist_limit, accept=accept)

    def run(self, move, gap: float) -> None:
        for i in range(int(round(move.seconds * self.hz))):
            self.step(move.at(i / self.hz), gap)

    def hold(self, pose, gap: float, seconds: float) -> None:
        for _ in range(int(round(seconds * self.hz))):
            self.step(pose, gap)

    @staticmethod
    def surface_now(body, surface):
        """The object's surface and centre of mass as it lies now (they were measured where it started)."""
        points, normals, com = surface
        turned = _matrix(body.q) @ _matrix(body.q0).T
        moved = (points - body.p0) @ turned.T + body.p
        centre = (turned @ (np.asarray(com) - body.p0) + body.p) if com is not None else moved.mean(axis=0)
        return moved, normals @ turned.T, centre

    def route(self, g, points: np.ndarray, centre, target) -> dict:
        """Where the hand goes for one grasp: above it, down to it, round to its spot, down to set it there."""
        azimuth = math.atan2(g.centre[1] - self.base[1], g.centre[0] - self.base[0])
        if self.arm.rig.cup is not None:
            # A cup turns any way: keep the wrist as it sits. It stops just short of the spot and the
            # suction takes hold from there (pressing in, the arm's stiff joints wedged the object).
            q_grip = self.arm.down(azimuth + self.offset)
            grip = np.array([g.centre[0], g.centre[1], g.tip_z + self.arm.tip + 0.003])
        else:
            q_grip = self.arm.down(self.wrist_friendly_yaw(g, azimuth, target))
            # The hand where its grip point (between the fingertips) meets the planned grip; a curling hand
            # starts lower, never below the table, so its fingertips close at the planned height.
            tips = max(g.tip_z - self.arm.rig.curl, self.table_top + 0.003)
            grip = np.array([g.centre[0], g.centre[1], tips]) - _matrix(q_grip) @ self.arm.grip_point
        drop = g.tip_z - points[:, 2].min()
        lift = grip[2] - g.tip_z  # the hand's height above its fingertips
        carry_z = self.table_top + self.carry_clear + drop + lift
        above = np.array([grip[0], grip[1], carry_z])
        # The object, not the hand, should land on its spot: turn the grip's offset with the swing.
        rel = np.array([grip[0] - centre[0], grip[1] - centre[1]])
        turn = ArcMove(self.base[:2], above, q_grip, np.array([target[0] + rel[0], target[1] + rel[1], carry_z]), 1.0).turn
        c, s = math.cos(turn), math.sin(turn)
        place = np.array([target[0] + rel[0] * c - rel[1] * s, target[1] + rel[0] * s + rel[1] * c, carry_z])
        down = np.array([place[0], place[1], self.table_top + 0.004 + drop + lift])
        return {"q": q_grip, "grip": grip, "above": above, "place": place, "down": down}

    def wrist_friendly_yaw(self, g, azimuth: float, target) -> float:
        """Of the two ways round a two-finger grip can be taken, the one that keeps the wrist's roll
        joint furthest inside its range, both at the grip and after the swing to ``target``."""
        _p, q_now = self.arm.hand_pose()
        yaw_now = self.arm.closing_yaw(q_now)
        swing = math.remainder(math.atan2(target[1] - self.base[1], target[0] - self.base[0]) - azimuth, 2 * math.pi)
        low, high = self.arm.wrist_limits()
        best, best_margin = None, -math.inf
        for yaw in (g.yaw, g.yaw + math.pi):
            turn = math.remainder(yaw - yaw_now, 2 * math.pi)
            at_grip, after_swing = self.arm.wrist_after([turn, swing])
            margin = min(at_grip - low, high - at_grip, after_swing - low, high - after_swing)
            if not math.isfinite(margin):
                margin = 0.0  # no wrist roll joint to keep in range (a humanoid): the usual way round decides
            # Prefer the usual way round (as the hand sits at rest) unless the wrist needs the other.
            margin -= 0.05 * abs(math.remainder(yaw - (azimuth + self.offset), 2 * math.pi))
            if margin > best_margin:
                best, best_margin = yaw, margin
        return best

    def pick_and_place(self, body, surface, target, mass: float | None, friction: float | None, say) -> dict:
        """Move one object to ``target`` (x, y); ``say(text, tone)`` reports what is happening
        (tone: "ink", "accent", "good" or "warn"). Returns its results."""
        open_gap = self.arm.open_gap
        result = {"mass_kg": mass, "result": "missed", "tries": 0}
        for attempt in range(1, self.tries + 1):
            points, normals, centre = self.surface_now(body, surface)
            if points[:, 2].max() < self.table_top - 0.02:
                result["result"] = "fell off the table"
                say("fell off the table", "warn")
                break
            g = self.plan(points, normals, centre, mass, friction)
            if g is None:
                result["result"] = "no grip" if attempt == 1 else result["result"]
                say("no grip found" if attempt == 1 else "no grip left to try", "warn")
                break
            result.update(tries=attempt, grip_mm=g.width * 1000, twist=g.twist)
            r = self.route(g, points, centre, target)
            q, grip, above = r["q"], r["grip"], r["above"]
            calm = max(0.2, 1.0 / (1.0 + 3.0 * g.twist))  # an object that could twist out of the grip is moved gently
            say("reaching" if attempt == 1 else f"trying again: {_ordinal(attempt)} try", "ink")
            p_now, q_now = self.arm.hand_pose()
            self.run(Move(p_now, q_now, above, q, move_time(p_now, above, least=1.0)), open_gap)
            self.run(Move(above, q, grip, q, move_time(above, grip, speed=0.25, least=1.0)), open_gap)
            self.hold((grip, q), open_gap, 0.3)
            result["reach_error_mm"] = float(np.linalg.norm(self.arm.hand_pose()[0] - grip)) * 1000  # did the tool get there?
            if result["reach_error_mm"] > 20:
                result["stuck_at"] = self.arm.joint_report()
            say("gripping", "accent")
            self.arm.planned_width = g.width
            self.hold((grip, q), 0.0, 0.7)
            result["closed_mm"] = self.arm.finger_gap() * 1000  # against grip_mm: did the fingers close on it?
            if self.arm.rig.assisted_grip:
                result["held"] = self.arm.take_hold(body, mass, friction, g.twist)
            if self.arm.rig.cup is not None:
                result["suction"] = self.arm.suction_report()
            z_before = body.p[2]
            self.run(Move(grip, q, above, q, move_time(grip, above, speed=0.25 * calm, least=1.0)), 0.0)
            lifted = body.p[2] - z_before
            result["lifted_mm"] = lifted * 1000
            if lifted < 0.5 * (above[2] - grip[2]):
                say("slipped out of the grip", "warn")
                result["result"] = "slipped"
                self.hold((above, q), open_gap, 0.5)  # let go over it, then look again
                continue
            say("carrying", "accent")
            hand_p, hand_q = self.arm.hand_pose()
            held_at = _matrix(hand_q).T @ (body.p - hand_p)
            swing = ArcMove(self.base[:2], above, q, r["place"], 1.0)
            reach = float(np.linalg.norm(r["place"][:2] - self.base[:2]))
            swing = ArcMove(self.base[:2], above, q, r["place"], max(1.6, abs(swing.turn) * reach / (0.35 * calm)))
            self.run(swing, 0.0)
            hand_p, hand_q = self.arm.hand_pose()
            result["slip_mm"] = float(np.linalg.norm(_matrix(hand_q).T @ (body.p - hand_p) - held_at)) * 1000
            if result["slip_mm"] > DROPPED_MM:
                # It came out of the fingers on the way: let go, rise clear, and go back for it.
                say("dropped on the way", "warn")
                result["result"] = "dropped"
                result["drops"] = result.get("drops", 0) + 1
                self.hold((r["place"], swing.q1), open_gap, 0.6)
                continue
            say("setting down", "accent")
            place, down, q_place = r["place"], r["down"], swing.q1
            self.run(Move(place, q_place, down, q_place, move_time(place, down, speed=0.25 * calm, least=1.0)), 0.0)
            self.hold((down, q_place), open_gap, 0.45)
            self.run(Move(down, q_place, place, q_place, move_time(down, place, speed=0.3, least=0.8)), open_gap)
            landed = body.world.mean(axis=0)
            error = float(np.linalg.norm(landed[:2] - np.asarray(target)))
            tilt = math.degrees(math.acos(max(-1.0, min(1.0, (_matrix(body.q) @ _matrix(body.q0).T)[2, 2]))))
            ok = error <= PLACE_TOLERANCE and landed[2] > self.table_top
            result.update(off_mm=error * 1000, tilt_deg=tilt, result="placed" if ok else "dropped")
            if ok:
                say(f"placed, {error * 1000:.0f} mm from its spot" + (f" ({_ordinal(attempt)} try)" if attempt > 1 else ""), "good")
            else:
                say("dropped", "warn")
            break
        return result

    def go_home(self) -> None:
        p_now, q_now = self.arm.hand_pose()
        self.run(Move(p_now, q_now, self.home_p, self.home_q, move_time(p_now, self.home_p, least=1.2)), self.arm.open_gap)
        self.hold((self.home_p, self.home_q), self.arm.open_gap, 1.0)


def _sample_mesh_points(root: Usd.Prim, cache: UsdGeom.XformCache, limit: int = 400) -> np.ndarray:
    """World points over the meshes under ``root``, thinned to about ``limit``."""
    chunks = []
    for prim in Usd.PrimRange(root, Usd.TraverseInstanceProxies(Usd.PrimDefaultPredicate)):
        if not prim.IsA(UsdGeom.Mesh):
            continue
        pts = UsdGeom.Mesh(prim).GetPointsAttr().Get()
        if not pts:
            continue
        m = np.array(cache.GetLocalToWorldTransform(prim), dtype=np.float64)
        chunks.append(np.asarray(pts, dtype=np.float64) @ m[:3, :3] + m[3, :3])
    if not chunks:
        return np.zeros((0, 3))
    pts = np.concatenate(chunks)
    return pts[:: max(1, len(pts) // limit)]


# --- the handover: two Frankas pass an object from one hand to the other ------------------------------

LEFT_BASE, RIGHT_BASE = (-0.42, 0.32), (0.42, 0.32)  # the two arms behind the table, facing its front
MEET = np.array([0.0, -0.02, TABLE_TOP + 0.34])  # where the object is handed over
SIDE = np.array([[0.0, 0.0, -1.0], [0.0, 1.0, 0.0], [1.0, 0.0, 0.0]])  # turns "in from +X" into "down"
SIDE_Q = np.array([math.sqrt(0.5), 0.0, math.sqrt(0.5), 0.0])  # the same turn, back to the world: (w, x, y, z)
FREE_END = 0.01  # metres: the left hand holds the object at least this far to the left of its middle, if it can
LEVEL = 0.35  # how far (sine) the right hand's closing line may lean from level: its fingers go beside the object, not under it
MAX_DROP = 0.015  # metres the object may fall when the right hand lets go of it on its spot
HANDOVER_TWIST = grasp_plan.TWIST_MARGIN - 0.1  # planned before the object is held out: keep a margin
MISSED_REACH_MM = 6.0  # the right hand this far short of its grip is not holding the object
SIDE_COVERAGE = 0.35  # share of the pad's width an object held from the side must fill: the pad stands on edge
TURNS = (0.0, math.pi / 2, -math.pi / 2, math.pi, math.pi / 4, -math.pi / 4, 3 * math.pi / 4, -3 * math.pi / 4)


def _fingers_below(arm: Arm, q, gap: float) -> float:
    """How far the fingers reach below the grip centre for a tool pose ``q`` (the hand on its side)."""
    rot = _matrix(q)
    c_world = rot @ arm.closing_axis
    w_world = rot @ np.cross(arm.tool_axis, arm.closing_axis)
    hand = arm.rig.hand
    return abs(c_world[2]) * (gap / 2 + hand.finger_thickness) + abs(w_world[2]) * hand.pad_width / 2


def _turned(points: np.ndarray, pivot, angle: float) -> np.ndarray:
    """``points`` turned by ``angle`` about the vertical line through ``pivot``."""
    c, s = math.cos(angle), math.sin(angle)
    rot = np.array([[c, -s, 0.0], [s, c, 0.0], [0.0, 0.0, 1.0]])
    return (np.asarray(points) - pivot) @ rot.T + pivot


class Handover:
    """Two arms pass objects across a table: the left picks one up from above and holds it out at the
    meeting point, turned so the right can take it from the side; the right takes it (its grip planned
    around the left hand, its fingers beside the object rather than under it); the left lets go and
    moves away; and the right sets it down on its spot. ``step(left_pose, left_gap, right_pose,
    right_gap)`` advances the world one physics step."""

    def __init__(self, left: Arm, right: Arm, hz: float, step, carry_clear: float) -> None:
        self.left, self.right, self.hz, self.step = left, right, float(hz), step
        self.carry_clear = carry_clear
        self.l_home, self.r_home = left.hand_pose(), right.hand_pose()
        self.l_base = np.array([LEFT_BASE[0], LEFT_BASE[1], TABLE_TOP])
        # No leaning back to the home posture: after the big turn that offers an object, the lean (the
        # shoulder and upper arm turning against each other at their torque limits) kept the left arm
        # rocking the object up to 11 cm while it held still. Each handover starts from home, so the
        # joints have no long run of moves to drift over.
        left.posture = right.posture = 0.0

    def _run(self, left_move, left_gap: float, right_move, right_gap: float, seconds: float) -> None:
        def at(move, t):
            return move.at(min(t, move.seconds)) if hasattr(move, "at") else move
        for i in range(int(round(seconds * self.hz))):
            t = i / self.hz
            self.step(at(left_move, t), left_gap, at(right_move, t), right_gap)

    def hold(self, seconds: float, left_gap: float | None = None, right_gap: float | None = None) -> None:
        lg = self.left.open_gap if left_gap is None else left_gap
        rg = self.right.open_gap if right_gap is None else right_gap
        self._run(self.left.hand_pose(), lg, self.right.hand_pose(), rg, seconds)

    def side_grip(self, points, normals, centre, obstacles, mass, friction):
        """The right hand's grip from the side (coming in along -X), clear of ``obstacles``: closing
        near level, so its fingers stand beside the object, and setting it down from a short drop."""
        hand = self.right.rig.hand
        bottom = float(np.asarray(points)[:, 2].min())

        def fits(centre_side, yaw, width) -> bool:
            c_world = SIDE.T @ np.array([math.cos(yaw), math.sin(yaw), 0.0])
            if abs(c_world[2]) > LEVEL:
                return False  # a finger under the object would carry it on, and drag it off its spot
            w_world = SIDE.T @ np.array([-math.sin(yaw), math.cos(yaw), 0.0])
            below = abs(c_world[2]) * (width / 2 + hand.finger_thickness) + abs(w_world[2]) * hand.pad_width / 2
            return below + 0.006 - ((SIDE.T @ np.asarray(centre_side))[2] - bottom) <= MAX_DROP

        return grasp_plan.plan(np.asarray(points) @ SIDE.T, np.asarray(normals) @ SIDE.T, np.asarray(centre) @ SIDE.T, -1e9,
                               hand, mass_kg=mass, friction=friction, grip_n=self.right.rig.grip_n,
                               obstacles=np.asarray(obstacles) @ SIDE.T, accept=fits, gravity=SIDE @ np.array([0.0, 0.0, -1.0]),
                               coverage=SIDE_COVERAGE)

    def offer(self, points, normals, centre, cloud, held_at, turned: float, mass, friction):
        """With the object held up at ``held_at`` (its points and the left hand's as they would be
        there): the turn about the vertical to hold it out at the meeting point by, leaving the right
        hand its steadiest grip, as ``(twist, turn, shift)`` (``shift`` moves the left hand from
        ``held_at`` to where it holds the object out), then the other workable turns, steadiest first.
        Empty when no turn the left wrist can make works. ``turned``: how far the left wrist will
        already have turned the tool, getting to ``held_at``."""
        low, high = self.left.wrist_limits()
        # Carried across with its orientation kept, the wrist also takes up the arm's swing.
        swing = math.remainder(math.atan2(MEET[1] - self.l_base[1], MEET[0] - self.l_base[0])
                               - math.atan2(held_at[1] - self.l_base[1], held_at[0] - self.l_base[0]), 2 * math.pi)
        found = []
        for rank, turn in enumerate(TURNS):
            if not low + 0.15 < self.left.wrist_after([turned + turn - swing])[0] < high - 0.15:
                continue
            shift = MEET - _turned(points, held_at, turn).mean(axis=0)  # its middle to the meeting point
            g2 = self.side_grip(_turned(points, held_at, turn) + shift, _turned(normals, np.zeros(3), turn),
                                _turned(np.asarray(centre)[None], held_at, turn)[0] + shift,
                                _turned(cloud, held_at, turn) + shift, mass, friction)
            if g2 is not None and g2.twist <= HANDOVER_TWIST:
                found.append((g2.twist + 0.02 * rank, g2.twist, turn, shift))  # a smaller turn wins a near tie
        return [(twist, turn, shift) for _key, twist, turn, shift in sorted(found, key=lambda f: f[0])]

    def pass_over(self, body, surface, target, mass: float | None, friction: float | None, say) -> dict:
        """Move one object to ``target`` (x, y) by way of a handover."""
        L, R = self.left, self.right
        lo, ro = L.open_gap, R.open_gap
        result = {"mass_kg": mass, "result": "missed"}
        points, normals, centre = PickPlace.surface_now(body, surface)

        def plan_left(accept=None):
            return grasp_plan.plan(points, normals, centre, TABLE_TOP, L.rig.hand, mass_kg=mass, friction=friction,
                                   grip_n=L.rig.grip_n, accept=accept)

        def bearing(p) -> float:
            return math.atan2(p[1] - self.l_base[1], p[0] - self.l_base[0])

        # Plan the whole handover before picking it up: for each way the left hand could hold it (by
        # either end, or anywhere; either way round), the turn to hold it out by that leaves the right
        # hand its steadiest grip.
        spread = points[:, :2] - points[:, :2].mean(axis=0)
        long_way = np.linalg.eigh(spread.T @ spread)[1][:, -1]
        grips = [plan_left(lambda c, _yaw, _width, way=way: (np.asarray(c[:2]) - centre[:2]) @ way <= -FREE_END)
                 for way in (long_way, -long_way)] + [plan_left()]
        p_now, q_now = L.hand_pose()
        lift = np.array([0.0, 0.0, self.carry_clear])
        best = None
        for g in (g for g in grips if g is not None):
            grip = np.array([g.centre[0], g.centre[1], g.tip_z + L.tip])
            for yaw in (g.yaw, g.yaw + math.pi):
                q_l = L.down(yaw)
                turned = (math.remainder(L.closing_yaw(q_l) - L.closing_yaw(q_now), 2 * math.pi)
                          - math.remainder(bearing(grip) - bearing(p_now), 2 * math.pi))
                plans = self.offer(points + lift, normals, np.asarray(centre) + lift, L.cloud_at(grip + lift, q_l, g.width),
                                   grip + lift, turned, mass, friction)
                if plans and (best is None or plans[0][0] < best[0] - 0.02):
                    best = (plans[0][0], g, q_l)
        if best is None:
            say("no grip both hands could share", "warn")
            result["result"] = "no handover grip" if any(grips) else "no grip"
            return result
        _twist, g, q_l = best
        result["left_grip_mm"] = g.width * 1000
        grip = np.array([g.centre[0], g.centre[1], g.tip_z + L.tip])
        above = grip + lift
        rest = self.r_home
        say("left hand reaching", "ink")
        p, q = L.hand_pose()
        self._run(Move(p, q, above, q_l, move_time(p, above, least=1.0)), lo, rest, ro, move_time(p, above, least=1.0))
        self._run(Move(above, q_l, grip, q_l, move_time(above, grip, speed=0.25, least=1.0)), lo, rest, ro,
                  move_time(above, grip, speed=0.25, least=1.0))
        self._run((grip, q_l), lo, rest, ro, 0.3)
        say("left hand gripping", "accent")
        self._run((grip, q_l), 0.0, rest, ro, 0.7)
        z0 = body.p[2]
        self._run(Move(grip, q_l, above, q_l, move_time(grip, above, speed=0.25, least=1.0)), 0.0, rest, ro,
                  move_time(grip, above, speed=0.25, least=1.0))
        if body.p[2] - z0 < 0.5 * self.carry_clear:
            say("slipped out of the left hand", "warn")
            result["result"] = "slipped"
            self._run((above, q_l), lo, rest, ro, 0.5)
            return result

        def put_back(start, q_start, why: str = "no grip for the right hand") -> dict:
            say(f"{why}: put back", "warn")
            result["result"] = "no handover grip"
            down = grip + [0.0, 0.0, 0.006]
            self._run(Move(start, q_start, down, q_l, move_time(start, down, least=1.5)), 0.0, rest, ro,
                      move_time(start, down, least=1.5))
            self._run((down, q_l), lo, rest, ro, 0.5)
            self._run(Move(down, q_l, self.l_home[0], self.l_home[1], 1.5), lo, rest, ro, 1.5)
            return result

        # The turn again, from where the object and the hand really are now; held out, the right hand's
        # grip is planned once more from where the object really is, and if that fails (it shifted in
        # the hand) the next turn is tried.
        held_at = L.hand_pose()[0]
        points, normals, centre = PickPlace.surface_now(body, surface)
        plans = self.offer(points, normals, centre, L.cloud(), held_at, 0.0, mass, friction)
        if not plans:
            return put_back(above, q_l)
        say("holding it out", "accent")
        start, q_start, g2 = above, q_l, None
        for _twist, turn, shift in plans[:3]:
            present = held_at + shift
            q_p = quat_mul(yaw_quat(turn), q_l)
            self._run(Move(start, q_start, present, q_p, move_time(start, present, least=1.5)), 0.0, rest, ro,
                      move_time(start, present, least=1.5))
            self._run((present, q_p), 0.0, rest, ro, 0.4)
            points, normals, centre = PickPlace.surface_now(body, surface)
            g2 = self.side_grip(points, normals, centre, L.cloud(), mass, friction)
            if g2 is not None:
                break
            start, q_start = present, q_p
        if g2 is None:
            return put_back(present, q_p)
        result["turned_deg"] = math.degrees(turn)
        result["right_grip_mm"] = g2.width * 1000
        # Of the two ways round, the one nearer how the right hand sits now.
        options = [quat_mul(SIDE_Q, R.down(y)) for y in (g2.yaw, g2.yaw + math.pi)]
        q_r = min(options, key=lambda o: float(np.linalg.norm(rotation_between(R.hand_pose()[1], o))))
        tool_world = _matrix(q_r) @ R.tool_axis  # which way the right hand points (along -X)
        take = SIDE.T @ np.array([g2.centre[0], g2.centre[1], g2.tip_z]) - R.tip * tool_world
        # Turned well clear of the object, then straight in along the fingers (the path the grip was
        # planned clear of): turning close by, the open fingers swept through the object or the other hand.
        ready = take - 0.22 * tool_world
        say("right hand taking it", "accent")
        p, q = R.hand_pose()
        self._run((present, q_p), 0.0, Move(p, q, ready, q_r, move_time(p, ready, least=1.5)), ro, move_time(p, ready, least=1.5))
        self._run((present, q_p), 0.0, Move(ready, q_r, take, q_r, move_time(ready, take, speed=0.2, least=1.0)), ro,
                  move_time(ready, take, speed=0.2, least=1.0))
        self._run((present, q_p), 0.0, (take, q_r), ro, 0.3)
        self._run((present, q_p), 0.0, (take, q_r), 0.0, 0.7)
        result["right_reach_mm"] = float(np.linalg.norm(R.hand_pose()[0] - take)) * 1000
        result["right_closed_mm"] = R.finger_gap() * 1000
        if result["right_reach_mm"] > MISSED_REACH_MM or R.finger_gap() < 0.5 * g2.width:
            # The right hand is not holding it (short of its grip, or the fingers closed past it): the
            # left keeps hold and puts it back, rather than letting go into nothing.
            self._run((present, q_p), 0.0, (take, q_r), ro, 0.4)
            self._run((present, q_p), 0.0, Move(take, q_r, ready, q_r, 1.0), ro, 1.0)
            self._run((present, q_p), 0.0, Move(ready, q_r, self.r_home[0], self.r_home[1], 1.5), ro, 1.5)
            put_back(present, q_p, "the right hand missed")
            result["result"] = "right hand missed"
            return result
        # The left lets go and moves away; the object must stay with the right hand.
        before = _matrix(R.hand_pose()[1]).T @ (body.p - R.hand_pose()[0])
        say("left hand letting go", "accent")
        self._run((present, q_p), lo, (take, q_r), 0.0, 0.5)
        away = present + [0.0, 0.0, 0.1]
        self._run(Move(present, q_p, away, q_p, 0.8), lo, (take, q_r), 0.0, 0.8)
        self._run(Move(away, q_p, self.l_home[0], self.l_home[1], 1.5), lo, (take, q_r), 0.0, 1.5)
        after = _matrix(R.hand_pose()[1]).T @ (body.p - R.hand_pose()[0])
        result["handover_slip_mm"] = float(np.linalg.norm(after - before)) * 1000
        if result["handover_slip_mm"] > DROPPED_MM:
            say("dropped in the handover", "warn")
            result["result"] = "dropped in the handover"
            self._run(self.l_home, lo, (take, q_r), ro, 0.6)
            self._run(self.l_home, lo, Move(take, q_r, self.r_home[0], self.r_home[1], 1.5), ro, 1.5)
            return result
        # The right sets it down on its spot: as low as the object's bottom and the lower finger both
        # allow (that finger stops just short of the table).
        say("setting down", "accent")
        result["tilt_held_deg"] = math.degrees(math.acos(max(-1.0, min(1.0, (_matrix(body.q) @ _matrix(body.q0).T)[2, 2]))))
        hand_p, hand_q = R.hand_pose()
        middle = body.world.mean(axis=0)
        lowest = float(body.world[:, 2].min())
        over = np.array([target[0] - (middle[0] - hand_p[0]), target[1] - (middle[1] - hand_p[1]), hand_p[2]])
        held = R.finger_gap()
        down = over.copy()
        down[2] = max(TABLE_TOP + 0.004 + (hand_p[2] - lowest), TABLE_TOP + 0.006 + _fingers_below(R, hand_q, held))
        result["drop_mm"] = max(0.0, (down[2] - (hand_p[2] - lowest)) - TABLE_TOP) * 1000
        self._run(self.l_home, lo, Move(take, q_r, over, q_r, move_time(take, over, least=1.5)), 0.0, move_time(take, over, least=1.5))
        self._run(self.l_home, lo, Move(over, q_r, down, q_r, move_time(over, down, speed=0.2, least=1.0)), 0.0,
                  move_time(over, down, speed=0.2, least=1.0))
        # Let go, the hand rising as fast as the lower finger opens downwards (it closes near level, so
        # only a little) to keep that finger clear of the table; then back away along the fingers and lift.
        release = ro
        let_go = down + [0.0, 0.0, abs((_matrix(hand_q) @ R.closing_axis)[2]) * (release - held) / 2 + 0.002]
        steps = 12
        for k in range(1, steps + 1):
            s = k / steps
            self._run(self.l_home, lo, (down + (let_go - down) * s, q_r), held + (release - held) * s, 0.45 / steps)
        self._run(self.l_home, lo, (let_go, q_r), release, 0.15)
        back = let_go - 0.12 * tool_world
        up = back + [0.0, 0.0, 0.08]
        self._run(self.l_home, lo, Move(let_go, q_r, back, q_r, 1.0), release, 1.0)
        self._run(self.l_home, lo, Move(back, q_r, up, q_r, 0.6), release, 0.6)
        self._run(self.l_home, lo, Move(up, q_r, self.r_home[0], self.r_home[1], 1.5), ro, 1.5)
        landed = body.world.mean(axis=0)
        error = float(np.linalg.norm(landed[:2] - np.asarray(target)))
        ok = error <= PLACE_TOLERANCE and landed[2] > TABLE_TOP
        tilt = math.degrees(math.acos(max(-1.0, min(1.0, (_matrix(body.q) @ _matrix(body.q0).T)[2, 2]))))
        result.update(off_mm=error * 1000, tilt_deg=tilt, result="placed" if ok else "dropped")
        say(f"handed over and placed, {error * 1000:.0f} mm from its spot" if ok else "dropped", "good" if ok else "warn")
        return result

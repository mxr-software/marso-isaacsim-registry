"""Sim Studio runner, launched by the extension in a separate, headless Isaac Sim:

    <isaac sim>/python.bat <extension>/marso/library/sim/runner.py --job <run folder>/job.json

Runs each test in the job, prints progress for the extension (one JSON object per line), and
writes ``run.json`` and ``report.html`` beside the videos.
"""

from __future__ import annotations

import argparse
import faulthandler
import json
import sys
import time
import traceback
import types
from pathlib import Path

EXTENSION_ROOT = Path(__file__).resolve().parents[3]


def _import_without_kit_extension() -> None:
    """Make ``marso.library.*`` importable without running the Kit extension's ``__init__``."""
    marso = types.ModuleType("marso")
    marso.__path__ = [str(EXTENSION_ROOT / "marso")]
    library = types.ModuleType("marso.library")
    library.__path__ = [str(EXTENSION_ROOT / "marso" / "library")]
    sys.modules.setdefault("marso", marso)
    sys.modules["marso.library"] = library


def main() -> int:
    # A crash inside PhysX or the renderer still leaves a Python stack in runner.log.
    faulthandler.enable()
    parser = argparse.ArgumentParser()
    parser.add_argument("--job", required=True)
    args, _ = parser.parse_known_args()
    job = json.loads(Path(args.job).read_text(encoding="utf-8"))
    out = Path(job["out_dir"])

    from isaacsim import SimulationApp

    # No viewport updates: only the test camera's render product is drawn (half the render cost).
    renderer = job.get("renderer", "RealTimePathTracing")
    spp = max(1, int(job.get("spp") or 0))
    app = SimulationApp({"headless": True, "width": int(job["width"]), "height": int(job["height"]), "renderer": renderer,
                         "anti_aliasing": int(job.get("anti_aliasing", 3)), "samples_per_pixel_per_frame": spp,
                         "denoiser": True, "disable_viewport_updates": True})
    _import_without_kit_extension()
    import carb.settings
    import omni.kit.app

    # Render the sky transparent so each frame can sit on Marso's backdrop instead of black.
    carb.settings.get_settings().set("/rtx/post/backgroundZeroAlpha/enabled", True)
    # A fixed exposure, like a studio camera: auto-exposure re-exposed every view, washing frames out when
    # an orbit turned towards the lights. No lens flares either.
    carb.settings.get_settings().set("/rtx/post/histogram/enabled", False)
    carb.settings.get_settings().set("/rtx/post/lensFlares/enabled", False)
    # CPU PhysX steps independent objects in parallel; physics is most of a run's time with big groups.
    import os

    carb.settings.get_settings().set("/persistent/physics/numThreads", max(4, min(16, (os.cpu_count() or 8) - 2)))
    if renderer == "PathTracing":
        # Each frame accumulates spp samples per subframe; let it keep accumulating across them.
        carb.settings.get_settings().set("/rtx/pathtracing/totalSpp", spp * int(job["subframes"]))

    from marso.library import usd_inspect
    from marso.library.core import api, sim_job, sim_report, storage
    from marso.library.sim import tests

    # Assets listed under a placeholder ("image 2") take the name their package carries.
    from pxr import Usd

    for asset in job["assets"]:
        if api.is_placeholder_name(asset["name"]):
            usd = storage.find_usd(Path(asset["folder"]))
            stage = Usd.Stage.Open(str(usd)) if usd else None
            better = usd_inspect.suggest_name(stage) if stage else ""
            asset["name"] = better or asset["name"]
    job["assets"] = sim_job.unique_names(job["assets"])

    def emit(event: str, **fields) -> None:
        print(sim_job.progress_line(event, **fields), flush=True)

    if not job.get("ffmpeg"):
        omni.kit.app.get_app().get_extension_manager().set_extension_enabled_immediate("omni.videoencoding", True)

    run = {
        "name": ", ".join(a["name"] for a in job["assets"]),
        "created": job.get("created", ""),
        "status": "running",
        "assets": [a["name"] for a in job["assets"]],
        "tests": [],
        "settings": {key: job[key] for key in ("quality", "aspect", "width", "height", "fps", "branding")},
        "errors": [],
    }

    # A resumed run (Isaac Sim stopped part way) keeps the tests it already finished.
    previous = out / sim_job.RUN_FILE
    if job.get("resume") and previous.is_file():
        try:
            earlier = json.loads(previous.read_text(encoding="utf-8"))
            run["tests"] = [t for t in earlier.get("tests", []) if t.get("key") in job["tests"]]
        except ValueError:
            pass
    finished = {t["key"] for t in run["tests"]}

    def save() -> None:
        (out / sim_job.RUN_FILE).write_text(json.dumps(run, indent=2), encoding="utf-8")

    save()
    emit("start", tests=job["tests"], resumed=sorted(finished))
    context = tests.Context(app, job, usd_inspect, storage, emit)
    for key in job["tests"]:
        if key in finished:
            continue
        started = time.time()
        try:
            entry = tests.TESTS[key](context)
            entry["seconds"] = round(time.time() - started)
            run["tests"].append(entry)
            emit("test_done", test=key, entry=entry)
        except Exception:  # noqa: BLE001 - one failing test must not lose the others
            error = traceback.format_exc()
            print(error, flush=True)
            run["errors"].append({"test": key, "error": error})
            emit("test_failed", test=key, error=error.strip().splitlines()[-1])
        save()
    run["status"] = "done" if not run["errors"] else ("partial" if run["tests"] else "failed")
    save()
    report = sim_report.write_report(out, run)
    emit("done", status=run["status"], report=report.name)
    app.close()
    return 0 if run["status"] == "done" else 1


if __name__ == "__main__":
    sys.exit(main())

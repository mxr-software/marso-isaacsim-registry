"""A wind sock for the wind test, so the wind's direction and strength read at a glance.

Built from USD prims (no physics, so nothing collides with it) and posed once per frame from the
wind speed: limp and hanging at 0, lifting as the wind rises, straight out from about 7.7 m/s
(15 knots, the aviation standard for a fully extended sock). It flutters in a wave that runs from
the mouth to the tail. Stripes alternate PBR violet and white, like the five 3-knot bands of a real sock.
"""

from __future__ import annotations

import math

from pxr import Gf, Sdf, UsdGeom, UsdShade

FULL_AT_MS = 7.7  # 15 knots: a standard sock is straight out
SEGMENTS = 5
SIDES = 28
VIOLET = (0.5, 0.24, 1.0)  # a deep PBR violet, clearly apart from the white bands
WHITE = (0.97, 0.97, 1.0)
POLE = (0.55, 0.56, 0.6)


def _material(stage, path: str, colour, roughness: float, emissive=None) -> UsdShade.Material:
    material = UsdShade.Material.Define(stage, path)
    shader = UsdShade.Shader.Define(stage, f"{path}/Surface")
    shader.CreateIdAttr("UsdPreviewSurface")
    shader.CreateInput("diffuseColor", Sdf.ValueTypeNames.Color3f).Set(Gf.Vec3f(*colour))
    shader.CreateInput("roughness", Sdf.ValueTypeNames.Float).Set(roughness)
    if emissive is not None:
        shader.CreateInput("emissiveColor", Sdf.ValueTypeNames.Color3f).Set(Gf.Vec3f(*emissive))
    material.CreateSurfaceOutput().ConnectToSource(shader.ConnectableAPI(), "surface")
    return material


def _tube(stage, path: str, length: float, r0: float, r1: float) -> UsdGeom.Mesh:
    """An open frustum along +X from x=0 (radius r0) to x=length (radius r1), seen from both sides."""
    mesh = UsdGeom.Mesh.Define(stage, path)
    points, counts, indices = [], [], []
    for x, r in ((0.0, r0), (length, r1)):
        for k in range(SIDES):
            a = 2 * math.pi * k / SIDES
            points.append(Gf.Vec3f(x, r * math.cos(a), r * math.sin(a)))
    for k in range(SIDES):
        n = (k + 1) % SIDES
        counts.append(4)
        indices += [k, n, SIDES + n, SIDES + k]
    mesh.CreatePointsAttr(points)
    mesh.CreateFaceVertexCountsAttr(counts)
    mesh.CreateFaceVertexIndicesAttr(indices)
    mesh.CreateDoubleSidedAttr(True)
    mesh.CreateSubdivisionSchemeAttr(UsdGeom.Tokens.none)
    return mesh


class WindSock:
    """A pole with a striped sock on top, pointing down the wind (+X, turned by ``heading_deg`` about Z)."""

    def __init__(self, stage, root: str, base: tuple[float, float, float], height: float, heading_deg: float = 0.0) -> None:
        self.height = height
        self.length = 0.7 * height
        mouth = 0.09 * height
        holder = UsdGeom.Xform.Define(stage, root)
        holder.AddTranslateOp().Set(Gf.Vec3d(*base))
        holder.AddRotateZOp().Set(float(heading_deg))  # 90: streams along +Y
        looks = f"{root}/Looks"
        pole_look = _material(stage, f"{looks}/Pole", POLE, 0.35)
        # A touch of glow so the sock reads against the dark set.
        stripes = (_material(stage, f"{looks}/Violet", VIOLET, 0.6, emissive=(0.14, 0.05, 0.34)),
                   _material(stage, f"{looks}/White", WHITE, 0.55, emissive=(0.06, 0.06, 0.065)))

        pole = UsdGeom.Cylinder.Define(stage, f"{root}/Pole")
        pole.CreateRadiusAttr(0.016 * height)
        pole.CreateHeightAttr(height)
        pole.CreateAxisAttr("Z")
        pole.AddTranslateOp().Set(Gf.Vec3d(0, 0, height / 2))
        UsdShade.MaterialBindingAPI.Apply(pole.GetPrim()).Bind(pole_look)
        foot = UsdGeom.Cylinder.Define(stage, f"{root}/Foot")
        foot.CreateRadiusAttr(0.06 * height)
        foot.CreateHeightAttr(0.012 * height)
        foot.CreateAxisAttr("Z")
        foot.AddTranslateOp().Set(Gf.Vec3d(0, 0, 0.006 * height))
        UsdShade.MaterialBindingAPI.Apply(foot.GetPrim()).Bind(pole_look)

        # The sock: a chain of stripes, each a child of the one before so bends add up.
        self.segments = []
        parent = f"{root}/Swivel"
        swivel = UsdGeom.Xform.Define(stage, parent)
        swivel.AddTranslateOp().Set(Gf.Vec3d(0, 0, height - mouth * 0.9))
        # A short arm holds the mouth off the pole, so a limp sock hangs beside it, not through it.
        arm_len = 1.4 * mouth
        arm = UsdGeom.Cylinder.Define(stage, f"{parent}/Arm")
        arm.CreateRadiusAttr(0.008 * height)
        arm.CreateHeightAttr(arm_len)
        arm.CreateAxisAttr("X")
        arm.AddTranslateOp().Set(Gf.Vec3d(arm_len / 2, 0, 0))
        UsdShade.MaterialBindingAPI.Apply(arm.GetPrim()).Bind(pole_look)
        seg_len = self.length / SEGMENTS
        for i in range(SEGMENTS):
            path = f"{parent}/S{i}" if i == 0 else f"{self.segments[-1]['path']}/S{i}"
            xform = UsdGeom.Xform.Define(stage, path)
            move = xform.AddTranslateOp()
            move.Set(Gf.Vec3d(arm_len if i == 0 else seg_len, 0, 0))
            if i == 0:
                ring = _tube(stage, f"{path}/Ring", 0.02 * height, mouth * 1.04, mouth * 1.04)
                UsdShade.MaterialBindingAPI.Apply(ring.GetPrim()).Bind(pole_look)
            bend = xform.AddRotateXYZOp()
            r0 = mouth * (1.0 - 0.5 * i / SEGMENTS)
            r1 = mouth * (1.0 - 0.5 * (i + 1) / SEGMENTS)
            shape = _tube(stage, f"{path}/Cloth", seg_len * 1.01, r0, r1)
            UsdShade.MaterialBindingAPI.Apply(shape.GetPrim()).Bind(stripes[i % 2])
            squash = UsdGeom.Xformable(shape).AddScaleOp()
            self.segments.append({"path": path, "bend": bend, "squash": squash})
        self.pose(0.0, 0.0)

    @property
    def top(self) -> float:
        return self.height

    def pose(self, wind: float, t: float) -> None:
        """Lift and flutter for this wind speed (m/s, along +X) at time t (s)."""
        fill = min(1.0, max(0.0, wind / FULL_AT_MS)) ** 0.8
        limp = 1.0 - fill
        # The flutter quickens and, once full, eases off into a small shiver.
        rate = 1.6 + 0.55 * min(wind, 20.0)
        amplitude = 2.0 + 9.0 * fill * (1.0 - 0.55 * min(1.0, max(0.0, (wind - FULL_AT_MS) / 15.0)))
        with Sdf.ChangeBlock():
            for i, seg in enumerate(self.segments):
                phase = rate * t - 0.9 * i
                droop = (62.0 if i == 0 else 7.0) * limp + (1.5 if i else 3.0) * fill
                wave = amplitude * (0.35 + 0.65 * i / SEGMENTS)
                seg["bend"].Set(Gf.Vec3f(wave * 0.25 * math.sin(phase * 1.7), droop + wave * 0.45 * math.sin(phase),
                                         wave * math.sin(phase + 0.6)))
                # A limp sock is flattened and narrower toward the tail; a full one is round.
                pinch = 1.0 - limp * (0.25 + 0.4 * i / SEGMENTS)
                seg["squash"].Set(Gf.Vec3f(1.0, 0.75 + 0.25 * pinch + 0.04 * fill * math.sin(phase * 2.3), pinch))

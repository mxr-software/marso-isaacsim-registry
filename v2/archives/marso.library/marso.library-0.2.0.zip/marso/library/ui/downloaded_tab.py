"""Downloaded tab: everything already on this computer, by project, usable offline."""

from __future__ import annotations

from typing import Callable

import omni.ui as ui

from .. import settings, usd_ops
from ..core import storage
from ..core.controller import LibraryController
from ..core.storage import LocalAsset
from .actions import Actions, copy_text, show_in_folder
from .details import WIDTH as DETAILS_WIDTH
from .details import DetailsPanel
from .grid import AssetGrid, Tile
from .widgets import FacetFilters, ListRow, SearchField, divider, empty_state, icon_button

ALL = ""
SIDE_WIDTH = 230


class DownloadedTab:
    def __init__(self, ctrl: LibraryController, actions: Actions, open_library: Callable[[], None]) -> None:
        self._ctrl = ctrl
        self._actions = actions
        self._open_library = open_library
        self._group = ALL
        self._search = ""
        self._rows: dict[str, ListRow] = {}
        self._menu: ui.Menu | None = None
        self._details = DetailsPanel(ctrl, on_favourite=self._actions.toggle_favourite)
        self._show_details = bool(settings.get_int(settings.KEY_SHOW_DETAILS, 1))
        self._facets = FacetFilters(self._apply_filters)
        self._grid = AssetGrid(
            on_favourite=lambda key: self._actions.toggle_favourite([key]),
            on_selection_changed=self._on_selection,
            on_activate=self._add,
            on_context_menu=self._show_menu,
            empty_fn=self._build_empty,
        )

    def build(self) -> None:
        with ui.HStack():
            with ui.ZStack(width=SIDE_WIDTH):
                ui.Rectangle(name="panel")
                with ui.VStack():
                    with ui.HStack(height=30):
                        ui.Spacer(width=10)
                        ui.Label("On this computer", name="heading")
                    self._groups_frame = ui.Frame(build_fn=self._build_groups)
            divider(vertical=True)
            with ui.VStack():
                with ui.HStack(height=34, spacing=8):
                    ui.Spacer(width=6)
                    self._title = ui.Label("", name="title", elided_text=True)
                    SearchField(self._on_search, hint="Search name, type, material...")
                    self._facets.build()
                    icon_button("folder.svg", "Open the downloads folder",
                                lambda: show_in_folder(self._ctrl.config.downloads_dir))
                    icon_button("refresh.svg", "Rescan the downloads folder", self._ctrl.rescan_local)
                    icon_button("info.svg", "Show or hide the details panel", self._toggle_details)
                    ui.Spacer(width=4)
                divider()
                with ui.HStack():
                    self._grid.build()
                    self._details_divider = ui.Frame(build_fn=lambda: divider(vertical=True), width=1)
                    self._details_holder = ui.Frame(build_fn=self._details.build, width=DETAILS_WIDTH)
                divider()
                with ui.HStack(height=36, spacing=6):
                    ui.Spacer(width=8)
                    self._select_all_button = ui.Button("Select all", width=80, height=26, clicked_fn=self._select_all)
                    self._deselect_button = ui.Button("Deselect", width=76, height=26, clicked_fn=self._deselect)
                    self._selection_label = ui.Label("", name="muted", width=ui.Fraction(1))
                    self._sim_button = ui.Button("Sim Studio", width=100, height=26,
                                                 clicked_fn=lambda: self._actions.test_in_sim(self._grid.selected),
                                                 tooltip="Film drop, friction, wind and scale tests of the selection")
                    self._delete_button = ui.Button("Delete...", width=80, height=26,
                                                    clicked_fn=lambda: self._actions.delete(self._grid.selected),
                                                    tooltip="Delete the selected downloads from disk (asks first)")
                    self._folder_button = ui.Button("Show in Folder", width=120, height=26, clicked_fn=self._reveal)
                    self._open_button = ui.Button("Open as Stage", width=120, height=26, clicked_fn=self._open,
                                                  tooltip="Open this asset's package on its own (replaces the stage)")
                    self._add_button = ui.Button("Add to Stage", name="primary", width=120, height=26,
                                                 clicked_fn=lambda: self._add(self._grid.selected))
                    ui.Spacer(width=8)
        self.refresh()

    def _build_groups(self) -> None:
        self._rows.clear()
        groups = self._groups()
        local = self._ctrl.local
        with ui.ScrollingFrame(horizontal_scrollbar_policy=ui.ScrollBarPolicy.SCROLLBAR_ALWAYS_OFF):
            with ui.VStack(height=0, spacing=2):
                if local:
                    self._add_row(ALL, "All downloads", list(local.values()))
                for name, items in groups.items():
                    self._add_row(name, name, items)
                if not local:
                    with ui.HStack(height=24):
                        ui.Spacer(width=10)
                        ui.Label("Nothing downloaded yet", name="faint")
                with ui.HStack(height=40):
                    ui.Spacer(width=10)
                    ui.Label(str(self._ctrl.config.downloads_dir), name="faint", word_wrap=True,
                             tooltip="Downloads folder (change it in Settings)")
                    ui.Spacer(width=6)

    def _add_row(self, key: str, title: str, items: list[LocalAsset]) -> None:
        size = storage.format_size(sum(item.size_bytes for item in items))
        subtitle = f"{len(items)} asset{'s' if len(items) != 1 else ''} · {size}"
        thumbs = [item.thumbnail_path for item in items if item.thumbnail_path]
        thumb = ""
        if key:
            project = next((p for p in self._ctrl.library.projects if p.name == key), None)
            cached = self._ctrl.thumbnail(storage.project_thumbnail_key(project.project_id)) if project else None
            thumb = str(cached or (thumbs[0] if thumbs else ""))
        with ui.HStack(height=42):
            ui.Spacer(width=4)
            self._rows[key] = ListRow(title, subtitle, lambda k=key: self._select_group(k),
                                      thumbnail=thumb, selected=key == self._group)
            ui.Spacer(width=4)

    def _build_empty(self) -> None:
        if not self._ctrl.local:
            empty_state(
                "Nothing downloaded yet",
                "Assets you download from the Library tab appear here and work offline. Assets the Marso "
                "Blender add-on downloaded show up too when both use the same downloads folder.",
                "Browse the Library",
                self._open_library,
            )
        else:
            empty_state("No downloads match", "Try a different search.")

    # --- refreshing ----------------------------------------------------------------------

    def refresh(self) -> None:
        if self._group and self._group not in self._groups():
            self._group = ALL
        self._groups_frame.rebuild()
        self._title.text = self._group or "All downloads"
        self._apply_filters()
        for frame in (self._details_divider, self._details_holder):
            frame.visible = self._show_details
        self._details.show(self._grid.selected[-1] if self._grid.selected else None)

    def on_local_changed(self, asset_id: str | None) -> None:
        """A single asset's details changed (e.g. its physics was read); refresh just that tile."""
        item = self._ctrl.local.get(asset_id) if asset_id else None
        if item is not None and any(tile.key == asset_id for tile in self._grid.tiles):
            self._grid.update_tile(self._tile(item))
        else:
            self.refresh()

    def destroy(self) -> None:
        self._grid.destroy()
        self._details.destroy()
        self._rows.clear()
        self._menu = None

    def _groups(self) -> dict[str, list[LocalAsset]]:
        groups: dict[str, list[LocalAsset]] = {}
        for item in sorted(self._ctrl.local.values(), key=lambda entry: entry.project_name.lower()):
            groups.setdefault(item.project_name, []).append(item)
        return groups

    def _visible(self) -> list[LocalAsset]:
        items = list(self._ctrl.local.values())
        if self._group:
            items = [item for item in items if item.project_name == self._group]
        if self._search:
            words = self._search.lower().split()
            items = [item for item in items if all(word in item.search_text for word in words)]
        items = [item for item in items
                 if self._facets.matches(item.enrichment.facet if item.enrichment else (lambda _key: ()))]
        return sorted(items, key=lambda entry: entry.downloaded_at, reverse=True)

    def _apply_filters(self) -> None:
        """Offer the facets of this group's downloads, then show what passes search and filters."""
        values: dict[str, list[str]] = {"category": [], "material": []}
        for item in self._ctrl.local.values():
            if item.enrichment is not None and (not self._group or item.project_name == self._group):
                for key in values:
                    values[key].extend(item.enrichment.facet(key))
        self._facets.set_values(values)
        self._grid.set_tiles([self._tile(item) for item in self._visible()])
        self._refresh_actions()

    def _tile(self, item: LocalAsset) -> Tile:
        thumb = item.thumbnail_path or self._ctrl.thumbnail(item.asset_id)
        lines = [item.name, f"Project: {item.project_name}", f"File: {item.usd_path}",
                 "Double-click or drag into the viewport to add it to the stage."]
        sim_ready = item.physics is not None and item.physics.sim_ready
        if item.physics is not None:
            lines.extend(["", *item.physics.describe()])
        detail = storage.format_size(item.size_bytes)
        if not self._group:
            detail = f"{item.project_name} · {detail}"
        update = self._ctrl.has_update(item.asset_id)
        if update:
            detail = "Update available"
            lines.append("Marso has a newer version: right-click > Update.")
        flags = self._ctrl.flags_of(item.asset_id)
        review = [flag for flag in flags if flag not in lines]
        if review:
            lines.extend(["", *review])
        return Tile(
            key=item.asset_id,
            title=item.name,
            status="update" if update else "downloaded",
            favourite=settings.is_favourite(item.asset_id),
            flags=tuple(flags),
            status_text=detail,
            thumbnail=str(thumb) if thumb else "",
            tooltip="\n".join(lines),
            glyph="simready" if sim_ready else "pbr",
            usd=True,
            drag_path=item.stage_path.as_posix(),
        )

    def _refresh_actions(self) -> None:
        selected = self._selected_local()
        visible = self._grid.tiles
        if selected:
            self._selection_label.text = f"{len(selected)} of {len(visible)} selected"
        else:
            self._selection_label.text = f"0 selected · {len(visible)} assets" if visible else ""
        self._select_all_button.enabled = bool(visible) and len(selected) < len(visible)
        self._deselect_button.enabled = bool(selected)
        self._add_button.enabled = bool(selected)
        self._add_button.text = f"Add to Stage ({len(selected)})" if len(selected) > 1 else "Add to Stage"
        self._open_button.enabled = len(selected) == 1
        self._sim_button.enabled = bool(selected)
        self._delete_button.enabled = bool(selected)
        self._folder_button.enabled = len(selected) == 1

    # --- events --------------------------------------------------------------------------

    def _selected_local(self) -> list[LocalAsset]:
        return [self._ctrl.local[key] for key in self._grid.selected if key in self._ctrl.local]

    def _select_group(self, key: str) -> None:
        self._group = key
        for name, row in self._rows.items():
            row.selected = name == key
        self._title.text = key or "All downloads"
        self._apply_filters()

    def _on_search(self, text: str) -> None:
        self._search = text
        self._grid.set_tiles([self._tile(item) for item in self._visible()])
        self._refresh_actions()

    def _on_selection(self) -> None:
        self._refresh_actions()
        self._details.show(self._grid.selected[-1] if self._grid.selected else None)

    def _select_all(self) -> None:
        self._grid.select_all()
        self._on_selection()

    def _deselect(self) -> None:
        self._grid.select([])
        self._on_selection()

    def _toggle_details(self) -> None:
        self._show_details = not self._show_details
        settings.set_value(settings.KEY_SHOW_DETAILS, int(self._show_details))
        for frame in (self._details_divider, self._details_holder):
            frame.visible = self._show_details

    def _add(self, keys: list[str]) -> None:
        self._actions.add_local_to_stage([self._ctrl.local[key] for key in keys if key in self._ctrl.local])

    def _reveal(self) -> None:
        selected = self._selected_local()
        if selected:
            show_in_folder(selected[0].usd_path)

    def _open(self) -> None:
        selected = self._selected_local()
        if len(selected) == 1:
            self._actions.open_as_stage(selected[0])

    def _show_menu(self, keys: list[str]) -> None:
        items = [self._ctrl.local[key] for key in keys if key in self._ctrl.local]
        if not items:
            return
        self._menu = ui.Menu("Marso download")
        with self._menu:
            ui.MenuItem("Add to Stage", triggered_fn=lambda: self._actions.add_local_to_stage(items))
            if any(self._ctrl.has_update(i.asset_id) for i in items):
                ui.MenuItem("Update", triggered_fn=lambda: self._actions.update([i.asset_id for i in items]))
            if len(items) == 1:
                ui.MenuItem("Open as Stage", triggered_fn=lambda: self._actions.open_as_stage(items[0]))
                ui.Separator()
                ui.MenuItem("Show in Folder", triggered_fn=lambda: show_in_folder(items[0].usd_path))
                ui.MenuItem("Copy File Path", triggered_fn=lambda: copy_text(str(items[0].usd_path)))
                ui.MenuItem("Copy Asset ID", triggered_fn=lambda: copy_text(items[0].asset_id))
            ui.Separator()
            ids = [i.asset_id for i in items]
            starred = all(settings.is_favourite(a) for a in ids)
            ui.MenuItem("Remove from Favourites" if starred else "Add to Favourites",
                        triggered_fn=lambda: self._actions.toggle_favourite(ids))
            ui.MenuItem("Test in Sim Studio", triggered_fn=lambda: self._actions.test_in_sim(ids))
            ui.Separator()
            ui.MenuItem("Delete Download...", triggered_fn=lambda: self._actions.delete(ids))
        self._menu.show()

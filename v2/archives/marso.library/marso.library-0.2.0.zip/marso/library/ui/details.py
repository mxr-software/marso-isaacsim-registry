"""The details panel: everything Marso knows about one asset, beside the Library and Downloaded grids.

Reads ``LibraryController.enrichment_of`` (the download's enrichment, with physics and real-world
size, else the listing's) plus what the extension measured itself (physics summary, file).
"""

from __future__ import annotations

import omni.ui as ui

from .. import settings
from ..core import storage
from ..core.controller import LibraryController
from . import style
from .actions import copy_text
from .grid import AssetGrid

WIDTH = 300
LABEL_W = 92


class DetailsPanel:
    """A side panel for the focused asset; ``show(None)`` shows a hint."""

    def __init__(self, ctrl: LibraryController, on_favourite=None) -> None:
        self._ctrl = ctrl
        self._on_favourite = on_favourite
        self._asset_id: str | None = None
        self._frame: ui.Frame | None = None

    def build(self) -> None:
        with ui.ZStack(width=WIDTH):
            ui.Rectangle(name="panel")
            self._frame = ui.Frame(build_fn=self._build)

    def show(self, asset_id: str | None) -> None:
        if asset_id != self._asset_id:
            self._asset_id = asset_id
            if self._frame is not None:
                self._frame.rebuild()

    def refresh(self) -> None:
        if self._frame is not None:
            self._frame.rebuild()

    def destroy(self) -> None:
        self._frame = None

    # --- building ----------------------------------------------------------------------------

    def _build(self) -> None:
        ctrl, asset_id = self._ctrl, self._asset_id
        if not asset_id:
            with ui.VStack():
                ui.Spacer(height=24)
                with ui.HStack(height=0):
                    ui.Spacer(width=16)
                    ui.Label("Select an asset to see what Marso knows about it: what it is, its materials, "
                             "physics and real-world size.", name="faint", word_wrap=True)
                    ui.Spacer(width=16)
                ui.Spacer()
            return
        asset = ctrl.library.asset(asset_id)
        local = ctrl.local.get(asset_id)
        info = ctrl.enrichment_of(asset_id)
        thumb = ctrl.asset_thumbnail(asset_id)
        sim_ready = local is not None and local.physics is not None and local.physics.sim_ready
        with ui.ScrollingFrame(horizontal_scrollbar_policy=ui.ScrollBarPolicy.SCROLLBAR_ALWAYS_OFF):
            with ui.VStack(height=0, spacing=4):
                ui.Spacer(height=10)
                with ui.HStack(height=WIDTH - 40):
                    ui.Spacer(width=20)
                    with ui.ZStack():
                        ui.Rectangle(name="thumb_bg")
                        ui.Image(str(thumb) if thumb else style.icon("placeholder.svg"),
                                 fill_policy=ui.FillPolicy.PRESERVE_ASPECT_FIT)
                    ui.Spacer(width=20)
                with ui.HStack(height=0):
                    ui.Spacer(width=14)
                    with ui.VStack(height=0, spacing=4):
                        with ui.HStack(height=0):
                            ui.Label(ctrl.name_of(asset_id), name="title", word_wrap=True)
                            starred = settings.is_favourite(asset_id)
                            star = ui.Image(style.icon("star_on.svg" if starred else "star.svg"), width=20, height=20,
                                            tooltip="Remove from favourites" if starred else "Add to favourites")
                            star.set_mouse_pressed_fn(lambda x, y, b, m: self._star(asset_id) if b == 0 else None)
                        with ui.HStack(height=22):
                            AssetGrid._build_chip("simready" if sim_ready else "pbr", local is not None)
                            ui.Spacer()
                        if info and info.description_short:
                            ui.Label(info.description_short, name="muted", word_wrap=True)
                    ui.Spacer(width=14)
                flags = ctrl.flags_of(asset_id)
                if ctrl.has_update(asset_id):
                    flags = ["Marso has a newer version: right-click the tile > Update", *flags]
                if flags:
                    self._section("Worth a look")
                    for flag in flags:
                        with ui.HStack(height=0):
                            ui.Spacer(width=14)
                            ui.Image(style.icon("flag.svg"), width=14, height=14)
                            ui.Spacer(width=6)
                            ui.Label(flag, name="muted", word_wrap=True)
                            ui.Spacer(width=14)
                if info:
                    self._section("What it is")
                    self._row("Type", info.taxonomy)
                    self._row("Materials", ", ".join(info.materials))
                    self._row("Setting", info.setting)
                    self._row("Used", ", ".join(info.placements))
                    self._row("Style", info.style_period)
                    self._row("Origin", info.region)
                    self._row("Condition", ", ".join(info.conditions + info.cleanliness))
                    if info.dimensions_m:
                        w, d, h = (v * 100 for v in info.dimensions_m)
                        self._section("Real-world size")
                        self._row("W x D x H", f"{w:.3g} x {d:.3g} x {h:.3g} cm")
                    physics_rows = [
                        ("Mass", f"{local.physics.mass_kg:.3g} kg (density x collider volume)"
                         if local is not None and local.physics is not None and local.physics.mass_kg else ""),
                        ("Density", f"{info.density_kg_m3:g} kg/m³" if info.density_kg_m3 else ""),
                        ("Friction", " / ".join(f"{v:g}" for v in (info.static_friction, info.dynamic_friction)
                                                if v is not None) + (" (static / dynamic)" if info.static_friction is not None else "")),
                        ("Bounce", f"{info.restitution:g} restitution" if info.restitution is not None else ""),
                        ("Hollow", {True: "yes", False: "no"}.get(info.hollow, "")),
                        ("Preset", info.physics_preset),
                    ]
                    if any(value for _, value in physics_rows):
                        self._section("Physics")
                        for label, value in physics_rows:
                            self._row(label, value)
                    if info.tags or info.search_aliases:
                        self._section("Search words")
                        self._row("Tags", ", ".join(info.tags))
                        self._row("Also called", ", ".join(info.search_aliases))
                    if info.needs_review:
                        self._section("Marso review")
                        self._row("Flagged", ", ".join(info.review_reasons) or "needs review", name="error")
                    if info.description_long:
                        self._section("Description")
                        with ui.HStack(height=0):
                            ui.Spacer(width=14)
                            ui.Label(info.description_long, name="muted", word_wrap=True)
                            ui.Spacer(width=14)
                else:
                    self._section("What it is")
                    with ui.HStack(height=0):
                        ui.Spacer(width=14)
                        ui.Label("Marso has not described this asset yet.", name="faint", word_wrap=True)
                        ui.Spacer(width=14)
                if local is not None and local.physics is not None:
                    self._section("In Isaac Sim")
                    for line in local.physics.describe():
                        with ui.HStack(height=0):
                            ui.Spacer(width=14)
                            ui.Label(line, name="muted", word_wrap=True)
                            ui.Spacer(width=14)
                self._section("File")
                project = asset.project_id if asset else (local.project_id if local else "")
                self._row("Project", ctrl.project_name(project) if project else (local.project_name if local else ""))
                if local is not None:
                    self._row("On disk", f"{storage.format_size(local.size_bytes)} · {local.usd_path.name}")
                elif asset is not None:
                    self._row("On disk", "not downloaded")
                if asset is not None and asset.model_version:
                    self._row("Version", asset.model_version)
                with ui.HStack(height=24):
                    ui.Spacer(width=14)
                    ui.Label("Asset ID", name="faint", width=LABEL_W)
                    ui.Label(asset_id[:8] + "...", name="muted", width=ui.Fraction(1), tooltip=asset_id)
                    ui.Button("Copy", width=52, height=20, clicked_fn=lambda: copy_text(asset_id))
                    ui.Spacer(width=14)
                ui.Spacer(height=14)

    def _star(self, asset_id: str) -> None:
        if self._on_favourite is not None:
            self._on_favourite([asset_id])

    @staticmethod
    def _section(title: str) -> None:
        ui.Spacer(height=6)
        with ui.HStack(height=16):
            ui.Spacer(width=14)
            ui.Label(title.upper(), name="eyebrow")

    @staticmethod
    def _row(label: str, value: str, name: str = "muted") -> None:
        if not value:
            return
        with ui.HStack(height=0):
            ui.Spacer(width=14)
            ui.Label(label, name="faint", width=LABEL_W)
            ui.Label(value, name=name, word_wrap=True)
            ui.Spacer(width=14)

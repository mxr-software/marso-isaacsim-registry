"""The Marso window: Library, Downloaded and Settings tabs."""

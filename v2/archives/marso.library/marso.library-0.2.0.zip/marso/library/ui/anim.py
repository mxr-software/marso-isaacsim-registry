"""Small animations for the Marso window: a dot spinner, a shimmer bar, pulses, fades and pops.

omni.ui has no animation system, so an ``Animator`` ticks registered callbacks from Kit's update loop,
about 30 times a second, and only while any are registered: an idle window costs nothing. Callbacks are
grouped, so a frame that rebuilds (and so recreates its widgets) clears its own group first.
"""

from __future__ import annotations

import asyncio
import logging
import math
import time
from collections.abc import Callable

import omni.kit.app
import omni.ui as ui

log = logging.getLogger("marso.library")

FPS = 30.0
Tick = Callable[[float], bool | None]  # given seconds since it was added; return False when finished


def with_alpha(colour: int, alpha: float) -> int:
    """An omni.ui 0xAABBGGRR colour with its alpha replaced (0..1)."""
    return (int(max(0.0, min(1.0, alpha)) * 255) << 24) | (colour & 0x00FFFFFF)


def mix(a: int, b: int, t: float) -> int:
    """Blend two 0xAABBGGRR colours (t 0 = a, 1 = b)."""
    t = max(0.0, min(1.0, t))
    out = 0
    for shift in (0, 8, 16, 24):
        ca, cb = (a >> shift) & 0xFF, (b >> shift) & 0xFF
        out |= round(ca + (cb - ca) * t) << shift
    return out


class Animator:
    def __init__(self) -> None:
        self._groups: dict[str, list[tuple[float, Tick]]] = {}
        self._task: asyncio.Future | None = None
        self._closed = False

    def add(self, group: str, tick: Tick) -> None:
        if self._closed:
            return
        self._groups.setdefault(group, []).append((time.monotonic(), tick))
        if self._task is None or self._task.done():
            self._task = asyncio.ensure_future(self._loop())

    def clear(self, group: str) -> None:
        self._groups.pop(group, None)

    def stop(self) -> None:
        self._closed = True
        self._groups.clear()
        if self._task is not None:
            self._task.cancel()
            self._task = None

    @property
    def running(self) -> bool:
        return any(self._groups.values())

    async def _loop(self) -> None:
        app = omni.kit.app.get_app()
        last = 0.0
        while self.running and not self._closed:
            await app.next_update_async()
            now = time.monotonic()
            if now - last < 1.0 / FPS:
                continue
            last = now
            for group, items in list(self._groups.items()):
                keep = []
                for started, tick in items:
                    try:
                        if tick(now - started) is not False:
                            keep.append((started, tick))
                    except Exception:  # noqa: BLE001 - a widget that went away ends its animation, nothing else
                        log.debug("Marso: an animation stopped", exc_info=True)
                if keep:
                    self._groups[group] = keep
                else:
                    self._groups.pop(group, None)


def spinner(animator: Animator, group: str, size: float, colour: int, dots: int = 8) -> ui.Widget:
    """A ring of dots chasing round (the Marso violet by default), for work in progress."""
    radius = size / 2.0
    dot = max(1.5, size / 9.0)
    circles: list[ui.Circle] = []
    root = ui.ZStack(width=size, height=size)
    with root:
        for i in range(dots):
            angle = 2 * math.pi * i / dots - math.pi / 2
            x = radius + (radius - dot) * math.cos(angle) - dot
            y = radius + (radius - dot) * math.sin(angle) - dot
            with ui.Placer(offset_x=x, offset_y=y):
                circles.append(ui.Circle(radius=dot, width=dot * 2, height=dot * 2,
                                         style={"background_color": with_alpha(colour, 0.2), "border_width": 0}))

    def tick(t: float) -> None:
        head = (t * dots * 1.1) % dots
        for i, circle in enumerate(circles):
            behind = (head - i) % dots  # 0 at the head, growing behind it
            circle.set_style({"background_color": with_alpha(colour, max(0.18, 1.0 - behind / dots * 1.3)),
                              "border_width": 0})

    animator.add(group, tick)
    return root


def shimmer(animator: Animator, group: str, height: float, colour: int, track: int, segment: float = 0.28) -> ui.Widget:
    """An indeterminate progress bar: a soft highlight sweeping along a thin track."""
    root = ui.ZStack(height=height)
    with root:
        bar = ui.Rectangle(style={"background_color": track, "border_radius": height / 2})
        with ui.HStack():
            lead = ui.Spacer(width=0)
            glow = ui.Rectangle(width=0, style={"background_color": colour, "border_radius": height / 2})
            ui.Spacer()

    def tick(t: float) -> None:
        width = bar.computed_width
        if width <= 0:
            return
        span = width * segment
        x = ((t * 0.55) % 1.4) * (width + span) - span  # sweep across, with a pause off the end
        start, end = max(0.0, x), min(width, x + span)
        lead.width = ui.Pixel(start)
        glow.width = ui.Pixel(max(0.0, end - start))

    animator.add(group, tick)
    return root


def pulse(animator: Animator, group: str, widget: ui.Widget, colour: int, key: str = "color", period: float = 1.3) -> None:
    """Breathe a widget's colour between dim and full (the step being worked on)."""
    def tick(t: float) -> None:
        level = 0.45 + 0.55 * (0.5 + 0.5 * math.sin(2 * math.pi * t / period))
        widget.set_style({key: with_alpha(colour, level)})

    animator.add(group, tick)


def fade_in(animator: Animator, group: str, widget: ui.Widget, colour: int = 0xFFFFFFFF, seconds: float = 0.45,
            key: str = "color") -> None:
    """Fade a widget in from transparent (a new image)."""
    widget.set_style({key: with_alpha(colour, 0.0)})

    def tick(t: float) -> bool:
        level = min(1.0, t / seconds)
        widget.set_style({key: with_alpha(colour, 1.0 - (1.0 - level) ** 3)})
        return level < 1.0

    animator.add(group, tick)


def pop(animator: Animator, group: str, image: ui.Image, size: float, seconds: float = 0.35) -> None:
    """Grow an icon in with a little overshoot (a step just done)."""
    def tick(t: float) -> bool:
        k = min(1.0, t / seconds)
        scale = 1.0 + 0.35 * math.sin(math.pi * k) if k < 1.0 else 1.0  # up past full size, then settle
        scale *= 0.55 + 0.45 * min(1.0, k * 2.0)
        image.width = image.height = ui.Pixel(size * scale)
        return k < 1.0

    image.width = image.height = ui.Pixel(size * 0.55)
    animator.add(group, tick)


def ticker(animator: Animator, group: str, label: ui.Label, text: Callable[[], str], every: float = 1.0) -> None:
    """Keep a label's text current (an elapsed time) without rebuilding anything."""
    state = {"next": 0.0}

    def tick(t: float) -> None:
        if t >= state["next"]:
            state["next"] = t + every
            label.text = text()

    animator.add(group, tick)

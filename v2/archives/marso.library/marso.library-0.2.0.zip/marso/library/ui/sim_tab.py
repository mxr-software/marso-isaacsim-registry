"""Sim Studio tab: pick objects and tests, render branded videos in the background, browse past runs."""

from __future__ import annotations

from pathlib import Path
from typing import Callable

import omni.ui as ui

from .. import settings, sim_service
from ..core import sim_job
from ..sim_service import SimStudio
from . import style
from .grid import AssetGrid
from .actions import notify, open_file, open_url, show_in_folder
from .widgets import divider

SIDE_WIDTH = 270
CARD_W = 252
PREVIEW_H = round(CARD_W * 9 / 16)  # the test's still, 16:9 across the top of its card
CARD_GAP = 12
RUN_W, RUN_H = 236, 200
QUALITY_KEYS = [q.key for q in sim_job.QUALITIES]
ASPECT_KEYS = list(sim_job.ASPECTS)
BRANDING_LABELS = {sim_job.BOTH: "Branded and clean", sim_job.BRANDED: "Branded only", sim_job.CLEAN: "Clean only"}

# (option key, label, min, max, step) shown on each test's card.
# Each test's settings: (option, label, low, high) for a number; low and high None for an on/off box.
FIELDS: dict[str, list[tuple[str, str, float | None, float | None]]] = {
    "scale": [("orbit_s", "Orbit (s)", 3, 30)],
    "drop": [("drop_height", "Height (m)", 0.1, 5)],
    "friction": [("max_angle", "Max tilt (°)", 10, 80), ("tilt_rate", "Tilt speed (°/s)", 1, 15)],
    "wind": [("max_wind", "Max wind (m/s)", 2, 60), ("ramp_s", "Ramp (s)", 3, 30)],
    "collision": [],
    "robot": [("speed", "Playback speed (x)", 1, 4), ("max_objects", "Objects (at most)", 1, 4),
              ("split_screen", "Split screen", None, None), ("labels", "Object labels", None, None),
              ("drop_in", "Drop onto the table", None, None), ("risky_grips", "Try risky grips", None, None),
              ("max_tries", "Tries per object", 1, 5)],
    "robot_suction": [("speed", "Playback speed (x)", 1, 4), ("max_objects", "Objects (at most)", 1, 4),
                      ("split_screen", "Split screen", None, None), ("labels", "Object labels", None, None),
                      ("drop_in", "Drop onto the table", None, None), ("max_tries", "Tries per object", 1, 5)],
    "robot_wide": [("speed", "Playback speed (x)", 1, 4), ("max_objects", "Objects (at most)", 1, 4),
                   ("split_screen", "Split screen", None, None), ("labels", "Object labels", None, None),
                   ("drop_in", "Drop onto the table", None, None), ("risky_grips", "Try risky grips", None, None),
                   ("max_tries", "Tries per object", 1, 5)],
    "robot_humanoid": [("speed", "Playback speed (x)", 1, 4), ("max_objects", "Objects (at most)", 1, 3),
                       ("split_screen", "Split screen", None, None), ("labels", "Object labels", None, None),
                       ("drop_in", "Drop onto the table", None, None), ("risky_grips", "Try risky grips", None, None),
                       ("max_tries", "Tries per object", 1, 5)],
    "robot_handover": [("speed", "Playback speed (x)", 1, 4), ("max_objects", "Objects (at most)", 1, 3),
                       ("split_screen", "Split screen", None, None)],
}


class SimTab:
    def __init__(self, studio: SimStudio, open_library: Callable[[], None]) -> None:
        self.studio = studio
        self._open_library = open_library
        prefs = sim_service.load_prefs()
        self._tests: set[str] = set(prefs.get("tests") or ["scale", "drop", "friction", "wind"])
        self._options: dict[str, dict] = {key: {**sim_job.spec(key).options, **(prefs.get("options", {}).get(key) or {})}
                                         for key in sim_job.TEST_KEYS}
        self._quality = prefs.get("quality", sim_job.DEFAULT_QUALITY)
        self._aspect = prefs.get("aspect", sim_job.DEFAULT_ASPECT)
        self._branding = prefs.get("branding", sim_job.BOTH)
        self._cards: dict[str, ui.Rectangle] = {}
        self._boxes: dict[str, ui.CheckBox] = {}
        self._open: set[str] = set()  # cards whose settings are showing
        self._columns = 0
        self._menu: ui.Menu | None = None
        self._picker = None
        self._built = False

    # --- building ------------------------------------------------------------------------------

    def build(self) -> None:
        with ui.HStack():
            with ui.ZStack(width=SIDE_WIDTH):
                ui.Rectangle(name="panel")
                with ui.VStack():
                    with ui.HStack(height=30):
                        ui.Spacer(width=10)
                        self._objects_title = ui.Label("Objects", name="heading")
                        ui.Button("Clear", width=56, height=22, clicked_fn=self.studio.clear)
                        ui.Spacer(width=8)
                    self._objects_frame = ui.Frame(build_fn=self._build_objects)
            divider(vertical=True)
            with ui.ScrollingFrame(horizontal_scrollbar_policy=ui.ScrollBarPolicy.SCROLLBAR_ALWAYS_OFF):
                with ui.HStack():
                    ui.Spacer(width=14)
                    with ui.VStack(height=0, spacing=10):
                        ui.Spacer(height=8)
                        self._section("TESTS", "What to film")
                        # Rows rather than a fixed grid: a card grows when its settings open, and its row with it.
                        self._cards_frame = ui.Frame(build_fn=self._build_cards, height=0)
                        self._cards_frame.set_computed_content_size_changed_fn(self._cards_resized)
                        self._section("OUTPUT", "How to film it")
                        self._build_output()
                        self._build_render_row()
                        self._section("RECENT", "Your Sim Studio runs")
                        self._runs_frame = ui.Frame(build_fn=self._build_runs, height=0)
                        ui.Spacer(height=12)
                    ui.Spacer(width=14)
        self._built = True
        self.refresh()

    def _section(self, eyebrow: str, title: str) -> None:
        with ui.VStack(height=0, spacing=2):
            ui.Spacer(height=6)
            ui.Label(eyebrow, name="eyebrow", height=16)
            ui.Label(title, name="title", height=24)

    def _build_objects(self) -> None:
        ctrl = self.studio.ctrl
        with ui.ScrollingFrame(horizontal_scrollbar_policy=ui.ScrollBarPolicy.SCROLLBAR_ALWAYS_OFF):
            with ui.VStack(height=0, spacing=2):
                if not self.studio.objects:
                    with ui.HStack(height=0):
                        ui.Spacer(width=10)
                        ui.Label("Right-click assets in the Library or Downloaded tab and choose Test in Sim Studio, "
                                 "or select them and press Sim Studio.", name="faint", word_wrap=True)
                        ui.Spacer(width=10)
                    with ui.HStack(height=34):
                        ui.Spacer(width=10)
                        ui.Button("Browse the Library", width=160, height=26, clicked_fn=self._open_library)
                for asset_id in self.studio.objects:
                    local = ctrl.local.get(asset_id)
                    thumb = ctrl.asset_thumbnail(asset_id)
                    sim_ready = local is not None and local.physics is not None and local.physics.sim_ready
                    with ui.ZStack(height=46):
                        ui.Rectangle(name="row")
                        with ui.HStack(spacing=8):
                            ui.Spacer(width=6)
                            with ui.VStack(width=34):
                                ui.Spacer()
                                with ui.ZStack(width=34, height=34):
                                    ui.Rectangle(name="thumb_bg")
                                    ui.Image(str(thumb) if thumb else style.icon("placeholder.svg"),
                                             fill_policy=ui.FillPolicy.PRESERVE_ASPECT_CROP)
                                ui.Spacer()
                            with ui.VStack():
                                ui.Spacer()
                                ui.Label(self.studio.name(asset_id), elided_text=True, height=18)
                                status = ("sim ready" if sim_ready else "downloaded") if local else "downloads first"
                                ui.Label(status, name="faint", height=15)
                                ui.Spacer()
                            with ui.VStack(width=0):
                                ui.Spacer()
                                AssetGrid._build_chip("simready" if sim_ready else "pbr", local is not None)
                                ui.Spacer()
                            ui.Button("×", width=24, height=24, tooltip="Remove",
                                      clicked_fn=lambda a=asset_id: self.studio.remove(a))
                            ui.Spacer(width=6)

    def _cards_resized(self) -> None:
        """Rebuild the cards when the window's width changes how many fit across."""
        if self._columns and self._columns != self._fit_columns():
            self._cards_frame.rebuild()

    def _fit_columns(self) -> int:
        width = self._cards_frame.computed_width if self._cards_frame else 0
        return max(1, int((width + CARD_GAP) // (CARD_W + CARD_GAP))) if width > 0 else 3

    def _build_cards(self) -> None:
        self._columns = self._fit_columns()
        specs = list(sim_job.TESTS)
        with ui.VStack(height=0, spacing=CARD_GAP):
            for start in range(0, len(specs), self._columns):
                # One row: its cards stand as tall as the tallest one in it.
                with ui.HStack(height=0, spacing=CARD_GAP):
                    for spec in specs[start:start + self._columns]:
                        self._build_card(spec)
                    ui.Spacer()

    def _build_card(self, spec: sim_job.TestSpec) -> None:
        with ui.ZStack(width=CARD_W):
            card = ui.Rectangle(name="card")
            card.selected = spec.key in self._tests
            self._cards[spec.key] = card
            with ui.VStack(height=0, spacing=6):
                # The test's still (made with the table tennis racket, in the Marso look); click to pick it.
                with ui.HStack(height=PREVIEW_H):
                    ui.Spacer(width=1)
                    still = style.preview(spec.key)
                    with ui.ZStack():
                        ui.Rectangle(name="preview_bg")
                        if still:
                            ui.Image(still, name="preview", fill_policy=ui.FillPolicy.PRESERVE_ASPECT_CROP,
                                     mouse_pressed_fn=lambda *_a, k=spec.key: self._flip(k))
                        else:
                            with ui.VStack():
                                ui.Spacer()
                                with ui.HStack(height=40):
                                    ui.Spacer()
                                    ui.Image(style.icon(f"test_{spec.key}.svg"), width=40, height=40)
                                    ui.Spacer()
                                ui.Spacer()
                    ui.Spacer(width=1)
                with ui.HStack(height=22, spacing=6):
                    ui.Spacer(width=8)
                    box = ui.CheckBox(width=18)
                    box.model.set_value(spec.key in self._tests)
                    box.model.add_value_changed_fn(lambda m, k=spec.key: self._toggle(k, m.get_value_as_bool()))
                    self._boxes[spec.key] = box
                    ui.Image(style.icon(f"test_{spec.key}.svg"), width=20, height=20)
                    ui.Label(spec.title, name="heading")
                with ui.HStack(height=0):
                    ui.Spacer(width=10)
                    ui.Label(spec.summary + (" Needs two or more objects." if spec.min_objects > 1 else ""),
                             name="muted", word_wrap=True)
                    ui.Spacer(width=8)
                fields = FIELDS[spec.key]
                if fields:
                    opened = spec.key in self._open
                    with ui.HStack(height=20):
                        ui.Spacer(width=10)
                        with ui.ZStack(width=0, tooltip="Show or hide this test's settings"):
                            hover = ui.Rectangle(name="expand")
                            with ui.HStack(width=0, spacing=6):
                                ui.Spacer(width=4)
                                with ui.VStack(width=8):
                                    ui.Spacer()
                                    arrow = ui.Triangle(name="expand", width=8, height=8, alignment=self._arrow(opened))
                                    ui.Spacer()
                                ui.Label(f"Settings ({len(fields)})", name="faint", width=0)
                                ui.Spacer(width=6)
                        ui.Spacer()
                    settings_box = ui.VStack(height=0, spacing=2, visible=opened)
                    hover.set_mouse_pressed_fn(lambda *_a, k=spec.key, a=arrow, s=settings_box: self._expand(k, a, s))
                    with settings_box:
                        for key, label, low, high in fields:
                            with ui.HStack(height=22, spacing=6):
                                ui.Spacer(width=10)
                                ui.Label(label, name="faint", width=130)
                                if low is None:
                                    flag = ui.CheckBox(width=20)
                                    flag.model.set_value(bool(self._options[spec.key].get(key, False)))
                                    flag.model.add_value_changed_fn(
                                        lambda m, k=spec.key, o=key: self._set_flag(k, o, m.get_value_as_bool()))
                                    continue
                                field = ui.FloatField(width=70)
                                field.model.set_value(float(self._options[spec.key].get(key, 0)))
                                field.model.add_end_edit_fn(lambda m, k=spec.key, o=key, a=low, b=high: self._set_option(k, o, m, a, b))
                ui.Spacer(height=8)

    @staticmethod
    def _arrow(opened: bool):
        return ui.Alignment.CENTER_BOTTOM if opened else ui.Alignment.RIGHT_CENTER

    def show_settings(self, key: str, shown: bool = True) -> None:
        """Open (or close) a test card's settings."""
        (self._open.add if shown else self._open.discard)(key)
        if self._built:
            self._cards_frame.rebuild()

    def _expand(self, key: str, arrow: ui.Triangle, box: ui.VStack) -> None:
        opened = key not in self._open
        (self._open.add if opened else self._open.discard)(key)
        box.visible = opened
        arrow.alignment = self._arrow(opened)

    def _flip(self, key: str) -> None:
        """Clicking a test's still picks it (or drops it), as its checkbox does."""
        box = self._boxes.get(key)
        if box is not None:
            box.model.set_value(not box.model.get_value_as_bool())

    def _build_output(self) -> None:
        def combo(label: str, values: list[str], labels: list[str], current: str, on_change, tooltip: str = "") -> None:
            with ui.HStack(height=24, spacing=8):
                ui.Label(label, width=110, tooltip=tooltip)
                index = values.index(current) if current in values else 0
                box = ui.ComboBox(index, *labels, width=220)
                box.model.add_item_changed_fn(lambda m, _i: on_change(values[m.get_item_value_model().as_int]))
                ui.Spacer()

        with ui.VStack(height=0, spacing=6):
            combo("Quality", QUALITY_KEYS,
                  [f"{q.label}  ({sim_job.resolution(q.key, '16:9')[0]}x{sim_job.resolution(q.key, '16:9')[1]}, {q.fps} fps)"
                   for q in sim_job.QUALITIES], self._quality, self._set_quality,
                  "All presets are path traced; higher ones take more samples per pixel: cleaner light, slower renders")
            combo("Aspect", ASPECT_KEYS, ["16:9 landscape", "9:16 vertical (Reels, Shorts, TikTok)", "1:1 square", "4:5 portrait"],
                  self._aspect, self._set_aspect)
            combo("Versions", list(BRANDING_LABELS), list(BRANDING_LABELS.values()), self._branding, self._set_branding,
                  "Branded adds Marso titles, labels, a results card and the outro; clean is the raw footage for your own edit")
            with ui.HStack(height=24, spacing=8):
                ui.Label("Save to", width=110)
                self._folder_label = ui.Label("", name="muted", elided_text=True)
                ui.Button("Change", width=70, clicked_fn=self._browse)
                ui.Button("Open", width=60, clicked_fn=lambda: show_in_folder(self._ensure_root()))

    def _build_render_row(self) -> None:
        with ui.VStack(height=0, spacing=6):
            ui.Spacer(height=6)
            with ui.HStack(height=34, spacing=10):
                self._render_button = ui.Button("Render", name="primary", width=170, height=32, clicked_fn=self._render)
                with ui.VStack():
                    ui.Spacer()
                    self._status = ui.Label("", name="muted", height=18, elided_text=True)
                    with ui.ZStack(height=5):
                        ui.Rectangle(name="progress_track")
                        with ui.HStack():
                            self._bar = ui.Rectangle(name="progress_fill", width=ui.Percent(0.1))
                            ui.Spacer()
                    ui.Spacer()
                self._cancel = ui.Button("Cancel", width=80, height=28, clicked_fn=self.studio.cancel)
                self._open_run = ui.Button("Open", width=70, height=28, clicked_fn=self._open_current)
            self._summary = ui.Label("", name="faint", height=16, word_wrap=True)

    def _build_runs(self) -> None:
        runs = self.studio.runs()
        if not runs:
            with ui.HStack(height=60):
                ui.Label("Renders appear here. Each run folder holds the videos, a results card per test, an "
                         "editable .usda scene and report.html.", name="faint", word_wrap=True)
            return
        with ui.VGrid(column_width=RUN_W + 12, row_height=RUN_H + 12, height=0):
            for run in runs:
                self._build_run(run)

    def _build_run(self, run: sim_job.RunSummary) -> None:
        with ui.VStack():
            with ui.ZStack(width=RUN_W, height=RUN_H):
                rect = ui.Rectangle(name="tile", tooltip=f"{run.name}\n{run.folder}\nClick to play; right-click for more.")
                with ui.VStack(spacing=4):
                    ui.Spacer(height=6)
                    with ui.HStack(height=int(RUN_W * 9 / 16) - 12):
                        ui.Spacer(width=6)
                        with ui.ZStack():
                            ui.Rectangle(name="thumb_bg")
                            thumb = run.thumbnail
                            ui.Image(str(thumb) if thumb else style.icon("placeholder.svg"), fill_policy=ui.FillPolicy.PRESERVE_ASPECT_FIT)
                        ui.Spacer(width=6)
                    with ui.HStack(height=18):
                        ui.Spacer(width=8)
                        ui.Label(run.name, name="tile_name", elided_text=True)
                        ui.Spacer(width=6)
                    with ui.HStack(height=16):
                        ui.Spacer(width=8)
                        titles = ", ".join(t.get("title", "") for t in run.tests) or "No videos"
                        colour = {"done": style.MUTED, "partial": style.AMBER, "failed": style.RED}.get(run.status, style.MUTED)
                        ui.Label(f"{run.created[:16].replace('T', ' ')}  ·  {titles}", name="tile_status", elided_text=True,
                                 style={"color": colour})
                        ui.Spacer(width=6)
                    with ui.HStack(height=22, spacing=4):
                        ui.Spacer(width=6)
                        ui.Button("Play", width=52, clicked_fn=lambda r=run: self._play(r))
                        ui.Button("Report", width=62, clicked_fn=lambda r=run: self._report(r), enabled=run.report is not None)
                        ui.Button("Folder", width=60, clicked_fn=lambda r=run: show_in_folder(r.folder))
                        ui.Spacer()
                    ui.Spacer(height=4)
            rect.set_mouse_pressed_fn(lambda x, y, b, m, r=run: self._run_menu(r) if b == 1 else None)

    # --- state -----------------------------------------------------------------------------------

    def refresh(self) -> None:
        if not self._built:
            return
        count = len(self.studio.objects)
        self._objects_title.text = f"Objects ({count})" if count else "Objects"
        self._objects_frame.rebuild()
        self._folder_label.text = str(self.studio.root)
        self.on_progress(self.studio.state)

    def on_event(self, topic: str, payload) -> None:
        if not self._built:
            return
        if topic == sim_service.EVENT_OBJECTS:
            self.refresh()
        elif topic == sim_service.EVENT_PROGRESS:
            self.on_progress(payload)
        elif topic == sim_service.EVENT_RUNS:
            self._runs_frame.rebuild()

    def on_progress(self, state: sim_service.RunState) -> None:
        active = state.active
        chosen = [k for k in sim_job.TEST_KEYS if k in self._tests]
        ready = bool(self.studio.objects) and bool(chosen) and not active
        self._render_button.enabled = ready
        n = len(chosen)
        self._render_button.text = f"Render {n} test{'s' if n != 1 else ''}" if n else "Render"
        self._cancel.visible = active
        self._open_run.visible = state.folder is not None and state.phase in (sim_service.PHASE_DONE, sim_service.PHASE_FAILED,
                                                                              sim_service.PHASE_RENDERING)
        if state.phase == sim_service.PHASE_IDLE:
            width, height = sim_job.resolution(self._quality, self._aspect)
            self._status.text = (f"{len(self.studio.objects)} object(s), {n} test(s) at {width}x{height}. "
                                 "Renders in a separate Isaac Sim; keep working while it runs.")
            self._bar.width = ui.Percent(0.1)
        else:
            detail = ""
            if state.phase == sim_service.PHASE_RENDERING and state.frames:
                detail = f"  frame {state.frame}/{state.frames}  ·  {len(state.done)} of {len(state.tests)} tests done"
            self._status.text = state.message + detail
            colour = {sim_service.PHASE_FAILED: style.RED, sim_service.PHASE_DONE: style.GREEN}.get(state.phase, style.MUTED)
            self._status.style = {"color": colour}
            self._bar.width = ui.Percent(max(0.1, state.fraction * 100))
        self._summary.text = ""

    # --- events ----------------------------------------------------------------------------------

    def _save(self) -> None:
        sim_service.save_prefs({"tests": sorted(self._tests), "options": self._options, "quality": self._quality,
                                "aspect": self._aspect, "branding": self._branding})
        self.on_progress(self.studio.state)

    def _toggle(self, key: str, on: bool) -> None:
        (self._tests.add if on else self._tests.discard)(key)
        self._cards[key].selected = on
        self._save()

    def _set_option(self, key: str, option: str, model, low: float, high: float) -> None:
        value = min(high, max(low, model.get_value_as_float()))
        model.set_value(value)
        self._options[key][option] = value
        self._save()

    def _set_flag(self, key: str, option: str, on: bool) -> None:
        self._options[key][option] = on
        self._save()

    def _set_quality(self, value: str) -> None:
        self._quality = value
        self._save()

    def _set_aspect(self, value: str) -> None:
        self._aspect = value
        self._save()

    def _set_branding(self, value: str) -> None:
        self._branding = value
        self._save()

    def _render(self) -> None:
        tests = [k for k in sim_job.TEST_KEYS if k in self._tests]
        options = {k: dict(self._options[k]) for k in tests}
        problem = self.studio.start(tests, options, self._quality, self._aspect, self._branding, outro=True)
        if problem:
            notify(problem, warning=True)

    def _ensure_root(self) -> Path:
        root = self.studio.root
        root.mkdir(parents=True, exist_ok=True)
        return root

    def _open_current(self) -> None:
        folder = self.studio.state.folder
        if folder is not None:
            report = folder / sim_job.REPORT_FILE
            open_url(report.as_uri()) if report.is_file() else show_in_folder(folder)

    def _play(self, run: sim_job.RunSummary) -> None:
        for test in run.tests:
            video = run.media(test.get("key", ""), "video") or run.media(test.get("key", ""), "clean")
            if video is not None:
                open_file(video)
                return
        notify("This run has no videos yet.", warning=True)

    def _report(self, run: sim_job.RunSummary) -> None:
        if run.report is not None:
            open_url(run.report.as_uri())

    def _run_menu(self, run: sim_job.RunSummary) -> None:
        self._menu = ui.Menu("Sim Studio run")
        with self._menu:
            for test in run.tests:
                key, title = test.get("key", ""), test.get("title", "")
                for kind, label in (("video", f"Play {title}"), ("clean", f"Play {title} (clean)")):
                    path = run.media(key, kind)
                    if path is not None:
                        ui.MenuItem(label, triggered_fn=lambda p=path: open_file(p))
                scene = run.media(key, "scene")
                if scene is not None:
                    ui.MenuItem(f"Open {title} scene in Isaac Sim", triggered_fn=lambda p=scene: _open_scene(p))
            ui.Separator()
            if run.report is not None:
                ui.MenuItem("Open Report", triggered_fn=lambda: open_url(run.report.as_uri()))
            ui.MenuItem("Show Folder", triggered_fn=lambda: show_in_folder(run.folder))
        self._menu.show()

    def _browse(self) -> None:
        try:
            from omni.kit.window.filepicker import FilePickerDialog
        except ImportError:
            notify("The folder picker is not available here.", warning=True)
            return

        def apply(filename: str, dirname: str) -> None:
            chosen = str(Path(dirname) / filename) if filename else dirname
            if self._picker is not None:
                self._picker.hide()
            if chosen:
                settings.set_value(settings.KEY_SIM_DIR, chosen)
                self.refresh()
                self._runs_frame.rebuild()

        if self._picker is not None:
            self._picker.destroy()
        self._picker = FilePickerDialog("Sim Studio folder", apply_button_label="Use This Folder", click_apply_handler=apply,
                                        item_filter_fn=lambda item: item is None or item.is_folder)
        self._picker.navigate_to(self._ensure_root().as_posix())
        self._picker.show()

    def destroy(self) -> None:
        if self._picker is not None:
            self._picker.destroy()
            self._picker = None
        self._menu = None
        self._cards.clear()
        self._boxes.clear()
        self._built = False


def _open_scene(path: Path) -> None:
    """Open a test's saved scene as the stage (Isaac Sim asks to save the current one first)."""
    try:
        import omni.kit.window.file as window_file

        window_file.open_stage(path.as_posix())
    except ImportError:
        import omni.usd

        omni.usd.get_context().open_stage(path.as_posix())

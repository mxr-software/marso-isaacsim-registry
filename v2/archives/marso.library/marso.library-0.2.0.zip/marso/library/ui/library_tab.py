"""Library tab: your Marso projects on the left, the chosen project's assets on the right."""

from __future__ import annotations

from typing import Callable

import omni.ui as ui

from .. import settings
from ..core import controller as ctl
from ..core import storage
from ..core.api import Asset
from ..core.controller import LibraryController
from ..core.studio_api import PROJECT_NAME as CREATED_PROJECT
from . import style
from .actions import Actions, copy_text, open_url, show_in_folder, MARSO_APP_URL
from .details import WIDTH as DETAILS_WIDTH
from .details import DetailsPanel
from .grid import AssetGrid, Tile
from .widgets import FacetFilters, ListRow, SearchField, divider, empty_state, icon_button

FILTERS = ("All assets", "Not downloaded", "Downloaded", "Updates available", "Needs a look")
FILTER_ALL, FILTER_REMOTE, FILTER_LOCAL, FILTER_UPDATES, FILTER_FLAGGED = range(5)
# Collections above the projects: assets from any project.
FAVOURITES, RECENT = "__favourites__", "__recent__"
COLLECTIONS = {FAVOURITES: ("Favourites", "favourites.svg"), RECENT: ("Recently used", "recent.svg")}
SIDE_WIDTH = 230


class LibraryTab:
    def __init__(self, ctrl: LibraryController, actions: Actions, open_settings: Callable[[], None]) -> None:
        self._ctrl = ctrl
        self._actions = actions
        self._open_settings = open_settings
        # Always one project open: thumbnails are fetched per project, as the Blender add-on does.
        self._project_id = settings.get(settings.KEY_LAST_PROJECT, "")
        self._opened = ""
        self._details = DetailsPanel(ctrl, on_favourite=self._actions.toggle_favourite)
        self._show_details = bool(settings.get_int(settings.KEY_SHOW_DETAILS, 1))
        self._facets = FacetFilters(self._apply_filters)
        self._search = ""
        self._filter = settings.get_int(settings.KEY_LIBRARY_FILTER, FILTER_ALL)
        self._rows: dict[str, ListRow] = {}
        self._menu: ui.Menu | None = None
        self._grid = AssetGrid(
            on_favourite=lambda key: self._actions.toggle_favourite([key]),
            on_selection_changed=self._on_selection,
            on_activate=self._actions.add_to_stage,
            on_context_menu=self._show_menu,
            empty_fn=self._build_empty,
            tile_size=settings.get_int(settings.KEY_TILE_SIZE, settings.DEFAULT_TILE_SIZE),
        )

    # --- building ------------------------------------------------------------------------

    def build(self) -> None:
        with ui.HStack():
            with ui.ZStack(width=SIDE_WIDTH):
                ui.Rectangle(name="panel")
                with ui.VStack():
                    with ui.HStack(height=30):
                        ui.Spacer(width=10)
                        ui.Label("Projects", name="heading")
                    self._projects_frame = ui.Frame(build_fn=self._build_projects)
            divider(vertical=True)
            with ui.VStack(spacing=0):
                with ui.HStack(height=34, spacing=8):
                    ui.Spacer(width=6)
                    self._title = ui.Label("", name="title", elided_text=True)
                    self._search_field = SearchField(self._on_search, hint="Search name, type, material...")
                    combo = ui.ComboBox(self._filter, *FILTERS, width=120, height=24)
                    combo.model.add_item_changed_fn(self._on_filter)
                    self._filter_combo = combo
                    self._facets.build()
                    with ui.HStack(width=90):
                        slider = ui.IntSlider(min=settings.MIN_TILE_SIZE, max=settings.MAX_TILE_SIZE, height=22,
                                              tooltip="Thumbnail size")
                        slider.model.set_value(settings.get_int(settings.KEY_TILE_SIZE, settings.DEFAULT_TILE_SIZE))
                        slider.model.add_value_changed_fn(self._on_tile_size)
                    icon_button("info.svg", "Show or hide the details panel", self._toggle_details)
                    ui.Spacer(width=4)
                divider()
                with ui.HStack():
                    self._grid.build()
                    self._details_divider = ui.Frame(build_fn=lambda: divider(vertical=True), width=1)
                    self._details_holder = ui.Frame(build_fn=self._details.build, width=DETAILS_WIDTH)
                divider()
                with ui.HStack(height=36, spacing=6):
                    ui.Spacer(width=8)
                    self._select_all_button = ui.Button("Select all", width=80, height=26, clicked_fn=self._select_all)
                    self._deselect_button = ui.Button("Deselect", width=76, height=26, clicked_fn=self._deselect)
                    self._selection_label = ui.Label("", name="muted", width=ui.Fraction(1))
                    self._cancel_button = ui.Button("Cancel downloads", width=140, height=26,
                                                    clicked_fn=lambda: self._actions.cancel())
                    self._missing_button = ui.Button("Download all missing", width=170, height=26,
                                                     clicked_fn=self._download_missing,
                                                     tooltip="Download every asset in view that is not on disk yet")
                    self._update_button = ui.Button("Update all", width=120, height=26, clicked_fn=self._update_all,
                                                    tooltip="Download Marso's newer version of the assets in view")
                    self._sim_button = ui.Button("Sim Studio", width=100, height=26,
                                                 clicked_fn=lambda: self._actions.test_in_sim(self._grid.selected),
                                                 tooltip="Film drop, friction, wind and scale tests of the selection")
                    self._download_button = ui.Button("Download", width=100, height=26,
                                                      clicked_fn=self._download_selected)
                    self._add_button = ui.Button("Add to Stage", name="primary", width=120, height=26,
                                                 clicked_fn=self._add_selected,
                                                 tooltip="Add the selected assets to the open stage "
                                                         "(downloading first if needed)")
                    ui.Spacer(width=8)
        self.refresh()

    def _build_projects(self) -> None:
        self._rows.clear()
        library = self._ctrl.library
        projects = [project for project in library.projects if project.assets or project.unfinished]
        hidden = len(library.projects) - len(projects)
        with ui.ScrollingFrame(horizontal_scrollbar_policy=ui.ScrollBarPolicy.SCROLLBAR_ALWAYS_OFF):
            with ui.VStack(height=0, spacing=2):
                total = len(library.assets)
                if projects:
                    for key, (title, icon) in COLLECTIONS.items():
                        self._add_row(key, title, self._collection(key), style.icon(icon))
                    with ui.HStack(height=8):
                        ui.Spacer()
                # Assets made from Isaac Sim (the Create tab) have their own project: pinned first, marked.
                created = [p for p in projects if p.name == CREATED_PROJECT]
                for project in created:
                    self._add_row(project.project_id, "Made in Isaac Sim", list(project.assets),
                                  style.icon("create.svg"), made_here=True, unfinished=project.unfinished)
                if created:
                    with ui.HStack(height=8):
                        ui.Spacer()
                for project in projects:
                    if project.name == CREATED_PROJECT:
                        continue
                    thumb = self._ctrl.thumbnail(storage.project_thumbnail_key(project.project_id))
                    self._add_row(project.project_id, project.name, list(project.assets), str(thumb or ""),
                                  unfinished=project.unfinished)
                if hidden:
                    with ui.HStack(height=24):
                        ui.Spacer(width=10)
                        plural = "s" if hidden != 1 else ""
                        ui.Label(f"{hidden} empty project{plural} hidden", name="faint")
                if not projects and total == 0:
                    with ui.HStack(height=24):
                        ui.Spacer(width=10)
                        ui.Label("No projects yet", name="faint")

    def _add_row(self, project_id: str, name: str, assets: list[Asset], thumbnail: str, made_here: bool = False,
                 unfinished: int = 0) -> None:
        downloaded = sum(1 for asset in assets if asset.asset_id in self._ctrl.local)
        count = len(assets)
        subtitle = f"{count} asset{'s' if count != 1 else ''}"
        colour = None
        if downloaded:
            subtitle += f" · {downloaded} downloaded" if downloaded < count else " · all downloaded"
            colour = style.GREEN if downloaded == count else None
        tooltip = ""
        if made_here:
            subtitle = f"{count} made here" + (f" · {downloaded} downloaded" if downloaded and downloaded < count else "")
            colour = style.PBR
            tooltip = f"Assets you made in the Create tab. In Marso they are in the {CREATED_PROJECT} project."
        if unfinished:
            subtitle = f"{subtitle} · {unfinished} being finished" if count else f"{unfinished} being finished by Marso"
            tooltip = (tooltip + " " if tooltip else "") + (
                "Marso is still finishing some assets here (their description, name and physics). They appear "
                "once they are ready, after the next sync.")
        with ui.HStack(height=42):
            ui.Spacer(width=4)
            self._rows[project_id] = ListRow(
                name, subtitle, lambda pid=project_id: self._select_project(pid),
                thumbnail=thumbnail, selected=project_id == self._project_id, subtitle_colour=colour, tooltip=tooltip,
            )
            ui.Spacer(width=4)

    def _build_empty(self) -> None:
        state = self._ctrl.sync_state
        if not self._ctrl.library.projects:
            if state.status == ctl.SYNC_NO_KEY:
                empty_state("Connect your Marso account",
                            "Add your Marso API key in Settings to browse your projects and import their assets.",
                            "Open Settings", self._open_settings)
            elif state.status == ctl.SYNC_RUNNING:
                empty_state("Loading your library...", "Fetching your projects from Marso.")
            elif state.status in (ctl.SYNC_FAILED, ctl.SYNC_AUTH_FAILED):
                button, action = (("Open Settings", self._open_settings) if state.status == ctl.SYNC_AUTH_FAILED
                                  else ("Try again", self._ctrl.sync))
                empty_state("Couldn't load your library", state.message, button, action)
            else:
                empty_state("No assets yet", "Generate PBR assets in Marso and they will appear here.",
                            "Open marso.app", lambda: open_url(MARSO_APP_URL))
        elif self._search or self._filter != FILTER_ALL:
            empty_state("No assets match", "Try a different search or filter.")
        else:
            empty_state("This project has no assets yet")

    # --- refreshing ----------------------------------------------------------------------

    def refresh(self) -> None:
        """Rebuild the project list and the grid from the controller's state."""
        library = self._ctrl.library
        if library.projects and self._project_id not in COLLECTIONS and (
                not self._project_id or library.project(self._project_id) is None):
            first = next((p for p in library.projects if p.assets), None)
            self._project_id = first.project_id if first is not None else ""
        self._projects_frame.rebuild()
        project = library.project(self._project_id) if self._project_id else None
        self._title.text = self._title_of(self._project_id)
        if (project is not None or self._project_id in COLLECTIONS) and self._opened != self._project_id:
            self._opened = self._project_id
            self._open(self._project_id)
        self._apply_filters()
        self._show_details_panel()

    def show_asset(self, asset_id: str) -> None:
        """Open the project holding an asset (Made in Isaac Sim first) and select the asset."""
        library = self._ctrl.library
        holders = [p for p in library.projects if any(a.asset_id == asset_id for a in p.assets)]
        holders.sort(key=lambda p: p.name != CREATED_PROJECT)
        if not holders:
            return
        self._select_project(holders[0].project_id)
        self._grid.select([asset_id])
        self._on_selection()

    def on_job(self, asset_id: str) -> None:
        asset = self._ctrl.library.asset(asset_id)
        if asset is not None:
            self._grid.update_tile(self._tile(asset))
        self._refresh_actions()
        if self._grid.selected and self._grid.selected[-1] == asset_id:
            self._details.refresh()

    def on_local(self, asset_id: str) -> None:
        """One asset landed on disk (or its physics was read)."""
        if self._filter != FILTER_ALL:
            self.refresh()  # it may have to move between the filtered views
            return
        self.on_job(asset_id)
        self._projects_frame.rebuild()  # the downloaded counts changed

    def on_thumbnail(self, key: str) -> None:
        asset = self._ctrl.library.asset(key)
        if asset is not None:
            self._grid.update_tile(self._tile(asset))
            if self._grid.selected and self._grid.selected[-1] == key:
                self._details.refresh()  # its picture arrived while it was selected
        elif key.startswith("project-"):
            self._projects_frame.rebuild()

    def destroy(self) -> None:
        self._grid.destroy()
        self._details.destroy()
        self._rows.clear()
        self._menu = None

    def _project_assets(self) -> list[Asset]:
        if self._project_id in COLLECTIONS:
            return self._collection(self._project_id)
        project = self._ctrl.library.project(self._project_id) if self._project_id else None
        return list({a.asset_id: a for a in project.assets}.values()) if project is not None else []

    def _collection(self, key: str) -> list[Asset]:
        ids = settings.favourites() if key == FAVOURITES else settings.recent()
        return [asset for asset in (self._ctrl.library.asset(a) for a in ids) if asset is not None]

    def _title_of(self, key: str) -> str:
        if key in COLLECTIONS:
            return COLLECTIONS[key][0]
        project = self._ctrl.library.project(key) if key else None
        if project is not None and project.name == CREATED_PROJECT:
            return "Made in Isaac Sim"
        return project.name if project is not None else ""

    def _open(self, key: str) -> None:
        """Fetch the thumbnails of what is now open: one project, or a collection across projects."""
        if key in COLLECTIONS:
            self._ctrl.fetch_thumbnails([asset.asset_id for asset in self._collection(key)])
        else:
            self._ctrl.open_project(key)

    def _visible_assets(self) -> list[Asset]:
        library = self._ctrl.library
        assets = self._project_assets()
        if self._search:
            words = self._search.lower().split()
            project_names = {p.project_id: p.name.lower() for p in library.projects}
            assets = [
                asset for asset in assets
                if all(word in f"{asset.search_text} {self._ctrl.name_of(asset.asset_id).lower()} "
                                f"{project_names.get(asset.project_id, '')}" for word in words)
            ]
        if self._filter == FILTER_REMOTE:
            assets = [asset for asset in assets if asset.asset_id not in self._ctrl.local]
        elif self._filter == FILTER_LOCAL:
            assets = [asset for asset in assets if asset.asset_id in self._ctrl.local]
        elif self._filter == FILTER_UPDATES:
            assets = [asset for asset in assets if self._ctrl.has_update(asset.asset_id)]
        elif self._filter == FILTER_FLAGGED:
            assets = [asset for asset in assets if self._ctrl.flags_of(asset.asset_id)]
        assets = [asset for asset in assets if self._facets.matches(self._facet_of(asset.asset_id))]
        return assets

    def _facet_of(self, asset_id: str):
        info = self._ctrl.enrichment_of(asset_id)
        return info.facet if info is not None else (lambda _key: ())

    def _apply_filters(self) -> None:
        """Offer the facets of this project's assets, then show what passes search and filters."""
        values: dict[str, list[str]] = {"category": [], "material": []}
        for asset in self._project_assets():
            info = self._ctrl.enrichment_of(asset.asset_id)
            if info is not None:
                for key in values:
                    values[key].extend(info.facet(key))
        self._facets.set_values(values)
        self._grid.set_tiles([self._tile(asset) for asset in self._visible_assets()])
        self._refresh_actions()

    def _tile(self, asset: Asset) -> Tile:
        status = self._ctrl.status(asset.asset_id)
        job = self._ctrl.jobs.get(asset.asset_id)
        local = self._ctrl.local.get(asset.asset_id)
        thumb = self._ctrl.asset_thumbnail(asset.asset_id)
        name = self._ctrl.name_of(asset.asset_id)
        lines = [name]
        if asset.display_name and asset.display_name != name:
            lines.append(asset.display_name)
        if asset.description:
            lines.append(asset.description)
        lines.append(f"Project: {self._ctrl.project_name(asset.project_id)}")
        if status == ctl.STATUS_REMOTE:
            text = "Not downloaded"
            lines.append("Not downloaded yet. Double-click to download and add it to the stage.")
        elif status == ctl.JOB_QUEUED:
            text = "Queued"
        elif status == ctl.JOB_DOWNLOADING:
            text = f"Downloading {job.progress:.0%}" if job else "Downloading"
        elif status == ctl.JOB_FAILED:
            text = "Download failed"
            lines.append(f"Failed: {job.error}" if job else "Failed")
        else:
            text = f"Downloaded · {storage.format_size(local.size_bytes)}" if local else "Downloaded"
            lines.append("On disk. Double-click or drag into the viewport to add it.")
        update = status == ctl.STATUS_DOWNLOADED and self._ctrl.has_update(asset.asset_id)
        if update:
            text = "Update available"
            lines.append("Marso has a newer version: right-click > Update, or Update all.")
        flags = self._ctrl.flags_of(asset.asset_id)
        if flags:
            lines.extend(["", *flags])
        sim_ready = local is not None and local.physics is not None and local.physics.sim_ready
        if local is not None and local.physics is not None:
            lines.extend(["", *local.physics.describe()])
        return Tile(
            key=asset.asset_id,
            title=name,
            status="update" if update else status,
            favourite=settings.is_favourite(asset.asset_id),
            flags=tuple(flags),
            status_text=text,
            thumbnail=str(thumb) if thumb else "",
            progress=job.progress if job else 0.0,
            tooltip="\n".join(lines),
            glyph="simready" if sim_ready else "pbr",
            usd=local is not None,
            drag_path=local.stage_path.as_posix() if local is not None and status == ctl.STATUS_DOWNLOADED else "",
        )

    def _refresh_actions(self) -> None:
        selected = self._grid.selected
        visible = self._grid.tiles
        remote = [key for key in selected if self._ctrl.status(key) in (ctl.STATUS_REMOTE, ctl.JOB_FAILED)]
        missing = [tile.key for tile in visible if self._ctrl.status(tile.key) in (ctl.STATUS_REMOTE, ctl.JOB_FAILED)]
        active = len(self._ctrl.active_jobs)
        on_disk = sum(1 for tile in visible if tile.status in (ctl.STATUS_DOWNLOADED, "update"))
        if selected:
            self._selection_label.text = f"{len(selected)} of {len(visible)} selected"
        else:
            self._selection_label.text = f"0 selected · {len(visible)} assets · {on_disk} downloaded" if visible else ""
        self._select_all_button.enabled = bool(visible) and len(selected) < len(visible)
        self._deselect_button.enabled = bool(selected)
        self._add_button.enabled = bool(selected)
        self._add_button.text = f"Add to Stage ({len(selected)})" if len(selected) > 1 else "Add to Stage"
        self._download_button.enabled = bool(remote)
        self._sim_button.enabled = bool(selected)
        self._missing_button.visible = bool(missing)
        self._missing_button.text = f"Download all missing ({len(missing)})"
        updates = [tile.key for tile in visible if tile.status == "update"]
        self._update_button.visible = bool(updates)
        self._update_button.text = f"Update all ({len(updates)})"
        self._cancel_button.visible = active > 0
        self._cancel_button.text = f"Cancel downloads ({active})"

    # --- events --------------------------------------------------------------------------

    def _select_project(self, project_id: str) -> None:
        self._project_id = project_id
        settings.set_value(settings.KEY_LAST_PROJECT, project_id)
        for key, row in self._rows.items():
            row.selected = key == project_id
        self._title.text = self._title_of(project_id)
        self._opened = project_id
        self._open(project_id)  # fetches its thumbnails, if any are missing
        self._apply_filters()

    def _on_search(self, text: str) -> None:
        self._search = text
        self._grid.set_tiles([self._tile(asset) for asset in self._visible_assets()])
        self._refresh_actions()

    def _on_filter(self, model, _item) -> None:
        self._filter = model.get_item_value_model().as_int
        settings.set_value(settings.KEY_LIBRARY_FILTER, self._filter)
        self._grid.set_tiles([self._tile(asset) for asset in self._visible_assets()])
        self._refresh_actions()

    def _on_selection(self) -> None:
        self._refresh_actions()
        self._details.show(self._grid.selected[-1] if self._grid.selected else None)

    def _select_all(self) -> None:
        self._grid.select_all()
        self._on_selection()

    def _deselect(self) -> None:
        self._grid.select([])
        self._on_selection()

    def _toggle_details(self) -> None:
        self._show_details = not self._show_details
        settings.set_value(settings.KEY_SHOW_DETAILS, int(self._show_details))
        self._show_details_panel()

    def _show_details_panel(self) -> None:
        for frame in (self._details_divider, self._details_holder):
            frame.visible = self._show_details
        self._details.show(self._grid.selected[-1] if self._grid.selected else None)

    def _on_tile_size(self, model) -> None:
        size = model.get_value_as_int()
        settings.set_value(settings.KEY_TILE_SIZE, size)
        self._grid.set_tile_size(size)

    def _download_selected(self) -> None:
        self._actions.download(self._grid.selected)

    def _update_all(self) -> None:
        self._actions.update([tile.key for tile in self._grid.tiles if tile.status == "update"])

    def _download_missing(self) -> None:
        missing = [tile.key for tile in self._grid.tiles
                   if self._ctrl.status(tile.key) in (ctl.STATUS_REMOTE, ctl.JOB_FAILED)]
        self._actions.download(missing)

    def _add_selected(self) -> None:
        self._actions.add_to_stage(self._grid.selected)

    def _show_menu(self, keys: list[str]) -> None:
        statuses = {key: self._ctrl.status(key) for key in keys}
        local = [self._ctrl.local[key] for key in keys if key in self._ctrl.local]
        self._menu = ui.Menu("Marso asset")
        with self._menu:
            ui.MenuItem("Add to Stage", triggered_fn=lambda: self._actions.add_to_stage(keys))
            if any(status in (ctl.STATUS_REMOTE, ctl.JOB_FAILED) for status in statuses.values()):
                ui.MenuItem("Download", triggered_fn=lambda: self._actions.download(keys))
            if any(self._ctrl.has_update(key) for key in keys):
                ui.MenuItem("Update", triggered_fn=lambda: self._actions.update(keys))
            if local:
                ui.MenuItem("Download Again", triggered_fn=lambda: self._actions.download(
                    [item.asset_id for item in local], force=True))
            if any(status in (ctl.JOB_QUEUED, ctl.JOB_DOWNLOADING) for status in statuses.values()):
                ui.MenuItem("Cancel Download", triggered_fn=lambda: self._actions.cancel(keys))
            if len(local) == 1:
                ui.Separator()
                ui.MenuItem("Show in Folder", triggered_fn=lambda: show_in_folder(local[0].usd_path))
            ui.Separator()
            starred = all(settings.is_favourite(key) for key in keys)
            ui.MenuItem("Remove from Favourites" if starred else "Add to Favourites",
                        triggered_fn=lambda: self._actions.toggle_favourite(keys))
            ui.MenuItem("Test in Sim Studio", triggered_fn=lambda: self._actions.test_in_sim(keys))
            if len(keys) == 1:
                ui.MenuItem("Copy Asset ID", triggered_fn=lambda: copy_text(keys[0]))
            if local:
                ui.Separator()
                ui.MenuItem("Delete Download...", triggered_fn=lambda: self._actions.delete([i.asset_id for i in local]))
        self._menu.show()

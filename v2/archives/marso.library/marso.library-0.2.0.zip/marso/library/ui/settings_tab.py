"""Settings tab: API key, the agent connection, storage folders, endpoint, and what is installed."""

from __future__ import annotations

import asyncio
import os
from pathlib import Path
from typing import TYPE_CHECKING, Any, Callable

import omni.ui as ui

from .. import settings
from ..core import config, placement
from ..core.controller import LibraryController
from ..core.thumbnails import pillow_available
from . import style
from .actions import MARSO_APP_URL, notify, open_url, show_in_folder

if TYPE_CHECKING:
    from ..agent_service import AgentService

LABEL_WIDTH = 130


class SettingsTab:
    def __init__(self, ctrl: LibraryController, version: str, on_config_changed: Callable[[bool], None],
                 agent: "AgentService | None" = None) -> None:
        self._ctrl = ctrl
        self._version = version
        self._on_config_changed = on_config_changed
        self._agent = agent
        self._agent_label: ui.Label | None = None
        self._unsubscribe_agent = agent.subscribe(self._agent_status) if agent is not None else None
        self._picker = None

    def build(self) -> None:
        with ui.ScrollingFrame(horizontal_scrollbar_policy=ui.ScrollBarPolicy.SCROLLBAR_ALWAYS_OFF):
            with ui.HStack():
                ui.Spacer(width=16)
                with ui.VStack(height=0, spacing=10):
                    ui.Spacer(height=6)
                    self._build_account()
                    self._build_agents()
                    self._build_storage()
                    self._build_adding()
                    self._build_advanced()
                    self._build_about()
                    ui.Spacer(height=10)
                ui.Spacer(width=16)
        self.refresh()

    # --- sections ------------------------------------------------------------------------

    def _build_account(self) -> None:
        with ui.CollapsableFrame("Marso account", height=0):
            with ui.VStack(height=0, spacing=6):
                ui.Spacer(height=4)
                with ui.HStack(height=24):
                    ui.Label("API key", width=LABEL_WIDTH, tooltip="Starts with mxr_live_")
                    self._key_field = ui.StringField(password_mode=True)
                    self._key_field.model.set_value(settings.get(config.KEY_API_KEY))
                    self._key_field.model.add_end_edit_fn(lambda _m: self._save(config.KEY_API_KEY, self._key_field))
                    ui.Spacer(width=6)
                    ui.Button("Check", width=80, clicked_fn=self._check)
                with ui.HStack(height=0):
                    ui.Spacer(width=LABEL_WIDTH)
                    self._key_note = ui.Label("", name="faint", word_wrap=True)
                with ui.HStack(height=0):
                    ui.Spacer(width=LABEL_WIDTH)
                    self._account_label = ui.Label("", name="muted", word_wrap=True)
                with ui.HStack(height=24):
                    ui.Spacer(width=LABEL_WIDTH)
                    ui.Button("Get an API key at marso.app", width=220, clicked_fn=lambda: open_url(MARSO_APP_URL))
                    ui.Spacer()
                ui.Spacer(height=4)

    def _build_agents(self) -> None:
        if self._agent is None:
            return
        with ui.CollapsableFrame("Agent connection", height=0):
            with ui.VStack(height=0, spacing=6):
                ui.Spacer(height=4)
                with ui.HStack(height=24):
                    ui.Label("Connect to Marso Agents", width=LABEL_WIDTH * 1.6)
                    box = ui.CheckBox(width=18)
                    box.model.set_value(self._agent.enabled)
                    box.model.add_value_changed_fn(lambda m: self._set_agents(m.get_value_as_bool()))
                    ui.Spacer()
                with ui.HStack(height=0):
                    ui.Spacer(width=LABEL_WIDTH)
                    ui.Label("Lets the agents you use with the Marso MCP (ChatGPT, Codex, Claude) put assets on this "
                             "stage and film them in Sim Studio. Isaac Sim connects out with your Marso API key; "
                             "nothing listens on this computer. Agents cannot change these settings, open files or "
                             "create assets here.", name="faint", word_wrap=True)
                with ui.HStack(height=0):
                    ui.Spacer(width=LABEL_WIDTH)
                    self._agent_label = ui.Label("", name="muted", word_wrap=True)
                with ui.HStack(height=24):
                    ui.Label("Agent server", width=LABEL_WIDTH)
                    self._agent_field = ui.StringField()
                    self._agent_field.model.set_value(settings.get(settings.KEY_AGENT_SERVER))
                    self._agent_field.model.add_end_edit_fn(lambda _m: self._save_agent_server())
                with ui.HStack(height=0):
                    ui.Spacer(width=LABEL_WIDTH)
                    ui.Label("Empty means the hosted Marso MCP (https://mcp.api.marso.app).", name="faint", word_wrap=True)
                ui.Spacer(height=4)
        self._agent_status(self._agent.status())

    def _set_agents(self, on: bool) -> None:
        settings.set_value(settings.KEY_AGENT_CONNECT, int(on))
        problem = self._agent.apply_settings() if self._agent is not None else None
        if problem:
            notify(problem, warning=True)

    def _save_agent_server(self) -> None:
        value = self._agent_field.model.get_value_as_string().strip()
        if value == settings.get(settings.KEY_AGENT_SERVER):
            return
        settings.set_value(settings.KEY_AGENT_SERVER, value)
        if self._agent is not None and self._agent.enabled:
            problem = self._agent.start()
            if problem:
                notify(problem, warning=True)

    def _agent_status(self, status: dict[str, Any]) -> None:
        if self._agent_label is None:
            return
        state = str(status.get("state", "off"))
        account = status.get("account")
        text = str(status.get("message", ""))
        if state == "connected" and account:
            text = f"Connected as {account}. Agents signed in to Marso can use this Isaac Sim."
        self._agent_label.text = text
        colour = {"connected": style.GREEN, "connecting": style.AMBER, "retrying": style.AMBER}.get(
            state, style.RED if state in ("refused", "replaced", "problem") else style.MUTED)
        self._agent_label.style = {"color": colour}

    def _build_storage(self) -> None:
        with ui.CollapsableFrame("Storage", height=0):
            with ui.VStack(height=0, spacing=6):
                ui.Spacer(height=4)
                self._in_use: dict[str, ui.Label] = {}
                self._folder_row(
                    "Downloads folder", config.KEY_DOWNLOADS_DIR,
                    "Downloaded assets (USDZ packages). Point the Marso Blender add-on at the same folder to share "
                    "downloads between the two.",
                )
                self._folder_row(
                    "Cache folder", config.KEY_CACHE_DIR,
                    "Thumbnails and the last synced listing. Safe to delete; it is rebuilt on the next sync.",
                )
                with ui.HStack(height=0):
                    ui.Spacer(width=LABEL_WIDTH)
                    ui.Label("Leave a folder empty to use the default.", name="faint")
                ui.Spacer(height=4)

    def _folder_row(self, label: str, key: str, help_text: str) -> None:
        with ui.HStack(height=24):
            ui.Label(label, width=LABEL_WIDTH, tooltip=help_text)
            field = ui.StringField(tooltip=help_text)
            field.model.set_value(settings.get(key))
            field.model.add_end_edit_fn(lambda _m, k=key, f=field: self._save(k, f))
            ui.Spacer(width=6)
            ui.Button("Browse", width=70, clicked_fn=lambda k=key, f=field: self._browse(k, f))
            ui.Button("Open", width=60, clicked_fn=lambda k=key: show_in_folder(self._effective_dir(k)))
        with ui.HStack(height=0):
            ui.Spacer(width=LABEL_WIDTH)
            with ui.VStack(height=0, spacing=2):
                self._in_use[key] = ui.Label("", name="muted", word_wrap=True)
                ui.Label(help_text, name="faint", word_wrap=True)

    def _build_adding(self) -> None:
        with ui.CollapsableFrame("Adding to the stage", height=0):
            with ui.VStack(height=0, spacing=6):
                ui.Spacer(height=4)
                self._check_row(settings.KEY_ADD_GROUND, 1, "Ground and physics",
                                "Add a physics scene and a ground when the stage has neither, so sim-ready assets "
                                "land on something when you press Play.")
                with ui.HStack(height=24):
                    ui.Label("Several at once", width=LABEL_WIDTH)
                    keys = list(placement.ARRANGEMENTS)
                    current = settings.get(settings.KEY_ARRANGE, placement.ARRANGE_ROW)
                    combo = ui.ComboBox(keys.index(current) if current in keys else 0, *placement.ARRANGEMENTS.values(),
                                        width=220)
                    combo.model.add_item_changed_fn(
                        lambda m, _i: settings.set_value(settings.KEY_ARRANGE, keys[m.get_item_value_model().as_int]))
                    ui.Spacer()
                with ui.HStack(height=0):
                    ui.Spacer(width=LABEL_WIDTH)
                    ui.Label("How assets added together are laid out. Stacked puts each above the last, ready to drop "
                             "onto each other.", name="faint", word_wrap=True)
                self._check_row(settings.KEY_USE_PAYLOADS, 0, "Use payloads",
                                "Add assets as payloads instead of references, so you can unload heavy ones from the "
                                "Stage window to keep a big scene responsive.")
                ui.Spacer(height=4)

    @staticmethod
    def _check_row(key: str, default: int, label: str, help_text: str) -> None:
        with ui.HStack(height=24):
            ui.Label(label, width=LABEL_WIDTH)
            box = ui.CheckBox(width=18)
            box.model.set_value(bool(settings.get_int(key, default)))
            box.model.add_value_changed_fn(lambda m: settings.set_value(key, int(m.get_value_as_bool())))
            ui.Spacer()
        with ui.HStack(height=0):
            ui.Spacer(width=LABEL_WIDTH)
            ui.Label(help_text, name="faint", word_wrap=True)

    def _build_advanced(self) -> None:
        with ui.CollapsableFrame("Advanced", height=0, collapsed=True):
            with ui.VStack(height=0, spacing=6):
                ui.Spacer(height=4)
                with ui.HStack(height=24):
                    ui.Label("API endpoint", width=LABEL_WIDTH)
                    self._endpoint_field = ui.StringField()
                    self._endpoint_field.model.set_value(settings.get(config.KEY_API_ENDPOINT))
                    self._endpoint_field.model.add_end_edit_fn(
                        lambda _m: self._save(config.KEY_API_ENDPOINT, self._endpoint_field))
                    ui.Spacer(width=6)
                    ui.Button("Reset", width=70, clicked_fn=self._reset_endpoint)
                with ui.HStack(height=0):
                    ui.Spacer(width=LABEL_WIDTH)
                    ui.Label(f"Empty means the production API ({config.DEFAULT_API_ENDPOINT}).", name="faint",
                             word_wrap=True)
                ui.Spacer(height=4)

    def _build_about(self) -> None:
        with ui.CollapsableFrame("About", height=0, collapsed=True):
            with ui.VStack(height=0, spacing=4):
                ui.Spacer(height=4)
                with ui.HStack(height=20):
                    ui.Label("Version", width=LABEL_WIDTH)
                    ui.Label(self._version, name="muted")
                with ui.HStack(height=20):
                    ui.Label("Thumbnails", width=LABEL_WIDTH)
                    text = "WebP and JPEG via Pillow" if pillow_available() else "PNG only (Pillow unavailable)"
                    ui.Label(text, name="muted")
                with ui.HStack(height=0):
                    ui.Label("Settings file", width=LABEL_WIDTH)
                    ui.Label("Saved by Isaac Sim with your other preferences (user.config.json). The API key is "
                             "stored there in plain text; leave it empty and set MARSO_API_KEY to avoid that.",
                             name="faint", word_wrap=True)
                ui.Spacer(height=4)

    # --- state ---------------------------------------------------------------------------

    def refresh(self) -> None:
        cfg = self._ctrl.config
        source = cfg.sources.get(config.KEY_API_KEY)
        if source == config.SOURCE_ENVIRONMENT:
            self._key_note.text = f"Using the key from the {config.ENV_API_KEY} environment variable."
        elif source == config.SOURCE_NONE:
            self._key_note.text = "Paste the API key from your Marso account settings."
        else:
            self._key_note.text = "Saved in Isaac Sim's settings."
        account, error = self._ctrl.account, self._ctrl.account_error
        if account is not None:
            self._account_label.text = f"Connected as {account.email or account.user_id}."
            self._account_label.style = {"color": style.GREEN}
        elif error:
            self._account_label.text = error
            self._account_label.style = {"color": style.RED}
        else:
            self._account_label.text = ""
        for key, label in self._in_use.items():
            source = cfg.sources.get(key)
            origin = {config.SOURCE_ENVIRONMENT: " (from the environment)", config.SOURCE_DEFAULT: " (default)"}
            label.text = f"In use: {self._effective_dir(key)}{origin.get(source, '')}"

    def destroy(self) -> None:
        if self._unsubscribe_agent is not None:
            self._unsubscribe_agent()
            self._unsubscribe_agent = None
        if self._picker is not None:
            self._picker.destroy()
            self._picker = None

    # --- events --------------------------------------------------------------------------

    def _save(self, key: str, field: ui.StringField) -> None:
        value = field.model.get_value_as_string().strip()
        if value == settings.get(key):
            return
        settings.set_value(key, value)
        resync = key in (config.KEY_API_KEY, config.KEY_API_ENDPOINT)
        self._on_config_changed(resync)
        self.refresh()

    def _reset_endpoint(self) -> None:
        self._endpoint_field.model.set_value("")
        self._save(config.KEY_API_ENDPOINT, self._endpoint_field)

    def _check(self) -> None:
        self._save(config.KEY_API_KEY, self._key_field)
        self._account_label.text = "Checking..."
        self._account_label.style = {"color": style.MUTED}

        async def run() -> None:
            await self._ctrl.check_account()
            self.refresh()

        asyncio.ensure_future(run())

    def _effective_dir(self, key: str) -> Path:
        cfg = self._ctrl.config
        return cfg.downloads_dir if key == config.KEY_DOWNLOADS_DIR else cfg.cache_dir

    def _browse(self, key: str, field: ui.StringField) -> None:
        try:
            from omni.kit.window.filepicker import FilePickerDialog
        except ImportError:
            notify("The folder picker is not available here; type the path instead.", warning=True)
            return

        def apply(filename: str, dirname: str) -> None:
            chosen = os.path.join(dirname, filename) if filename else dirname
            chosen = chosen.replace("file:/", "") if chosen.startswith("file:/") else chosen
            if self._picker is not None:
                self._picker.hide()
            if chosen:
                field.model.set_value(os.path.normpath(chosen))
                self._save(key, field)

        if self._picker is not None:
            self._picker.destroy()
        self._picker = FilePickerDialog(
            "Choose a folder",
            apply_button_label="Use This Folder",
            click_apply_handler=apply,
            item_filter_fn=lambda item: item is None or item.is_folder,
        )
        start = self._effective_dir(key)
        start.mkdir(parents=True, exist_ok=True)
        self._picker.navigate_to(start.as_posix())
        self._picker.show()

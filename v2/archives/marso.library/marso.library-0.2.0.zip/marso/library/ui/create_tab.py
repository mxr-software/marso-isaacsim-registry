"""The Create tab: make a new asset in Marso from a prompt or a picture, then bring it into the library.

Step 1 makes the image (generated from a prompt, or imported). Step 2 turns it into a 3D asset with PBR
materials; once Marso has finished it (description, name, physics) it downloads into the IsaacSim_AddOn
project, and onto the stage if "Import onto stage" is ticked. Runs carry on in the background and across
restarts.

The pipeline strip at the top and each run's step tracker show where things are: done steps turn green
(with a pop as they finish), the step being worked on breathes in violet, a failed one turns red. Work in
progress has a spinner and a shimmer bar; a new image fades in. Animations only run while something is
being made (``anim.Animator``).
"""

from __future__ import annotations

import os
import time
from collections.abc import Callable
from pathlib import Path

import omni.ui as ui

from .. import settings
from ..core import creation
from ..core.creation import Run
from ..core.studio_api import IMAGE_TYPES, PROJECT_NAME, check_prompt
from ..creation_service import EVENT_DRAFT, EVENT_RUNS, Creator
from . import anim, style
from .actions import notify, open_url

TOP_UP_URL = "https://marso.app/dashboard/projects?settings=credits"
PREVIEW = 240

# The steps of making an asset, as the strip and each run's tracker show them.
STEPS = (
    ("create_image.svg", "Image"),
    ("create_mesh.svg", "3D mesh"),
    ("create_pbr.svg", "PBR materials"),
    ("create_finish.svg", "Finished by Marso"),
    ("create_library.svg", "In your library"),
)
STEP_OF_STAGE = {
    creation.STAGE_MESH: 1,
    creation.STAGE_PBR: 2,
    creation.STAGE_MINTING: 3,
    creation.STAGE_LISTING: 4,
    creation.STAGE_READY: 4,
    creation.STAGE_DOWNLOADING: 4,
    creation.STAGE_DONE: len(STEPS),
}


def step_of(run: Run) -> int:
    """The step a run is on (len(STEPS) when done); a failed or stopped run is on the step that stopped."""
    if run.stage in (creation.STAGE_FAILED, creation.STAGE_STOPPED):
        return STEP_OF_STAGE.get(run.failed_stage, 1)
    return STEP_OF_STAGE.get(run.stage, 1)


class CreateTab:
    def __init__(self, creator: Creator, show_asset: Callable[[str], None], open_settings: Callable[[], None]) -> None:
        self._creator = creator
        self._show_asset = show_asset
        self._open_settings = open_settings
        self._prompt = creator.draft.prompt
        self._to_stage = bool(settings.get_int(settings.KEY_CREATE_TO_STAGE, 0))
        self._picker = None
        self._built = False
        self._anim = anim.Animator()
        self._seen: dict[str, int] = {}  # each run's step at the last build, to pop the steps it has finished since
        self._shown_image = creator.draft.image_path  # the preview's image, to fade a new one in
        self._unsubscribe = creator.subscribe(self._on_event)

    # --- building ----------------------------------------------------------------------------

    def build(self) -> None:
        with ui.HStack(spacing=0):
            ui.Spacer(width=16)
            with ui.ScrollingFrame(horizontal_scrollbar_policy=ui.ScrollBarPolicy.SCROLLBAR_ALWAYS_OFF):
                with ui.VStack(height=0, spacing=6):
                    ui.Spacer(height=6)
                    ui.Label("CREATE", name="eyebrow", height=16)
                    with ui.HStack(height=26, spacing=8):
                        _icon("create.svg", 22, style.PBR)
                        ui.Label("Make a new asset", name="title")
                    ui.Label(f"Describe one object, or import a picture of it. Marso makes the image, then a 3D model "
                             "with PBR materials, then finishes it with a description, a name and physics. Marso has "
                             "a basic version of the model before it is finished; only the finished one comes into "
                             f"your library, ready for simulation, in the {PROJECT_NAME} project.", name="muted",
                             word_wrap=True, height=0)
                    self._flow_frame = ui.Frame(height=0, build_fn=self._build_flow)
                    ui.Spacer(height=2)
                    with ui.HStack(height=0, spacing=18):
                        with ui.VStack(height=0, spacing=6):
                            self._build_image_step()
                            ui.Spacer(height=8)
                            self._build_asset_step()
                        with ui.VStack(width=PREVIEW, height=0, spacing=4):
                            self._preview_frame = ui.Frame(height=PREVIEW, build_fn=self._build_preview)
                            self._preview_label = ui.Label("", name="faint", height=16, elided_text=True,
                                                           alignment=ui.Alignment.CENTER)
                    ui.Spacer(height=10)
                    with ui.HStack(height=16, spacing=6):
                        ui.Label("RUNS", name="eyebrow", width=0)
                        self._runs_count = ui.Label("", name="faint")
                    self._runs_frame = ui.Frame(height=0, build_fn=self._build_runs)
                    ui.Spacer(height=10)
            ui.Spacer(width=16)
        self._built = True
        self._creator.refresh_account()
        self._refresh()

    def _build_flow(self) -> None:
        """The pipeline at a glance, showing the newest run's step (or the image being made)."""
        self._anim.clear("flow")
        active = next((run for run in self._creator.runs if run.active), None)
        if active is not None:
            current, state = step_of(active), "active"
        elif self._creator.draft_busy:
            current, state = 0, "active"
        else:
            current, state = -1, "idle"
        with ui.ZStack(height=58):
            ui.Rectangle(name="card")
            with ui.HStack(spacing=0):
                ui.Spacer(width=14)
                for index, (icon_name, label) in enumerate(STEPS):
                    if index:
                        with ui.VStack(width=ui.Fraction(0.6)):
                            ui.Spacer(height=18)
                            done = state == "active" and index <= current
                            ui.Rectangle(height=2, style={"background_color": style.GREEN if done else style.LINE,
                                                          "border_radius": 1})
                            ui.Spacer()
                    with ui.VStack(width=0, spacing=4):
                        ui.Spacer(height=8)
                        with ui.HStack(height=22):
                            ui.Spacer()
                            if state == "idle":
                                colour = style.PBR
                            elif index < current:
                                colour = style.GREEN
                            elif index == current:
                                colour = style.PBR
                            else:
                                colour = style.FAINT
                            image = _icon(icon_name, 22, colour)
                            if state == "active" and index == current:
                                anim.pulse(self._anim, "flow", image, style.PBR)
                            ui.Spacer()
                        ui.Label(label, name="faint", alignment=ui.Alignment.CENTER, height=14, width=0)
                    ui.Spacer(width=0)
                ui.Spacer(width=14)

    def _build_image_step(self) -> None:
        with ui.HStack(height=22, spacing=8):
            _icon("create_image.svg", 18, style.PBR)
            ui.Label("1  Image", name="heading")
        ui.Label("Describe one object, for example: a red enamel watering can with a long spout", name="faint",
                 height=16)
        self._prompt_field = ui.StringField(multiline=True, height=64)
        self._prompt_field.model.set_value(self._prompt)
        self._prompt_field.model.add_value_changed_fn(self._on_prompt)
        with ui.HStack(height=28, spacing=8):
            self._generate_button = _button("Generate Image", "create_wand.svg", self._generate, 170, primary=True,
                                            tooltip="Generate one image of the object from the description")
            self._import_button = _button("Import Image...", "create_upload.svg", self._browse, 150,
                                          tooltip="Use your own picture (PNG, JPEG or WebP, up to 5 MB). Free.")
            self._clear_button = _button("Clear", "create_clear.svg", self._creator.clear_image, 84,
                                         tooltip="Start again with a new image")
            ui.Spacer()
        with ui.HStack(height=16, spacing=6):
            _icon("create_coin.svg", 14, style.FAINT)
            self._image_cost = ui.Label("", name="faint")
        self._image_busy = ui.Frame(height=0, build_fn=self._build_image_busy)
        self._image_status = ui.Label("", name="muted", height=0, word_wrap=True)

    def _build_image_busy(self) -> None:
        self._anim.clear("image")
        with ui.VStack(height=0):  # always something to build, so a rebuild replaces the bar when the image is done
            if self._creator.draft_busy:
                ui.Spacer(height=2)
                anim.shimmer(self._anim, "image", 3, anim.with_alpha(style.PBR, 0.9), anim.with_alpha(style.LINE, 0.8))
            else:
                ui.Spacer(height=0)

    def _build_asset_step(self) -> None:
        with ui.HStack(height=22, spacing=8):
            _icon("create_mesh.svg", 18, style.PBR)
            ui.Label("2  3D Asset", name="heading")
        with ui.HStack(height=16, spacing=6):
            _icon("create_coin.svg", 14, style.FAINT)
            self._asset_cost = ui.Label("", name="faint")
        with ui.HStack(height=22, spacing=6):
            box = ui.CheckBox(width=18)
            box.model.set_value(self._to_stage)
            box.model.add_value_changed_fn(self._on_to_stage)
            _icon("create_stage.svg", 16, style.MUTED)
            ui.Label("Import onto stage when ready", name="muted",
                     tooltip="When the asset is downloaded, add it to the open stage as well")
        with ui.HStack(height=28, spacing=8):
            self._create_button = _button("Create 3D Asset", "create_mesh.svg", self._create, 170, primary=True,
                                          tooltip="Make a 3D asset with PBR materials from the image")
            self._top_up = _button("Top Up Credits", "create_coin.svg", lambda: open_url(TOP_UP_URL), 150)
            self._top_up.visible = False
            self._settings_button = ui.Button("Open Settings", width=120, visible=False, clicked_fn=self._open_settings)
            ui.Spacer()
        self._asset_status = ui.Label("", name="muted", height=0, word_wrap=True)
        self._balance = ui.Label("", name="faint", height=16)

    def _build_preview(self) -> None:
        self._anim.clear("preview")
        draft = self._creator.draft
        has_image = bool(draft.image_path) and Path(draft.image_path).is_file()
        with ui.ZStack(width=PREVIEW, height=PREVIEW):
            ui.Rectangle(name="preview_bg", style={"border_radius": 7, "corner_flag": 15})
            if has_image:
                image = ui.Image(draft.image_path, fill_policy=ui.FillPolicy.PRESERVE_ASPECT_FIT)
                if draft.image_path != self._shown_image:  # a new image: fade it in
                    anim.fade_in(self._anim, "preview", image)
            if self._creator.draft_busy:
                if has_image:
                    ui.Rectangle(style={"background_color": anim.with_alpha(style.NODE_BODY, 0.55), "border_radius": 7})
                with ui.VStack():
                    ui.Spacer()
                    with ui.HStack(height=34):
                        ui.Spacer()
                        anim.spinner(self._anim, "preview", 34, style.PBR)
                        ui.Spacer()
                    ui.Spacer(height=10)
                    ui.Label("Making the image...", name="muted", alignment=ui.Alignment.CENTER, height=18)
                    ui.Spacer()
                    with ui.HStack(height=3):
                        ui.Spacer(width=18)
                        anim.shimmer(self._anim, "preview", 3, anim.with_alpha(style.PBR, 0.9),
                                     anim.with_alpha(style.LINE, 0.6))
                        ui.Spacer(width=18)
                    ui.Spacer(height=16)
            elif not has_image:
                with ui.VStack():
                    ui.Spacer()
                    with ui.HStack(height=44):
                        ui.Spacer()
                        _icon("create_image.svg", 44, anim.with_alpha(style.FAINT, 0.6))
                        ui.Spacer()
                    ui.Spacer(height=8)
                    ui.Label("Your image appears here", name="faint", alignment=ui.Alignment.CENTER, height=20)
                    ui.Spacer()
        self._shown_image = draft.image_path if has_image else self._shown_image

    def _build_runs(self) -> None:
        self._anim.clear("runs")
        runs = self._creator.runs
        with ui.VStack(height=0, spacing=6):
            if not runs:
                with ui.HStack(height=24, spacing=8):
                    _icon("create_library.svg", 16, style.FAINT)
                    ui.Label("Assets you make appear here while Marso works on them.", name="faint")
            for run in runs:
                self._build_run(run)
        self._seen = {run.run_id: step_of(run) for run in runs}

    def _build_run(self, run: Run) -> None:
        colour = {creation.STAGE_DONE: style.GREEN, creation.STAGE_FAILED: style.RED,
                  creation.STAGE_STOPPED: style.AMBER}.get(run.stage)
        current = step_of(run)
        before = self._seen.get(run.run_id)
        with ui.ZStack(height=70):
            ui.Rectangle(name="card")
            with ui.VStack():
                with ui.HStack(spacing=10):
                    ui.Spacer(width=6)
                    with ui.VStack(width=48):
                        ui.Spacer()
                        with ui.ZStack(width=48, height=48):
                            ui.Rectangle(name="thumb_bg")
                            if run.image_path and Path(run.image_path).is_file():
                                ui.Image(run.image_path, fill_policy=ui.FillPolicy.PRESERVE_ASPECT_CROP)
                        ui.Spacer()
                    with ui.VStack(spacing=3):
                        ui.Spacer()
                        with ui.HStack(height=18, spacing=8):
                            ui.Label(run.label or "New asset", elided_text=True)
                        self._build_tracker(run, current, before)
                        extra = {"style": {"color": colour}} if colour is not None else {}
                        message = run.message or creation.STAGE_LABELS.get(run.stage, run.stage)
                        line = ui.Label(message, name="faint", elided_text=True, height=16, **extra)
                        if run.active:  # the time it has taken, kept current
                            anim.ticker(self._anim, "runs", line,
                                        lambda r=run, m=message: f"{m}  ·  {_elapsed(time.time() - r.created_at)}")
                        ui.Spacer()
                    self._build_run_state(run, before)
                    self._build_run_buttons(run)
                    ui.Spacer(width=6)
                if run.active:
                    with ui.HStack(height=3):
                        ui.Spacer(width=8)
                        anim.shimmer(self._anim, "runs", 3, anim.with_alpha(style.PBR, 0.85),
                                     anim.with_alpha(style.LINE, 0.0))
                        ui.Spacer(width=8)
                    ui.Spacer(height=3)

    def _build_tracker(self, run: Run, current: int, before: int | None) -> None:
        """The run's steps as small icons: done green (popping as they finish), current breathing, failed red."""
        stopped = run.stage in (creation.STAGE_FAILED, creation.STAGE_STOPPED)
        with ui.HStack(height=16, spacing=0):
            for index, (icon_name, label) in enumerate(STEPS):
                if index:
                    with ui.VStack(width=14):
                        ui.Spacer()
                        ui.Rectangle(height=2, style={"background_color": style.GREEN if index <= current else style.LINE,
                                                      "border_radius": 1})
                        ui.Spacer()
                if index < current:
                    tint = style.GREEN
                elif index == current and stopped:
                    tint = style.RED if run.stage == creation.STAGE_FAILED else style.AMBER
                elif index == current:
                    tint = style.PBR
                else:
                    tint = anim.with_alpha(style.FAINT, 0.7)
                with ui.ZStack(width=20, height=16, tooltip=label):
                    with ui.VStack():
                        ui.Spacer()
                        with ui.HStack(height=0):
                            ui.Spacer()
                            image = _icon(icon_name, 14, tint)
                            ui.Spacer()
                        ui.Spacer()
                if index == current and run.active:
                    anim.pulse(self._anim, "runs", image, style.PBR)
                elif before is not None and before <= index < current:
                    anim.pop(self._anim, "runs", image, 14)  # finished since the last look
            ui.Spacer()

    def _build_run_state(self, run: Run, before: int | None) -> None:
        with ui.VStack(width=28):
            ui.Spacer()
            with ui.HStack(height=24):
                ui.Spacer()
                if run.active:
                    anim.spinner(self._anim, "runs", 22, style.PBR)
                else:
                    name, tint = {creation.STAGE_DONE: ("create_check.svg", style.GREEN),
                                  creation.STAGE_FAILED: ("create_alert.svg", style.RED),
                                  creation.STAGE_STOPPED: ("create_pause.svg", style.AMBER)}.get(
                        run.stage, ("create_pause.svg", style.FAINT))
                    with ui.ZStack(width=24, height=24):
                        with ui.VStack():
                            ui.Spacer()
                            with ui.HStack(height=0):
                                ui.Spacer()
                                image = _icon(name, 20, tint)
                                ui.Spacer()
                            ui.Spacer()
                    if run.stage == creation.STAGE_DONE and before is not None and before < len(STEPS):
                        anim.pop(self._anim, "runs", image, 20)  # it has just finished
                ui.Spacer()
            ui.Spacer()

    def _build_run_buttons(self, run: Run) -> None:
        with ui.HStack(width=0, spacing=6):
            if run.active:
                with ui.VStack(width=0):
                    ui.Spacer()
                    with ui.HStack(height=22, width=0, spacing=4):
                        box = ui.CheckBox(width=18, tooltip="Add it to the stage when it is downloaded")
                        box.model.set_value(run.add_to_stage)
                        box.model.add_value_changed_fn(
                            lambda m, rid=run.run_id: self._creator.set_add_to_stage(rid, m.get_value_as_bool()))
                        _icon("create_stage.svg", 14, style.FAINT)
                    ui.Spacer()
                self._run_button("Stop", "create_stop.svg", lambda rid=run.run_id: self._creator.stop(rid),
                                 "Stop waiting. Marso carries on and the asset appears in the library later.")
            if run.stage in (creation.STAGE_FAILED, creation.STAGE_STOPPED):
                self._run_button("Retry", "create_retry.svg", lambda rid=run.run_id: self._creator.retry(rid),
                                 "Carry on from the step that stopped (earlier steps are not paid for again)")
            if run.stage == creation.STAGE_DONE:
                self._run_button("Show", "create_show.svg", lambda aid=run.pbr_asset_id: self._show_asset(aid),
                                 f"Show it in the Library, in {PROJECT_NAME}")
            if not run.active:
                self._run_button("Remove", "create_remove.svg", lambda rid=run.run_id: self._creator.dismiss(rid),
                                 "Remove from this list (the asset stays in your library)", width=88)

    @staticmethod
    def _run_button(text: str, icon_name: str, fn: Callable[[], None], tooltip: str, width: int = 78) -> None:
        with ui.VStack(width=width):
            ui.Spacer()
            _button(text, icon_name, fn, width, height=26, tooltip=tooltip)
            ui.Spacer()

    # --- refreshing -----------------------------------------------------------------------------

    def _on_event(self, topic: str, _payload) -> None:
        if not self._built:
            return
        if topic == EVENT_DRAFT:
            self._preview_frame.rebuild()
            self._image_busy.rebuild()
            self._flow_frame.rebuild()
        if topic == EVENT_RUNS:
            self._runs_frame.rebuild()
            self._flow_frame.rebuild()
        self._refresh()

    def _refresh(self) -> None:
        if not self._built:
            return
        creator, draft = self._creator, self._creator.draft
        prices = creator.prices
        blocked = creator.blocked()
        busy = creator.draft_busy
        prompt_problem = check_prompt(self._prompt)

        self._image_cost.text = f"Image: {_credits(prices.image)} · Import: free"
        self._generate_button.enabled = not blocked and not busy and not prompt_problem and creator.can_afford(prices.image)
        self._import_button.enabled = not blocked and not busy
        self._clear_button.enabled = draft.state != creation.DRAFT_EMPTY or busy
        failed = draft.state == creation.DRAFT_FAILED
        self._image_status.text = draft.message or (prompt_problem if self._prompt.strip() else "")
        self._image_status.name = "error" if failed else "muted"
        self._preview_label.text = draft.label if draft.state == creation.DRAFT_READY else ""

        cost = prices.asset
        self._asset_cost.text = f"Mesh and PBR materials: {_credits(cost)}"
        has_image = draft.state == creation.DRAFT_READY and bool(draft.image_asset_id)
        affordable = creator.can_afford(cost)
        self._create_button.enabled = not blocked and has_image and affordable
        reason = blocked or ("" if has_image else "Make or import an image first.")
        if not reason and not affordable:
            reason = f"Not enough credits: this needs {cost:,} and you have {creator.credits:,}."
        self._asset_status.text = reason
        self._asset_status.name = "error" if reason and not affordable else "muted"
        self._top_up.visible = bool(reason) and not affordable and not blocked
        self._settings_button.visible = bool(blocked)
        if creator.credits >= 0:
            after = f", {creator.credits - cost:,} after this asset" if cost >= 0 and affordable else ""
            self._balance.text = f"Balance: {creator.credits:,} credits{after}"
        else:
            self._balance.text = creator.account_error
        active = len(creator.active_runs)
        total = len(creator.runs)
        self._runs_count.text = (f"{active} in progress · {total - active} finished" if active else
                                 f"{total} finished" if total else "")

    # --- events -------------------------------------------------------------------------------

    def _on_prompt(self, model) -> None:
        self._prompt = model.get_value_as_string()
        self._refresh()

    def _on_to_stage(self, model) -> None:
        self._to_stage = model.get_value_as_bool()
        settings.set_value(settings.KEY_CREATE_TO_STAGE, int(self._to_stage))

    def _generate(self) -> None:
        problem = self._creator.generate_image(self._prompt)
        if problem:
            notify(problem, warning=True)

    def _create(self) -> None:
        problem = self._creator.create_asset(self._to_stage)
        if problem:
            notify(problem, warning=True)
        else:
            notify(f"Making the 3D asset. It will appear in {PROJECT_NAME} once Marso has finished it.")

    def _browse(self) -> None:
        try:
            from omni.kit.window.filepicker import FilePickerDialog
        except ImportError:
            notify("The file picker is not available here.", warning=True)
            return

        def apply(filename: str, dirname: str) -> None:
            chosen = os.path.join(dirname, filename) if filename else ""
            chosen = chosen.replace("file:/", "") if chosen.startswith("file:/") else chosen
            if self._picker is not None:
                self._picker.hide()
            if chosen:
                problem = self._creator.import_image(os.path.normpath(chosen))
                if problem:
                    notify(problem, warning=True)

        def is_image(item) -> bool:
            return item is None or item.is_folder or Path(item.path).suffix.lower() in IMAGE_TYPES

        if self._picker is not None:
            self._picker.destroy()
        self._picker = FilePickerDialog("Import an image", apply_button_label="Use This Image", click_apply_handler=apply,
                                        item_filter_fn=is_image)
        self._picker.show()

    def destroy(self) -> None:
        self._unsubscribe()
        self._anim.stop()
        self._built = False
        if self._picker is not None:
            self._picker.destroy()
            self._picker = None


def _icon(name: str, size: float, colour: int) -> ui.Image:
    """One of data/icons, tinted (the Create icons are drawn in white for this)."""
    return ui.Image(style.icon(name), width=size, height=size, style={"color": colour})


def _button(text: str, icon_name: str, fn: Callable[[], None], width: int, *, primary: bool = False, height: int = 28,
            tooltip: str = "") -> ui.Button:
    """A button with its icon before the text."""
    return ui.Button(text, name="primary" if primary else "", width=width, height=height, clicked_fn=fn, tooltip=tooltip,
                     image_url=style.icon(icon_name), image_width=16, image_height=16, spacing=6,
                     style={"stack_direction": ui.Direction.LEFT_TO_RIGHT})  # the icon beside the text, not above


def _credits(value: int) -> str:
    return f"{value:,} credits" if value >= 0 else "price unknown"


def _elapsed(seconds: float) -> str:
    seconds = max(0, int(seconds))
    return f"{seconds // 60} min {seconds % 60:02d} s" if seconds >= 60 else f"{seconds} s"

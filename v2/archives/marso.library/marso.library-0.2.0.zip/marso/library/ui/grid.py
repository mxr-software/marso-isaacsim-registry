"""A scrollable grid of asset tiles with selection, drag-to-viewport and live download progress."""

from __future__ import annotations

import functools
from dataclasses import dataclass, replace
from typing import Callable

import carb.input
import omni.ui as ui

from . import style

STATUS_ICONS = {
    "remote": "remote.svg",
    "queued": "queued.svg",
    "downloading": "queued.svg",
    "downloaded": "downloaded.svg",
    "failed": "failed.svg",
    "update": "update.svg",  # downloaded, but Marso has a newer version
}

_SHIFT = carb.input.KEYBOARD_MODIFIER_FLAG_SHIFT
_CONTROL = carb.input.KEYBOARD_MODIFIER_FLAG_CONTROL
_LEFT, _RIGHT = 0, 1
_PAD = 5
_LABEL_ROWS_HEIGHT = 40


@dataclass(frozen=True)
class Tile:
    """What one tile shows. ``key`` is the asset id."""

    key: str
    title: str
    status: str
    status_text: str
    thumbnail: str = ""
    progress: float = 0.0
    tooltip: str = ""
    glyph: str = "pbr"  # "pbr" (a PBR model) or "simready" (PBR model + Physics badge); "" hides the chip
    usd: bool = False  # on disk as a USD file: the chip adds the USD tag
    drag_path: str = ""  # a local USD file the viewport can take as a drop
    favourite: bool = False  # starred: a filled star in the corner
    flags: tuple[str, ...] = ()  # things worth a look (Marso's review, our file checks): a warning chip


class AssetGrid:
    """Owns its tiles and selection; tells its owner about selection, activation and context clicks."""

    def __init__(
        self,
        *,
        on_selection_changed: Callable[[], None] | None = None,
        on_activate: Callable[[list[str]], None] | None = None,
        on_context_menu: Callable[[list[str]], None] | None = None,
        empty_fn: Callable[[], None] | None = None,
        tile_size: int = 128,
        on_favourite: Callable[[str], None] | None = None,
    ) -> None:
        self._on_favourite = on_favourite
        self._on_selection_changed = on_selection_changed
        self._on_activate = on_activate
        self._on_context_menu = on_context_menu
        self._empty_fn = empty_fn
        self._tile_size = tile_size
        self._tiles: list[Tile] = []
        self._by_key: dict[str, Tile] = {}
        self._frames: dict[str, ui.Frame] = {}
        self._rects: dict[str, ui.Rectangle] = {}
        self._fills: dict[str, ui.Rectangle] = {}
        self._status_labels: dict[str, ui.Label] = {}
        self._images: dict[str, ui.Image] = {}
        self.selected: list[str] = []
        self._anchor: str | None = None
        self._frame: ui.Frame | None = None

    # --- public --------------------------------------------------------------------------

    def build(self) -> None:
        """Create the grid's widgets inside the current layout."""
        self._frame = ui.Frame(build_fn=self._build_grid)

    @property
    def tiles(self) -> list[Tile]:
        return list(self._tiles)

    def set_tiles(self, tiles: list[Tile]) -> None:
        self._tiles = list(tiles)
        self._by_key = {tile.key: tile for tile in self._tiles}
        kept = [key for key in self.selected if key in self._by_key]
        changed = kept != self.selected
        self.selected = kept
        if self._frame is not None:
            self._frame.rebuild()
        if changed and self._on_selection_changed:
            self._on_selection_changed()

    def update_tile(self, tile: Tile) -> None:
        """Refresh one tile: progress in place, anything else by rebuilding just that tile."""
        previous = self._by_key.get(tile.key)
        if previous is None:
            return
        self._by_key[tile.key] = tile
        self._tiles = [tile if item.key == tile.key else item for item in self._tiles]
        if previous == tile:
            return
        if replace(previous, progress=tile.progress, status_text=tile.status_text) == tile:
            fill = self._fills.get(tile.key)
            if fill is not None:
                fill.width = ui.Percent(max(1.0, tile.progress * 100.0))
            label = self._status_labels.get(tile.key)
            if label is not None:
                label.text = tile.status_text
            return
        frame = self._frames.get(tile.key)
        if frame is not None:
            frame.rebuild()

    def set_tile_size(self, size: int) -> None:
        if size != self._tile_size:
            self._tile_size = size
            if self._frame is not None:
                self._frame.rebuild()

    def select(self, keys: list[str]) -> None:
        self.selected = [key for key in keys if key in self._by_key]
        self._anchor = self.selected[-1] if self.selected else None
        self._refresh_selection()

    def select_all(self) -> None:
        self.select([tile.key for tile in self._tiles])

    def destroy(self) -> None:
        self._frames.clear()
        self._rects.clear()
        self._fills.clear()
        self._status_labels.clear()
        self._images.clear()
        self._frame = None

    # --- building ------------------------------------------------------------------------

    def _build_grid(self) -> None:
        self._frames.clear()
        self._rects.clear()
        self._fills.clear()
        self._status_labels.clear()
        self._images.clear()
        if not self._tiles:
            if self._empty_fn is not None:
                self._empty_fn()
            return
        size = self._tile_size
        with ui.ScrollingFrame(
            horizontal_scrollbar_policy=ui.ScrollBarPolicy.SCROLLBAR_ALWAYS_OFF,
            vertical_scrollbar_policy=ui.ScrollBarPolicy.SCROLLBAR_AS_NEEDED,
        ):
            with ui.VGrid(column_width=size + 4 * _PAD, row_height=size + _LABEL_ROWS_HEIGHT + 4 * _PAD):
                for tile in self._tiles:
                    self._frames[tile.key] = ui.Frame(build_fn=functools.partial(self._build_tile, tile.key))

    def _build_tile(self, key: str) -> None:
        tile = self._by_key.get(key)
        if tile is None:
            return
        size = self._tile_size
        with ui.VStack():
            ui.Spacer(height=_PAD)
            with ui.HStack():
                ui.Spacer(width=_PAD)
                root = ui.ZStack()
                with root:
                    rect = ui.Rectangle(name="tile", tooltip=tile.tooltip)
                    rect.selected = key in self.selected
                    self._rects[key] = rect
                    with ui.VStack(spacing=2):
                        ui.Spacer(height=_PAD)
                        with ui.HStack(height=size):
                            ui.Spacer(width=_PAD)
                            self._build_thumbnail(tile)
                            ui.Spacer(width=_PAD)
                        with ui.HStack(height=18):
                            ui.Spacer(width=_PAD + 1)
                            ui.Label(tile.title, name="tile_name", elided_text=True, tooltip=tile.tooltip)
                            ui.Spacer(width=_PAD)
                        with ui.HStack(height=14):
                            ui.Spacer(width=_PAD + 1)
                            colour = style.STATUS_COLOURS.get(tile.status, style.MUTED)
                            self._status_labels[key] = ui.Label(
                                tile.status_text, name="tile_status", elided_text=True, style={"color": colour}
                            )
                            ui.Spacer(width=_PAD)
                        ui.Spacer(height=2)
                ui.Spacer(width=_PAD)
            ui.Spacer(height=_PAD)
        root.set_mouse_pressed_fn(lambda x, y, b, m, k=key: self._on_press(k, b, m))
        root.set_mouse_double_clicked_fn(lambda x, y, b, m, k=key: self._on_double_click(k, b))

    def _build_thumbnail(self, tile: Tile) -> None:
        with ui.ZStack():
            ui.Rectangle(name="thumb_bg")
            if tile.thumbnail:
                image = ui.Image(tile.thumbnail, fill_policy=ui.FillPolicy.PRESERVE_ASPECT_FIT)
            else:
                with ui.VStack():
                    ui.Spacer()
                    with ui.HStack(height=ui.Percent(40)):
                        ui.Spacer()
                        image = ui.Image(style.icon("placeholder.svg"), fill_policy=ui.FillPolicy.PRESERVE_ASPECT_FIT)
                        ui.Spacer()
                    ui.Spacer()
            self._images[tile.key] = image
            image.set_drag_fn(lambda k=tile.key: self._on_drag(k))
            with ui.VStack():
                with ui.HStack(height=24):
                    ui.Spacer(width=4)
                    if tile.glyph:
                        with ui.VStack(width=0):
                            ui.Spacer(height=3)
                            self._build_chip(tile.glyph, tile.usd)
                    ui.Spacer()
                    with ui.VStack(width=22):
                        ui.Spacer(height=3)
                        with ui.ZStack(width=20, height=20):
                            ui.Rectangle(name="badge")
                            with ui.HStack():
                                ui.Spacer(width=2)
                                with ui.VStack():
                                    ui.Spacer(height=2)
                                    ui.Image(style.icon(STATUS_ICONS.get(tile.status, "remote.svg")), width=16, height=16)
                                    ui.Spacer(height=2)
                                ui.Spacer(width=2)
                    ui.Spacer(width=3)
                ui.Spacer()
                with ui.HStack(height=24):
                    ui.Spacer(width=4)
                    if tile.flags:
                        with ui.VStack(width=0):
                            with ui.ZStack(width=20 + (12 if len(tile.flags) > 1 else 0), height=20):
                                ui.Rectangle(name="badge", tooltip="\n".join(tile.flags))
                                with ui.HStack():
                                    ui.Spacer(width=2)
                                    with ui.VStack(width=16):
                                        ui.Spacer(height=2)
                                        ui.Image(style.icon("flag.svg"), width=16, height=16, tooltip="\n".join(tile.flags))
                                        ui.Spacer(height=2)
                                    if len(tile.flags) > 1:
                                        ui.Label(str(len(tile.flags)), name="tile_status", width=10,
                                                 style={"color": style.AMBER})
                                    ui.Spacer(width=2)
                            ui.Spacer(height=3)
                    ui.Spacer()
                    if self._on_favourite is not None:
                        with ui.VStack(width=20):
                            star = ui.Image(style.icon("star_on.svg" if tile.favourite else "star.svg"), width=18, height=18,
                                            tooltip="Remove from favourites" if tile.favourite else "Add to favourites")
                            star.set_mouse_pressed_fn(lambda x, y, b, m, k=tile.key: self._star(k, b))
                            ui.Spacer(height=3)
                    ui.Spacer(width=4)
                if tile.status == "downloading":
                    with ui.HStack(height=6):
                        ui.Spacer(width=6)
                        with ui.ZStack():
                            ui.Rectangle(name="progress_track")
                            with ui.HStack():
                                self._fills[tile.key] = ui.Rectangle(
                                    name="progress_fill", width=ui.Percent(max(1.0, tile.progress * 100.0))
                                )
                                ui.Spacer()
                        ui.Spacer(width=6)
                    ui.Spacer(height=6)

    @staticmethod
    def _build_chip(glyph: str, usd: bool) -> None:
        """The Design Language badge: the PBR (or sim-ready) glyph, then the USD tag once it is a USD file."""
        icon = "simready.svg" if glyph == "simready" else "pbr.svg"
        size = 20 if glyph == "simready" else 18  # the sim-ready glyph's badge overhangs the 24 grid
        with ui.ZStack(width=size + (36 if usd else 6), height=22):
            ui.Rectangle(name="chip")
            with ui.HStack():
                ui.Spacer(width=3)
                with ui.VStack(width=size):
                    ui.Spacer()
                    ui.Image(style.icon(icon), width=size, height=size)
                    ui.Spacer()
                if usd:
                    ui.Spacer(width=3)
                    with ui.VStack(width=28):
                        ui.Spacer(height=4)
                        with ui.ZStack(height=14):
                            ui.Rectangle(name="usd_tag")
                            ui.Label("USD", name="usd_tag", alignment=ui.Alignment.CENTER)
                        ui.Spacer(height=4)
                ui.Spacer(width=3)

    # --- interaction ---------------------------------------------------------------------

    def _on_press(self, key: str, button: int, modifier: int) -> None:
        if button == _RIGHT:
            if key not in self.selected:
                self.select([key])
                self._notify_selection()
            if self._on_context_menu:
                self._on_context_menu(list(self.selected))
            return
        if button != _LEFT:
            return
        if modifier & _SHIFT and self._anchor in self._by_key:
            keys = [tile.key for tile in self._tiles]
            start, end = sorted((keys.index(self._anchor), keys.index(key)))
            self.selected = keys[start : end + 1]
        elif modifier & _CONTROL:
            if key in self.selected:
                self.selected = [item for item in self.selected if item != key]
            else:
                self.selected = [*self.selected, key]
            self._anchor = key
        else:
            self.selected = [key]
            self._anchor = key
        self._refresh_selection()
        self._notify_selection()

    def _star(self, key: str, button: int) -> None:
        if button == 0 and self._on_favourite is not None:
            self._on_favourite(key)

    def _on_double_click(self, key: str, button: int) -> None:
        if button == _LEFT and self._on_activate:
            self._on_activate([key])

    def _on_drag(self, key: str) -> str:
        """Hand the viewport a local USD path; it adds the asset where it is dropped."""
        tile = self._by_key.get(key)
        if tile is None:
            return ""
        with ui.VStack(width=72, height=72):
            if tile.thumbnail:
                ui.Image(tile.thumbnail, fill_policy=ui.FillPolicy.PRESERVE_ASPECT_FIT, width=72, height=64)
            if not tile.drag_path:
                ui.Label("Download first", name="faint", alignment=ui.Alignment.CENTER)
        return tile.drag_path

    def _refresh_selection(self) -> None:
        chosen = set(self.selected)
        for key, rect in self._rects.items():
            rect.selected = key in chosen

    def _notify_selection(self) -> None:
        if self._on_selection_changed:
            self._on_selection_changed()

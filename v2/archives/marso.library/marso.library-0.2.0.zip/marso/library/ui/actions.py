"""What the buttons and menus do, shared by the Library and Downloaded tabs."""

from __future__ import annotations

import os
import subprocess
import sys
import webbrowser
from pathlib import Path
from typing import Iterable

import carb
import omni.kit.undo

from .. import settings, usd_ops
from ..core import storage
from ..core.controller import LibraryController
from ..core.storage import LocalAsset
from .widgets import ConfirmDialog

MARSO_APP_URL = "https://marso.app/"
# Above this many downloads at once, ask first: Marso packages are often 30-200 MB each.
CONFIRM_DOWNLOADS_OVER = 10


class Actions:
    def __init__(self, ctrl: LibraryController, open_sim=None, on_collections_changed=None) -> None:
        self._ctrl = ctrl
        self._open_sim = open_sim
        self._on_collections_changed = on_collections_changed  # favourites or recently used changed
        self._dialog: ConfirmDialog | None = None

    def add_to_stage(self, asset_ids: Iterable[str]) -> None:
        """Add assets to the open stage, downloading any that are not on disk yet."""
        ids = list(asset_ids)
        if ids:
            self._used(ids)
            self._confirm_downloads(ids, False, "Download and Add", lambda: self._add_to_stage(ids))

    def _add_to_stage(self, ids: list[str]) -> None:
        placer = usd_ops.StagePlacer()  # one placer, so late arrivals join the same row
        batch = {"open": True}

        def ready(local: LocalAsset) -> None:
            path = placer.add(local)
            if batch["open"]:
                return  # on disk already: reported together below
            if path:
                notify(f"Downloaded and added {local.name} to the stage.")
            elif placer.errors:
                notify(placer.errors[-1], warning=True)

        with omni.kit.undo.group():
            queued = self._ctrl.request(ids, on_ready=ready)
        batch["open"] = False
        self._report(placer)
        if queued:
            plural = "s" if queued != 1 else ""
            notify(f"Downloading {queued} asset{plural}; added to the stage when ready.")

    def add_local_to_stage(self, locals_: list[LocalAsset]) -> None:
        if locals_:
            self._used([item.asset_id for item in locals_])
            self._report(usd_ops.add_to_stage(locals_))

    def open_as_stage(self, local: LocalAsset) -> None:
        self._used([local.asset_id])
        usd_ops.open_as_stage(local)

    def update(self, asset_ids: Iterable[str]) -> None:
        """Download Marso's newer version of assets already on disk."""
        ids = [asset_id for asset_id in asset_ids if self._ctrl.has_update(asset_id)]
        if ids:
            self.download(ids, force=True)

    def toggle_favourite(self, asset_ids: Iterable[str]) -> None:
        ids = list(asset_ids)
        if ids:
            settings.toggle_favourite(ids)
            self._changed()

    def delete(self, asset_ids: Iterable[str]) -> None:
        """Delete downloads from disk, after asking (they can be downloaded again)."""
        ids = [asset_id for asset_id in asset_ids if asset_id in self._ctrl.local]
        if not ids:
            return
        size = storage.format_size(sum(self._ctrl.local[a].size_bytes for a in ids))
        names = ", ".join(self._ctrl.name_of(a) for a in ids[:3]) + (f" and {len(ids) - 3} more" if len(ids) > 3 else "")
        in_use = usd_ops.assets_in_stage(ids)
        warning = (f" {len(in_use)} of them {'is' if len(in_use) == 1 else 'are'} in the open stage and will show as "
                   "missing until downloaded again." if in_use else "")
        if self._dialog is not None:
            self._dialog.close()
        self._dialog = ConfirmDialog(
            f"Delete {len(ids)} download{'s' if len(ids) != 1 else ''}?",
            f"This removes {names} ({size}) from your downloads folder. You can download "
            f"{'it' if len(ids) == 1 else 'them'} again from the Library.{warning}",
            "Delete",
            lambda: self._delete(ids),
        )

    def _delete(self, ids: list[str]) -> None:
        deleted, failed = self._ctrl.delete_downloads(ids)
        if deleted:
            notify(f"Deleted {len(deleted)} download{'s' if len(deleted) != 1 else ''}.")
        for asset_id, reason in failed.items():
            notify(f"Could not delete {self._ctrl.name_of(asset_id)}: {reason}", warning=True)

    def _used(self, ids: list[str]) -> None:
        settings.note_used(ids)
        self._changed()

    def _changed(self) -> None:
        if self._on_collections_changed is not None:
            self._on_collections_changed()

    def download(self, asset_ids: Iterable[str], *, force: bool = False) -> None:
        ids = list(asset_ids)
        if ids:
            self._confirm_downloads(ids, force, "Download", lambda: self._ctrl.request(ids, force=force))

    def _confirm_downloads(self, ids: list[str], force: bool, confirm: str, proceed) -> None:
        count = len(ids) if force else sum(1 for asset_id in ids if asset_id not in self._ctrl.local)
        if count <= CONFIRM_DOWNLOADS_OVER:
            proceed()
            return
        if self._dialog is not None:
            self._dialog.close()
        self._dialog = ConfirmDialog(
            f"Download {count} assets?",
            f"This downloads {count} assets. Marso packages are often 30-200 MB each, so it can take a "
            "while and use several GB of disk. Downloads run in the background and can be cancelled.",
            confirm,
            proceed,
        )

    def test_in_sim(self, asset_ids: Iterable[str]) -> None:
        """Queue assets in Sim Studio (downloading happens when the render starts)."""
        ids = list(asset_ids)
        if ids and self._open_sim is not None:
            self._used(ids)
            self._open_sim(ids)

    def cancel(self, asset_ids: Iterable[str] | None = None) -> None:
        if asset_ids is None:
            self._ctrl.cancel()
            return
        for asset_id in asset_ids:
            self._ctrl.cancel(asset_id)

    @staticmethod
    def _report(placer: usd_ops.StagePlacer) -> None:
        if placer.ground:
            notify("Added a physics scene and a ground, so the assets have something to land on when you press Play.")
        if placer.added:
            names = ", ".join(path.rsplit("/", 1)[-1] for path in placer.added[:3])
            more = f" and {len(placer.added) - 3} more" if len(placer.added) > 3 else ""
            notify(f"Added {names}{more} to the stage.")
        for error in placer.errors:
            notify(error, warning=True)


def open_file(path: Path) -> None:
    """Open a file with the system's default app (a video in the player, for example)."""
    try:
        if sys.platform.startswith("win"):
            os.startfile(str(path))  # noqa: S606 - opening the user's own render
        elif sys.platform == "darwin":
            subprocess.Popen(["open", str(path)])
        else:
            subprocess.Popen(["xdg-open", str(path)])
    except OSError as exc:
        notify(f"Could not open {path.name}: {exc}", warning=True)


def show_in_folder(path: Path) -> None:
    """Reveal a file (or open a folder) in the system file browser."""
    try:
        if sys.platform.startswith("win"):
            if path.is_file():
                subprocess.Popen(["explorer", "/select,", str(path)])
            else:
                os.startfile(str(path))  # noqa: S606 - opening a local folder for the user
        elif sys.platform == "darwin":
            subprocess.Popen(["open", "-R", str(path)] if path.is_file() else ["open", str(path)])
        else:
            subprocess.Popen(["xdg-open", str(path.parent if path.is_file() else path)])
    except OSError as exc:
        notify(f"Could not open {path}: {exc}", warning=True)


def open_url(url: str) -> None:
    webbrowser.open(url)


def copy_text(text: str) -> None:
    try:
        import omni.kit.clipboard

        omni.kit.clipboard.copy(text)
    except ImportError:
        carb.log_warn(f"Marso: clipboard unavailable; value was {text}")


def notify(message: str, warning: bool = False) -> None:
    """A toast in the corner when the notification manager is loaded, else the log."""
    try:
        import omni.kit.notification_manager as nm

        status = nm.NotificationStatus.WARNING if warning else nm.NotificationStatus.INFO
        nm.post_notification(message, status=status, hide_after_timeout=True)
    except ImportError:
        (carb.log_warn if warning else carb.log_info)(f"Marso: {message}")

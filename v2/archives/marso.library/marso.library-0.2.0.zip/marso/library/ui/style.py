"""Colours, icon paths and the omni.ui style sheet for the Marso window."""

from __future__ import annotations

from pathlib import Path

ICONS: Path = Path(__file__).resolve().parents[3] / "data" / "icons"


PREVIEWS: Path = Path(__file__).resolve().parents[3] / "data" / "previews"


def icon(name: str) -> str:
    return str(ICONS / name)


def preview(test_key: str) -> str | None:
    """The Sim Studio card still for a test (data/previews/test_<key>.jpg), or None if there is none."""
    path = PREVIEWS / f"test_{test_key}.jpg"
    return str(path) if path.is_file() else None


def rgba(hex_colour: str, alpha: float = 1.0) -> int:
    """'#RRGGBB' to omni.ui's 0xAABBGGRR integer."""
    value = hex_colour.lstrip("#")
    red, green, blue = int(value[0:2], 16), int(value[2:4], 16), int(value[4:6], 16)
    return (int(alpha * 255) << 24) | (blue << 16) | (green << 8) | red


# Marso Design Language v1 tokens (marso-motion studio/src/ui/dl/tokens.ts). Colour means
# progress (2D -> 3D -> PBR); PBR violet is the payoff and the only accent. USD and sim-ready
# have no colour of their own: they are the PBR glyph plus the USD tag.
TEXT = rgba("#f8f8fb")  # ink
MUTED = rgba("#9ea7b8")  # ink secondary
FAINT = rgba("#7a8290")  # ink muted
PBR = rgba("#b48bff")
ACCENT = PBR
GREEN = rgba("#3fd98a")  # success
AMBER = rgba("#f4c352")  # warning
RED = rgba("#f5746d")  # danger
NODE_BODY = rgba("#060607")
TILE = rgba("#1f2227")  # surface raised
TILE_HOVER = rgba("#262a31")
TILE_SELECTED = rgba("#231d33")
THUMB_BG = NODE_BODY
CHIP = rgba("#121318")  # badge chip; data/icons/simready.svg draws its knock-out in this colour
LINE = rgba("#32363f")  # hairline
ROW_HOVER = rgba("#23262c")
ROW_SELECTED = rgba("#2a2140")
TRANSPARENT = 0x00000000

STATUS_COLOURS = {
    "remote": MUTED,
    "queued": MUTED,
    "downloading": PBR,
    "downloaded": GREEN,
    "failed": RED,
    "update": AMBER,
}

STYLE = {
    "Label": {"color": TEXT, "font_size": 14},
    "Label::title": {"font_size": 16, "color": TEXT},
    "Label::eyebrow": {"font_size": 11, "color": PBR},
    "Label::heading": {"font_size": 14, "color": TEXT},
    "Label::muted": {"color": MUTED, "font_size": 13},
    "Label::faint": {"color": FAINT, "font_size": 12},
    "Label::error": {"color": RED, "font_size": 13},
    "Label::ok": {"color": GREEN, "font_size": 13},
    "Label::tile_name": {"color": TEXT, "font_size": 13},
    "Label::tile_status": {"color": MUTED, "font_size": 12},
    "Label::usd_tag": {"color": NODE_BODY, "font_size": 10},
    "Label::empty_title": {"font_size": 17, "color": TEXT},
    "Label::empty_body": {"font_size": 13, "color": MUTED},
    "Rectangle::tile": {"background_color": TILE, "border_radius": 5, "border_width": 1, "border_color": TILE},
    "Rectangle::tile:hovered": {"background_color": TILE_HOVER, "border_color": TILE_HOVER},
    "Rectangle::tile:selected": {"background_color": TILE_SELECTED, "border_color": ACCENT, "border_width": 2},
    "Rectangle::thumb_bg": {"background_color": THUMB_BG, "border_radius": 4},
    "Rectangle::progress_track": {"background_color": rgba("#000000", 0.55), "border_radius": 2},
    "Rectangle::progress_fill": {"background_color": ACCENT, "border_radius": 2},
    "Rectangle::row": {"background_color": TRANSPARENT, "border_radius": 4},
    "Rectangle::row:hovered": {"background_color": ROW_HOVER},
    "Rectangle::row:selected": {"background_color": ROW_SELECTED},
    "Rectangle::line": {"background_color": LINE},
    "Rectangle::panel": {"background_color": rgba("#000000", 0.12)},
    "Rectangle::badge": {"background_color": rgba("#060607", 0.7), "border_radius": 9},
    "Rectangle::chip": {"background_color": CHIP, "border_radius": 4},
    "Rectangle::card": {"background_color": TILE, "border_radius": 8, "border_width": 1, "border_color": LINE},
    "Rectangle::card:selected": {"background_color": TILE_SELECTED, "border_color": PBR, "border_width": 1.5},
    "Rectangle::usd_tag": {"background_color": PBR, "border_radius": 3},
    "Rectangle::preview_bg": {"background_color": NODE_BODY, "border_radius": 7, "corner_flag": 3},
    "Image::preview": {"border_radius": 7, "corner_flag": 3},
    "Rectangle::expand": {"background_color": TRANSPARENT, "border_radius": 4},
    "Rectangle::expand:hovered": {"background_color": ROW_HOVER},
    "Triangle::expand": {"background_color": MUTED},
    "Button::tab": {"background_color": TRANSPARENT, "border_radius": 0, "padding": 6, "margin": 0},
    "Button::tab:hovered": {"background_color": ROW_HOVER},
    "Button::tab:selected": {"background_color": TRANSPARENT, "border_width": 0},
    "Button.Label::tab": {"color": MUTED, "font_size": 14},
    "Button.Label::tab:selected": {"color": TEXT},
    "Rectangle::tab_underline": {"background_color": TRANSPARENT},
    "Rectangle::tab_underline:selected": {"background_color": ACCENT},
    # Primary buttons are ink on black (DL); only Generate is ever tinted, and there is none here.
    "Button::primary": {"background_color": TEXT, "border_radius": 6},
    "Button::primary:hovered": {"background_color": rgba("#ffffff")},
    "Button::primary:disabled": {"background_color": rgba("#2a2d33")},
    "Button.Label::primary": {"color": NODE_BODY},
    "Button.Label::primary:disabled": {"color": FAINT},
    "Button.Image": {"color": TEXT},  # button icons (drawn white) take the label's colour
    "Button.Image:disabled": {"color": FAINT},
    "Button.Image::primary": {"color": NODE_BODY},
    "Button.Image::primary:disabled": {"color": FAINT},
    "Button": {"border_radius": 4},
    "Button.Label:disabled": {"color": FAINT},
    "Button::icon": {"background_color": TRANSPARENT, "border_radius": 4, "padding": 3},
    "Button::icon:hovered": {"background_color": ROW_HOVER},
    "Button.Image::icon": {"color": TEXT},
    "Field": {"border_radius": 4},
}

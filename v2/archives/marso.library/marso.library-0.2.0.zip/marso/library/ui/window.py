"""The dockable Marso window: header with tabs, the tab bodies, and a status footer."""

from __future__ import annotations

import time
from typing import TYPE_CHECKING, Any, Callable

import omni.ui as ui

from ..core import controller as ctl
from ..core.controller import LibraryController
from ..creation_service import Creator
from ..sim_service import SimStudio
from . import style
from .actions import Actions, notify
from .create_tab import CreateTab
from .downloaded_tab import DownloadedTab
from .library_tab import LibraryTab
from .settings_tab import SettingsTab
from .sim_tab import SimTab
from .widgets import divider, icon_button

if TYPE_CHECKING:
    from ..agent_service import AgentService

WINDOW_TITLE = "Marso"
TAB_LIBRARY, TAB_DOWNLOADED, TAB_CREATE, TAB_SIM, TAB_SETTINGS = range(5)
TAB_NAMES = ("Library", "Downloaded", "Create", "Sim Studio", "Settings")


class MarsoWindow:
    def __init__(self, ctrl: LibraryController, version: str, on_visibility_changed: Callable[[bool], None],
                 studio: SimStudio, creator: Creator, agent: "AgentService | None" = None) -> None:
        self._ctrl = ctrl
        self._agent = agent
        self._studio = studio
        self._creator = creator
        self._on_visibility_changed = on_visibility_changed
        self._actions = Actions(ctrl, open_sim=self.open_sim, on_collections_changed=self._collections_changed)
        self._tab = TAB_LIBRARY
        self._built = False
        self._docked = False
        self._library = LibraryTab(ctrl, self._actions, open_settings=lambda: self.show_tab(TAB_SETTINGS))
        self._downloaded = DownloadedTab(ctrl, self._actions, open_library=lambda: self.show_tab(TAB_LIBRARY))
        self._settings = SettingsTab(ctrl, version, on_config_changed=self._config_changed, agent=agent)
        self._sim = SimTab(studio, open_library=lambda: self.show_tab(TAB_LIBRARY))
        self._create = CreateTab(creator, show_asset=self.show_asset, open_settings=lambda: self.show_tab(TAB_SETTINGS))
        creator.on_finished = self._creation_finished
        self._tab_buttons: list[tuple[ui.Button, ui.Rectangle]] = []
        self._tab_frames: list[ui.Frame] = []
        self._window = ui.Window(
            WINDOW_TITLE,
            width=980,
            height=560,
            visible=False,
            dockPreference=ui.DockPreference.LEFT_BOTTOM,
        )
        self._window.frame.set_style(style.STYLE)
        self._window.frame.set_build_fn(self._build)
        self._window.set_visibility_changed_fn(self._visibility_changed)
        self._unsubscribe = ctrl.subscribe(self._on_event)
        self._unsubscribe_sim = studio.subscribe(self._on_sim_event)

    # --- public --------------------------------------------------------------------------

    def _collections_changed(self) -> None:
        """Favourites or recently used changed: the tabs show stars and those collections."""
        if self._built:
            self._library.refresh()
            self._downloaded.refresh()

    @property
    def visible(self) -> bool:
        return bool(self._window and self._window.visible)

    def show(self, visible: bool = True) -> None:
        if visible and not self._docked:
            self._docked = True
            # Sit beside the Content browser, like the other asset browsers.
            self._window.deferred_dock_in("Content", ui.DockPolicy.CURRENT_WINDOW_IS_ACTIVE)
        self._window.visible = visible
        if visible:
            self._window.focus()

    def show_tab(self, index: int) -> None:
        self._tab = index
        for position, (button, underline) in enumerate(self._tab_buttons):
            button.selected = underline.selected = position == index
        for position, frame in enumerate(self._tab_frames):
            frame.visible = position == index

    def show_asset(self, asset_id: str) -> None:
        """Show one asset in the Library tab, in its project, selected."""
        self.show_tab(TAB_LIBRARY)
        self._library.show_asset(asset_id)

    def _creation_finished(self, run, local) -> None:
        """A new asset from the Create tab is downloaded: onto the stage if asked, and shown in the Library."""
        if run.add_to_stage:
            self._actions.add_local_to_stage([local])
        name = local.name or run.label or "The new asset"  # Marso's name for it, once minted
        notify(f"{name} is in your library" + (" and on the stage." if run.add_to_stage else "."))
        if self._built:
            self._library.refresh()

    def open_sim(self, asset_ids: list[str]) -> None:
        """Queue assets in Sim Studio and show its tab."""
        self._studio.add(asset_ids)
        self.show_tab(TAB_SIM)

    def destroy(self) -> None:
        self._unsubscribe()
        self._unsubscribe_sim()
        self._sim.destroy()
        self._create.destroy()
        self._creator.on_finished = None
        self._library.destroy()
        self._downloaded.destroy()
        self._settings.destroy()
        self._on_visibility_changed = lambda _visible: None
        self._tab_buttons.clear()
        self._tab_frames.clear()
        self._built = False
        if self._window is not None:
            self._window.set_visibility_changed_fn(None)
            self._window.destroy()
            self._window = None

    # --- building ------------------------------------------------------------------------

    def _build(self) -> None:
        self._tab_buttons.clear()
        self._tab_frames.clear()
        with ui.VStack():
            self._build_header()
            divider()
            with ui.ZStack():
                for index, tab in enumerate((self._library, self._downloaded, self._create, self._sim, self._settings)):
                    frame = ui.Frame(visible=index == self._tab)
                    with frame:
                        tab.build()
                    self._tab_frames.append(frame)
            divider()
            self._build_footer()
        self._built = True
        self._update_status()

    def _build_header(self) -> None:
        with ui.HStack(height=34, spacing=2):
            ui.Spacer(width=10)
            with ui.VStack(width=22):
                ui.Spacer()
                ui.Image(style.icon("marso_mark.png"), width=22, height=16)
                ui.Spacer()
            ui.Spacer(width=6)
            ui.Label("Marso", name="title", width=60)
            ui.Spacer(width=10)
            for index, name in enumerate(TAB_NAMES):
                with ui.VStack(width=112):
                    button = ui.Button(name, name="tab", height=32, clicked_fn=lambda i=index: self.show_tab(i))
                    underline = ui.Rectangle(name="tab_underline", height=2)
                    button.selected = underline.selected = index == self._tab
                    self._tab_buttons.append((button, underline))
            ui.Spacer()
            self._sync_label = ui.Label("", name="faint", width=0, alignment=ui.Alignment.RIGHT_CENTER)
            ui.Spacer(width=8)
            self._refresh_button = icon_button("refresh.svg", "Sync your Marso library", self._sync)
            ui.Spacer(width=10)

    def _build_footer(self) -> None:
        with ui.HStack(height=24):
            ui.Spacer(width=10)
            self._status_label = ui.Label("", name="muted", elided_text=True)
            self._jobs_label = ui.Label("", name="muted", width=0, alignment=ui.Alignment.RIGHT_CENTER)
            ui.Spacer(width=10)

    # --- events --------------------------------------------------------------------------

    def _on_event(self, topic: str, payload: Any) -> None:
        if not self._built:
            return
        if topic == ctl.EVENT_LIBRARY:
            self._library.refresh()
            self._downloaded.refresh()
        elif topic == ctl.EVENT_LOCAL:
            if payload is None:
                self._library.refresh()
                self._downloaded.refresh()
            else:
                self._library.on_local(payload)
                self._downloaded.on_local_changed(payload)
        elif topic == ctl.EVENT_JOB:
            self._library.on_job(payload)
            self._update_jobs()
        elif topic == ctl.EVENT_THUMBNAIL:
            self._library.on_thumbnail(payload)
        elif topic == ctl.EVENT_SYNC:
            self._update_status()
            if not self._ctrl.library.projects:
                self._library.refresh()
        elif topic == ctl.EVENT_ACCOUNT:
            self._settings.refresh()

    def _on_sim_event(self, topic: str, payload: Any) -> None:
        if self._built:
            self._sim.on_event(topic, payload)

    def _update_status(self) -> None:
        if not self._built:
            return
        state = self._ctrl.sync_state
        colour = {ctl.SYNC_FAILED: style.RED, ctl.SYNC_AUTH_FAILED: style.RED, ctl.SYNC_NO_KEY: style.AMBER}
        self._status_label.text = state.message or ("Ready" if self._ctrl.library.projects else "")
        self._status_label.style = {"color": colour.get(state.status, style.MUTED)}
        if state.status == ctl.SYNC_RUNNING:
            self._sync_label.text = "Syncing..."
        elif state.synced_at:
            self._sync_label.text = f"Synced {time.strftime('%H:%M', time.localtime(state.synced_at))}"
        else:
            self._sync_label.text = "Not synced yet"
        self._refresh_button.enabled = state.status != ctl.SYNC_RUNNING
        self._update_jobs()

    def _update_jobs(self) -> None:
        active = self._ctrl.active_jobs
        failed = sum(1 for job in self._ctrl.jobs.values() if job.status == ctl.JOB_FAILED)
        parts = []
        running = next((job for job in active if job.status == ctl.JOB_DOWNLOADING), None)
        if running is not None:
            asset = self._ctrl.library.asset(running.asset_id)
            name = asset.name if asset is not None else running.asset_id
            parts.append(f"Downloading {name} ({running.progress:.0%})")
        queued = len(active) - (1 if running is not None else 0)
        if queued:
            parts.append(f"{queued} queued")
        if failed:
            parts.append(f"{failed} failed")
        self._jobs_label.text = " · ".join(parts)
        self._jobs_label.style = {"color": style.RED if failed and not active else style.MUTED}

    def _sync(self) -> None:
        self._ctrl.rescan_local()
        self._ctrl.sync()

    def _config_changed(self, resync: bool) -> None:
        self._ctrl.reload_config()
        if resync:
            self._ctrl.sync()
            if self._agent is not None and self._agent.enabled:
                self._agent.start()  # a new key or endpoint: connect again with it

    def _visibility_changed(self, visible: bool) -> None:
        self._on_visibility_changed(visible)

"""Small building blocks shared by the tabs."""

from __future__ import annotations

from typing import Callable

import omni.ui as ui

from . import style


class SearchField:
    """A text field with a "Search" hint that calls back on every keystroke."""

    def __init__(self, on_changed: Callable[[str], None], hint: str = "Search", width: int = 220) -> None:
        self._on_changed = on_changed
        with ui.ZStack(width=width, height=24):
            self._field = ui.StringField()
            with ui.HStack():
                ui.Spacer(width=6)
                with ui.VStack(width=14):
                    ui.Spacer()
                    self._icon = ui.Image(style.icon("search.svg"), width=14, height=14)
                    ui.Spacer()
                ui.Spacer(width=5)
                self._hint = ui.Label(hint, name="faint")
        self._field.model.add_value_changed_fn(self._changed)

    @property
    def text(self) -> str:
        return self._field.model.get_value_as_string().strip()

    def _changed(self, model) -> None:
        value = model.get_value_as_string()
        self._hint.visible = not value
        self._icon.visible = not value
        self._on_changed(value.strip())


def empty_state(title: str, body: str = "", button: str = "", on_click: Callable[[], None] | None = None) -> None:
    """A centred message for an empty grid, with an optional call to action."""
    with ui.VStack():
        ui.Spacer()
        with ui.HStack(height=0):
            ui.Spacer()
            with ui.VStack(width=380, height=0, spacing=8):
                ui.Label(title, name="empty_title", alignment=ui.Alignment.CENTER, word_wrap=True)
                if body:
                    ui.Label(body, name="empty_body", alignment=ui.Alignment.CENTER, word_wrap=True)
                if button and on_click is not None:
                    with ui.HStack(height=30):
                        ui.Spacer()
                        ui.Button(button, name="primary", width=160, clicked_fn=on_click)
                        ui.Spacer()
            ui.Spacer()
        ui.Spacer()


def divider(vertical: bool = False) -> None:
    if vertical:
        ui.Rectangle(name="line", width=1)
    else:
        ui.Rectangle(name="line", height=1)


def icon_button(icon: str, tooltip: str, on_click: Callable[[], None], size: int = 24) -> ui.Button:
    return ui.Button(
        "",
        name="icon",
        image_url=style.icon(icon),
        image_width=size - 8,
        image_height=size - 8,
        width=size,
        height=size,
        tooltip=tooltip,
        clicked_fn=on_click,
    )


class ConfirmDialog:
    """A small modal question with Cancel and a confirming button."""

    def __init__(self, title: str, message: str, confirm: str, on_confirm: Callable[[], None]) -> None:
        self._on_confirm = on_confirm
        self.message = message
        flags = (
            ui.WINDOW_FLAGS_MODAL
            | ui.WINDOW_FLAGS_NO_RESIZE
            | ui.WINDOW_FLAGS_NO_COLLAPSE
            | ui.WINDOW_FLAGS_NO_SCROLLBAR
            | ui.WINDOW_FLAGS_NO_DOCKING
        )
        self._window = ui.Window(title, width=440, height=0, flags=flags, visible=True)
        self._window.frame.set_style(style.STYLE)
        with self._window.frame:
            with ui.VStack(height=0, spacing=12):
                ui.Spacer(height=4)
                with ui.HStack(height=0):
                    ui.Spacer(width=12)
                    ui.Label(message, word_wrap=True)
                    ui.Spacer(width=12)
                with ui.HStack(height=28, spacing=8):
                    ui.Spacer()
                    ui.Button("Cancel", width=90, clicked_fn=self.close)
                    ui.Button(confirm, name="primary", width=140, clicked_fn=self._confirm)
                    ui.Spacer(width=12)
                ui.Spacer(height=4)

    def _confirm(self) -> None:
        self.close()
        self._on_confirm()

    def close(self) -> None:
        if self._window is not None:
            self._window.visible = False
            self._window.destroy()
            self._window = None


class ListRow:
    """A selectable row in a side list: optional thumbnail, a title and a muted subtitle."""

    def __init__(
        self,
        title: str,
        subtitle: str,
        on_click: Callable[[], None],
        *,
        thumbnail: str = "",
        selected: bool = False,
        subtitle_colour: int | None = None,
        tooltip: str = "",
    ) -> None:
        self.root = ui.ZStack(height=42)
        with self.root:
            self.rect = ui.Rectangle(name="row", tooltip=tooltip or title)
            self.rect.selected = selected
            with ui.HStack(spacing=8):
                ui.Spacer(width=4)
                with ui.VStack(width=32):
                    ui.Spacer()
                    with ui.ZStack(width=32, height=32):
                        ui.Rectangle(name="thumb_bg")
                        ui.Image(thumbnail or style.icon("project.svg"), fill_policy=ui.FillPolicy.PRESERVE_ASPECT_CROP)
                    ui.Spacer()
                with ui.VStack():
                    ui.Spacer()
                    ui.Label(title, elided_text=True, height=18)
                    extra = {"style": {"color": subtitle_colour}} if subtitle_colour is not None else {}
                    ui.Label(subtitle, name="faint", elided_text=True, height=15, **extra)
                    ui.Spacer()
                ui.Spacer(width=4)
        self.root.set_mouse_pressed_fn(lambda x, y, b, m: on_click() if b == 0 else None)

    @property
    def selected(self) -> bool:
        return self.rect.selected

    @selected.setter
    def selected(self, value: bool) -> None:
        self.rect.selected = value


class FacetFilters:
    """Category and Material drop-downs filled from Marso's enrichment of the assets in view."""

    LABELS = {"category": "All categories", "material": "All materials"}

    def __init__(self, on_changed: Callable[[], None]) -> None:
        self._on_changed = on_changed
        self.chosen: dict[str, str] = {key: "" for key in self.LABELS}
        self._values: dict[str, list[str]] = {key: [] for key in self.LABELS}
        self._frame: ui.Frame | None = None

    def build(self) -> None:
        self._frame = ui.Frame(build_fn=self._build, width=0)

    def set_values(self, values: dict[str, list[str]]) -> None:
        """Offer these values; a choice no longer offered falls back to "All"."""
        values = {key: sorted(set(values.get(key) or []), key=str.lower) for key in self.LABELS}
        if values == self._values:
            return
        self._values = values
        dropped = [key for key, value in self.chosen.items() if value and value not in values[key]]
        for key in dropped:
            self.chosen[key] = ""
        if self._frame is not None:
            self._frame.rebuild()
        if dropped:
            self._on_changed()

    def matches(self, facet) -> bool:
        """``facet(key)`` returns an asset's values for a facet."""
        return all(not value or value in facet(key) for key, value in self.chosen.items())

    def _build(self) -> None:
        with ui.HStack(width=0, spacing=6):
            for key, label in self.LABELS.items():
                options = [label, *self._values[key]]
                current = options.index(self.chosen[key]) if self.chosen[key] in options else 0
                combo = ui.ComboBox(current, *options, width=130, height=24,
                                    tooltip=f"Filter by Marso's {key}" if len(options) > 1 else f"No {key} described yet")
                combo.enabled = len(options) > 1
                combo.model.add_item_changed_fn(lambda m, _i, k=key, o=options: self._pick(k, o, m))

    def _pick(self, key: str, options: list[str], model) -> None:
        index = model.get_item_value_model().as_int
        self.chosen[key] = options[index] if index > 0 else ""
        self._on_changed()

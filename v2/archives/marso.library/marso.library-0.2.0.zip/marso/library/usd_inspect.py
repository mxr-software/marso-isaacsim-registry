"""USD work that needs only ``pxr`` (no Kit): reading a package's physics and writing its wrapper layer.

Runs on the controller's worker thread after each download. The wrapper,
``<asset>/isaacsim/<Name>.usda``, is what Isaac Sim references instead of
``model.usdz``:

    def Xform "Wooden_Crate" (kind = "component")   <- translate / rotateXYZ / scale, identity
        def "model" (references = @../model.usdz@)   <- the package, untouched

The wrapper also corrects mass: when a package has a density (on the body, the collider or its
physics material) the wrapper sets the body's ``physics:mass`` to 0, which USD Physics reads as "not
set", so PhysX computes mass and inertia from density x collider volume. Marso's exports author a mass
of density x bounding-box volume, several times too heavy; the package itself is never changed.

Marso packages author their own ops on the root prim (for example
``[xformOp:scale:virtuosoScale, xformOp:rotateX:virtuosoUpAxis]``), an order
Kit's transform tools cannot edit. Wrapping them gives every placed asset a
plain translate/rotate/scale root the gizmo and property panel handle, names
viewport drops after the asset instead of "model", and normalises older Y-up
packages to Z-up metres.
"""

from __future__ import annotations

from pathlib import Path

import json
import math
import re
from dataclasses import replace

from pxr import Gf, Kind, Sdf, Tf, Usd, UsdGeom, UsdPhysics, UsdShade

from .core import api, checks, enrichment, placement, sim_metrics, storage
from .core.controller import Prepared
from .core.physics import PREPARE_VERSION, PhysicsSummary
from .core.storage import LocalAsset

STANDARD_OPS = ["xformOp:translate", "xformOp:rotateXYZ", "xformOp:scale"]
CHILD_NAME = "model"
CUSTOM_DATA_KEY = "marso"


def prepare(local: LocalAsset) -> Prepared:
    """Read the package's physics and (re)write its wrapper layer."""
    stage = Usd.Stage.Open(str(local.usd_path), Usd.Stage.LoadAll)
    if stage is None or not stage.GetDefaultPrim():
        raise RuntimeError(f"{local.usd_path.name} has no default prim")
    physics, clear = _analyse(stage)
    name = suggest_name(stage)
    if name and api.is_placeholder_name(local.name):
        local = replace(local, name=name)  # the wrapper's root prim takes the better name too
    found = read_enrichment(stage)
    return Prepared(physics=physics, stage_file=write_wrapper(local, stage, clear), name=name,
                    enrichment=found.to_dict() if found else None)


def read_enrichment(stage: Usd.Stage) -> enrichment.Enrichment | None:
    """Marso's enrichment stored on the default prim: ``customData["virtuoso"]["enrichment"]``."""
    root = stage.GetDefaultPrim()
    virtuoso = (root.GetCustomData() or {}).get("virtuoso") if root else None
    return enrichment.parse(virtuoso.get("enrichment")) if isinstance(virtuoso, dict) else None


_GENERIC_PRIMS = {"world", "root", "geometry", "geom", "looks", "materials", "physicsmaterials", "mesh", "meshes",
                  "model", "scene", "render", "proxy", "collision", "colliders"}
_ID_LIKE = re.compile(r"[0-9a-f]{8}([_-]?[0-9a-f]{4}){3}|[0-9a-f]{16,}|_\d{3,}$", re.IGNORECASE)


def suggest_name(stage: Usd.Stage) -> str:
    """A human name found inside a package: Marso's embedded display name, else the most specific
    semantic class label, else a descriptive prim name. Empty when there is nothing better."""
    root = stage.GetDefaultPrim()
    if root:
        virtuoso = (root.GetCustomData() or {}).get("virtuoso")
        enrichment = virtuoso.get("enrichment") if isinstance(virtuoso, dict) else None
        if isinstance(enrichment, str):
            try:
                enrichment = json.loads(enrichment)
            except ValueError:
                enrichment = None
        if isinstance(enrichment, dict):
            display = str(enrichment.get("display_name") or "").strip()
            if display and not api.is_placeholder_name(display):
                return display
    start = root if root else stage.GetPseudoRoot()
    for prim in Usd.PrimRange(start):
        attr = prim.GetAttribute("semantics:labels:class")
        labels = [str(label).strip() for label in (attr.Get() or []) if str(label).strip()] if attr else []
        if labels:  # Marso lists general to specific: ["accessory", "shoe"]
            label = labels[-1]
            return label[:1].upper() + label[1:]
    for prim in Usd.PrimRange(start):
        raw = prim.GetName()
        words = raw.replace("_", " ").replace("-", " ").strip()
        if (raw.lower() in _GENERIC_PRIMS or _ID_LIKE.search(raw) or api.is_placeholder_name(words)
                or not re.search(r"[A-Za-z]{3}", words) or prim.IsA(UsdShade.Shader)):
            continue
        return words[:1].upper() + words[1:]
    return ""


def prim_name(name: str) -> str:
    """A valid prim name from an asset name ("Wooden Crate" -> "Wooden_Crate")."""
    return Tf.MakeValidIdentifier(name.strip() or "Asset")


def write_wrapper(local: LocalAsset, asset_stage: Usd.Stage, clear_mass: list[Sdf.Path] | None = None) -> str:
    """Write ``isaacsim/<Name>.usda`` beside the package; return its path relative to the asset folder.

    ``clear_mass``: rigid bodies (package paths) whose authored mass PhysX should ignore in favour of density.
    """
    name = prim_name(local.name)
    folder = local.folder / storage.STAGE_DIR
    folder.mkdir(parents=True, exist_ok=True)
    for stale in folder.glob("*.usda"):  # the asset may have been renamed since
        if stale.name != f"{name}.usda" and Sdf.Layer.Find(str(stale)) is None:
            stale.unlink()
    path = folder / f"{name}.usda"

    layer = Sdf.Layer.Find(str(path))  # already open (e.g. referenced in the stage): rewrite in place
    if layer is not None:
        layer.Clear()
    else:
        if path.exists():
            path.unlink()
        layer = Sdf.Layer.CreateNew(str(path))
    stage = Usd.Stage.Open(layer)
    UsdGeom.SetStageUpAxis(stage, UsdGeom.Tokens.z)
    UsdGeom.SetStageMetersPerUnit(stage, 1.0)
    UsdPhysics.SetStageKilogramsPerUnit(stage, UsdPhysics.GetStageKilogramsPerUnit(asset_stage) or 1.0)

    root = UsdGeom.Xform.Define(stage, f"/{name}")
    stage.SetDefaultPrim(root.GetPrim())
    Usd.ModelAPI(root.GetPrim()).SetKind(Kind.Tokens.component)
    root.AddTranslateOp(UsdGeom.XformOp.PrecisionDouble).Set(Gf.Vec3d(0.0))
    root.AddRotateXYZOp(UsdGeom.XformOp.PrecisionDouble).Set(Gf.Vec3d(0.0))
    root.AddScaleOp(UsdGeom.XformOp.PrecisionDouble).Set(Gf.Vec3d(1.0))
    root.GetPrim().SetCustomDataByKey(CUSTOM_DATA_KEY, {"assetId": local.asset_id, "source": "Marso"})

    child = stage.DefinePrim(f"/{name}/{CHILD_NAME}")
    child.GetReferences().AddReference(f"../{local.usd_path.name}")
    correction = placement.stage_correction(
        UsdGeom.GetStageUpAxis(asset_stage), UsdGeom.GetStageMetersPerUnit(asset_stage), "Z", 1.0
    )
    prepend_ops(child, 0.0, correction.rotate_x_deg, correction.scale)
    default = asset_stage.GetDefaultPrim().GetPath()
    for body in clear_mass or ():
        if not body.HasPrefix(default):
            continue  # outside what the wrapper references
        target = child if body == default else stage.OverridePrim(child.GetPath().AppendPath(body.MakeRelativePath(default)))
        target.CreateAttribute("physics:mass", Sdf.ValueTypeNames.Float).Set(0.0)
    layer.Save()
    return f"{storage.STAGE_DIR}/{path.name}"


def apply_placement(prim: Usd.Prim, translate_x: float, rotate_x: float, scale: float,
                    translate_y: float = 0.0, translate_z: float = 0.0) -> None:
    """Move/correct a just-referenced prim: through its standard ops if it has them, else in front of its own."""
    xformable = UsdGeom.Xformable(prim)
    if list(xformable.GetXformOpOrderAttr().Get() or []) != STANDARD_OPS:
        prepend_ops(prim, translate_x, rotate_x, scale, translate_y, translate_z)
        return
    if translate_x or translate_y or translate_z:
        prim.GetAttribute("xformOp:translate").Set(Gf.Vec3d(translate_x, translate_y, translate_z))
    if rotate_x:
        prim.GetAttribute("xformOp:rotateXYZ").Set(Gf.Vec3d(rotate_x, 0.0, 0.0))
    if abs(scale - 1.0) > 1e-9:
        prim.GetAttribute("xformOp:scale").Set(Gf.Vec3d(scale))


def prepend_ops(prim: Usd.Prim, translate_x: float, rotate_x: float, scale: float,
                translate_y: float = 0.0, translate_z: float = 0.0) -> None:
    """Put placement ops in front of a referenced prim's own ops, never replacing them."""
    xformable = UsdGeom.Xformable(prim)
    inherited = list(xformable.GetXformOpOrderAttr().Get() or [])
    names = []
    if translate_x or translate_y or translate_z:
        xformable.AddTranslateOp(UsdGeom.XformOp.PrecisionDouble, "marsoPlacement").Set(
            Gf.Vec3d(translate_x, translate_y, translate_z))
        names.append("xformOp:translate:marsoPlacement")
    if rotate_x:
        xformable.AddRotateXOp(UsdGeom.XformOp.PrecisionDouble, "marsoUpAxis").Set(float(rotate_x))
        names.append("xformOp:rotateX:marsoUpAxis")
    if abs(scale - 1.0) > 1e-9:
        xformable.AddScaleOp(UsdGeom.XformOp.PrecisionDouble, "marsoUnits").Set(Gf.Vec3d(scale))
        names.append("xformOp:scale:marsoUnits")
    if names:
        xformable.GetXformOpOrderAttr().Set(names + [name for name in inherited if name not in names])


def analyse_physics(stage: Usd.Stage) -> PhysicsSummary:
    """Count the rigid bodies, colliders, physics materials and semantic labels a package authors, and the
    mass PhysX will simulate once the wrapper is in place."""
    return _analyse(stage)[0]


def physics_mass(stage: Usd.Stage) -> tuple[float | None, list[Sdf.Path]]:
    """The mass PhysX will simulate (kg), and the bodies whose authored mass the wrapper should clear.

    A body with a density (its own MassAPI density, else each collider's, else the collider's physics
    material) gets density x collider volume; one without keeps its authored mass.
    """
    return physics_mass_under(stage.GetPseudoRoot())


def physics_mass_under(root: Usd.Prim) -> tuple[float | None, list[Sdf.Path]]:
    """``physics_mass`` for the rigid bodies under one prim (an asset placed in a larger stage)."""
    kilograms_per_unit = UsdPhysics.GetStageKilogramsPerUnit(root.GetStage()) or 1.0
    cache = UsdGeom.XformCache()
    total, found, clear = 0.0, False, []
    predicate = Usd.TraverseInstanceProxies(Usd.PrimDefaultPredicate)
    for body in Usd.PrimRange(root, predicate):
        if not body.HasAPI(UsdPhysics.RigidBodyAPI):
            continue
        authored = _positive(body, "physics:mass")
        body_density = _positive(body, "physics:density")
        computed, measured = 0.0, False
        for prim in Usd.PrimRange(body, predicate):
            if not prim.HasAPI(UsdPhysics.CollisionAPI):
                continue
            density = body_density or _positive(prim, "physics:density") or _material_density(prim)
            volume = _collider_volume(prim, cache)
            if density and volume:
                computed += density * volume
                measured = True
        if measured:
            total += computed * kilograms_per_unit
            found = True
            if authored:
                clear.append(body.GetPath())
        elif authored:
            total += authored * kilograms_per_unit
            found = True
    return (total if found else None), clear


def _positive(prim: Usd.Prim, name: str) -> float | None:
    attr = prim.GetAttribute(name)
    value = attr.Get() if attr else None
    return float(value) if value and value > 0 else None


def _material_density(prim: Usd.Prim) -> float | None:
    material, _rel = UsdShade.MaterialBindingAPI(prim).ComputeBoundMaterial("physics")
    return _positive(material.GetPrim(), "physics:density") if material else None


def _collider_volume(prim: Usd.Prim, cache: UsdGeom.XformCache) -> float | None:
    """A collider's volume in stage units^3: the mesh's own for meshes, exact for cubes and spheres."""
    matrix = cache.GetLocalToWorldTransform(prim)
    if prim.IsA(UsdGeom.Mesh):
        mesh = UsdGeom.Mesh(prim)
        points, counts, indices = (mesh.GetPointsAttr().Get(), mesh.GetFaceVertexCountsAttr().Get(),
                                   mesh.GetFaceVertexIndicesAttr().Get())
        if not points or not counts or not indices:
            return None
        world = [matrix.Transform(Gf.Vec3d(p)) for p in points] if len(points) < 2000 else None
        if world is None:
            import numpy as np

            m = np.array(matrix, dtype=np.float64)
            world = np.asarray(points, dtype=np.float64) @ m[:3, :3] + m[3, :3]
        volume = sim_metrics.mesh_volume(world, sim_metrics.fan_triangles(counts, indices))
        return volume or None
    scale = Gf.Transform(matrix).GetScale()
    if prim.IsA(UsdGeom.Cube):
        size = UsdGeom.Cube(prim).GetSizeAttr().Get() or 2.0
        return abs(size ** 3 * scale[0] * scale[1] * scale[2])
    if prim.IsA(UsdGeom.Sphere):
        radius = UsdGeom.Sphere(prim).GetRadiusAttr().Get() or 1.0
        return abs(4.0 / 3.0 * math.pi * radius ** 3 * scale[0] * scale[1] * scale[2])
    return None


def measure(stage: Usd.Stage) -> tuple[tuple[float, float, float] | None, float | None, tuple[float, float] | None]:
    """The package's size (m, bounding box), mesh volume (m^3) and, for a roughly round object, its
    roundness ((radius m, out of round mm), ``sim_metrics.roundness``)."""
    import numpy as np

    root = stage.GetDefaultPrim()
    if not root:
        return None, None, None
    mpu = UsdGeom.GetStageMetersPerUnit(stage) or 0.01
    cache = UsdGeom.BBoxCache(Usd.TimeCode.Default(), [UsdGeom.Tokens.default_, UsdGeom.Tokens.render])
    box = cache.ComputeWorldBound(root).ComputeAlignedRange()
    size = None if box.IsEmpty() else tuple(float(box.GetSize()[i]) * mpu for i in range(3))
    xforms = UsdGeom.XformCache()
    volume, samples = 0.0, []
    for prim in Usd.PrimRange(root, Usd.TraverseInstanceProxies(Usd.PrimDefaultPredicate)):
        if not prim.IsA(UsdGeom.Mesh) or UsdGeom.Imageable(prim).ComputePurpose() in ("guide", "proxy"):
            continue
        mesh = UsdGeom.Mesh(prim)
        points, counts, indices = (mesh.GetPointsAttr().Get(), mesh.GetFaceVertexCountsAttr().Get(),
                                   mesh.GetFaceVertexIndicesAttr().Get())
        if not points or not counts or not indices:
            continue
        m = np.array(xforms.GetLocalToWorldTransform(prim), dtype=np.float64)
        world = np.asarray(points, dtype=np.float64) @ m[:3, :3] + m[3, :3]
        volume += sim_metrics.mesh_volume(world, sim_metrics.fan_triangles(counts, indices))
        samples.append(world[:: max(1, len(world) // 20000)])
    roundness = None
    if size and min(size) > 0 and max(size) / min(size) < 1.12 and samples:
        roundness = sim_metrics.roundness(np.concatenate(samples) * mpu)
    return size, (volume * mpu ** 3 if volume else None), roundness


def _analyse(stage: Usd.Stage) -> tuple[PhysicsSummary, list[Sdf.Path]]:
    rigid = colliders = materials = labelled = articulations = 0
    approximations: list[str] = []
    mass, clear = physics_mass(stage)
    found = tuple(checks.file_checks(read_enrichment(stage), *measure(stage)))
    for prim in Usd.PrimRange(stage.GetPseudoRoot(), Usd.TraverseInstanceProxies(Usd.PrimDefaultPredicate)):
        schemas = prim.GetAppliedSchemas()
        if not schemas:
            continue
        if "PhysicsRigidBodyAPI" in schemas:
            rigid += 1
        if "PhysicsCollisionAPI" in schemas:
            colliders += 1
            if prim.IsA(UsdGeom.Mesh):
                has_mesh_api = prim.HasAPI(UsdPhysics.MeshCollisionAPI)
                approximation = prim.GetAttribute("physics:approximation").Get() if has_mesh_api else None
                approximations.append(str(approximation or "none"))
        if "PhysicsMaterialAPI" in schemas:
            materials += 1
        if "PhysicsArticulationRootAPI" in schemas:
            articulations += 1
        if any(name.startswith(("SemanticsLabelsAPI", "SemanticsAPI")) for name in schemas):
            labelled += 1
    summary = PhysicsSummary(
        rigid_bodies=rigid,
        colliders=colliders,
        approximations=tuple(approximations),
        mass_kg=round(mass, 4) if mass is not None else None,
        physics_materials=materials,
        semantic_labels=labelled,
        articulations=articulations,
        version=PREPARE_VERSION,
        checks=found,
    )
    return summary, clear


def analyse_file(path: Path) -> PhysicsSummary:
    """``analyse_physics`` for a file on disk."""
    stage = Usd.Stage.Open(str(path), Usd.Stage.LoadAll)
    if stage is None:
        raise RuntimeError(f"Could not open {path.name}")
    return analyse_physics(stage)

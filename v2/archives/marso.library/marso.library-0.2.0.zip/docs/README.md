# Marso Library for Isaac Sim

Browse your [Marso](https://marso.app/) library inside Isaac Sim, download the PBR assets you
generated, add them to your stage, and make new ones without leaving Isaac Sim. Maintained by M-XR.

Tested with Isaac Sim 6.0.1. Assets arrive as USDZ packages (model and textures in one file),
authored Z-up in metres, so they land upright and at real-world size in a default Isaac Sim stage.

## Install

1. Unzip the release. You get a folder called `marso.library`.
2. In Isaac Sim, open **Window > Extensions**, click the menu (three lines) next to the search
   box, choose **Settings**, and add the folder that *contains* `marso.library` under
   **Extension Search Paths**.
3. Search for **Marso**, enable **Marso Library**, and tick **Autoload** so it loads every time.

Alternatively, copy `marso.library` into Isaac Sim's `extsUser` folder, or start Isaac Sim with
`--ext-folder <folder containing marso.library> --enable marso.library`.

The Marso window opens beside the Content browser. Reopen it from **Window > Marso Library**.

## Set up

Open the **Settings** tab and paste your Marso API key (get one at [marso.app](https://marso.app/)).
If `MARSO_API_KEY` is set in your environment, it is used whenever the field is empty.

| Setting | Default | What it holds |
| --- | --- | --- |
| Downloads folder | `Documents/Marso/Downloads` | The downloaded USDZ packages. |
| Cache folder | your local app-data folder, `Marso/IsaacSim/Cache` | Thumbnails and the last synced listing. Safe to delete. |

Point the Marso Blender add-on's **Downloads Path** at the same folder and both apps share
downloads: anything one downloaded shows as downloaded in the other.

## Connect your AI agents

Turn on **Settings > Agent connection > Connect to Marso Agents** and the agents you use with the
Marso MCP (ChatGPT, Codex, Claude) can work in this Isaac Sim alongside you. Ask them to make assets
in Marso and put them on your stage, or to film assets in Sim Studio, and the video appears in your
chat.

- Isaac Sim connects *out* to the Marso MCP with your Marso API key; nothing listens on this
  computer. The status under the switch shows when it is connected, and as which account.
- Only agents signed in to the same Marso account reach this Isaac Sim. If you connect a second
  Isaac Sim with the same account, it takes over from the first.
- Agents can add Marso assets to the stage, download them, see the Marso assets on the stage, and
  run Sim Studio. They cannot change these settings or folders, use the Create tab (generation
  happens in Marso, where it is quoted), delete downloads, or open files. Videos sent to the chat
  are ones Sim Studio made, up to 50 MB, and the link lasts a day; the files stay in your Sim
  Studio folder.
- **Agent server** is empty for the hosted Marso MCP; change it only if M-XR asks you to.

Add the Marso MCP to your chat app with the address `https://mcp.api.marso.app/mcp`.

## Library tab

- **Projects** on the left; one project is open at a time (the last one you opened). Its thumbnails
  download when you open it, so a large library stays quick: nothing is fetched for projects you
  never look at. Empty projects are hidden.
- **Favourites** and **Recently used** sit above the projects. Star an asset (the star in a tile's
  bottom-right corner, or in the details panel) to keep it in Favourites; Recently used lists what you
  last added to a stage or tested in Sim Studio, across projects.
- Each tile shows the asset's status in its top-right corner: a cloud (not downloaded), a clock
  (queued or downloading, with a progress bar) a green tick (downloaded), an amber arrow (downloaded,
  and Marso has a newer version) or a red mark (failed; hover for the reason).
- A **flag** in a tile's bottom-left corner means it is worth a look before you rely on it: Marso
  flagged it for review, or the extension's own checks found something in the file (see
  [Checks](#checks)). The details panel lists them under **Worth a look**.
- Click to select, Ctrl+click to add to the selection, Shift+click for a range. **Select all** and
  **Deselect** sit at the bottom left, beside the number selected.
- **Add to Stage** (or double-click) adds the selection to the open stage, downloading first if
  needed. **Download** only downloads. **Download all missing** fetches everything in view that is
  not on disk yet.
- Drag a downloaded tile into the viewport to drop it where you point (it is named after the
  asset, not after its file).
- **Update all** (bottom bar, when any are due) downloads Marso's newer versions of the assets in
  view; right-click > **Update** does one.
- Right-click for more: download again, update, add to or remove from favourites, cancel, show in
  folder, delete the download, copy the asset id.
- The search box matches names and everything Marso has written about an asset: what it is
  (category, type, detail), its materials and finishes, tags, other names it goes by ("flask" finds
  a water bottle), where it is used. The status filter narrows the grid to downloaded or
  not-yet-downloaded assets, ones with an update, or ones that **Need a look**; **Category** and
  **Material** filter by Marso's description; the slider sets the thumbnail size.
- **Details** (the (i) button) opens a panel beside the grid for the asset you last selected: what it
  is, materials, setting, condition, real-world size, physics (density, friction, bounce, whether it
  is hollow, the mass PhysX simulates), search words, anything Marso flagged for review, and the
  file. Physics and real-world size come from the downloaded file, so they appear once it is on disk.

The library syncs the first time you open the window in a session; the refresh button in the
header syncs again.

**Assets still being finished** (made in Marso a moment ago, from Isaac Sim or anywhere else) are
left out of the Library until Marso has finished them; their project says "1 being finished" and they
appear after the next sync. A few minutes after the Create tab brings in a new asset, the add-on syncs
once by itself, so its thumbnail and any assets finished meanwhile show up without a manual refresh.
Assets made before Marso added descriptions are shown as they are.

## Downloaded tab

Everything in your downloads folder, newest first, grouped by project on the left. It works
offline. **Add to Stage**, **Open as Stage** (opens the asset's own package on its own) and
**Show in Folder** act on the selection. Search, **Category** and **Material** filters, **Select
all** / **Deselect**, stars, flags and the details panel work as in the Library, using the
description stored in each downloaded file.

**Delete...** removes the selected downloads from disk after asking. The question names them and
their total size, and warns if any are in the open stage (they would show as missing until
downloaded again). Only asset folders inside the downloads folder can be deleted; you can download
them again from the Library.

## Create tab

Make a new asset from a description or a picture, the way the Marso Blender add-on's Create panel
does. New assets go in a Marso project called **IsaacSim_AddOn**, made the first time you create
something.

1. **Image.** Describe one object and press **Generate Image**, or press **Import Image...** to use
   your own picture (PNG, JPEG or WebP, up to 5 MB; importing is free). The image appears on the
   right. Generate again for another try, or **Clear** to start over.
2. **3D Asset.** Tick **Import onto stage when ready** if you want the asset in the open stage as
   soon as it arrives, then press **Create 3D Asset**. Marso makes a 3D mesh from the image and PBR
   materials for it.

Each step shows its cost in credits and your balance before you press it; a step you cannot afford
is greyed out with a **Top Up Credits** button. An image costs 10 credits and a 3D asset about 70
at the time of writing (Marso sets the prices; the tab reads them live).

Marso makes each asset in two goes: first a basic model (mesh and textures only), then the
**finished** one, with Marso's description, a proper name and physics (a rigid body and colliders).
The run says "Marso is finishing it" while that happens, usually under a minute. Only the finished
asset comes into your library, so it arrives ready for simulation; the add-on never downloads the
basic version. Then it downloads and prepares like any other asset. It shows up in the
Library under **Made in Isaac Sim**, pinned above your other projects with its own icon, and on the
stage if you ticked the box. **Show** in the run's row selects it there.

A 3D asset takes several minutes. Runs carry on in the background while you work. The strip at the
top of the tab and each run in the **Runs** list show the steps (image, 3D mesh, PBR materials,
finished by Marso, in your library): finished steps turn green, the one under way pulses, and the run
shows how long it has taken. If Isaac Sim closes part-way, the run carries on from the same
step the next time it starts, so nothing is paid for twice. **Stop** stops waiting (Marso keeps
working, and the asset appears in IsaacSim_AddOn after a sync); **Retry** carries on from the step
that stopped or failed, without redoing the earlier ones.

## Sim readiness

Tiles carry Marso's badges in the top-left corner, in PBR violet:

- the **PBR model** glyph (a sphere): every Marso asset is a PBR model;
- the **USD** tag, once it is downloaded as a USD file;
- the **sim-ready** glyph (the PBR sphere with a physics atom) instead of the plain sphere, once the
  downloaded file is found to have a rigid body and colliders.

After a download, the extension reads the package's physics. Hover a tile for the details: Sim
ready, Colliders only (it collides but will not move) or Visual only (no physics), plus the collider
approximation, mass, physics materials and semantic labels.

**Better names.** Many assets are still listed under a file name such as "image" or "generated".
Once one is downloaded, the extension looks inside the file for a real name: Marso's own display name
stored in the USD, else its most specific semantic label ("shoe"), else a descriptive part name. The
Library, Downloaded tab and Sim Studio then use it ("image" becomes "Watermelon").

**Mass comes from density.** When an asset gives a density (on its physics material, collider or
rigid body), the extension lets PhysX compute its mass and inertia from the collider: density x
volume, the way PhysX does when no mass is set. Any mass the file authors is ignored, because current
Marso exports author density x bounding-box volume, which makes most objects several times too heavy
(a metal mug came out at 9.8 kg instead of 0.66 kg). The downloaded file itself is never changed; the
correction lives in the extension's wrapper layer (below), and the mass shown on the tile is the one
PhysX simulates. An asset with no density keeps its authored mass. Hollow objects modelled as a
closed solid (no inner wall) still come out heavy, since their whole volume counts.

## Checks

When an asset is downloaded the extension compares the file with what Marso says about it, and
flags anything worth a look:

- **Marso's review flags.** Marso marks some descriptions for review itself (for example
  "dimension mismatch"); the reasons are shown as they are.
- **Size.** The file's largest dimension against Marso's described real-world size. More than 35%
  (and 2 cm) apart usually means the model was scaled wrongly, so it will look and weigh wrong.
- **Hollow but modelled solid.** Marso says it is hollow (a bottle, a cup), but the mesh is a closed
  solid filling most of its box, so PhysX counts its whole volume and it comes out too heavy.
- **Out of round.** A ball whose surface is more than 1 mm out of round wobbles and veers when it
  rolls.

Physics warnings (no colliders, no mass or density) appear in the same list.

## Sim Studio

Film your assets under physics, as branded videos for marketing or clean footage for your own
edits. Select one or more assets in the Library or Downloaded tab and press **Sim Studio** (or
right-click and choose **Test in Sim Studio**), pick the tests, then **Render**. Each test has a card
with a still of what it films (made with a table tennis racket and other everyday objects); tick its box or click the still to pick
it, and open **Settings** on the card to change that test's options.

| Test | What it shows | Its numbers |
| --- | --- | --- |
| **Scale** | The objects beside a banded height pole on a floor with 10 cm dots, the camera orbiting | Size (cm), mass (density x collider volume), density, volume |
| **Drop** | Dropped from a height (default 1 m), at half speed | Bounces, rebound, measured against authored restitution, settling, resting gap (collider fit), slide, tilt |
| **Friction** | A motorised table tilts until each object slides, tips or rolls | The angle it lets go, the friction that implies, against the authored static and dynamic friction |
| **Wind** | A rising wind (default to 30 m/s), with a wind sock and gauge | The wind speed each object starts to move (or roll) at, and when it blows over |
| **Collision** | The objects dropped onto each other (needs two or more) | Every contact: when, how hard, how deep they overlapped, and what each rests on |
| **Robot** | A Franka arm on a table picks up each object it can hold and sets it down on a marked ring, at 1.5x speed. Split screen by default: a close shot, a camera on the robot's wrist and a top view | The grip, how far it lifted, how far it slipped in the fingers, how close to its ring it landed, whether it stayed upright; why any object was not attempted |
| **Robot: suction** | The same, with a UR10 and a suction cup: it lifts by a flat spot near the centre of mass, up to 10 kg, any width | As Robot, and which objects have no flat spot for the cup to seal on |
| **Robot: wide gripper** | The same, with a UR10e and a Robotiq 2F-140: objects up to 14 cm across and 11 kg | As Robot |
| **Robot: humanoid** | A Unitree G1 humanoid standing at a table picks up light objects with its five-finger hands, each hand taking the objects on its side and setting them down in front of it | As Robot. The grip is assisted: once the fingers close on an object it moves with the hand while its weight, swing and twist stay within what the pinch holds; heavier objects (over about 1.5 kg) and ones it would twist out of are listed |
| **Robot: handover** | Two Franka arms pass each object across the table: one picks it up and turns it to offer it, the other takes it from the side and sets it down. Split screen: a close shot and a camera on each wrist | Both grips, how far it slipped in the handover, how close to its ring it landed, whether it stayed upright; objects no pair of grips suits are left alone, and if the second hand misses, the first puts the object back |

- **Quality**: every preset is path traced and denoised, so moving objects never leave trails:
  Preview (720p, 16 samples per pixel, fast), Standard (1080p, 64), Marketing (1080p, 128: final
  quality light and reflections) or Marketing 4K.
- **Aspect**: 16:9, 9:16 vertical (Reels, Shorts, TikTok), 1:1 or 4:5.
- **Versions**: branded (Marso titles, labels, a results card and the outro), clean (just the
  footage) or both.

Rendering happens in a separate, headless Isaac Sim, so your scene is never touched and you can keep
working. Progress shows in the tab, with Cancel. Each run is a folder (by default
`Documents/Marso/Sim Studio`) holding, per test:

- `<test>.mp4` and `<test>_clean.mp4`, the videos;
- `<test>_card.png`, the results card;
- `<test>_scene.usda`, the set as built, so you can open it, move the camera or lights, press Play and
  shoot your own take. The friction table tilts by itself on Play.

`report.html` gathers everything. The **Recent** gallery plays any video, opens a report or folder,
and (right-click) opens a test's scene in Isaac Sim.

How the tests measure:

- **The floor and table pass the asset's own friction and restitution through** (PhysX combine modes
  multiply with 1.0 and max with 0.0), so the numbers are the asset's authored values.
- **Objects collide with each other in every test**, as they would in a real scene. The Collision
  test drops them onto each other on purpose and measures every contact.
- **Wind is drag on each object's frontal area** (air 1.225 kg/m³, Cd 1.05). It is not an airflow
  simulation. The wind sock is a guide: limp when calm, straight out from 7.7 m/s (15 knots).
- **Robot settings**: playback speed, how many objects (up to four), **Split screen** (on: three
  angles; off: one wide shot with a grip gauge), **Object labels** (off by default, for clean
  marketing footage), **Drop onto the table** (the objects fall onto the table at the start and are
  picked up from wherever they land), **Try risky grips** (also try grips an object might twist out
  of; the card says so) and **Tries per object** (how often it goes back for something that slips or
  falls).
- **Objects start at rest.** An asset modelled in a pose it cannot rest in (a pistol standing on its
  edge) is laid in its most stable resting pose before any test, so nothing topples at the start;
  poses an asset can rest in are kept.
- **If the robot drops something, it tries again**, up to three times, from wherever the object ended
  up; the card says how many tries it took.
- **The robot holds objects by friction alone.** It plans where its fingers can close on each asset's
  own shape (a handle, a strap, a cup's wall), squeezes with 70 N per finger on rubber pads, and the
  grip's friction is the asset's own. Objects over the Franka's 3 kg payload, or with nowhere its 8 cm
  gripper can hold, are listed on the card instead.
- **The robots are NVIDIA's models** (Franka Panda, UR10 with a suction cup, UR10e with a Robotiq
  2F-140, Unitree G1 with Inspire hands), fetched from the Isaac Sim assets server the first time a robot test runs, so the first run
  needs internet and takes a little longer. Offline, the test stops and says it could not load the
  robot. Lights built into a robot model are switched off, so the studio lighting stays even.
- **The handover is the hardest robot test.** The second hand must grip the object from the side,
  clear of the first hand, with its fingers beside the object so it can set it down; small or very
  flat objects, and handles that would let an object swing out, often have no such grip.
- **Round objects are checked for roundness.** An asset's collider follows its mesh, so a ball whose
  mesh is out of round wobbles, veers and slows as it rolls; the results card says by how much.

## Where assets go in the stage

Each asset becomes an Xform under the stage's default prim (`/World` in Isaac Sim), named after the
asset, with plain translate, rotate and scale you can edit with the gizmo. It references a small
layer saved beside the download (`isaacsim/<Asset Name>.usda`), which wraps the untouched
`model.usdz`, turns older Y-up packages upright, and hands mass to PhysX as described above. If your stage uses a different up axis or unit,
the asset is rotated and scaled to fit. Undo removes it; several assets added together undo
together.

Options in **Settings > Adding to the stage**:

- **Add a ground and physics scene if the stage has none** (on by default): the first asset with
  physics also adds a `/PhysicsScene` (gravity along the stage's up axis) and a 20 m
  `GroundPlane` with a collider under the default prim, so pressing Play works straight away. Stages
  that already have a physics scene or a static collider are left alone. Undo removes them with the
  assets.
- **Several at once**: a row along +X (default), a grid five wide, or a stack, each asset centred on
  top of the last (ready to press Play and watch them fall).
- **Use payloads**: assets come in as payloads instead of references, so heavy scenes can be opened
  with them unloaded and loaded as needed.

Downloading more than 10 assets at once asks first, since Marso packages are often 30-200 MB each.

## Troubleshooting

- **"Marso rejected the API key"**: check the key in Settings, then press **Check**.
- **A tile says "no USD package"**: the asset has no USDZ yet (for example a material generated
  from an image). It cannot be added to a stage.
- **"The existing download could not be replaced"**: the file is open in the stage. Close or
  remove it from the stage, then download again.
- **A Create run says "Not enough Marso credits"**: top up at marso.app, then press **Retry**; the
  steps already done are kept.
- **A Create run is still "Waiting for Marso to mint the USD" after a long time**: Marso can take a
  while at busy times. After 30 minutes the run stops waiting with a message; **Retry** waits again,
  or sync the Library later, as the asset appears in IsaacSim_AddOn once it is ready.
- **Thumbnails missing**: press the refresh button; thumbnail links from Marso expire after a
  minute, so a slow first sync can miss some.

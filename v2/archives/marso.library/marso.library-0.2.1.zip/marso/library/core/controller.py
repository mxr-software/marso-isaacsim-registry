"""The library's state and the background work that changes it.

One ``LibraryController`` per extension. Its methods run on the asyncio loop
(Kit's main thread); network and disk work runs on a small thread pool and
reports back to the loop, so subscribers (the UI) are only ever called on the
loop thread. Nothing here touches Kit, which keeps it testable with a plain
asyncio loop and a local mock of the API.
"""

from __future__ import annotations

import asyncio
import functools
import logging
import time
from collections import deque
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, replace
from pathlib import Path
from typing import Any, Callable, Iterable

from . import api, checks, config, downloads, http, storage, thumbnails
from .api import Asset, Library
from .enrichment import Enrichment
from .physics import PhysicsSummary
from .storage import LocalAsset

log = logging.getLogger("marso.library")

# Event topics passed to subscribers as ``fn(topic, payload)``.
EVENT_LIBRARY = "library"  # payload: None
EVENT_LOCAL = "local"  # payload: None
EVENT_THUMBNAIL = "thumbnail"  # payload: thumbnail key
EVENT_JOB = "job"  # payload: asset id
EVENT_SYNC = "sync"  # payload: SyncState
EVENT_ACCOUNT = "account"  # payload: None

SYNC_IDLE = "idle"
SYNC_RUNNING = "running"
SYNC_FAILED = "failed"
SYNC_NO_KEY = "no_key"
SYNC_AUTH_FAILED = "auth_failed"

JOB_QUEUED = "queued"
JOB_DOWNLOADING = "downloading"
JOB_FAILED = "failed"

STATUS_REMOTE = "remote"
STATUS_DOWNLOADED = "downloaded"

ConfigFn = Callable[[], config.Config]
PrepareFn = Callable[[LocalAsset], "Prepared"]
ReadyFn = Callable[[LocalAsset], None]
Subscriber = Callable[[str, Any], None]


@dataclass(frozen=True)
class SyncState:
    status: str = SYNC_IDLE
    message: str = ""
    synced_at: float | None = None


@dataclass(frozen=True)
class Prepared:
    """What the host's prepare step found and wrote for one downloaded asset."""

    physics: PhysicsSummary
    stage_file: str = ""  # a layer to reference instead of the package, relative to the asset folder
    name: str = ""  # a name found inside the package, for assets listed under a placeholder name
    enrichment: dict | None = None  # Marso's enrichment stored in the package (Enrichment.to_dict)


@dataclass
class DownloadJob:
    asset_id: str
    status: str = JOB_QUEUED
    progress: float = 0.0
    error: str = ""
    force: bool = False
    on_ready: list[ReadyFn] | None = None


class LibraryController:
    def __init__(
        self,
        config_fn: ConfigFn,
        *,
        prepare_fn: PrepareFn | None = None,
        loop: asyncio.AbstractEventLoop | None = None,
        source: str = "marso-isaacsim",
    ) -> None:
        self._config_fn = config_fn
        self._prepare_fn = prepare_fn
        self._loop = loop or asyncio.get_event_loop()
        self._source = source
        # One slot each for a sync, a download, a physics read and a quick account check.
        self._executor = ThreadPoolExecutor(max_workers=4, thread_name_prefix="marso")
        self._subscribers: list[Subscriber] = []
        self.config = config_fn()
        self.library = Library()
        self.local: dict[str, LocalAsset] = {}
        self.jobs: dict[str, DownloadJob] = {}
        self.sync_state = SyncState()
        self.account: api.Account | None = None
        self.account_error = ""
        self._queue: deque[str] = deque()
        self._worker: asyncio.Task | None = None
        self._cancel_current = False
        self._sync_task: asyncio.Task | None = None
        self._analysing = False
        self._closed = False
        # Asset thumbnails are fetched per project, when it is opened (thumbnails for a whole
        # library take minutes and the links expire within a minute of listing).
        self.open_project_id = ""
        self._thumbnail_jobs: set[str] = set()

    # --- lifecycle ---------------------------------------------------------------------

    def start(self) -> None:
        """Show what is on disk straight away; the caller decides when to sync."""
        self.load_cached()
        self.rescan_local()

    def shutdown(self) -> None:
        """Stop all work. Running tasks are cancelled; they finish on the loop's next turn."""
        self._closed = True
        self._queue.clear()
        self._cancel_current = True
        self._subscribers.clear()
        for task in (self._worker, self._sync_task):
            if task is not None and not task.done():
                task.cancel()
        self._executor.shutdown(wait=False, cancel_futures=True)

    def subscribe(self, fn: Subscriber) -> Callable[[], None]:
        self._subscribers.append(fn)
        return lambda: self._subscribers.remove(fn) if fn in self._subscribers else None

    def reload_config(self) -> None:
        """Pick up changed settings: re-read the folders, forget the account if the key changed."""
        previous = self.config
        self.config = self._config_fn()
        if (previous.api_key, previous.api_endpoint) != (self.config.api_key, self.config.api_endpoint):
            self.account = None
            self.account_error = ""
            self._emit(EVENT_ACCOUNT, None)
            if not self.config.has_api_key:
                self._set_sync(SYNC_NO_KEY, "Add your Marso API key in Settings.")
        if previous.cache_dir != self.config.cache_dir:
            self.load_cached()
        if previous.downloads_dir != self.config.downloads_dir:
            self.rescan_local()

    # --- library -----------------------------------------------------------------------

    def load_cached(self) -> None:
        library, synced_at = storage.load_library(self.config.cache_dir)
        self.library = library
        self.local = _named_from_library(self.local, library)
        state = SYNC_IDLE if self.config.has_api_key else SYNC_NO_KEY
        message = "" if self.config.has_api_key else "Add your Marso API key in Settings."
        self.sync_state = SyncState(state, message, synced_at)
        self._emit(EVENT_LIBRARY, None)
        self._emit(EVENT_SYNC, self.sync_state)

    def sync(self) -> asyncio.Task | None:
        """Start a refresh of the listing (and missing thumbnails) unless one is running."""
        if self._sync_task is not None and not self._sync_task.done():
            return self._sync_task
        self._sync_task = self._loop.create_task(self._sync())
        return self._sync_task

    @property
    def is_syncing(self) -> bool:
        return self._sync_task is not None and not self._sync_task.done()

    async def _sync(self) -> bool:
        cfg = self.config
        if not cfg.has_api_key:
            self._set_sync(SYNC_NO_KEY, "Add your Marso API key in Settings.")
            return False
        self._set_sync(SYNC_RUNNING, "Syncing your Marso library...")
        cached = self.library
        on_page = functools.partial(self._threadsafe, self._show_partial, cached)
        on_saved = functools.partial(self._threadsafe, self._emit, EVENT_THUMBNAIL)
        try:
            library = await self._run(self._walk, cfg, on_page, on_saved, self.open_project_id)
        except http.MarsoAuthError as exc:
            self._restore(cached)
            self._set_sync(SYNC_AUTH_FAILED, f"Marso rejected the API key. Check it in Settings. {exc}")
            return False
        except http.NETWORK_ERRORS as exc:
            self._restore(cached)
            self._set_sync(SYNC_FAILED, f"Could not sync: {exc}")
            return False

        synced_at = time.time()
        self.library = library
        self.local = _named_from_library(self.local, library)
        await self._run(storage.save_library, cfg.cache_dir, library, synced_at)
        self._emit(EVENT_LIBRARY, None)
        self._emit(EVENT_LOCAL, None)
        projects = sum(1 for project in library.projects if project.assets)
        self._set_sync(SYNC_IDLE, f"{projects} projects, {len(library.assets)} assets", synced_at)
        return True

    @staticmethod
    def _walk(cfg: config.Config, on_page: Callable[[Library], None], on_saved: Callable[[str], None],
              open_project: str = "") -> Library:
        """Page through the listing (worker thread), fetching project thumbnails while their links are fresh.

        Asset thumbnails wait until a project is opened (``open_project``), except the open project's own,
        fetched as its page goes by.
        """
        library = Library()
        seen: set[str] = set()
        for library in api.iter_library(cfg.api_key, cfg.api_endpoint):
            on_page(library)
            fresh = [p for p in library.projects if p.project_id not in seen or p.project_id == api.UNGROUPED_PROJECT_ID]
            seen.update(p.project_id for p in fresh)
            items = [(storage.project_thumbnail_key(p.project_id), p.thumbnail_url) for p in fresh]
            items += [(asset.asset_id, asset.thumbnail_url) for p in fresh if p.project_id == open_project
                      for asset in p.assets]
            try:
                thumbnails.fetch_missing(items, cfg.cache_dir, on_saved=lambda key, _path: on_saved(key))
            except OSError as exc:  # thumbnails are cosmetic; keep listing
                log.warning("Marso thumbnails: %s", exc)
        return library

    def _show_partial(self, cached: Library, partial: Library) -> None:
        """Show what has been listed so far, with not-yet-listed cached projects after it."""
        listed = {project.project_id for project in partial.projects}
        rest = tuple(project for project in cached.projects if project.project_id not in listed)
        self.library = Library(partial.projects + rest)
        self.local = _named_from_library(self.local, self.library)
        self._emit(EVENT_LIBRARY, None)
        count = sum(1 for project in partial.projects if project.assets)
        self._set_sync(SYNC_RUNNING, f"Syncing your Marso library... {count} projects so far")

    def merge_project(self, project: api.Project) -> None:
        """Put a freshly listed project into the library (a new asset made from Isaac Sim) without a full sync.

        It goes first, as the newest project; the listing cache is saved so it is there offline too.
        """
        rest = tuple(p for p in self.library.projects if p.project_id != project.project_id and p.name != project.name)
        self.library = Library((project, *rest))
        self.local = _named_from_library(self.local, self.library)
        cfg, synced_at = self.config, self.sync_state.synced_at or time.time()
        self._loop.create_task(self._run(storage.save_library, cfg.cache_dir, self.library, synced_at))
        self._emit(EVENT_LIBRARY, None)

    def _restore(self, cached: Library) -> None:
        if self.library is not cached:
            self.library = cached
            self._emit(EVENT_LIBRARY, None)

    def open_project(self, project_id: str) -> None:
        """A project was opened: fetch its missing asset thumbnails in the background (as the Blender add-on does)."""
        self.open_project_id = project_id
        project = self.library.project(project_id)
        if project is None or not self.config.has_api_key or self._closed or project_id in self._thumbnail_jobs:
            return
        wanted = {a.asset_id for a in project.assets if self.asset_thumbnail(a.asset_id) is None}
        if not wanted:
            return
        self._thumbnail_jobs.add(project_id)
        on_saved = functools.partial(self._threadsafe, self._emit, EVENT_THUMBNAIL)
        self._loop.create_task(self._fetch_project_thumbnails(project_id, wanted, on_saved))

    async def _fetch_project_thumbnails(self, project_id: str, wanted: set[str], on_saved: Callable[[str], None]) -> None:
        cfg = self.config
        try:
            await self._run(self._project_thumbnails, cfg, project_id, wanted, on_saved)
        except (http.MarsoAuthError, *http.NETWORK_ERRORS, OSError) as exc:  # cosmetic: the tiles keep their placeholder
            log.warning("Marso thumbnails for project %s: %s", project_id, exc)
        finally:
            self._thumbnail_jobs.discard(project_id)

    @staticmethod
    def _project_thumbnails(cfg: config.Config, project_id: str, wanted: set[str], on_saved: Callable[[str], None]) -> None:
        """Re-list the one project for fresh links (worker thread), then fetch the thumbnails it is missing."""
        project = api.find_project(cfg.api_key, cfg.api_endpoint, project_id)
        if project is None:
            return
        items = [(a.asset_id, a.thumbnail_url) for a in project.assets if a.asset_id in wanted and a.thumbnail_url]
        thumbnails.fetch_missing(items, cfg.cache_dir, on_saved=lambda key, _path: on_saved(key))

    def name_of(self, asset_id: str) -> str:
        """The name to show: Marso's ``enrichment.display_name`` when there is one, else the library's name,
        unless that is a placeholder the download has bettered."""
        asset = self.library.asset(asset_id)
        local = self.local.get(asset_id)
        if asset is not None and asset.display_name:
            return asset.display_name
        if local is not None and local.enrichment is not None and local.enrichment.display_name:
            return local.enrichment.display_name
        if asset is not None and not (local is not None and api.is_placeholder_name(asset.name)
                                      and not api.is_placeholder_name(local.name)):
            return asset.name
        return local.name if local is not None else asset_id

    def flags_of(self, asset_id: str) -> list[str]:
        """Things worth a look: what Marso flagged, what the file check found, physics warnings."""
        local = self.local.get(asset_id)
        found = checks.review_flags(self.enrichment_of(asset_id))
        if local is not None and local.physics is not None:
            found += list(local.physics.checks) + local.physics.warnings()
        return found

    def has_update(self, asset_id: str) -> bool:
        """Downloaded, and Marso now lists a different model version than the one on disk."""
        local = self.local.get(asset_id)
        asset = self.library.asset(asset_id)
        return (local is not None and asset is not None and bool(local.model_version) and bool(asset.model_version)
                and local.model_version != asset.model_version)

    def delete_downloads(self, asset_ids: Iterable[str]) -> tuple[list[str], dict[str, str]]:
        """Delete downloads from disk. Returns (deleted ids, {id: why not}) and refreshes the local list."""
        deleted, failed = [], {}
        for asset_id in dict.fromkeys(asset_ids):
            local = self.local.get(asset_id)
            if local is None:
                continue
            if asset_id in self.jobs:
                failed[asset_id] = "it is downloading"
                continue
            try:
                storage.delete_download(local.folder, self.config.downloads_dir)
            except storage.NotADownload as exc:
                failed[asset_id] = str(exc)
                continue
            except OSError as exc:  # e.g. the file is open in the stage
                failed[asset_id] = f"could not delete it ({exc.strerror or exc}); close any stage using it"
                continue
            self.local.pop(asset_id, None)
            deleted.append(asset_id)
        if deleted:
            self._emit(EVENT_LOCAL, None)
        return deleted, failed

    def fetch_thumbnails(self, asset_ids: Iterable[str]) -> None:
        """Fetch missing thumbnails for assets from any projects (favourites, recently used)."""
        by_project: dict[str, set[str]] = {}
        for asset_id in asset_ids:
            asset = self.library.asset(asset_id)
            if asset is not None and self.asset_thumbnail(asset_id) is None:
                by_project.setdefault(asset.project_id, set()).add(asset_id)
        if not by_project or not self.config.has_api_key or self._closed:
            return
        on_saved = functools.partial(self._threadsafe, self._emit, EVENT_THUMBNAIL)
        for project_id, wanted in by_project.items():
            if project_id not in self._thumbnail_jobs:
                self._thumbnail_jobs.add(project_id)
                self._loop.create_task(self._fetch_project_thumbnails(project_id, wanted, on_saved))

    def enrichment_of(self, asset_id: str) -> Enrichment | None:
        """Marso's description of an asset: the download's (it adds physics and size), else the listing's."""
        local = self.local.get(asset_id)
        if local is not None and local.enrichment is not None:
            return local.enrichment
        asset = self.library.asset(asset_id)
        return asset.enrichment if asset is not None else None

    def project_name(self, project_id: str) -> str:
        project = self.library.project(project_id)
        return project.name if project is not None else project_id

    def thumbnail(self, key: str) -> Path | None:
        return storage.find_thumbnail(self.config.cache_dir, key)

    def asset_thumbnail(self, asset_id: str) -> Path | None:
        cached = self.thumbnail(asset_id)
        if cached is not None:
            return cached
        local = self.local.get(asset_id)
        return local.thumbnail_path if local is not None else None

    # --- account -----------------------------------------------------------------------

    async def check_account(self) -> bool:
        cfg = self.config
        if not cfg.has_api_key:
            self.account, self.account_error = None, "No API key set."
            self._emit(EVENT_ACCOUNT, None)
            return False
        try:
            self.account = await self._run(api.fetch_account, cfg.api_key, cfg.api_endpoint)
            self.account_error = ""
        except http.MarsoAuthError:
            self.account, self.account_error = None, "Marso rejected this API key."
        except http.NETWORK_ERRORS as exc:
            self.account, self.account_error = None, f"Could not reach Marso: {exc}"
        self._emit(EVENT_ACCOUNT, None)
        return self.account is not None

    # --- local downloads ---------------------------------------------------------------

    def rescan_local(self) -> None:
        self.local = _named_from_library(storage.scan_downloads(self.config.downloads_dir), self.library)
        self._emit(EVENT_LOCAL, None)
        self.analyse_missing()

    def status(self, asset_id: str) -> str:
        job = self.jobs.get(asset_id)
        if job is not None:
            return job.status
        return STATUS_DOWNLOADED if asset_id in self.local else STATUS_REMOTE

    def analyse_missing(self) -> None:
        """Prepare downloaded assets that are not yet (e.g. Blender downloads, or older sidecars)."""
        if self._prepare_fn is None or self._analysing or self._closed:
            return
        pending = [item for item in self.local.values() if not item.is_prepared]
        if pending:
            self._analysing = True
            self._loop.create_task(self._analyse(pending))

    async def _analyse(self, pending: list[LocalAsset]) -> None:
        try:
            for item in pending:
                if self._closed:
                    return
                prepared = await self._run(self._prepare_and_record, item)
                current = self.local.get(item.asset_id)
                if current is not None and current.usd_path == item.usd_path:
                    self.local[item.asset_id] = prepared
                    self._emit(EVENT_LOCAL, item.asset_id)
        finally:
            self._analysing = False

    def _prepare_and_record(self, item: LocalAsset) -> LocalAsset:
        """Run the host's prepare step (worker thread) and record its result beside the asset."""
        assert self._prepare_fn is not None
        try:
            prepared = self._prepare_fn(item)
        except Exception as exc:  # noqa: BLE001 - any USD failure becomes an "unknown" summary
            prepared = Prepared(PhysicsSummary(errors=(str(exc) or type(exc).__name__,)))
        # An asset listed as "image" or "generated" takes the name its package carries.
        name = prepared.name if prepared.name and api.is_placeholder_name(item.name) else item.name
        try:
            storage.update_sidecar(item.folder, physics=prepared.physics.to_dict(), stage_file=prepared.stage_file,
                                   name=name, enrichment=prepared.enrichment)
        except OSError as exc:
            log.warning("Marso: could not record physics for %s: %s", item.asset_id, exc)
        return replace(item, physics=prepared.physics, stage_file=prepared.stage_file, name=name,
                       enrichment=Enrichment.from_dict(prepared.enrichment) or item.enrichment)

    # --- downloads ---------------------------------------------------------------------

    def request(self, asset_ids: Iterable[str], *, force: bool = False, on_ready: ReadyFn | None = None) -> int:
        """Make assets available locally, then call ``on_ready`` for each (immediately if on disk).

        Returns how many downloads were queued.
        """
        queued = 0
        for asset_id in dict.fromkeys(asset_ids):
            local = self.local.get(asset_id)
            job = self.jobs.get(asset_id)
            if local is not None and not force and job is None:
                if on_ready is not None:
                    on_ready(local)
                continue
            if job is not None and job.status != JOB_FAILED:
                if on_ready is not None:
                    job.on_ready = [*(job.on_ready or []), on_ready]
                continue
            if self.library.asset(asset_id) is None:
                self.jobs[asset_id] = DownloadJob(asset_id, JOB_FAILED, error="Not in your Marso library.")
                self._emit(EVENT_JOB, asset_id)
                continue
            self.jobs[asset_id] = DownloadJob(asset_id, force=force, on_ready=[on_ready] if on_ready else None)
            self._queue.append(asset_id)
            queued += 1
            self._emit(EVENT_JOB, asset_id)
        if queued and (self._worker is None or self._worker.done()):
            self._worker = self._loop.create_task(self._work())
        return queued

    def cancel(self, asset_id: str | None = None) -> None:
        """Cancel one queued or running download, or all of them."""
        targets = list(self.jobs) if asset_id is None else [asset_id]
        for target in targets:
            job = self.jobs.get(target)
            if job is None:
                continue
            if job.status == JOB_DOWNLOADING:
                self._cancel_current = True
            elif job.status == JOB_QUEUED:
                if target in self._queue:
                    self._queue.remove(target)
                del self.jobs[target]
                self._emit(EVENT_JOB, target)
            elif job.status == JOB_FAILED:
                del self.jobs[target]
                self._emit(EVENT_JOB, target)

    @property
    def active_jobs(self) -> list[DownloadJob]:
        return [job for job in self.jobs.values() if job.status in (JOB_QUEUED, JOB_DOWNLOADING)]

    async def _work(self) -> None:
        while self._queue and not self._closed:
            asset_id = self._queue.popleft()
            job = self.jobs.get(asset_id)
            asset = self.library.asset(asset_id)
            if job is None or asset is None:
                continue
            cfg = self.config
            job.status, job.progress = JOB_DOWNLOADING, 0.0
            self._cancel_current = False
            self._emit(EVENT_JOB, asset_id)
            request = downloads.DownloadRequest(
                asset=asset,
                project_name=self.project_name(asset.project_id),
                api_key=cfg.api_key,
                base_url=cfg.api_endpoint,
                downloads_dir=cfg.downloads_dir,
                cache_dir=cfg.cache_dir,
                source=self._source,
            )
            try:
                local = await self._run(
                    downloads.download_asset,
                    request,
                    progress=functools.partial(self._threadsafe, self._on_progress, asset_id),
                    cancelled=lambda: self._cancel_current or self._closed,
                )
                if self._prepare_fn is not None:
                    local = await self._run(self._prepare_and_record, local)
            except http.DownloadCancelled:
                self.jobs.pop(asset_id, None)
                self._emit(EVENT_JOB, asset_id)
                continue
            except http.MarsoAuthError:
                job.status, job.error = JOB_FAILED, "Marso rejected the API key. Check it in Settings."
                self._emit(EVENT_JOB, asset_id)
                continue
            except (downloads.DownloadError, *http.NETWORK_ERRORS) as exc:
                job.status, job.error = JOB_FAILED, str(exc)
                log.warning("Marso download failed for %s: %s", asset_id, exc)
                self._emit(EVENT_JOB, asset_id)
                continue

            self.local[asset_id] = local
            callbacks = job.on_ready or []
            self.jobs.pop(asset_id, None)
            self._emit(EVENT_LOCAL, asset_id)
            self._emit(EVENT_JOB, asset_id)
            for callback in callbacks:
                if callback is None:
                    continue
                try:
                    callback(local)
                except Exception:  # noqa: BLE001 - one failing callback must not stop the queue
                    log.exception("Marso: callback for %s failed", asset_id)

    def _on_progress(self, asset_id: str, done: int, total: int) -> None:
        job = self.jobs.get(asset_id)
        if job is None or total <= 0:
            return
        progress = min(1.0, done / total)
        if progress - job.progress >= 0.01 or progress >= 1.0:
            job.progress = progress
            self._emit(EVENT_JOB, asset_id)

    # --- plumbing ----------------------------------------------------------------------

    async def _run(self, fn: Callable, *args, **kwargs):
        return await self._loop.run_in_executor(self._executor, functools.partial(fn, *args, **kwargs))

    def _threadsafe(self, fn: Callable, *args) -> None:
        if not self._closed:
            self._loop.call_soon_threadsafe(fn, *args)

    def _set_sync(self, status: str, message: str, synced_at: float | None = None) -> None:
        self.sync_state = SyncState(status, message, synced_at if synced_at is not None else self.sync_state.synced_at)
        self._emit(EVENT_SYNC, self.sync_state)

    def _emit(self, topic: str, payload: Any) -> None:
        for fn in list(self._subscribers):
            try:
                fn(topic, payload)
            except Exception:  # noqa: BLE001 - a broken subscriber must not break the controller
                log.exception("Marso: subscriber failed on %s", topic)


def _named_from_library(local: dict[str, LocalAsset], library: Library) -> dict[str, LocalAsset]:
    """Give downloads made elsewhere (no ``marso.json``) their library name and project, and every download
    the library's ``enrichment.display_name`` once Marso lists one."""
    named = {}
    for asset_id, item in local.items():
        asset: Asset | None = library.asset(asset_id)
        if asset is not None and asset.display_name and item.name != asset.display_name:
            item = replace(item, name=asset.display_name)
        if asset is not None and not item.has_sidecar:
            project = library.project(asset.project_id)
            item = replace(
                item,
                name=item.name if api.is_placeholder_name(asset.name) and not api.is_placeholder_name(item.name) else asset.name,
                project_id=asset.project_id,
                project_name=project.name if project is not None else item.project_name,
            )
        named[asset_id] = item
    return named

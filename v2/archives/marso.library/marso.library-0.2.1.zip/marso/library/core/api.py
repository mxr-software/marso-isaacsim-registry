"""Client for the parts of the Marso public API the library browser uses.

  GET  {base}/assets            -- PBR assets grouped by project, cursor-paginated
  POST {base}/assets/download   -- presigned URLs (valid ~2 minutes) for up to 100 ids
  GET  {base}/account/me        -- who the API key belongs to

The grouped listing carries every project's full asset list, so one walk of
its pages is the whole library. Assets that belong to no project (everything
created through the API) arrive in ``ungrouped_assets`` and are shown as one
extra pseudo-project.
"""

from __future__ import annotations

import re
import urllib.parse
from dataclasses import dataclass, field, replace
from pathlib import PurePosixPath
from typing import Any, Iterable, Iterator

from . import http
from .enrichment import Enrichment
from .enrichment import parse as parse_enrichment

ASSETS_PATH = "/assets"
DOWNLOAD_PATH = "/assets/download"
ACCOUNT_PATH = "/account/me"

PAGE_LIMIT = 25
DOWNLOAD_BATCH_LIMIT = 100
USDZ_ROLE = "usdz"

# An asset's ``enriched_status`` once Marso has settled it. Any other value (``in_progress``) means Marso is
# still finishing it (its description, name and physics): it is listed with only a basic USD, so the library
# leaves it out until it is finished. Older assets never enriched (``not_started``) and ones whose enrichment
# failed are shown as they are: Marso will not finish them.
SETTLED_ENRICHMENT = frozenset({"", "not_started", "succeeded", "failed", "error", "skipped", "none"})

# The project the Create tab makes assets in. Its assets are named after what they were made from, never
# after the project (which the single-asset rule below would otherwise do).
CREATED_PROJECT_NAME = "IsaacSim_AddOn"

UNGROUPED_PROJECT_ID = "__ungrouped__"
UNGROUPED_PROJECT_NAME = "Ungrouped"

# File stems Marso's pipeline gives its outputs ("generated", "edited", "01-image-1790784450831");
# as an asset name they say nothing.
_PLACEHOLDER_NAMES = {"generated", "edited"}
_PLACEHOLDER_PATTERN = re.compile(r"^\d+-image-\d+$")
# Any name with one of these words is treated as a placeholder ("image", "image 2", "generated_3").
_PLACEHOLDER_WORDS = re.compile(r"(^|[^a-z])(image|generated?|edited)([^a-z]|$)", re.IGNORECASE)


def is_placeholder_name(name: str) -> bool:
    """Whether a name is one of Marso's file-stem fallbacks rather than a real name."""
    name = (name or "").strip()
    return (not name or name.lower() in _PLACEHOLDER_NAMES or bool(_PLACEHOLDER_PATTERN.match(name))
            or bool(_PLACEHOLDER_WORDS.search(name)))


@dataclass(frozen=True)
class Asset:
    """One PBR asset as the library lists it (metadata only, no download URL)."""

    asset_id: str
    name: str
    project_id: str
    thumbnail_url: str = ""
    display_name: str = ""
    description: str = ""
    category: str = ""
    tags: tuple[str, ...] = ()
    model_version: str = ""
    enrichment: Enrichment | None = field(default=None, compare=False)  # Marso's description of the asset
    enriched_status: str = ""  # see SETTLED_ENRICHMENT

    @property
    def being_finished(self) -> bool:
        """Marso is still finishing this asset (only its basic USD exists): not shown yet."""
        return self.enriched_status.lower() not in SETTLED_ENRICHMENT

    @property
    def search_text(self) -> str:
        """Everything a search box should match against, lower-cased."""
        parts = [self.name, self.display_name, self.category, self.description, *self.tags,
                 self.enrichment.search_text if self.enrichment else ""]
        return " ".join(part for part in parts if part).lower()


@dataclass(frozen=True)
class Project:
    """A Marso project and the PBR assets it produced."""

    project_id: str
    name: str
    thumbnail_url: str = ""
    assets: tuple[Asset, ...] = ()
    unfinished: int = 0  # assets Marso is still finishing, left out of ``assets`` until they are done


@dataclass(frozen=True)
class Library:
    """The whole remote library: projects newest first, then the ungrouped pseudo-project."""

    projects: tuple[Project, ...] = ()
    _by_id: dict[str, Asset] = field(default_factory=dict, compare=False, repr=False)

    @property
    def unfinished(self) -> int:
        """Assets Marso is still finishing, across every project (shown once they are done)."""
        return sum(project.unfinished for project in self.projects)

    def __post_init__(self) -> None:
        # One asset can belong to several projects; the first (newest) project's entry wins.
        for project in self.projects:
            for asset in project.assets:
                self._by_id.setdefault(asset.asset_id, asset)

    def asset(self, asset_id: str) -> Asset | None:
        return self._by_id.get(asset_id)

    def project(self, project_id: str) -> Project | None:
        return next((project for project in self.projects if project.project_id == project_id), None)

    @property
    def assets(self) -> list[Asset]:
        """Every distinct asset once, in listing order (an asset in two projects appears once)."""
        return list(self._by_id.values())


@dataclass(frozen=True)
class DownloadFile:
    """One file of a resolved asset, with its short-lived presigned URL."""

    role: str
    download_url: str
    file_type: str = ""
    pass_name: str = ""
    size_bytes: int = 0


@dataclass(frozen=True)
class AssetDownload:
    """Every downloadable file for one asset id."""

    asset_id: str
    files: tuple[DownloadFile, ...]

    @property
    def usdz(self) -> DownloadFile | None:
        """The self-contained USDZ package (model plus textures), if the asset has one."""
        return next((item for item in self.files if item.role == USDZ_ROLE), None)


@dataclass(frozen=True)
class Account:
    user_id: str
    email: str


class ApiError(http.MarsoApiError):
    """The API answered, but not with something this client can use."""


def list_library(api_key: str, base_url: str) -> Library:
    """Walk every page of the grouped listing and return the whole library."""
    library = Library()
    for library in iter_library(api_key, base_url):
        pass
    return library


def iter_library(api_key: str, base_url: str) -> Iterator[Library]:
    """Yield the library as it grows, once per page; the last one yielded is complete.

    Presigned thumbnail URLs expire within about a minute, so a caller can
    fetch each page's thumbnails before asking for the next page.
    """
    projects: list[Project] = []
    ungrouped: list[Asset] = []
    cursor: str | None = None
    while True:
        payload = http.json_request("GET", _list_url(base_url, cursor), api_key=api_key)
        page_projects, page_ungrouped, cursor = parse_page(payload)
        projects.extend(page_projects)
        ungrouped.extend(page_ungrouped)
        loose = [Project(UNGROUPED_PROJECT_ID, UNGROUPED_PROJECT_NAME, "", tuple(ungrouped))] if ungrouped else []
        yield Library(tuple(projects + loose))
        if cursor is None:
            return


def find_project(api_key: str, base_url: str, project_id: str) -> Project | None:
    """One project with fresh thumbnail links: pages through the listing until it appears.

    The ungrouped pseudo-project gathers every page's ``ungrouped_assets``, so it needs the full walk.
    """
    ungrouped: list[Asset] = []
    cursor: str | None = None
    while True:
        payload = http.json_request("GET", _list_url(base_url, cursor), api_key=api_key)
        page_projects, page_ungrouped, cursor = parse_page(payload)
        ungrouped.extend(page_ungrouped)
        found = next((p for p in page_projects if p.project_id == project_id), None)
        if found is not None:
            return found
        if cursor is None:
            if project_id == UNGROUPED_PROJECT_ID and ungrouped:
                return Project(UNGROUPED_PROJECT_ID, UNGROUPED_PROJECT_NAME, "", tuple(ungrouped))
            return None


def parse_page(payload: dict[str, Any]) -> tuple[list[Project], list[Asset], str | None]:
    """Split one ``GET /assets`` page into projects, ungrouped assets and the next cursor."""
    projects = [_parse_project(raw) for raw in payload.get("data") or [] if isinstance(raw, dict)]
    ungrouped = [
        asset
        for asset in (_parse_asset(raw, UNGROUPED_PROJECT_ID) for raw in payload.get("ungrouped_assets") or [])
        if asset is not None and not asset.being_finished
    ]
    pagination = payload.get("pagination") if isinstance(payload.get("pagination"), dict) else {}
    next_cursor = pagination.get("next_cursor")
    if not pagination.get("has_more") or not isinstance(next_cursor, str) or not next_cursor:
        next_cursor = None
    return [project for project in projects if project.project_id], ungrouped, next_cursor


def request_downloads(
    api_key: str, base_url: str, asset_ids: Iterable[str]
) -> tuple[dict[str, AssetDownload], dict[str, str]]:
    """Resolve presigned URLs for asset ids. Returns (resolved, per-id error reasons)."""
    ids = list(dict.fromkeys(asset_ids))
    resolved: dict[str, AssetDownload] = {}
    errors: dict[str, str] = {}
    for offset in range(0, len(ids), DOWNLOAD_BATCH_LIMIT):
        batch = ids[offset : offset + DOWNLOAD_BATCH_LIMIT]
        payload = http.json_request("POST", f"{base_url.rstrip('/')}{DOWNLOAD_PATH}", api_key, {"asset_ids": batch})
        for raw in payload.get("assets") or []:
            item = _parse_download(raw)
            if item is not None:
                resolved[item.asset_id] = item
        for raw in payload.get("errors") or []:
            if isinstance(raw, dict) and raw.get("asset_id"):
                errors[str(raw["asset_id"])] = _download_error_reason(raw)
    for asset_id in ids:
        if asset_id not in resolved and asset_id not in errors:
            errors[asset_id] = "The API returned no download for this asset."
    return resolved, errors


def fetch_account(api_key: str, base_url: str) -> Account:
    """Identify the account the API key belongs to."""
    payload = http.json_request("GET", f"{base_url.rstrip('/')}{ACCOUNT_PATH}", api_key=api_key)
    user_id = str(payload.get("user_id") or "")
    if not user_id:
        raise ApiError("The account response had no user id.")
    return Account(user_id=user_id, email=str(payload.get("email") or ""))


def _list_url(base_url: str, cursor: str | None) -> str:
    query = {"type": "pbr", "group_by": "projects", "limit": str(PAGE_LIMIT)}
    if cursor:
        query["cursor"] = cursor
    return f"{base_url.rstrip('/')}{ASSETS_PATH}?{urllib.parse.urlencode(query)}"


def _parse_project(raw: dict[str, Any]) -> Project:
    project_id = str(raw.get("group_id") or "")
    project_name = str(raw.get("name") or "")
    entries = [entry for entry in _asset_entries(raw) if isinstance(entry, dict)]
    parsed = [(entry, asset) for entry, asset in ((e, _parse_asset(e, project_id)) for e in entries) if asset]
    finished = [(entry, asset) for entry, asset in parsed if not asset.being_finished]
    assets = tuple(asset for _entry, asset in finished)
    # The only asset of a project, still under a placeholder name, is best known by the project's.
    if (len(assets) == 1 and project_name and project_name != CREATED_PROJECT_NAME and not assets[0].display_name
            and _has_placeholder_name(finished[0][0])):
        assets = (replace(assets[0], name=project_name),)
    return Project(
        project_id=project_id,
        name=project_name or project_id,
        thumbnail_url=str(raw.get("thumbnail_url") or ""),
        assets=assets,
        unfinished=len(parsed) - len(finished),
    )


def _has_placeholder_name(raw: dict[str, Any]) -> bool:
    """Whether an asset's ``name`` is the API's fallback rather than a real name."""
    name = str(raw.get("name") or "")
    stem = PurePosixPath(str(raw.get("file_name") or "")).stem
    return not name or name == stem or is_placeholder_name(name)


def _asset_entries(raw: dict[str, Any]) -> Iterable[Any]:
    """Assets arrive as a list; tolerate a dict keyed by id as well."""
    assets = raw.get("assets")
    if isinstance(assets, list):
        return assets
    if isinstance(assets, dict):
        return [{"id": key, **value} for key, value in assets.items() if isinstance(value, dict)]
    return []


def _parse_asset(raw: Any, project_id: str) -> Asset | None:
    if not isinstance(raw, dict):
        return None
    asset_id = raw.get("id") or raw.get("asset_id")
    if not asset_id:
        return None
    # ``file_name`` is the SOURCE model's name ("generated.glb" for most), never a label.
    enrichment = raw.get("enrichment") if isinstance(raw.get("enrichment"), dict) else {}
    tags = enrichment.get("tags") if isinstance(enrichment.get("tags"), list) else []
    name = str(raw.get("name") or "")
    display_name = str(enrichment.get("display_name") or "")
    # Marso's enrichment display name is the name the library shows; the API's own name is only the
    # fallback (often a file stem like "generated" or "edited") while an asset has no display name yet.
    if display_name:
        name = display_name
    return Asset(
        asset_id=str(asset_id),
        name=name or str(asset_id),
        project_id=project_id,
        thumbnail_url=str(raw.get("thumbnail_url") or ""),
        display_name=str(enrichment.get("display_name") or ""),
        description=str(enrichment.get("description_short") or ""),
        category=str(enrichment.get("category") or ""),
        tags=tuple(str(tag) for tag in tags if tag),
        model_version=str(raw.get("model_version") or ""),
        enrichment=parse_enrichment(enrichment) if enrichment else None,
        enriched_status=str(raw.get("enriched_status") or ""),
    )


def _parse_download(raw: Any) -> AssetDownload | None:
    if not isinstance(raw, dict) or not raw.get("asset_id"):
        return None
    files = []
    for item in raw.get("files") or []:
        if not isinstance(item, dict) or not item.get("download_url") or not item.get("role"):
            continue
        files.append(
            DownloadFile(
                role=str(item["role"]),
                download_url=str(item["download_url"]),
                file_type=str(item.get("type") or ""),
                pass_name=str(item.get("pass") or ""),
                size_bytes=int(item.get("size_bytes") or 0),
            )
        )
    return AssetDownload(str(raw["asset_id"]), tuple(files)) if files else None


def _download_error_reason(raw: dict[str, Any]) -> str:
    code = str(raw.get("code") or "")
    if code == "ASSET_NOT_FOUND":
        return "This asset no longer exists in your Marso library."
    if code == "DOWNLOAD_URL_UNAVAILABLE":
        return "Marso could not create a download link right now. Try again."
    return str(raw.get("message") or code or "Unknown download error.")

# Changelog

## [0.2.1] - 2026-10-06

### Changed

- Tested with Isaac Sim 6.1.0 as well as 6.0.1.
- Assets are named by Marso's `enrichment.display_name` everywhere: the Library, the Downloaded tab,
  search, and the name of the prim added to the stage. The API's own name is used only until Marso
  has made a display name. Downloads made before pick up the display name on the next sync.

## [0.2.0] - 2026-10-04

### Added

- Agent connection: switch on **Connect to Marso Agents** in Settings and the agents you use with the
  Marso MCP (ChatGPT, Codex, Claude) can work in this Isaac Sim. They can put Marso assets on the
  stage (downloading them first, with physics prepared), see what is on it, and film assets in Sim
  Studio, with the video shown in the chat for a day. It uses the account's Marso API key and
  connects out to the Marso MCP; nothing listens on this computer. Off by default.
- What agents cannot do, checked here whatever the server sends: change settings, folders or the
  key, use the Create tab, delete downloads, open files, or pass any path. Videos sent to the chat
  are only ones Sim Studio made, up to 50 MB.

## [0.1.0] - 2026-10-02

### Added

- Library tab: browse your Marso projects and their PBR assets, with thumbnails, search, and a
  filter for downloaded or not-yet-downloaded assets.
- Each asset shows whether it is downloaded, queued, downloading (with progress) or failed.
- Download one asset, a selection, or everything missing in view. Downloads run in the background
  and can be cancelled.
- Add to Stage: adds assets to the open stage as USD references under the default prim, downloading
  them first when needed. Several assets added together are lined up in a row. Undoable.
- Each download gets a small wrapper layer (`isaacsim/<Name>.usda`) with a plain
  translate/rotate/scale root, so placed assets can be moved with the gizmo, viewport drops are
  named after the asset, and older Y-up packages stand upright.
- Drag a downloaded asset into the viewport to drop it where you point.
- Downloading more than 10 assets at once asks for confirmation first.
- Assets shown under the API's file-name fallback ("generated", "edited") use their descriptive
  name from Marso instead. An asset in several projects is listed once under All projects.
- Downloaded tab: everything on this computer, grouped by project, usable offline, including
  assets downloaded by the Marso Blender add-on into the same folder.
- Physics check for downloaded assets (rigid bodies, colliders, mass, physics materials, semantic
  labels). Tiles use Marso's Design Language badges: the PBR model glyph, the USD tag once
  downloaded, and the sim-ready glyph for assets with a rigid body and colliders.
- Sim Studio tab: film scale, drop, friction (tilting table), wind (with a wind sock) and collision
  tests of one asset or a group, rendered in a separate headless Isaac Sim. Output is branded (Marso
  Design Language, Geist type, results card, outro) and/or clean video, at up to 4K, in 16:9, 9:16,
  1:1 or 4:5. Each run also saves results cards, an editable scene per test and an HTML report.
- Library: no "All projects" view; a project's thumbnails download when it is opened. Select all,
  Deselect and a selected count in both browsers.
- Details panel and filters from Marso's enrichment (category, materials, physics, real-world size,
  aliases); search matches all of it.
- Names from the USD: an asset listed under a placeholder ("image", "generated", "edited") takes the
  name stored in its file (Marso's display name, else its semantic class) once downloaded.
- Mass from density: when an asset has a density, PhysX computes its mass and inertia from the
  collider instead of using the authored mass (current Marso exports author density x bounding-box
  volume). Done in the wrapper layer; downloaded files are not changed. Existing downloads update on
  the next launch.
- Updates: a download whose model version Marso has since changed shows an amber update badge;
  **Update all** in the bottom bar (or right-click > Update) fetches the newer versions. An **Updates
  available** filter lists them.
- Delete downloads (right-click > Delete Download..., or **Delete...** in the Downloaded tab), after a
  confirmation that names them, their size, and any that are in the open stage.
- Flags: a flag chip on tiles worth a look, from Marso's own review flags and the extension's file
  checks (size against Marso's description, hollow objects modelled solid, balls out of round) plus
  physics warnings. Listed under **Worth a look** in the details panel; a **Needs a look** filter.
- Favourites (a star on each tile and in the details panel) and **Recently used** (what you last
  added or tested) at the top of the Library's sidebar.
- Adding to the stage (Settings): add a ground and physics scene when the stage has none (on by
  default), lay several assets out in a row, a grid or a stack, and add assets as payloads.
- Sim Studio robot test: a Franka arm picks up each object it can hold and sets it down on a pad,
  with grasps planned from the asset's own surface and held by friction alone; the card reports the
  grip, slip, placement and why any object was not attempted (too heavy, too wide). Filmed split
  screen (close shot, wrist camera, top view) under studio softboxes, with the Marso logo on the
  robot's base; labels and split screen can be switched in its settings. Anything that slips or
  falls on the way is picked up again (up to three tries). Optional: drop the objects onto the table
  first, and try risky grips.
- Three more robot tests. **Robot: suction**: a UR10 with a suction cup lifts each object by a flat
  spot near its centre of mass (up to 10 kg, any width; it lets go past 120 N). **Robot: wide
  gripper**: a UR10e with a Robotiq 2F-140 holds objects up to 14 cm across and 11 kg. **Robot:
  handover**: two Frankas pass each object across the table: the first picks it up and turns it to
  offer it, the second takes it from the side around the first hand and sets it down. The whole
  handover is planned before the pick; objects no grip pair suits are left alone, and if the second
  hand misses, the first puts the object back. The robots download from NVIDIA's asset server the first time a test runs;
  without a connection the test stops and says so. Lights that come with a robot model are
  switched off so the studio lighting stays even.
- Robot: suction works when other tests run before it in the same run (it used to find no suction cup
  and report every object as slipped).
- Sim Studio test cards show a still of each test (a table tennis racket, or an everyday object the robot
  holds better, in the Marso look); click a still to pick its test. Each card's settings open and close under **Settings**, and
  cards no longer overlap when a test has many settings.
- **Robot: humanoid**: a Unitree G1 humanoid with Inspire five-finger hands stands at a table and
  picks up light objects (up to about 1.5 kg), each hand taking the objects on its side. It pinches
  between its thumb and two fingers; the grip is assisted (the fingers close on the object, then it moves
  with the hand while the pinch's friction could hold it), and the card says so.
- Sim Studio: assets modelled in a pose they cannot rest in are laid down first; the drop camera
  follows the objects down; the friction table is sized to its objects and measures from where they
  settle.
- **Create tab**: make a new asset from a description or your own picture: an image, then a 3D mesh
  with PBR materials, as in the Marso Blender add-on. New assets go in the **IsaacSim_AddOn** Marso
  project (made if missing) and enter the library only once Marso has minted their USD; they show
  under **Made in Isaac Sim**, pinned and marked in the Library, and optionally go straight onto the
  stage. Costs and your balance are shown before each step; runs carry on in the background and
  resume after a restart without paying twice; a failed step can be retried on its own.
- The Create tab shows the way an asset is made: a strip of the five steps (image, 3D mesh, PBR
  materials, finished by Marso, in your library) and a step tracker on each run, with the step under way
  breathing, finished steps turning green, a spinner and shimmer while Marso works, and the new image
  fading in. Its buttons and headings have icons.
- The Library leaves out assets Marso is still finishing (only their basic model exists yet) until they
  are finished, and says so on their project. A few minutes after a new asset arrives from the Create
  tab, the library syncs once by itself for its thumbnail and anything finished meanwhile.
- Settings tab: API key (or `MARSO_API_KEY`), downloads and cache folders, API endpoint.
